import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { consumeQuota } from '../../shared/quota.ts';

/**
 * Rédaction d'une lettre administrative belge (données déjà anonymisées côté client).
 * Le quota freemium "document_count" est décompté côté serveur avant l'appel au modèle.
 */
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const anonymized = body?.anonymized || {};
    const documentTypeLabel = String(body?.documentTypeLabel || 'Document administratif').slice(0, 120);
    const categoryLabel = String(body?.categoryLabel || 'Autre').slice(0, 120);
    const title = String(body?.title || '').slice(0, 200);
    const language = String(body?.language || 'fr').slice(0, 10);

    const quota = await consumeQuota(base44, user, 'document_count');
    if (!quota.allowed) {
      return Response.json({ error: 'Limite de documents atteinte pour votre formule.', quota }, { status: 429 });
    }

    const prompt = `
      Langue de réponse: ${language}.
      Génère une lettre administrative formelle pour la Belgique, en format texte brut.

      Type de document: ${documentTypeLabel}
      Catégorie: ${categoryLabel}
      Destinataire: ${anonymized.recipient}
      Objet: ${title}

      Informations de l'expéditeur (anonymisées):
      - Nom complet: ${anonymized.fullName}
      - Adresse: ${anonymized.address}
      - Email: ${anonymized.email}
      - Téléphone: ${anonymized.phone}

      Description détaillée de la situation et de la demande (anonymisée):
      ${anonymized.details}

      Instructions:
      1. Rédige une lettre formelle et complète en utilisant les informations anonymisées ci-dessus.
      2. Utilise les pseudonymes (ex: [PERSON_1], [EMAIL_1]) dans le corps du texte lorsque tu fais référence aux données.
      3. La lettre doit être prête à être envoyée. Ne mets pas de placeholders comme "[Votre Nom]".
    `;

    const content = await base44.asServiceRole.integrations.Core.InvokeLLM({ prompt });

    return Response.json({ content, quota });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}