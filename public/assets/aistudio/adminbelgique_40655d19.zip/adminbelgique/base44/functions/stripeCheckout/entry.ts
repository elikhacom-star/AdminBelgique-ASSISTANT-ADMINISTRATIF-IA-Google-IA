import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Stripe from 'npm:stripe@14.11.0';

Deno.serve(async (req) => {
  try {
    // 1. Vérifier la clé API Stripe
    const stripeKey = Deno.env.get('STRIPE_SECRET_KEY');
    if (!stripeKey || stripeKey === 'your_stripe_secret_key_here') {
      return Response.json({ 
        error: 'STRIPE_SECRET_KEY non configurée. Contactez elikaccesit@gmail.com pour activer les paiements.' 
      }, { status: 500 });
    }

    const stripe = new Stripe(stripeKey, {
      apiVersion: '2023-10-16',
    });

    // 2. Authentification utilisateur
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Non authentifié' }, { status: 401 });
    }

    // 3. Récupérer les paramètres
    const { plan, billing_period } = await req.json();
    
    if (!plan || !billing_period) {
      return Response.json({ 
        error: 'Paramètres manquants (plan et billing_period requis)' 
      }, { status: 400 });
    }

    // 4. Vérifier les IDs de prix Stripe
    const PRICE_IDS = {
      pro_monthly: Deno.env.get('STRIPE_PRICE_PRO_MONTHLY'),
      pro_yearly: Deno.env.get('STRIPE_PRICE_PRO_YEARLY'),
      cabinet_monthly: Deno.env.get('STRIPE_PRICE_CABINET_MONTHLY'),
      cabinet_yearly: Deno.env.get('STRIPE_PRICE_CABINET_YEARLY'),
    };

    const priceKey = `${plan}_${billing_period}`;
    const priceId = PRICE_IDS[priceKey];

    if (!priceId || priceId.startsWith('price_XXXXX')) {
      return Response.json({ 
        error: `ID de prix Stripe non configuré pour ${priceKey}. Les prix doivent être créés dans Stripe puis configurés dans les variables d'environnement.`,
        help: 'Contactez elikaccesit@gmail.com pour configurer les prix Stripe.'
      }, { status: 500 });
    }

    // 5. Déterminer l'URL de base de l'application de façon sécurisée
    //    (on ne fait jamais confiance à l'en-tête Origin fourni par le client,
    //     car un attaquant peut le falsifier pour rediriger vers un site de phishing)
    const APP_URL = Deno.env.get('APP_URL'); // ex: https://adminbelgique.com
    const ALLOWED_ORIGINS = [
      'https://adminbelgique.com',
      'https://www.adminbelgique.com',
      'http://localhost:5173',
      'http://localhost:8080',
    ];
    const originHeader = req.headers.get('origin');
    const baseUrl = APP_URL
      || (originHeader && ALLOWED_ORIGINS.includes(originHeader) ? originHeader : null);
    if (!baseUrl) {
      return Response.json({ 
        error: 'URL de l\'application non configurée (APP_URL). Contactez l\'administrateur.' 
      }, { status: 500 });
    }

    // 6. Créer la session Stripe Checkout
    const session = await stripe.checkout.sessions.create({
      customer_email: user.email,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${baseUrl}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${baseUrl}/pricing`,
      
      payment_method_types: [
        'card',
        'bancontact',
        'ideal',
        'sepa_debit',
      ],
      
      locale: 'fr',
      billing_address_collection: 'required',
      
      metadata: {
        user_email: user.email,
        plan: plan,
        billing_period: billing_period,
      },
    });

    return Response.json({ url: session.url });

  } catch (error) {
    console.error('Erreur Stripe complète:', error);
    
    // Messages d'erreur détaillés selon le type
    let userMessage = error.message;
    let helpMessage = '';

    if (error.type === 'StripeInvalidRequestError') {
      userMessage = 'Configuration Stripe invalide';
      helpMessage = 'Les clés API ou les IDs de prix Stripe sont incorrects.';
    } else if (error.type === 'StripeAuthenticationError') {
      userMessage = 'Authentification Stripe échouée';
      helpMessage = 'La clé API Stripe est invalide.';
    } else if (error.code === 'resource_missing') {
      userMessage = 'Produit ou prix Stripe introuvable';
      helpMessage = 'Le prix doit être créé dans le tableau de bord Stripe.';
    }

    return Response.json({ 
      error: userMessage,
      help: helpMessage,
      technical_details: error.message,
      contact: 'Pour activer les paiements, contactez elikaccesit@gmail.com ou +32 467 80 10 41'
    }, { status: 500 });
  }
});