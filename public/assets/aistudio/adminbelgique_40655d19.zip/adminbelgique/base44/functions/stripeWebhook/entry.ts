import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Stripe from 'npm:stripe@14.11.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'), {
  apiVersion: '2023-10-16',
});

Deno.serve(async (req) => {
  try {
    const signature = req.headers.get('stripe-signature');
    const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

    if (!signature || !webhookSecret) {
      return Response.json({ error: 'Missing signature or secret' }, { status: 400 });
    }

    const body = await req.text();
    let event;

    try {
      event = await stripe.webhooks.constructEventAsync(body, signature, webhookSecret);
    } catch (err) {
      console.error('Webhook signature verification failed:', err.message);
      return Response.json({ error: 'Invalid signature' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);

    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object;
        const userEmail = session.metadata.user_email;
        const plan = session.metadata.plan;

        await base44.asServiceRole.entities.Subscription.create({
          user_email: userEmail,
          plan: plan,
          stripe_customer_id: session.customer,
          stripe_subscription_id: session.subscription,
          status: 'active',
          current_period_start: new Date().toISOString(),
          current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
        });

        await base44.asServiceRole.entities.UsageLimit.update({
          user_email: userEmail
        }, {
          plan: plan
        });

        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object;
        await base44.asServiceRole.entities.Subscription.update({
          stripe_subscription_id: subscription.id
        }, {
          status: 'canceled',
          cancel_at_period_end: true
        });

        const sub = await base44.asServiceRole.entities.Subscription.filter({
          stripe_subscription_id: subscription.id
        });

        if (sub.length > 0) {
          await base44.asServiceRole.entities.UsageLimit.update({
            user_email: sub[0].user_email
          }, {
            plan: 'free'
          });
        }

        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object;
        await base44.asServiceRole.entities.Subscription.update({
          stripe_subscription_id: invoice.subscription
        }, {
          status: 'past_due'
        });
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return Response.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});