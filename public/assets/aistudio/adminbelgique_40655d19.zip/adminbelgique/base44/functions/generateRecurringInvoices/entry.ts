import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

/**
 * Émission des factures récurrentes.
 *
 * Deux modes :
 *  1. { planId } → émission immédiate demandée par l'utilisateur connecté (propriétaire de l'échéancier).
 *  2. Sans planId → passage quotidien automatique (workflow planifié) : toutes les échéances
 *     dont la date d'émission est atteinte sont facturées.
 *
 * Le mode automatique est idempotent : après émission, la prochaine date est repoussée dans le futur,
 * donc un même passage (ou un appel répété) ne peut jamais produire deux factures pour la même période.
 *
 * Le passage automatique est réservé au planificateur ou à un administrateur authentifié :
 * il n'est pas déclenchable par un visiteur anonyme.
 */

const FREQUENCY_MONTHS = {
  mensuelle: 1,
  trimestrielle: 3,
  semestrielle: 6,
  annuelle: 12,
};

const MAX_PLANS_PER_RUN = 200;

function todayInBrussels(): string {
  return new Date().toLocaleDateString('sv-SE', { timeZone: 'Europe/Brussels' });
}

function addMonths(dateStr: string, months: number): string {
  const parts = String(dateStr).split('-').map(Number);
  const year = parts[0];
  const month = parts[1];
  const day = parts[2];
  const base = new Date(Date.UTC(year, month - 1 + months, 1));
  const lastDay = new Date(Date.UTC(base.getUTCFullYear(), base.getUTCMonth() + 1, 0)).getUTCDate();
  const safeDay = Math.min(day, lastDay);
  return `${base.getUTCFullYear()}-${String(base.getUTCMonth() + 1).padStart(2, '0')}-${String(safeDay).padStart(2, '0')}`;
}

function addDays(dateStr: string, days: number): string {
  const parts = String(dateStr).split('-').map(Number);
  const base = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2] + days));
  return `${base.getUTCFullYear()}-${String(base.getUTCMonth() + 1).padStart(2, '0')}-${String(base.getUTCDate()).padStart(2, '0')}`;
}

function nextDueDate(fromDate: string, months: number): string {
  const today = todayInBrussels();
  let next = addMonths(fromDate, months);
  let guard = 0;
  while (next <= today && guard < 24) {
    next = addMonths(next, months);
    guard++;
  }
  return next;
}

function formatDateFr(dateStr: string): string {
  const parts = String(dateStr).split('-');
  if (parts.length !== 3) return String(dateStr);
  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

function money(value: number): string {
  return `${Number(value || 0).toFixed(2).replace('.', ',')} €`;
}

function round2(value: number): number {
  return Math.round((Number(value) || 0) * 100) / 100;
}

function buildContent(plan: any, data: any): string {
  const line = '-'.repeat(68);
  const rows: string[] = [];

  const senderLines: string[] = [];
  if (plan.sender_name) senderLines.push(String(plan.sender_name));
  if (plan.sender_details) {
    String(plan.sender_details)
      .split('\n')
      .forEach((entry: string) => {
        if (entry.trim()) senderLines.push(entry.trim());
      });
  }
  if (!senderLines.length && plan.owner_email) senderLines.push(String(plan.owner_email));

  const clientLines: string[] = [String(plan.client_name || '')];
  if (plan.client_address) clientLines.push(String(plan.client_address));
  if (plan.client_vat) clientLines.push(`TVA / BCE : ${plan.client_vat}`);
  if (plan.client_email) clientLines.push(String(plan.client_email));

  rows.push(`FACTURE ${data.invoiceNumber}`);
  rows.push('');
  rows.push(line);
  rows.push(`Date d'emission : ${formatDateFr(data.issueDate)}`);
  rows.push(`Date d'echeance : ${formatDateFr(data.dueDate)}`);
  rows.push(`Delai de paiement : ${data.terms} jours`);
  rows.push(line);
  rows.push('');
  rows.push('EMETTEUR');
  senderLines.forEach((entry) => rows.push(entry));
  rows.push('');
  rows.push('CLIENT');
  clientLines.forEach((entry) => rows.push(entry));
  rows.push('');
  rows.push(line);
  rows.push(
    'Description'.padEnd(36) + 'Qte'.padStart(6) + 'P.U. HT'.padStart(13) + 'Total HT'.padStart(13)
  );
  rows.push(line);
  rows.push(
    String(plan.description || 'Prestation').slice(0, 36).padEnd(36) +
      String(data.quantity).padStart(6) +
      money(data.unitPrice).padStart(13) +
      money(data.exclVat).padStart(13)
  );
  rows.push(line);
  rows.push('');
  rows.push(`Total HT : ${money(data.exclVat)}`);
  rows.push(`TVA ${data.vatRate} % : ${money(data.vat)}`);
  rows.push(`TOTAL A PAYER : ${money(data.inclVat)}`);
  rows.push('');
  rows.push(`Paiement a effectuer dans les ${data.terms} jours suivant la date d'emission.`);
  rows.push('Tout retard de paiement entraine de plein droit des interets de retard legaux.');
  if (plan.notes) {
    rows.push('');
    rows.push(`Mentions : ${plan.notes}`);
  }
  rows.push('');
  rows.push("Document genere automatiquement, a verifier avant envoi.");

  return rows.join('\n');
}

async function createInvoiceForPlan(svcClient: any, plan: any, today: string) {
  const months = FREQUENCY_MONTHS[plan.frequency] || 1;
  const issueDate = plan.next_issue_date && plan.next_issue_date <= today ? plan.next_issue_date : today;

  const quantity = Number(plan.quantity) > 0 ? Number(plan.quantity) : 1;
  const unitPrice = round2(Number(plan.unit_price) || 0);
  const vatRate = Number.isFinite(Number(plan.vat_rate)) ? Number(plan.vat_rate) : 21;
  const exclVat = round2(quantity * unitPrice);
  const vat = round2((exclVat * vatRate) / 100);
  const inclVat = round2(exclVat + vat);

  const terms = Number.isFinite(Number(plan.payment_terms_days)) ? Number(plan.payment_terms_days) : 30;
  const dueDate = addDays(issueDate, terms);

  const sequence = (Number(plan.generated_count) || 0) + 1;
  const reference = String(plan.id || '')
    .replace(/[^a-zA-Z0-9]/g, '')
    .slice(-4)
    .toUpperCase();
  const invoiceNumber = `FAC-${issueDate.slice(0, 4)}${issueDate.slice(5, 7)}-${reference || '0000'}-${String(sequence).padStart(3, '0')}`;

  const content = buildContent(plan, {
    invoiceNumber,
    issueDate,
    dueDate,
    terms,
    quantity,
    unitPrice,
    vatRate,
    exclVat,
    vat,
    inclVat,
  });

  // 🔒 Réclamation atomique de l'échéance : la date est repoussée AVANT la création de la facture,
  // et uniquement si la valeur lue est encore celle en base (mise à jour conditionnelle).
  // Deux appels concurrents ne peuvent donc pas émettre deux factures pour la même période.
  const claimQuery: any = { id: plan.id };
  if (plan.next_issue_date) claimQuery.next_issue_date = plan.next_issue_date;

  const claim = await svcClient.entities.RecurringInvoice.updateMany(claimQuery, {
    $set: {
      next_issue_date: nextDueDate(issueDate, months),
      last_generated_date: issueDate,
      generated_count: sequence,
    },
  });
  if (!claim || claim.updated !== 1) return null;

  try {
    return await svcClient.entities.Invoice.create({
      invoice_number: invoiceNumber,
      plan_id: plan.id,
      client_name: plan.client_name,
      client_email: plan.client_email || '',
      client_address: plan.client_address || '',
      client_vat: plan.client_vat || '',
      description: plan.description,
      quantity,
      unit_price: unitPrice,
      vat_rate: vatRate,
      amount_excl_vat: exclVat,
      vat_amount: vat,
      amount_incl_vat: inclVat,
      issue_date: issueDate,
      due_date: dueDate,
      status: 'emise',
      content,
      owner_email: plan.owner_email || plan.created_by || '',
      notes: plan.notes || '',
    });
  } catch (error) {
    // Réclamation annulée : la période reste à facturer au prochain passage.
    await svcClient.entities.RecurringInvoice.update(plan.id, {
      next_issue_date: plan.next_issue_date || issueDate,
      last_generated_date: plan.last_generated_date || null,
      generated_count: Number(plan.generated_count) || 0,
    });
    throw error;
  }
}

export default async function (req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const planId = body && body.planId ? String(body.planId) : null;
    const today = todayInBrussels();
    const svc = base44.asServiceRole;

    if (planId) {
      const user = await base44.auth.me();
      if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

      const plan = await svc.entities.RecurringInvoice.get(planId);
      const isOwner = plan && (plan.created_by_id === user.id || plan.owner_email === user.email);
      if (!plan || (!isOwner && user.role !== 'admin')) {
        return Response.json({ error: 'Échéancier introuvable.' }, { status: 404 });
      }

      const invoice = await createInvoiceForPlan(svc, plan, today);
      if (!invoice) {
        // Un autre appel a déjà émis cette échéance.
        return Response.json({ generated_count: 0, invoices: [], date: today });
      }
      return Response.json({ generated_count: 1, invoices: [invoice.invoice_number], date: today });
    }

    // 🔒 Le passage automatique facture TOUS les utilisateurs via le service role : il exige donc
    // un administrateur authentifié (déclenchement planifié de la plateforme ou admin connecté).
    let caller: any = null;
    try {
      caller = await base44.auth.me();
    } catch (_) {
      caller = null;
    }
    if (!caller) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (caller.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const found = await svc.entities.RecurringInvoice.filter(
      { active: true, next_issue_date: { $lte: today } },
      { sort: 'next_issue_date', limit: MAX_PLANS_PER_RUN }
    );
    const plans = Array.isArray(found) ? found : found && Array.isArray(found.items) ? found.items : [];

    const issued: string[] = [];
    for (const plan of plans) {
      const invoice = await createInvoiceForPlan(svc, plan, today);
      if (invoice) issued.push(invoice.invoice_number);
    }

    return Response.json({ generated_count: issued.length, invoices: issued, date: today });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}