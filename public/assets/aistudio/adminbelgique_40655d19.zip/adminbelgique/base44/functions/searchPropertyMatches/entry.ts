import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { consumeQuota } from '../../shared/quota.ts';

/**
 * Recherche de biens correspondant STRICTEMENT aux critères d'un client immobilier (ImmoBoost).
 * Seules les annonces dont le lien direct est exploitable et dont les informations clés
 * proviennent d'une source consultable sont renvoyées. Les critères ne sont jamais élargis
 * automatiquement et aucune annonce n'est inventée.
 * Le quota freemium "immo_search_count" est décompté côté serveur avant l'appel au modèle.
 */

const NON_LISTING_URL_PATTERNS = [
  /google\./i,
  /bing\./i,
  /duckduckgo\./i,
  /\/search/i,
  /\/recherche/i,
  /\/zoeken/i,
  /\?q=/i,
  /\?query=/i
];

const hasText = (value) => {
  if (typeof value !== 'string') return false;
  const trimmed = value.trim();
  return trimmed !== '' && !/^(n\/?a|non communiqué|-)$/i.test(trimmed);
};

const isDirectListingUrl = (url) => {
  if (!hasText(url)) return false;
  let parsed;
  try {
    parsed = new URL(url.trim());
  } catch {
    return false;
  }
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return false;
  return !NON_LISTING_URL_PATTERNS.some((pattern) => pattern.test(url));
};

const portalFromUrl = (url) => {
  try {
    const host = new URL(url.trim()).hostname.replace(/^www\./, '');
    const label = host.split('.')[0];
    return label ? label.charAt(0).toUpperCase() + label.slice(1) : null;
  } catch {
    return null;
  }
};

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const criteria = body?.criteria || {};
    const transactionLabel = criteria.transaction_type === 'location' ? 'à louer' : 'à vendre';

    const quota = await consumeQuota(base44, user, 'immo_search_count');
    if (!quota.allowed) {
      return Response.json({ error: 'Limite de recherches atteinte pour votre formule.', quota }, { status: 429 });
    }

    const prompt = `
      Tu es un assistant immobilier spécialisé sur le marché belge.

      Critères STRICTS du client :
      - Type de bien : ${criteria.property_type || 'non spécifié'}
      - Transaction : ${transactionLabel}
      - Zone recherchée : ${criteria.location || 'Belgique'}
      - Budget maximum : ${criteria.max_budget ? criteria.max_budget + ' EUR' : 'non précisé'}
      - Chambres minimum : ${criteria.min_bedrooms || 'non précisé'}

      Mission : retrouver des annonces RÉELLES, actuellement en ligne sur des portails immobiliers
      belges (Immoweb, Zimmo, Logic-Immo, Vlan, Heylen, Immoscoop, Realo, Immovlan...).

      Règles impératives :
      1. Chaque annonce doit avoir l'URL DIRECTE de sa page détail sur le portail. Jamais une page de
         recherche, jamais un lien Google/Bing, jamais une URL construite par toi.
      2. N'invente rien : ni annonce, ni prix, ni adresse, ni surface, ni coordonnées GPS. Si une
         information n'est pas visible sur l'annonce, laisse le champ vide ou mets "N/A".
      3. Respecte STRICTEMENT les critères : n'inclus aucun bien qui dépasse le budget maximum ou qui
         ne correspond pas au type, à la transaction, à la zone ou au nombre de chambres minimum.
         N'élargis jamais la zone ni le budget de ta propre initiative.
      4. Indique pour chaque annonce le nom du portail dans le champ source et, si elle est visible sur
         l'annonce, la date de mise en ligne dans published_date.
      5. Renvoie toutes les annonces strictement conformes que tu trouves (0 à 10). S'il n'y en a aucune,
         renvoie une liste vide et explique brièvement pourquoi dans no_results_reason. Ne complète
         jamais avec des biens approximatifs ni des suggestions.
      6. Si c'est une vente, estime un loyer mensuel réaliste (estimated_rent_num) pour calculer la
         rentabilité.
      7. Extrait la date de contrôle depuis la page consultée et laisse verified_at vide, il est calculé
         côté serveur.
    `;

    const jsonSchema = {
      type: "object",
      properties: {
        properties: {
          type: "array",
          items: {
            type: "object",
            properties: {
              title: { type: "string" },
              price: { type: "string" },
              price_num: { type: "number", description: "Prix exact en chiffres uniquement, e.g. 250000" },
              location: { type: "string" },
              lat: { type: "number", description: "Latitude approximative issue de l'adresse de l'annonce" },
              lng: { type: "number", description: "Longitude approximative issue de l'adresse de l'annonce" },
              estimated_rent_num: { type: "number", description: "Pour une vente, loyer mensuel estimé en EUR. 0 sinon." },
              summary: { type: "string" },
              url: { type: "string", description: "URL directe de la page détail de l'annonce sur le portail" },
              source: { type: "string", description: "Nom du portail (Immoweb, Zimmo, Logic-Immo...)" },
              published_date: { type: "string", description: "Date de mise en ligne si visible sur l'annonce" },
              bedrooms: { type: "string" },
              surface: { type: "string" },
              features: { type: "string" },
              correspondence_score: { type: "string" },
              match_analysis: { type: "string", description: "Pourquoi cette annonce respecte strictement les critères" }
            },
            required: ["title", "location", "url", "source"]
          }
        },
        no_results_reason: { type: "string", description: "Expliqué uniquement si aucune annonce conforme n'a été trouvée" }
      }
    };

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: jsonSchema
    });

    const checkedAt = new Date().toISOString();
    const candidates = (result && Array.isArray(result.properties)) ? result.properties : [];
    const properties = [];
    let discardedCount = 0;

    for (const candidate of candidates) {
      const url = hasText(candidate?.url) ? candidate.url.trim() : '';
      const source = hasText(candidate?.source) ? candidate.source.trim() : portalFromUrl(url);
      const verifiable = isDirectListingUrl(url) && !!source && hasText(candidate?.title) && hasText(candidate?.location);

      if (!verifiable) {
        discardedCount += 1;
        continue;
      }

      const confirmedFields = [];
      const missingFields = [];
      const record = (label, available) => {
        if (available) confirmedFields.push(label);
        else missingFields.push(label);
      };

      record('prix', Number(candidate?.price_num) > 0 || hasText(candidate?.price));
      record('chambres', hasText(candidate?.bedrooms));
      record('surface', hasText(candidate?.surface));
      record('adresse', hasText(candidate?.location));

      properties.push({
        ...candidate,
        url,
        source,
        verified: true,
        verified_at: checkedAt,
        confirmed_fields: confirmedFields,
        missing_fields: missingFields
      });
    }

    const noResultsReason = properties.length === 0
      ? (hasText(result?.no_results_reason)
        ? result.no_results_reason
        : 'Aucune annonce avec lien direct vérifiable ne correspond strictement aux critères fournis.')
      : null;

    return Response.json({
      properties,
      strict_matches: properties.length,
      discarded_count: discardedCount,
      no_results_reason: noResultsReason,
      quota
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}