// This function serves the PWA manifest file.
// It ensures the correct Content-Type header is sent.
Deno.serve((req) => {
  const manifest = {
    "name": "AdminBelgique Assistant Administratif IA",
    "short_name": "AdminBE",
    "description": "Votre assistant administratif IA pour la Belgique. Rapide, sécurisé et maintenant disponible hors ligne.",
    "start_url": "/",
    "display": "standalone",
    "background_color": "#F9FAFB",
    "theme_color": "#FBBF24",
    "orientation": "portrait-primary",
    "icons": [
      {
        "src": "https://www.w3.org/TR/appmanifest/images/icon-192x192.png",
        "type": "image/png",
        "sizes": "192x192",
        "purpose": "any maskable"
      },
      {
        "src": "https://www.w3.org/TR/appmanifest/images/icon-512x512.png",
        "type": "image/png",
        "sizes": "512x512",
        "purpose": "any maskable"
      }
    ]
  };

  return new Response(JSON.stringify(manifest), {
    headers: { "Content-Type": "application/manifest+json" },
    status: 200,
  });
});