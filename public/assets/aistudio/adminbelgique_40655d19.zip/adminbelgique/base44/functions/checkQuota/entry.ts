import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { getQuotaStatus, isQuotaFeature } from '../../shared/quota.ts';

/**
 * État du quota freemium d'un utilisateur (lecture seule, autorité serveur).
 * Utilisé par l'interface pour afficher les compteurs et le mur payant.
 */
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    let feature = null;
    try {
      const body = await req.json();
      feature = body?.feature;
    } catch (e) {
      feature = null;
    }

    if (!isQuotaFeature(feature)) {
      return Response.json({ error: 'Fonctionnalité inconnue' }, { status: 400 });
    }

    const status = await getQuotaStatus(base44, user, feature);
    return Response.json(status);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}