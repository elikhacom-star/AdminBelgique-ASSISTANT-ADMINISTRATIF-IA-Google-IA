import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { consumeEmailSend, isPrivileged } from '../../shared/quota.ts';
import { isValidEmail, normalizeEmail } from '../../shared/html.ts';

const MAX_MESSAGE_LENGTH = 600;
const MAX_DOCUMENT_LENGTH = 20000;
const MAX_KNOWN_CLIENTS = 200;

/**
 * Envoi d'un document administratif par email.
 * Le contenu de l'email est composé côté serveur à partir du document enregistré
 * (jamais depuis le navigateur), le destinataire est contrôlé et les envois sont limités.
 */
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const documentId = body?.documentId;
    const clientId = body?.clientId ? String(body.clientId) : null;
    const recipient = normalizeEmail(body?.to);

    if (!documentId) return Response.json({ error: 'Document requis' }, { status: 400 });
    if (!isValidEmail(recipient)) return Response.json({ error: 'Adresse email invalide' }, { status: 400 });

    let document = null;
    try {
      document = await base44.entities.Document.get(documentId);
    } catch (e) {
      document = null;
    }
    if (!document) return Response.json({ error: 'Document introuvable' }, { status: 404 });

    const sharedWith = Array.isArray(document.shared_with) ? document.shared_with : [];
    const canAccess =
      isPrivileged(user) ||
      document.created_by_id === user.id ||
      sharedWith.map(normalizeEmail).includes(normalizeEmail(user.email));
    if (!canAccess) return Response.json({ error: 'Accès refusé à ce document' }, { status: 403 });

    const rawClients = await base44.entities.Client.filter({}, '-created_date', MAX_KNOWN_CLIENTS);
    const knownClients = Array.isArray(rawClients) ? rawClients : [];

    // ─── Contrôle du destinataire côté serveur (anti-relais de spam) ───
    if (!isPrivileged(user)) {
      const allowed = new Set([normalizeEmail(user.email)]);
      sharedWith.forEach((email) => allowed.add(normalizeEmail(email)));
      if (isValidEmail(document.recipient)) allowed.add(normalizeEmail(document.recipient));

      knownClients.forEach((client) => {
        if (isValidEmail(client.email)) allowed.add(normalizeEmail(client.email));
      });

      if (!allowed.has(recipient)) {
        return Response.json({
          error: "Destinataire non autorisé. Enregistrez cette adresse sur la fiche du document (champ Destinataire) ou dans vos clients avant l'envoi."
        }, { status: 403 });
      }
    }

    const emailQuota = await consumeEmailSend(base44, user);
    if (!emailQuota.allowed) {
      return Response.json({
        error: `Trop d'emails envoyés. Réessayez dans ${emailQuota.retryAfterMinutes} minute(s).`
      }, { status: 429 });
    }

    // ─── Composition serveur : aucun contenu arbitraire depuis le navigateur ───
    const documentTitle = String(document.title || 'Document').slice(0, 150);
    const subject = String(body?.subject || `Document administratif : ${documentTitle}`)
      .replace(/[\r\n]+/g, ' ')
      .slice(0, 150);
    const intro = String(body?.message || 'Veuillez trouver ci-dessous le document demandé.')
      .slice(0, MAX_MESSAGE_LENGTH);
    const documentContent = String(document.content || '').slice(0, MAX_DOCUMENT_LENGTH);

    const emailBody = `${intro}\n\n═══════════════════\n\n${documentContent}\n\n═══════════════════\n\nDocument envoyé via AdminBelgique 🇧🇪`;

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: recipient,
      subject,
      body: emailBody,
      from_name: 'Agent Admin Belgique'
    });

    // ─── Consignation dans l'historique d'activités du ou des clients concernés ───
    const matchingClients = knownClients.filter(
      (c) => (clientId && c.id === clientId) || (isValidEmail(c.email) && normalizeEmail(c.email) === recipient)
    );
    const activityEntry = {
      type: 'document',
      channel: 'email',
      title: documentTitle,
      details: `Envoyé par email (${recipient})`,
      date: new Date().toISOString()
    };
    await Promise.allSettled(
      matchingClients.map((client) => {
        const existing = Array.isArray(client.activity_history) ? client.activity_history : [];
        return base44.entities.Client.update(client.id, {
          activity_history: [activityEntry, ...existing].slice(0, 100)
        });
      })
    );

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}