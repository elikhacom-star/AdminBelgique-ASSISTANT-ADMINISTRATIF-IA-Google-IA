import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { consumeEmailSend, isPrivileged } from '../../shared/quota.ts';
import { isValidEmail, normalizeEmail, sanitizeEmailHtml } from '../../shared/html.ts';

// ─── SSRF PROTECTION ───────────────────────────────────────────
const ALLOWED_IMAGE_DOMAINS = [
  'images.unsplash.com',
  'immoweb.be',
  'zimmo.be',
  'logic-immo.be',
  'immovlan.be',
  'adminbelgique.com',
  'base44.com',
  'cdn.base44.com'
];

function validateImageUrl(url) {
  try {
    const parsed = new URL(url);
    return ALLOWED_IMAGE_DOMAINS.some(d =>
      parsed.hostname === d || parsed.hostname.endsWith('.' + d)
    );
  } catch {
    return false;
  }
}

function sanitizeHtmlContent(html) {
  if (!html) return '';
  // 🔒 Assainissement complet du HTML contrôlé par l'appelant avant tout
  // traitement : suppression des scripts, cadres, formulaires, gestionnaires
  // d'événements et URLs actives (le filtrage des images se fait ensuite).
  const cleaned = sanitizeEmailHtml(html);
  const imgRegex = /<img[^>]+src=["']([^"']+)["']/gi;
  return cleaned.replace(imgRegex, (match, url) => {
    if (validateImageUrl(url)) return match;
    return '<!-- Image bloquée : protection SSRF -->';
  });
}

// ─── ÉVASION HTML ──────────────────────────────────────────────
// Empêche l'injection de balises HTML/script dans les champs fournis
// par l'utilisateur (propertyData) lorsqu'ils sont interpolés dans le
// modèle HTML de l'email. Le contenu marketing reste du HTML assaini
// (sanitizeHtmlContent), mais les champs structurés sont du texte brut.
function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ─── TEMPLATE EMAIL TRILINGUE ──────────────────────────────────
function buildTrilingualEmail(propertyData, marketingContent) {
  const p = propertyData || {};
  // 🔒 Tous les champs de propertyData sont échappés avant interpolation
  // pour empêcher l'injection HTML/script (CWE-79).
  const title = escapeHtml(p.title || 'Bien immobilier');
  const location = escapeHtml(p.location || 'Belgique');
  const price = escapeHtml(p.price || 'N/A');
  const surface = escapeHtml(p.surface || 'N/A');
  const bedrooms = escapeHtml(p.bedrooms || 'N/A');
  const safeContent = sanitizeHtmlContent(marketingContent);

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;font-family:Arial,Helvetica,sans-serif;background:#f4f4f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f5;padding:20px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
          <tr>
            <td style="background:linear-gradient(135deg,#1e3a5f,#2563eb);padding:24px 32px;">
              <h1 style="margin:0;color:#ffffff;font-size:22px;font-weight:bold;">🏡 Dossier Marketing ImmoBoost AI</h1>
              <p style="margin:4px 0 0;color:#bfdbfe;font-size:13px;">${title} — ${location}</p>
            </td>
          </tr>
          <tr>
            <td style="padding:20px 32px;border-bottom:1px solid #e5e7eb;">
              <table width="100%" cellpadding="4" cellspacing="0">
                <tr>
                  <td style="color:#6b7280;font-size:12px;">💰 Prix</td>
                  <td style="color:#111827;font-size:14px;font-weight:bold;">${price}</td>
                  <td style="color:#6b7280;font-size:12px;">📐 Surface</td>
                  <td style="color:#111827;font-size:14px;font-weight:bold;">${surface}</td>
                </tr>
                <tr>
                  <td style="color:#6b7280;font-size:12px;">🛏️ Chambres</td>
                  <td style="color:#111827;font-size:14px;font-weight:bold;">${bedrooms}</td>
                  <td style="color:#6b7280;font-size:12px;">📍 Localisation</td>
                  <td style="color:#111827;font-size:14px;font-weight:bold;">${location}</td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td style="padding:24px 32px;">
              ${safeContent.replace(/\n/g, '<br>')}
            </td>
          </tr>
          <tr>
            <td style="background:#f9fafb;padding:16px 32px;border-top:1px solid #e5e7eb;">
              <p style="margin:0;color:#6b7280;font-size:11px;text-align:center;">
                Dossier généré par ImmoBoost AI — AdminBelgique.com 🇧🇪<br>
                Service privé d'assistance administrative. Non affilié à une entité gouvernementale.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

// ─── RESEND FALLBACK (sécurisé) ────────────────────────────────
async function sendViaResend(to, subject, html) {
  const apiKey = Deno.env.get('RESEND_API_KEY');
  if (!apiKey) {
    throw new Error('RESEND_API_KEY non configuré — impossible d\'envoyer aux destinataires externes.');
  }

  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      from: 'ImmoBoost AI <noreply@adminbelgique.com>',
      to: [to],
      subject,
      html
    })
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Resend API error (${response.status}): ${errorText}`);
  }

  return await response.json();
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { to, propertyData, marketingContent } = body;

    if (!to || !marketingContent) {
      return Response.json({ error: 'Destinataire (to) et contenu marketing requis' }, { status: 400 });
    }

    if (!isValidEmail(to)) {
      return Response.json({ error: 'Adresse email invalide' }, { status: 400 });
    }

    const recipient = normalizeEmail(to);

    // ─── 🔒 CONTRÔLE D'ACCÈS AU DESTINATAIRE (anti-relais) ───────
    // Un administrateur peut écrire à n'importe quelle adresse ; un
    // utilisateur ne peut écrire qu'à lui-même ou à un client de son
    // propre portefeuille, vérifié côté serveur.
    if (!isPrivileged(user)) {
      let isAllowedRecipient = normalizeEmail(user.email) === recipient;
      if (!isAllowedRecipient) {
        const clients = await base44.entities.Client.filter({}, '-created_date', 200);
        const clientEmails = new Set(
          (Array.isArray(clients) ? clients : [])
            .filter((client) => isValidEmail(client.email))
            .map((client) => normalizeEmail(client.email))
        );
        isAllowedRecipient = clientEmails.has(recipient);
      }
      if (!isAllowedRecipient) {
        console.warn(`Envoi marketing refusé vers un destinataire non autorisé (${user.email})`);
        return Response.json({
          error: "Destinataire non autorisé : seuls vos propres clients peuvent recevoir un dossier marketing."
        }, { status: 403 });
      }
    }

    // ─── 🔒 QUOTA ANTI-SPAM ─────────────────────────────────────
    const emailQuota = await consumeEmailSend(base44, user);
    if (!emailQuota.allowed) {
      return Response.json({
        error: `Trop d'emails envoyés. Réessayez dans ${emailQuota.retryAfterMinutes} minute(s).`
      }, { status: 429 });
    }

    const emailHtml = buildTrilingualEmail(propertyData, marketingContent);
    // 🔒 Le titre est échappé pour éviter toute injection dans l'objet du mail.
    const safeSubjectTitle = escapeHtml(propertyData?.title || 'Bien immobilier');
    const subject = `🏡 Dossier Marketing — ${safeSubjectTitle} — ImmoBoost AI`;

    try {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: recipient,
        subject,
        body: emailHtml
      });

      return Response.json({
        success: true,
        message: 'Dossier marketing envoyé (utilisateur enregistré)'
      });

    } catch (sendEmailError) {
      const isExternalRecipient =
        sendEmailError.message &&
        sendEmailError.message.includes('outside the app');

      if (!isExternalRecipient) throw sendEmailError;

      // ─── 🔒 CONTRÔLE D’ACCÈS : admin, superadmin, email_external ───
      const role = user.role || 'user';

      // 🔒 Seuls les vrais administrateurs peuvent envoyer vers des destinataires externes.
      // Le rôle personnalisé 'email_external' est volontairement exclu pour éviter
      // qu'un utilisateur non-admin puisse contourner la restriction et utiliser
      // l'application comme relais vers des adresses arbitraires.
      const isAuthorizedExternalSender =
        role === 'admin' ||
        role === 'superadmin';

      if (!isAuthorizedExternalSender) {
        console.warn(`Tentative non autorisée d'envoi externe par ${user.email}`);
        return Response.json({
          error: 'Envoi vers des destinataires externes réservé aux administrateurs ou aux utilisateurs autorisés.',
          status: 403
        }, { status: 403 });
      }

      await sendViaResend(recipient, subject, emailHtml);

      return Response.json({
        success: true,
        message: 'Dossier marketing envoyé (Resend — autorisé)'
      });
    }

  } catch (error) {
    return Response.json({
      error: error.message || 'Erreur lors de l\'envoi'
    }, { status: 500 });
  }
}