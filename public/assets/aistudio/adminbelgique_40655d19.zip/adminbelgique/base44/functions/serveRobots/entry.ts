/**
 * 🤖 Fonction pour servir le fichier robots.txt
 * URL: /api/serveRobots
 */

Deno.serve((req) => {
  const robotsTxt = `# robots.txt optimisé pour AdminBelgique.com
# Dernière mise à jour : 2026-08-04

User-agent: *
Allow: /

# ✅ AUTORISER Stripe (paiements)
Allow: /v3

# ❌ BLOQUER pages techniques/admin
Disallow: /admin/
Disallow: /dashboard/
Disallow: /ConfigurationGuide
Disallow: /SEODiagnostic
Disallow: /SEOValidation
Disallow: /Redirections301Guide
Disallow: /SearchConsoleGuide
Disallow: /WhatsAppSetup
Disallow: /AccessManagement
Disallow: /ActionsPrioritaires

# Bloquer fichiers système
Disallow: /api/internal/
Disallow: /*.json$

# ✅ Sitemap
Sitemap: https://app.adminbelgique.com/functions/serveSitemap

# ✅ Google Search Console
User-agent: Googlebot
Allow: /
Allow: /*.js
Allow: /*.css
Disallow: /admin/
Disallow: /dashboard/
Disallow: /ConfigurationGuide
Disallow: /SEODiagnostic
Disallow: /SEOValidation
Disallow: /Redirections301Guide
Disallow: /SearchConsoleGuide
Disallow: /WhatsAppSetup
Disallow: /AccessManagement

# Bing
User-agent: Bingbot
Allow: /
Allow: /*.js
Allow: /*.css
Disallow: /admin/
Disallow: /dashboard/
Disallow: /ConfigurationGuide

# Autres bots légitimes
User-agent: Slurp
Allow: /
Disallow: /admin/

User-agent: DuckDuckBot
Allow: /
Disallow: /admin/

# Bloquer bots scraping agressifs
User-agent: AhrefsBot
Crawl-delay: 10

User-agent: SemrushBot
Crawl-delay: 10

User-agent: MJ12bot
Disallow: /

User-agent: dotbot
Disallow: /`;

  return new Response(robotsTxt, {
    status: 200,
    headers: {
      'Content-Type': 'text/plain',
      'Cache-Control': 'public, max-age=86400'
    }
  });
});
