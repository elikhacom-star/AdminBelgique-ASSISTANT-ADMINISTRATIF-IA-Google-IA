import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import { secrets } from 'base44:runtime';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    // 🔒 Two authorized access modes:
    //   1. Scheduled task (cron) with a valid shared secret
    //   2. Authenticated administrator (base44.auth.me() + role === 'admin')
    const CRON_SECRET = secrets.get('CRON_SECRET');
    const providedSecret = req.headers.get('x-cron-secret');
    const isCronCall = CRON_SECRET && providedSecret && providedSecret === CRON_SECRET;

    let isAdminCall = false;
    if (!isCronCall) {
      // No valid cron call → require an authenticated admin
      let user;
      try {
        user = await base44.auth.me();
      } catch (_) {
        user = null;
      }
      if (!user || user.role !== 'admin') {
        console.error('❌ Accès refusé : ni secret cron valide, ni administrateur authentifié');
        return Response.json({ error: 'Unauthorized' }, { status: 401 });
      }
      isAdminCall = true;
    }

    const AGENT_NAME = "admin_belge";
    const ARCHIVE_THRESHOLD_DAYS = 60;

    const thresholdDate = new Date();
    thresholdDate.setDate(thresholdDate.getDate() - ARCHIVE_THRESHOLD_DAYS);

    const conversations = await base44.asServiceRole.agents.listConversations({
      agent_name: AGENT_NAME
    });

    let archivedCount = 0;

    for (const conv of conversations) {
      if (conv.metadata?.archived) continue;

      const updatedAt = new Date(conv.updated_date || conv.created_date);

      if (updatedAt < thresholdDate) {
        await base44.asServiceRole.agents.updateConversation(conv.id, {
          metadata: {
            ...conv.metadata,
            archived: true,
            auto_archived_date: new Date().toISOString()
          }
        });
        archivedCount++;
      }
    }

    return Response.json({
      success: true,
      message: `${archivedCount} conversations archivées automatiquement (inactives depuis ${ARCHIVE_THRESHOLD_DAYS} jours).`,
      archived_count: archivedCount,
      triggered_by: isCronCall ? 'cron' : 'admin'
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}