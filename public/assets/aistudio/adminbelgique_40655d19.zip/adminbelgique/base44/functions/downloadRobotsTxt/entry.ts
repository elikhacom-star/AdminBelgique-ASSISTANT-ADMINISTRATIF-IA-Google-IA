/**
 * 📥 Génère un fichier robots.txt téléchargeable
 * URL: /api/downloadRobotsTxt
 */

export default async function(req) {
  const robotsTxt = `# robots.txt optimisé pour AdminBelgique.com
# Dernière mise à jour : 2026-08-04

User-agent: *
Allow: /

# ✅ AUTORISER Stripe (paiements)
Allow: /v3

# Bloquer admin/dashboard
Disallow: /admin/
Disallow: /dashboard/api/

# Bloquer fichiers système
Disallow: /api/internal/
Disallow: /*.json$

# ✅ Sitemap
Sitemap: https://app.adminbelgique.com/api/serveSitemap

# ✅ Google Search Console
User-agent: Googlebot

Allow: /
Allow: /*.js
Allow: /*.css

# Bing
User-agent: Bingbot
Allow: /
Allow: /*.js
Allow: /*.css

# Autres bots légitimes
User-agent: Slurp
Allow: /

User-agent: DuckDuckBot
Allow: /

# Bloquer bots scraping agressifs
User-agent: AhrefsBot
Crawl-delay: 10

User-agent: SemrushBot
Crawl-delay: 10

User-agent: MJ12bot
Disallow: /

User-agent: dotbot
Disallow: /`;

  return new Response(robotsTxt, {
    status: 200,
    headers: {
      'Content-Type': 'text/plain',
      'Content-Disposition': 'attachment; filename="robots.txt"',
      'Cache-Control': 'no-cache'
    }
  });
} 