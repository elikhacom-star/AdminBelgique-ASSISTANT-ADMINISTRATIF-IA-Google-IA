import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

/**
 * 🤖 WhatsApp Business Webhook
 * Reçoit les messages WhatsApp et répond avec l'agent IA AdminBelgique
 * 
 * Documentation Meta : https://developers.facebook.com/docs/whatsapp/cloud-api/webhooks
 */

Deno.serve(async (req) => {
  // 🚫 WEBHOOK DÉSACTIVÉ — le compte Meta WhatsApp d'origine a été supprimé.
  // Tant que l'App Secret et les nouveaux tokens ne sont pas reconfigurés,
  // aucune requête n'est traitée pour éviter tout abus (spam, usurpation).
  return Response.json({ error: 'WhatsApp webhook disabled — reconfiguration required' }, { status: 503 });
});

/* === Ancien code désactivé (à réactiver après reconfiguration Meta) ===
Deno.serve(async (req) => {
  try {
    // ✅ ÉTAPE 1 : Vérification du webhook (GET)
    if (req.method === 'GET') {
      const url = new URL(req.url);
      const mode = url.searchParams.get('hub.mode');
      const token = url.searchParams.get('hub.verify_token');
      const challenge = url.searchParams.get('hub.challenge');
      
      const VERIFY_TOKEN = Deno.env.get('WHATSAPP_VERIFY_TOKEN');
      if (!VERIFY_TOKEN) {
        console.error('❌ WHATSAPP_VERIFY_TOKEN non configuré');
        return Response.json({ error: 'Verification token not configured' }, { status: 503 });
      }
      
      if (mode === 'subscribe' && token === VERIFY_TOKEN) {
        console.log('✅ Webhook vérifié avec succès !');
        return new Response(challenge, { 
          status: 200,
          headers: { 'Content-Type': 'text/plain' }
        });
      } else {
        console.error('❌ Vérification webhook échouée');
        return Response.json({ error: 'Verification failed' }, { status: 403 });
      }
    }
    
    // 🔥 ÉTAPE 2 : Traiter les messages entrants (POST)
    if (req.method === 'POST') {
      // 🔒 Vérification de la signature HMAC-SHA256 (X-Hub-Signature-256) envoyée par Meta
      const APP_SECRET = Deno.env.get('WHATSAPP_APP_SECRET');
      const rawBody = await req.text();

      if (APP_SECRET) {
        const signatureHeader = req.headers.get('X-Hub-Signature-256') || '';
        const expectedSignature = await hmacSha256Hex(APP_SECRET, rawBody);
        if (!signatureHeader.startsWith('sha256=') || !await secureCompare(signatureHeader.slice(7), expectedSignature)) {
          console.error('❌ Signature HMAC invalide — requête rejetée');
          return Response.json({ error: 'Invalid signature' }, { status: 401 });
        }
      } else {
        console.warn('⚠️ WHATSAPP_APP_SECRET non configuré — webhook non protégé contre l\'usurpation');
      }

      const body = JSON.parse(rawBody);
      console.log('📩 Webhook reçu:', JSON.stringify(body, null, 2));
      
      // Extraire les messages
      const entry = body.entry?.[0];
      const changes = entry?.changes?.[0];
      const value = changes?.value;
      const messages = value?.messages;
      
      if (!messages || messages.length === 0) {
        console.log('ℹ️ Pas de nouveau message');
        return Response.json({ status: 'no_message' });
      }
      
      const message = messages[0];
      const from = message.from; // Numéro de l'utilisateur
      const messageText = message.text?.body || '';
      
      console.log(`💬 Message de ${from}: "${messageText}"`);
      
      // 🤖 ÉTAPE 3 : Traiter avec l'agent IA AdminBelgique (MÊME AGENT QUE LE CHAT)
      const base44 = createClientFromRequest(req);
      
      try {
        // 🔥 IMPORTANT : Utiliser le MÊME nom d'agent que dans Chat.jsx
        const AGENT_NAME = "admin_belge";
        
        // Créer ou récupérer une conversation WhatsApp pour cet utilisateur
        let conversation;
        
        try {
          // Essayer de récupérer la conversation existante
          const conversations = await base44.asServiceRole.agents.listConversations({
            agent_name: AGENT_NAME
          });
          
          conversation = conversations.find(c => 
            c.metadata?.whatsapp_number === from || 
            c.metadata?.platform === 'whatsapp' && c.metadata?.user_phone === from
          );
          
          if (!conversation) {
            // Créer une nouvelle conversation avec métadonnées WhatsApp
            conversation = await base44.asServiceRole.agents.createConversation({
              agent_name: AGENT_NAME,
              metadata: {
                whatsapp_number: from,
                platform: 'whatsapp',
                created_at: new Date().toISOString(),
                user_name: value?.contacts?.[0]?.profile?.name || 'Utilisateur WhatsApp'
              }
            });
            console.log(`✅ Nouvelle conversation créée: ${conversation.id}`);
            
            // 🎉 Message de bienvenue automatique (première fois seulement)
            const welcomeMessage = `👋 Bonjour ! Je suis votre assistant administratif IA pour la Belgique.

🇧🇪 Je peux vous aider avec :
• Questions SPF Finances, INAMI, ONEM
• Génération de lettres administratives
• Analyse de documents officiels
• Suivi de vos démarches

💬 Posez-moi votre question en français, néerlandais ou allemand !`;
            
            await sendWhatsAppMessage(from, welcomeMessage);
          }
        } catch (convError) {
          console.error('❌ Erreur conversation:', convError);
          throw convError;
        }
        
        // Ajouter le message de l'utilisateur à la conversation
        await base44.asServiceRole.agents.addMessage(conversation, {
          role: 'user',
          content: messageText
        });
        
        // Récupérer les messages mis à jour (incluant la réponse de l'IA)
        const updatedConversation = await base44.asServiceRole.agents.getConversation(conversation.id);
        const lastMessage = updatedConversation.messages[updatedConversation.messages.length - 1];
        
        if (lastMessage.role === 'assistant') {
          const aiResponse = lastMessage.content;
          
          // 📤 ÉTAPE 4 : Envoyer la réponse sur WhatsApp
          await sendWhatsAppMessage(from, aiResponse);
          
          console.log(`✅ Réponse envoyée à ${from}`);
        }
        
      } catch (aiError) {
        console.error('❌ Erreur agent IA:', aiError);
        
        // Message d'erreur convivial
        await sendWhatsAppMessage(
          from, 
          "Désolé, une erreur est survenue. Notre équipe technique a été notifiée. 🔧\n\nMerci de réessayer dans quelques instants ou contactez-nous :\n📧 elikaccesit@gmail.com\n📞 +32 467 80 10 41"
        );
      }
      
      // Confirmer la réception à Meta
      return Response.json({ status: 'received' });
    }
    
    return Response.json({ error: 'Méthode non supportée' }, { status: 405 });
    
  } catch (error) {
    console.error('💥 Erreur webhook:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
=== Fin de l'ancien code désactivé === */

/**
 * 🔐 Calculer le HMAC-SHA256 d'un message avec une clé, retourné en hexadécminuscules
 */
async function hmacSha256Hex(key: string, message: string): Promise<string> {
  const enc = new TextEncoder();
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    enc.encode(key),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const signature = await crypto.subtle.sign('HMAC', cryptoKey, enc.encode(message));
  return Array.from(new Uint8Array(signature)).map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * 🔒 Comparaison en temps constant pour éviter les attaques par timing
 */
async function secureCompare(a: string, b: string): Promise<boolean> {
  const enc = new TextEncoder();
  const aBytes = enc.encode(a);
  const bBytes = enc.encode(b);
  if (aBytes.length !== bBytes.length) return false;
  let diff = 0;
  for (let i = 0; i < aBytes.length; i++) {
    diff |= aBytes[i] ^ bBytes[i];
  }
  return diff === 0;
}

/**
 * 📤 Envoyer un message WhatsApp
 */
async function sendWhatsAppMessage(to, text) {
  const token = Deno.env.get('WHATSAPP_TOKEN');
  const phoneNumberId = Deno.env.get('WHATSAPP_PHONE_NUMBER_ID');
  
  if (!token || !phoneNumberId) {
    throw new Error('WHATSAPP_TOKEN ou WHATSAPP_PHONE_NUMBER_ID non configurés');
  }
  
  const url = `https://graph.facebook.com/v18.0/${phoneNumberId}/messages`;
  
  // Limiter à 4096 caractères (limite WhatsApp)
  let finalText = text;
  if (text.length > 4096) {
    finalText = text.substring(0, 4090) + "\n\n[...]";
  }
  
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      messaging_product: 'whatsapp',
      to: to,
      type: 'text',
      text: {
        preview_url: true, // Active les aperçus de liens
        body: finalText
      }
    })
  });
  
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Erreur envoi WhatsApp: ${error}`);
  }
  
  return await response.json();
}