import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

/**
 * Recherche en direct de biens comparables sur les portails immobiliers belges.
 *
 * C'est le remplaçant réel du "web_search" que le prompt de real_estate_assistant
 * demandait mais qui n'existe pas comme tool sur Base44. Cette fonction fait un vrai
 * fetch() côté serveur (Deno) vers Immoweb/Zimmo, et extrait les données structurées
 * en priorité via JSON-LD (schema.org), avec un fallback HTML si le JSON-LD est absent.
 *
 * Payload attendu (typiquement la sortie de refineSearchCriteria.refined) :
 * {
 *   propertyType: "maison" | "appartement" | "terrain" | "commerce",
 *   transaction: "a-vendre" | "a-louer",
 *   postalCode?: string,      // code postal belge à 4 chiffres
 *   cityName?: string,        // nom de commune si pas de code postal
 *   maxPrice?: number,
 *   minBedrooms?: number,
 *   limit?: number            // défaut 12
 * }
 *
 * Réponse :
 * {
 *   comparables: [{ address, price, surface, pricePerM2, bedrooms, epb, url, source }],
 *   count: number,
 *   sources_attempted: string[],
 *   sources_blocked: string[],   // sources qui ont probablement un mur anti-bot (Cloudflare, 403...)
 *   errors: string[],
 *   partial: boolean             // true si on n'a pas atteint le nombre demandé
 * }
 *
 * ⚠️ IMPORTANT : cette fonction ne fabrique JAMAIS de données. Si une source est
 * bloquée ou ne renvoie rien d'exploitable, elle est listée dans sources_blocked /
 * errors et n'apparaît simplement pas dans comparables — à charge de l'agent IA
 * de le dire honnêtement à l'utilisateur plutôt que d'inventer un tableau plausible.
 */

const REALISTIC_HEADERS = {
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Accept':
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
  'Accept-Language': 'fr-BE,fr;q=0.9,nl-BE;q=0.7,en;q=0.5',
  'Cache-Control': 'no-cache',
  'Pragma': 'no-cache',
};

const CLOUDFLARE_MARKERS = [
  'just a moment',
  'checking your browser',
  'attention required',
  'cf-browser-verification',
  'cf-chl',
];

function isLikelyBlocked(status, html) {
  if (status === 403 || status === 429 || status === 503) return true;
  const lower = (html || '').slice(0, 3000).toLowerCase();
  return CLOUDFLARE_MARKERS.some((marker) => lower.includes(marker));
}

function slugifyCity(cityName) {
  if (!cityName) return '';
  return cityName
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

function buildImmowebUrl(params) {
  const transactionPath = params.transaction === 'a-louer' ? 'a-louer' : 'a-vendre';
  const typePath =
    { maison: 'maison', appartement: 'appartement', terrain: 'terrain', commerce: 'bien-commercial' }[
      params.propertyType
    ] || 'maison';
  const locationPart = params.postalCode
    ? `${params.postalCode}`
    : slugifyCity(params.cityName) || 'belgique';

  const search = new URLSearchParams();
  if (params.maxPrice) search.set('maxPrice', String(params.maxPrice));
  if (params.minBedrooms) search.set('minBedroomCount', String(params.minBedrooms));
  search.set('page', '1');
  search.set('orderBy', 'relevance');

  return `https://www.immoweb.be/fr/recherche/${typePath}/${transactionPath}/${locationPart}?${search.toString()}`;
}

function buildZimmoUrl(params) {
  const transactionPath = params.transaction === 'a-louer' ? 'te-huur' : 'te-koop';
  const typePath = { maison: 'huis', appartement: 'appartement', terrain: 'grond', commerce: 'handelspand' }[
    params.propertyType
  ] || 'huis';
  const locationPart = params.postalCode || slugifyCity(params.cityName) || '';

  const search = new URLSearchParams();
  if (params.maxPrice) search.set('prijs-tot', String(params.maxPrice));

  return `https://www.zimmo.be/nl/${locationPart ? locationPart + '/' : ''}${typePath}/${transactionPath}/?${search.toString()}`;
}

async function fetchPage(url) {
  const res = await fetch(url, { headers: REALISTIC_HEADERS, redirect: 'follow' });
  const html = await res.text();
  return { status: res.status, html };
}

// Extrait tous les blocs <script type="application/ld+json">...</script> et
// tente d'y trouver des objets de type RealEstateListing / Offer / Product.
function extractJsonLdListings(html, sourceName) {
  const listings = [];
  const scriptRegex = /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  let match;
  while ((match = scriptRegex.exec(html)) !== null) {
    let parsed;
    try {
      parsed = JSON.parse(match[1].trim());
    } catch {
      continue; // JSON-LD mal formé, on ignore ce bloc plutôt que de planter
    }
    const nodes = Array.isArray(parsed) ? parsed : [parsed];
    for (const node of nodes) {
      const graph = node['@graph'] ? node['@graph'] : [node];
      for (const item of graph) {
        const type = (item['@type'] || '').toString().toLowerCase();
        if (
          type.includes('realestatelisting') ||
          type.includes('residence') ||
          type.includes('product') ||
          type.includes('offer')
        ) {
          const offers = item.offers || item;
          const price = offers?.price || item.price;
          const address = item.address
            ? [item.address.streetAddress, item.address.postalCode, item.address.addressLocality]
                .filter(Boolean)
                .join(', ')
            : item.name || null;
          if (price || address) {
            listings.push({
              address: address || 'Adresse non précisée',
              price: price ? Number(price) : null,
              surface: item.floorSize?.value ? Number(item.floorSize.value) : null,
              bedrooms: item.numberOfBedrooms ? Number(item.numberOfBedrooms) : null,
              epb: null,
              url: item.url || null,
              source: sourceName,
            });
          }
        }
      }
    }
  }
  return listings;
}

// Fallback best-effort si aucun JSON-LD n'est présent : repère des cartes
// d'annonce via des motifs de classes/attributs courants. Moins fiable —
// ne renvoie que ce qui est extrait avec une confiance raisonnable.
function extractFallbackListings(html, sourceName) {
  const listings = [];
  const priceRegex = /(\d{2,3}(?:[.\s]\d{3}){1,2})\s*€/g;
  const linkRegex = /<a[^>]+href=["']([^"']*(?:classified|listing|annonce|advert)[^"']*)["']/gi;

  const urls = new Set();
  let m;
  while ((m = linkRegex.exec(html)) !== null && urls.size < 20) {
    urls.add(m[1].startsWith('http') ? m[1] : undefined);
  }

  // Sans structure fiable, on ne fabrique pas de fausses lignes : on renvoie
  // seulement une trace que la page a été lue, pour transparence côté agent.
  if (urls.size === 0) return listings;
  return listings; // volontairement vide — voir note dans le README de la fonction
}

function computeDerivedFields(listings) {
  return listings
    .filter((l) => l.price)
    .map((l) => ({
      ...l,
      pricePerM2: l.surface ? Math.round(l.price / l.surface) : null,
    }));
}

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const params = {
      propertyType: body?.propertyType || 'maison',
      transaction: body?.transaction || 'a-vendre',
      postalCode: body?.postalCode || null,
      cityName: body?.cityName || null,
      maxPrice: body?.maxPrice || null,
      minBedrooms: body?.minBedrooms || null,
      limit: Math.min(body?.limit || 12, 20),
    };

    if (!params.postalCode && !params.cityName) {
      return Response.json(
        { error: 'postalCode ou cityName requis pour lancer une recherche.' },
        { status: 400 }
      );
    }

    const sourcesToTry = [
      { name: 'Immoweb', url: buildImmowebUrl(params) },
      { name: 'Zimmo', url: buildZimmoUrl(params) },
    ];

    const comparables = [];
    const sourcesAttempted = [];
    const sourcesBlocked = [];
    const errors = [];

    for (const source of sourcesToTry) {
      if (comparables.length >= params.limit) break;
      sourcesAttempted.push(source.name);
      try {
        const { status, html } = await fetchPage(source.url);

        if (isLikelyBlocked(status, html)) {
          sourcesBlocked.push(source.name);
          continue;
        }
        if (status >= 400) {
          errors.push(`${source.name}: HTTP ${status}`);
          continue;
        }

        let listings = extractJsonLdListings(html, source.name);
        if (listings.length === 0) {
          listings = extractFallbackListings(html, source.name);
        }
        comparables.push(...listings);
      } catch (err) {
        errors.push(`${source.name}: ${err.message}`);
      }
    }

    const finalComparables = computeDerivedFields(comparables).slice(0, params.limit);

    return Response.json({
      comparables: finalComparables,
      count: finalComparables.length,
      sources_attempted: sourcesAttempted,
      sources_blocked: sourcesBlocked,
      errors,
      partial: finalComparables.length < params.limit,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}