import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { isPrivileged } from '../../shared/quota.ts';

const ARTICLE_SCHEMA = {
  type: 'object',
  properties: {
    title: { type: 'string', description: 'Titre H1 accrocheur incluant le mot-clé' },
    slug: { type: 'string', description: 'URL slug en kebab-case, 3-5 mots' },
    excerpt: { type: 'string', description: 'Résumé de 150-200 caractères' },
    category: { type: 'string', description: 'Catégorie éditoriale courte' },
    meta_title: { type: 'string' },
    meta_description: { type: 'string' },
    keywords: { type: 'array', items: { type: 'string' } },
    read_time: { type: 'string', description: 'Temps de lecture, ex: 8 min' },
    image_alt: { type: 'string' },
    content: { type: 'string', description: 'Article complet en Markdown, sans le titre H1' },
    faq: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          question: { type: 'string' },
          answer: { type: 'string' }
        },
        required: ['question', 'answer']
      }
    }
  },
  required: ['title', 'slug', 'excerpt', 'category', 'meta_title', 'meta_description', 'content', 'faq']
};

function buildArticlePrompt(mainKeyword, extraBrief = '') {
  return `Tu es un expert SEO et rédacteur web B2B spécialisé dans le marché belge. Tu écris en français belge, ton professionnel mais accessible.

MISSION : Créer un article de blog SEO complet pour AdminBelgique (https://adminbelgique.com), plateforme SaaS d'assistant IA pour PME belges qui automatise les démarches administratives (RGPD, données en Belgique).

PARAMÈTRES SEO OBLIGATOIRES :
- Article de 1500-2000 mots
- Mot-clé principal : "${mainKeyword}"
- 3-5 mots-clés secondaires LSI
- Structure hiérarchique H2/H3 en Markdown (le H1 est le champ "title", ne le répète pas dans le contenu)
- Densité mot-clé naturelle : 1-2%, jamais de keyword stuffing
- Meta title : 50-60 caractères, incluant le mot-clé
- Meta description : 150-160 caractères, incluant le mot-clé + un appel à l'action
- Slug : kebab-case, 3-5 mots max, incluant le mot-clé
- 2-3 références à des sources officielles belges (SPF Finances, ONSS, BCE, Statbel, APD, MyMinfin)
- FAQ de 4 à 5 questions que les Belges se posent réellement

STRUCTURE ATTENDUE DU CONTENU MARKDOWN :
1. Introduction (100-150 mots) : accroche sur le problème, promesse de l'article, mot-clé dans le premier paragraphe
2. ## Contexte / le problème (200-300 mots) : chiffres belges, cadre légal
3. ## Solution étape par étape (600-800 mots) : 4-6 sous-sections ###, étapes concrètes et actionnables, exemples belges réels, tableau si pertinent
4. ## Outils et ressources utiles (200-300 mots) : 5-8 outils et portails officiels belges
5. ## Conclusion + CTA AdminBelgique (150-200 mots) : récap et appel à l'action vers AdminBelgique

TONALITÉ :
- Vouvoiement, professionnel mais jamais robotique
- Exemples concrets belges (Bruxelles, Liège, Anvers, Gand, Namur), montants en EUR, prénoms belges
- Phrases courtes, listes à puces pour la scannabilité, pas de jargon corporate
- Optimise pour les featured snippets (réponses courtes, listes, tableaux)
- Mets en avant le côté "Made in Belgium" et la conformité RGPD
${extraBrief ? `\nCONSIGNES SUPPLÉMENTAIRES DE L'ÉDITEUR :\n${extraBrief}\n` : ''}
Réponds uniquement avec la structure JSON demandée.`;
}

/** Génération d'un article de blog SEO (réservé aux administrateurs). */
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (!isPrivileged(user)) return Response.json({ error: 'Forbidden' }, { status: 403 });

    const body = await req.json();
    const keyword = String(body?.keyword || '').slice(0, 200);
    const brief = String(body?.brief || '').slice(0, 2000);
    if (!keyword.trim()) return Response.json({ error: 'Mot-clé requis' }, { status: 400 });

    const article = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: buildArticlePrompt(keyword, brief),
      add_context_from_internet: true,
      model: 'gemini_3_1_pro',
      response_json_schema: ARTICLE_SCHEMA
    });

    return Response.json({ article });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}