import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

/**
 * Affinage IA des critères de recherche client → paramètres URL structurés
 * Permet de "traduire" des critères vagues ("petit budget", "centre ville")
 * en paramètres précis (maxPrice=250000, postalCodes=1000)
 *
 * Payload: { criteria: { transaction_type, property_type, location, min_bedrooms, max_budget, notes } }
 * Response: { refined: { propertyType, transaction, postalCode, cityName, maxPrice, minBedrooms, radiusKm, confidence, reasoning } }
 */
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const criteria = body?.criteria || {};

    const transactionLabel = criteria.transaction_type === 'location' ? 'à louer' : 'à vendre';

    const prompt = `
Tu es un expert immobilier belge. Convertis les critères de recherche suivants en paramètres d'URL structurés pour les portails immobiliers belges (Immoweb, Zimmo, etc.).

Critères du client :
- Type de transaction : ${transactionLabel}
- Type de bien : ${criteria.property_type || 'non spécifié'}
- Localisation : ${criteria.location || 'Belgique'}
- Budget max : ${criteria.max_budget ? criteria.max_budget + ' EUR' : 'flexible'}
- Chambres min : ${criteria.min_bedrooms || 'non spécifié'}
- Notes libres : ${criteria.notes || 'aucune'}

Règles :
1. Détecte le code postal belge (4 chiffres) dans la localisation. Si absent, mets null.
2. Si le budget est "flexible" ou non précisé, déduis un budget raisonnable selon le type de bien et la région (ex: appartement à Bruxelles → 250000-400000 EUR).
3. Si "petit budget" est mentionné dans les notes, réduis le budget de 20%.
4. Si "grand" ou "spacieux" est mentionné, augmente minBedrooms.
5. Déduis un rayon de recherche (radiusKm) : 5km pour une ville précise, 15km pour une région, 30km pour "Belgique" seul.
6. Confidence : ton niveau de certitude (0-100%) sur la qualité de la traduction.

Réponds UNIQUEMENT en JSON selon le schéma demandé.
`;

    const jsonSchema = {
      type: "object",
      properties: {
        propertyType: { type: "string", description: "maison | appartement | terrain | commerce" },
        transaction: { type: "string", description: "a-vendre | a-louer" },
        postalCode: { type: "string", description: "Code postal 4 chiffres ou null" },
        cityName: { type: "string", description: "Nom de la ville nettoyé" },
        maxPrice: { type: "number", description: "Budget max déduit en EUR" },
        minBedrooms: { type: "number", description: "Chambres min déduites" },
        radiusKm: { type: "number", description: "Rayon de recherche en km" },
        confidence: { type: "number", description: "Niveau de certitude 0-100" },
        reasoning: { type: "string", description: "Explication courte des déductions" }
      },
      required: ["propertyType", "transaction", "maxPrice", "minBedrooms", "radiusKm", "confidence"]
    };

    const response = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: jsonSchema
    });

    return Response.json({ refined: response });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}