import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { isPrivileged } from '../../shared/quota.ts';

/** Génération de l'image de couverture d'un article de blog (réservé aux administrateurs). */
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (!isPrivileged(user)) return Response.json({ error: 'Forbidden' }, { status: 403 });

    const body = await req.json();
    const imageAlt = String(body?.imageAlt || '').slice(0, 500);
    if (!imageAlt.trim()) return Response.json({ error: "Description de l'image requise" }, { status: 400 });

    const result = await base44.asServiceRole.integrations.Core.GenerateImage({
      prompt: `Photorealistic professional editorial photograph: ${imageAlt}. Realistic, high resolution, natural lighting, serious and professional tone, no cartoon, no illustration, no drawing, suitable for a Belgian administrative blog article cover.`
    });

    return Response.json({ url: result?.url || '' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}