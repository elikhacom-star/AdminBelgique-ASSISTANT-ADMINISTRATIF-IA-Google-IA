import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

/**
 * Compteur public de documents générés.
 * Renvoie uniquement un nombre (aucune donnée personnelle, aucun titre de document),
 * afin d'être affichable sur la page d'accueil sans connexion.
 */
const CACHE_TTL_MS = 60000;
let cachedCount = 0;
let cachedAt = 0;

export default async function (req: Request): Promise<Response> {
  try {
    const now = Date.now();
    if (cachedAt && now - cachedAt < CACHE_TTL_MS) {
      return Response.json({ count: cachedCount });
    }

    const base44 = createClientFromRequest(req);
    const total = await base44.asServiceRole.entities.Document.count({});

    cachedCount = Number(total) || 0;
    cachedAt = now;

    return Response.json({ count: cachedCount });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}