import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { consumeQuota } from '../../shared/quota.ts';

/**
 * Réponse IA à une question administrative belge (question déjà anonymisée côté client).
 * Le quota freemium est décompté côté serveur avant l'appel au modèle.
 */
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const anonymizedQuestion = String(body?.anonymizedQuestion || '').slice(0, 4000);
    const categoryLabel = String(body?.categoryLabel || 'général').slice(0, 100);
    const languageName = String(body?.languageName || 'Français').slice(0, 40);

    if (!anonymizedQuestion.trim()) {
      return Response.json({ error: 'Question requise' }, { status: 400 });
    }

    const quota = await consumeQuota(base44, user, 'research_count');
    if (!quota.allowed) {
      return Response.json({ error: 'Limite de questions atteinte pour votre formule.', quota }, { status: 429 });
    }

    const prompt = `Tu es un agent administratif virtuel spécialisé pour la Belgique. 
      IMPORTANT: Tu DOIS répondre en ${languageName}.
      
      Réponds de manière professionnelle, claire et accessible à cette question administrative belge :
      
      Catégorie: ${categoryLabel}
      Question (anonymisée): ${anonymizedQuestion}
      
      Donne une réponse pratique et structurée EN ${languageName} avec :
      - Les étapes à suivre
      - Les documents nécessaires  
      - Les délais à respecter
      - Les liens vers les organismes officiels belges concernés
      
      Rappelle que c'est de l'information générale et qu'il faut consulter un professionnel pour des cas complexes.
      Utilise les pseudonymes (ex: [NN_1], [EMAIL_1]) dans ta réponse lorsque tu te réfères aux données anonymisées.`;

    const response = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true
    });

    return Response.json({ response, quota });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}