import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { consumeQuota } from '../../shared/quota.ts';

/**
 * Étape 2 de l'analyse de document : analyse IA du contenu déjà anonymisé côté client.
 * Le quota freemium "analysis_count" est décompté ici, côté serveur, avant l'appel au modèle.
 */
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const anonymizedContent = String(body?.anonymizedContent || '').slice(0, 30000);
    if (!anonymizedContent.trim()) {
      return Response.json({ error: 'Contenu à analyser requis' }, { status: 400 });
    }

    const quota = await consumeQuota(base44, user, 'analysis_count');
    if (!quota.allowed) {
      return Response.json({ error: "Limite d'analyses atteinte pour votre formule.", quota }, { status: 429 });
    }

    const prompt = `Tu es un expert en administration belge. Analyse ce document et fournis:

1. **Résumé**: Résume en 2-3 phrases ce dont il s'agit.
2. **Analyse de complétude & Incohérences**: Identifie s'il manque des informations cruciales, des signatures, des dates, ou s'il y a des incohérences manifestes dans le document (ex: dates contradictoires, montants bizarres).
3. **Actions recommandées**: Que doit faire l'utilisateur concrètement suite à ce document?
4. **Formulaires & Procédures suggérés**: Suggère précisément les formulaires administratifs ou les procédures officielles belges à suivre.
5. **Délais importants**: Y a-t-il des échéances strictes à respecter?
6. **Organismes à contacter**: Quelles administrations ou services contacter si nécessaire?
7. **Conseils pratiques**: Conseils spécifiques pour optimiser le traitement du dossier.

Document analysé (anonymisé): ${anonymizedContent}

Réponds en français, de manière claire et actionnable. Formate ta réponse en Markdown pour une lecture facile. Utilise les pseudonymes dans ta réponse.`;

    const analysis = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true
    });

    return Response.json({ analysis, quota });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}