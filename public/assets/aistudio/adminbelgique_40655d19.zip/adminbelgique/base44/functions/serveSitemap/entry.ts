/**
 * 🗺️ Sitemap XML dynamique pour les pages publiques d'AdminBelgique
 * URL: /api/serveSitemap
 * Inclut : Blog, FAQ, pages publiques, et tous les articles de blog publiés
 * NB: La Home (/) n'est PAS incluse car elle est canonical vers adminbelgique.com (GitHub)
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

const APP_DOMAIN = 'https://app.adminbelgique.com';

function escapeXml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function urlEntry(loc, lastmod, priority, changefreq) {
  return `<url><loc>${escapeXml(loc)}</loc><lastmod>${lastmod}</lastmod><changefreq>${changefreq}</changefreq><priority>${priority}</priority></url>`;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const now = new Date().toISOString().split('T')[0];

    // Récupérer tous les articles publiés (service role pour bypass RLS)
    const articles = await base44.asServiceRole.entities.Article.filter(
      { published: true },
      '-updated_date',
      500
    );

    // Articles statiques (pages BlogArticle* dans pages.config.js)
    const staticArticles = [
      { path: 'BlogArticle5TachesAutomatiser', datePublished: '2025-01-15' },
      { path: 'BlogArticleIATransformation', datePublished: '2025-01-10' },
      { path: 'BlogArticleAssistantVsIA', datePublished: '2025-01-05' },
      { path: 'BlogArticleDeclarationImpots', datePublished: '2025-01-01' },
      { path: 'BlogArticleINAMIOptimise', datePublished: '2024-12-28' },
      { path: 'BlogArticleONEMChomage', datePublished: '2024-12-20' }
    ];

    const urls = [];

    // Blog (liste)
    urls.push(urlEntry(`${APP_DOMAIN}/Blog`, now, '0.8', 'daily'));

    // FAQ
    urls.push(urlEntry(`${APP_DOMAIN}/FAQ`, now, '0.7', 'monthly'));

    // Pages publiques (About, Contact, Guide, Services, Pricing, Help)
    urls.push(urlEntry(`${APP_DOMAIN}/About`, now, '0.7', 'monthly'));
    urls.push(urlEntry(`${APP_DOMAIN}/Contact`, now, '0.7', 'monthly'));
    urls.push(urlEntry(`${APP_DOMAIN}/GuideDemarchesBelgique`, now, '0.8', 'monthly'));
    urls.push(urlEntry(`${APP_DOMAIN}/Services`, now, '0.8', 'monthly'));
    urls.push(urlEntry(`${APP_DOMAIN}/Pricing`, now, '0.8', 'monthly'));
    urls.push(urlEntry(`${APP_DOMAIN}/Help`, now, '0.8', 'monthly')); // <--- Nouvelle ligne ajoutée !

    
    // ImmoBoost AI (landing page publique)
    urls.push(urlEntry(`${APP_DOMAIN}/ImmoBoost`, now, '0.9', 'weekly'));

    // Articles de blog dynamiques (entité Article) — route /blog/:slug (minuscule)
    for (const article of articles) {
      const lastmod = article.updated_date
        ? new Date(article.updated_date).toISOString().split('T')[0]
        : article.published_date || now;
      urls.push(urlEntry(
        `${APP_DOMAIN}/blog/${article.slug}`,
        lastmod,
        '0.6',
        'weekly'
      ));
    }

    // Articles de blog statiques (pages BlogArticle*)
    for (const article of staticArticles) {
      urls.push(urlEntry(
        `${APP_DOMAIN}/${article.path}`,
        article.datePublished,
        '0.6',
        'monthly'
      ));
    }

    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.join('\n')}
</urlset>`;

    return new Response(sitemap, {
      status: 200,
      headers: {
        'Content-Type': 'application/xml; charset=utf-8',
        'Cache-Control': 'public, max-age=3600'
      }
    });
  } catch (error) {
    console.error('serveSitemap error:', error);
    return new Response(
      `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></urlset>`,
      {
        status: 500,
        headers: { 'Content-Type': 'application/xml; charset=utf-8' }
      }
    );
  }
});
