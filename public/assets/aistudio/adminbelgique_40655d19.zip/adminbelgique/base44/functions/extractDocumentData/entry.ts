import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { getQuotaStatus } from '../../shared/quota.ts';

/**
 * Étape 1 de l'analyse de document : extraction structurée du fichier téléversé.
 * Vérifie le quota freemium côté serveur ; le décompte est effectué sur l'étape IA (analyzeAnonymizedDocument).
 */
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const fileUrl = String(body?.fileUrl || '').slice(0, 2000);
    if (!fileUrl) return Response.json({ error: 'Fichier requis' }, { status: 400 });

    const quota = await getQuotaStatus(base44, user, 'analysis_count');
    if (!quota.allowed) {
      return Response.json({ error: "Limite d'analyses atteinte pour votre formule.", quota }, { status: 429 });
    }

    const extractionResponse = await base44.asServiceRole.integrations.Core.ExtractDataFromUploadedFile({
      file_url: fileUrl,
      json_schema: {
        type: "object",
        properties: {
          type: { type: "string", description: "Type de document (facture, courrier administratif, etc.)" },
          content: { type: "string", description: "Contenu principal du document" },
          key_information: {
            type: "array",
            items: { type: "string" },
            description: "Informations clés extraites du document"
          },
          sender: { type: "string", description: "Expéditeur du document" },
          recipient: { type: "string", description: "Destinataire du document" },
          date: { type: "string", description: "Date du document si mentionnée" }
        }
      }
    });

    return Response.json({
      status: extractionResponse?.status,
      details: extractionResponse?.details ?? null,
      output: extractionResponse?.output ?? null,
      quota
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}