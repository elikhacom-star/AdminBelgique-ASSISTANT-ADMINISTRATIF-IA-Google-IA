import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

/**
 * Calcule les prochaines échéances fiscales belges (TVA, IPP, ISOC)
 * selon le type d'entité et le régime du client.
 *
 * ⚠️ RÈGLES VÉRIFIÉES LE 17/08/2026 (sources : SPF Finances, RSM Belgium,
 * Scutera Fiduciaire). Suite à la réforme de la "chaîne TVA" applicable
 * depuis 2026 :
 * - Déclarants TRIMESTRIELS : délai repoussé du 20 au 25 du mois suivant
 *   le trimestre.
 * - Déclarants MENSUELS : délai inchangé, toujours le 20 du mois suivant.
 * - La tolérance estivale (report des délais de juin/juillet) est supprimée.
 * ⚠️ Ces règles peuvent encore évoluer par arrêté royal — le champ
 * "to_verify" reste actif sur les points les plus susceptibles de changer
 * (IPP, ISOC, franchise) pour inciter à une confirmation officielle plutôt
 * que d'affirmer une date avec une fausse certitude.
 *
 * Payload: { entity_type: 'personne_physique' | 'societe', vat_regime: 'mensuel' | 'trimestriel' | 'franchise', reference_date?: string (ISO), fiscal_year_end?: string (MM-DD) }
 * Response: { deadlines: [{ obligation, period, due_date, filing_mode, to_verify }] }
 */
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const entityType = body?.entity_type || 'societe';
    const vatRegime = body?.vat_regime || 'trimestriel';
    const referenceDate = body?.reference_date ? new Date(body.reference_date) : new Date();
    // Date de clôture de l'exercice (par défaut 31/12, format 'MM-DD')
    const fiscalYearEnd = body?.fiscal_year_end || '12-31';

    const deadlines = [];

    // --- TVA ---
    if (vatRegime === 'trimestriel') {
      // Réforme "chaîne TVA" 2026 : délai trimestriel repoussé au 25 (était le 20)
      const quarter = Math.floor(referenceDate.getMonth() / 3);
      const nextQuarterDeadlineMonth = (quarter + 1) * 3; // mois suivant le trimestre
      const dueDate = new Date(referenceDate.getFullYear(), nextQuarterDeadlineMonth, 25);
      if (dueDate < referenceDate) dueDate.setMonth(dueDate.getMonth() + 3);
      deadlines.push({
        obligation: 'Déclaration TVA trimestrielle',
        period: `T${quarter + 1} ${referenceDate.getFullYear()}`,
        due_date: dueDate.toISOString().split('T')[0],
        filing_mode: 'Intervat (dépôt électronique obligatoire)',
        note: 'Délai au 25 du mois suivant le trimestre depuis la réforme "chaîne TVA" 2026 (auparavant le 20).',
        to_verify: false
      });
    } else if (vatRegime === 'mensuel') {
      const dueDate = new Date(referenceDate.getFullYear(), referenceDate.getMonth() + 1, 20);
      deadlines.push({
        obligation: 'Déclaration TVA mensuelle',
        period: `${referenceDate.toLocaleString('fr-BE', { month: 'long' })} ${referenceDate.getFullYear()}`,
        due_date: dueDate.toISOString().split('T')[0],
        filing_mode: 'Intervat (dépôt électronique obligatoire)',
        note: 'Délai inchangé par la réforme "chaîne TVA" — reste au 20 du mois suivant.',
        to_verify: false
      });
    } else {
      // Régime de franchise (petites entreprises) — seuil 25 000 € (national) / 100 000 € (UE)
      deadlines.push({
        obligation: 'Franchise de taxe — pas de déclaration TVA périodique',
        period: 'N/A',
        due_date: null,
        filing_mode: 'Pas de déclaration périodique tant que le CA reste sous 25 000 € HTVA',
        note: 'Seuil national 25 000 € HTVA (proratisé la première année). Le franchisé doit néanmoins déposer un listing client annuel avant le 31 mars de chaque année (tolérance ponctuelle au 30/04 pour 2026 uniquement).',
        to_verify: false
      });
      deadlines.push({
        obligation: 'Listing client annuel (régime franchise)',
        period: `Année ${referenceDate.getFullYear() - 1}`,
        due_date: `${referenceDate.getFullYear()}-03-31`,
        filing_mode: 'MyMinfin — obligatoire même à montant nul',
        to_verify: true
      });
    }

    // --- IPP / ISOC ---
    if (entityType === 'personne_physique') {
      deadlines.push({
        obligation: 'Déclaration IPP (impôt des personnes physiques)',
        period: `Revenus ${referenceDate.getFullYear() - 1}`,
        due_date: null,
        filing_mode: 'Tax-on-web — la date exacte (généralement mi-année) est fixée chaque année par le SPF Finances et communiquée individuellement',
        note: 'Ne jamais annoncer de date précise sans confirmation sur MyMinfin — elle varie chaque année et selon le mode de dépôt (papier vs en ligne, avec ou sans mandataire).',
        to_verify: true
      });
    } else {
      // ISOC + dépôt des comptes annuels : fin du 7e mois suivant la clôture
      const [endMonth, endDay] = fiscalYearEnd.split('-').map(Number);
      let closureYear = referenceDate.getFullYear();
      let closureDate = new Date(closureYear, endMonth - 1, endDay);
      if (closureDate > referenceDate) closureDate.setFullYear(closureYear - 1);

      const isocDue = new Date(closureDate);
      isocDue.setMonth(isocDue.getMonth() + 7);
      isocDue.setDate(0); // dernier jour du 7e mois suivant

      deadlines.push({
        obligation: 'Déclaration ISOC (impôt des sociétés)',
        period: `Exercice clôturé le ${closureDate.toISOString().split('T')[0]}`,
        due_date: isocDue.toISOString().split('T')[0],
        filing_mode: 'Biztax — dépôt électronique obligatoire',
        note: 'Délai standard : fin du 7e mois suivant la clôture comptable. À confirmer si l\'Assemblée Générale a lieu à une date différente de celle prévue par les statuts.',
        to_verify: true
      });
      deadlines.push({
        obligation: 'Dépôt des comptes annuels à la BNB',
        period: `Exercice clôturé le ${closureDate.toISOString().split('T')[0]}`,
        due_date: isocDue.toISOString().split('T')[0],
        filing_mode: 'Banque Nationale de Belgique (BNB) — dépôt électronique',
        note: 'Même délai que l\'ISOC : fin du 7e mois suivant la clôture.',
        to_verify: true
      });
    }

    return Response.json({
      deadlines,
      rules_verified_on: '2026-08-17',
      note: 'Les échéances marquées "to_verify: true" dépendent de paramètres propres au client (date d\'AG, mode de dépôt) ou sont sujettes à confirmation officielle sur MyMinfin / SPF Finances avant communication à un client. Les délais TVA (mensuel/trimestriel) sont vérifiés et à jour de la réforme "chaîne TVA" 2026.'
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
