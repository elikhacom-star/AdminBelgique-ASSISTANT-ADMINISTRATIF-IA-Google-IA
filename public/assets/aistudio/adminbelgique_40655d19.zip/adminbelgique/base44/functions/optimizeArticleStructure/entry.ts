import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { isPrivileged } from '../../shared/quota.ts';

const RESULT_SCHEMA = {
  type: 'object',
  properties: {
    markdown: { type: 'string' },
    verdict: { type: 'string', enum: ['fort', 'modere', 'aucun'] },
    summary: { type: 'string' },
    gains: { type: 'array', items: { type: 'string' } }
  },
  required: ['markdown', 'verdict', 'summary']
};

function buildStructurePrompt(content) {
  return `Tu es un expert SEO belge. Voici un article en Markdown. Ta mission : insérer des titres H2 (##) et H3 (###) pour structurer le contenu, SANS RIEN PERDRE DU TEXTE EXISTANT.

CRITIQUE — ce qu'il ne faut PAS faire :
- Ne renvoie JAMAIS une liste de titres seuls. Le champ "markdown" doit contenir l'article COMPLET avec tous les paragraphes d'origine intacts.
- Ne supprime, ne résume et ne réécris aucun paragraphe. Chaque phrase du contenu source doit se retrouver dans le résultat.

Ce qu'il faut faire :
- Garde l'intégralité du texte original mot pour mot.
- Insère uniquement des titres H2 (##) et H3 (###) aux bons endroits pour structurer le contenu.
- Si des H2/H3 existent déjà, conserve-les et complète la structure.

Renvoie aussi une évaluation honnête et sévère : "verdict" ("fort" = structure réellement améliorée pour Google, "modere" = gains limités, "aucun" = l'article était déjà bien structuré et tes changements sont cosmétiques), "summary" (1-2 phrases sur l'impact concret pour Google) et "gains" (2 à 5 gains SEO précis et vérifiables ; liste vide si verdict = "aucun").

Contenu à structurer (renvoie-le EN ENTIER avec les titres ajoutés) :
${content}`;
}

function buildSeoPrompt(content, title, category) {
  return `Tu es un expert SEO Google (marché belge francophone). Optimise la structure de titres de cet article pour le référencement Google.

CRITIQUE — ce qu'il ne faut PAS faire :
- Ne renvoie JAMAIS une liste de titres seuls. Le champ "markdown" doit contenir l'article COMPLET avec tous les paragraphes d'origine intacts.
- Ne supprime, ne résume et ne réécris aucun paragraphe. Chaque phrase du contenu source doit se retrouver dans le résultat.

Règles :
- Réécris uniquement les titres H2 (##) et H3 (###) : rends-les clairs, accrocheurs, 40-60 caractères, avec des mots-clés pertinents et des intentions de recherche (comment, pourquoi, combien, délais, étapes).
- Vise une structure idéale : 5 à 8 H2, et 2 à 3 H3 sous chaque H2 quand c'est pertinent. Ajoute les titres manquants et supprime les doublons.
- NE réécris PAS les paragraphes existants : conserve le texte tel quel. Tu peux uniquement déplacer un paragraphe sous le bon titre.
- N'ajoute jamais de H1 (le titre de l'article est déjà "${title}").
- Catégorie de l'article : ${category || 'administratif belge'}.

Renvoie aussi une évaluation honnête et sévère de ton propre travail :
- "verdict" : "fort" si la structure était pauvre et gagne réellement en visibilité Google, "modere" si les gains sont limités, "aucun" si l'article était déjà bien optimisé et que tes changements sont uniquement cosmétiques. Sois honnête : si l'existant était déjà bon, réponds "aucun".
- "summary" : 1 à 2 phrases expliquant l'impact concret sur le référencement Google.
- "gains" : 2 à 5 gains SEO précis et vérifiables (ex : "3 H2 ajoutés couvrant les requêtes 'délai' et 'montant'", "titres passés de 12 à 52 caractères, meilleur affichage dans les extraits Google"). Si verdict = "aucun", laisse la liste vide.

Contenu :
${content}`;
}

/** Optimisation IA de la structure H2/H3 d'un article de blog (réservé aux administrateurs). */
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (!isPrivileged(user)) return Response.json({ error: 'Forbidden' }, { status: 403 });

    const body = await req.json();
    const mode = body?.mode === 'seo' ? 'seo' : 'structure';
    const content = String(body?.content || '').slice(0, 60000);
    const title = String(body?.title || '').slice(0, 200);
    const category = String(body?.category || '').slice(0, 100);
    if (!content.trim()) return Response.json({ error: 'Contenu requis' }, { status: 400 });

    const prompt = mode === 'seo'
      ? buildSeoPrompt(content, title, category)
      : buildStructurePrompt(content);

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: RESULT_SCHEMA
    });

    return Response.json({ result });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}