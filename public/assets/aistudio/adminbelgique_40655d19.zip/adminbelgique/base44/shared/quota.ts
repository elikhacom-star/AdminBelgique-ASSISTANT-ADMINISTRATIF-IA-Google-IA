/**
 * Application server-side des quotas freemium.
 * Module partagé par toutes les fonctions backend qui exécutent une action IA facturable.
 * Les compteurs sont lus et écrits en rôle service (bypass RLS) :
 * un utilisateur ne peut donc jamais les modifier ni les contourner depuis le navigateur.
 */

export const QUOTA_FEATURES = [
  'research_count',
  'analysis_count',
  'document_count',
  'ai_messages_count',
  'immo_search_count'
];

export const PLAN_LIMITS = {
  free: { research_count: 1, analysis_count: 1, document_count: 1, ai_messages_count: 1, immo_search_count: 1 },
  pro: { research_count: 999999, analysis_count: 999999, document_count: 999999, ai_messages_count: 999999, immo_search_count: 999999 },
  cabinet: { research_count: 999999, analysis_count: 999999, document_count: 999999, ai_messages_count: 999999, immo_search_count: 999999 },
  enterprise: { research_count: 999999, analysis_count: 999999, document_count: 999999, ai_messages_count: 999999, immo_search_count: 999999 }
};

const UNLIMITED = 999999;
const EMPTY_COUNTERS = {
  research_count: 0,
  analysis_count: 0,
  document_count: 0,
  ai_messages_count: 0,
  immo_search_count: 0
};

// Limitation anti-spam des envois d'emails (tous les plans, admins inclus)
const EMAIL_MAX_PER_WINDOW = 20;
const EMAIL_WINDOW_MS = 60 * 60 * 1000;

export function isPrivileged(user) {
  return user?.role === 'admin' || user?.role === 'superadmin';
}

export function isQuotaFeature(feature) {
  return QUOTA_FEATURES.indexOf(feature) !== -1;
}

function limitsFor(plan) {
  return PLAN_LIMITS[plan] || PLAN_LIMITS.free;
}

function asRecords(result) {
  if (Array.isArray(result)) return result;
  if (result && Array.isArray(result.items)) return result.items;
  return [];
}

async function loadRecord(base44, user) {
  const found = await base44.asServiceRole.entities.UsageLimit.filter({ user_email: user.email });
  const records = asRecords(found);
  const now = new Date();

  if (records.length === 0) {
    return await base44.asServiceRole.entities.UsageLimit.create({
      user_email: user.email,
      plan: 'free',
      ...EMPTY_COUNTERS,
      last_reset_date: now.toISOString(),
      subscription_start: now.toISOString()
    });
  }

  const record = records[0];
  const lastReset = record.last_reset_date ? new Date(record.last_reset_date) : null;
  const needsReset =
    !lastReset ||
    Number.isNaN(lastReset.getTime()) ||
    lastReset.getMonth() !== now.getMonth() ||
    lastReset.getFullYear() !== now.getFullYear();

  if (needsReset) {
    return await base44.asServiceRole.entities.UsageLimit.update(record.id, {
      ...EMPTY_COUNTERS,
      last_reset_date: now.toISOString()
    });
  }

  return record;
}

function statusFromRecord(record, feature) {
  const plan = PLAN_LIMITS[record.plan] ? record.plan : 'free';
  const limit = limitsFor(plan)[feature];
  const used = record[feature] || 0;
  return {
    allowed: used < limit,
    plan,
    feature,
    limit,
    used,
    remaining: Math.max(0, limit - used)
  };
}

/** Lit l'état du quota sans le consommer (affichage / mur payant). */
export async function getQuotaStatus(base44, user, feature) {
  if (isPrivileged(user)) {
    return { allowed: true, plan: 'admin', feature, limit: UNLIMITED, used: 0, remaining: UNLIMITED };
  }
  const record = await loadRecord(base44, user);
  return statusFromRecord(record, feature);
}

/**
 * Consomme une unité de quota de façon atomique côté serveur.
 * À appeler dans la fonction backend qui exécute réellement l'action facturable.
 */
export async function consumeQuota(base44, user, feature) {
  if (isPrivileged(user)) {
    return { allowed: true, plan: 'admin', feature, limit: UNLIMITED, used: 0, remaining: UNLIMITED };
  }

  const record = await loadRecord(base44, user);
  const status = statusFromRecord(record, feature);
  if (!status.allowed) return status;

  const updated = await base44.asServiceRole.entities.UsageLimit.update(record.id, {
    [feature]: status.used + 1
  });

  return {
    allowed: true,
    plan: status.plan,
    feature,
    limit: status.limit,
    used: (updated && updated[feature]) || status.used + 1,
    remaining: Math.max(0, status.limit - status.used - 1)
  };
}

/** Limitation anti-spam des envois d'emails (fenêtre glissante par utilisateur). */
export async function consumeEmailSend(base44, user) {
  const record = await loadRecord(base44, user);
  const now = Date.now();
  const windowStart = record.email_window_start ? new Date(record.email_window_start).getTime() : 0;
  const inWindow = windowStart > 0 && (now - windowStart) < EMAIL_WINDOW_MS;
  const count = inWindow ? (record.email_send_count || 0) : 0;

  if (count >= EMAIL_MAX_PER_WINDOW) {
    return {
      allowed: false,
      retryAfterMinutes: Math.max(1, Math.ceil((EMAIL_WINDOW_MS - (now - windowStart)) / 60000))
    };
  }

  await base44.asServiceRole.entities.UsageLimit.update(record.id, {
    email_send_count: count + 1,
    email_window_start: inWindow ? record.email_window_start : new Date(now).toISOString()
  });

  return { allowed: true, remaining: EMAIL_MAX_PER_WINDOW - count - 1 };
}