/**
 * Assainissement du HTML inséré dans les emails de l'application.
 * Aucun contenu contrôlé par un utilisateur ne doit être injecté brut dans un email.
 */

export function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function isValidEmail(value) {
  return typeof value === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value.trim());
}

export function normalizeEmail(value) {
  return typeof value === 'string' ? value.trim().toLowerCase() : '';
}

// Balises retirées avec leur contenu
const DROP_WITH_CONTENT = ['script', 'style', 'iframe', 'object', 'embed', 'form', 'svg', 'math', 'applet', 'template', 'noscript', 'frame', 'frameset'];

// Balises retirées en conservant le texte interne
const DROP_TAGS_ONLY = ['input', 'button', 'textarea', 'select', 'option', 'link', 'meta', 'base', 'audio', 'video', 'source', 'track'];

/**
 * Supprime les vecteurs d'exécution et de tromperie d'un HTML destiné à un email :
 * scripts, cadres, formulaires, gestionnaires d'événements et URLs actives.
 */
export function sanitizeEmailHtml(html) {
  if (!html) return '';
  let out = String(html);

  for (const tag of DROP_WITH_CONTENT) {
    out = out.replace(new RegExp(`<${tag}\\b[^>]*>[\\s\\S]*?<\\/${tag}>`, 'gi'), '');
    out = out.replace(new RegExp(`<${tag}\\b[^>]*\\/?>`, 'gi'), '');
  }

  for (const tag of DROP_TAGS_ONLY) {
    out = out.replace(new RegExp(`<\\/?${tag}\\b[^>]*>`, 'gi'), '');
  }

  // Gestionnaires d'événements (onclick, onerror, ...)
  out = out.replace(/\son[a-z]+\s*=\s*"[^"]*"/gi, '');
  out = out.replace(/\son[a-z]+\s*=\s*'[^']*'/gi, '');
  out = out.replace(/\son[a-z]+\s*=\s*[^\s>]+/gi, '');

  // URLs actives
  out = out.replace(/(href|src|xlink:href|action|formaction)\s*=\s*(["'])\s*(javascript|data|vbscript|file):[^"']*\2/gi, '$1="#"');

  // iframes/objets injectés via srcdoc
  out = out.replace(/\ssrcdoc\s*=\s*("[^"]*"|'[^']*')/gi, '');

  return out;
}