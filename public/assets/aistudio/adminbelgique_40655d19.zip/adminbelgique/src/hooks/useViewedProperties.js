import { useState, useEffect, useCallback } from 'react';

const STORAGE_KEY = 'immoscrap_viewed_properties';

/**
 * Hook pour tracker les biens déjà consultés (par portail) dans localStorage
 * Retourne { isViewed, markAsViewed, viewedPortals }
 */
export function useViewedProperties() {
  const [viewed, setViewed] = useState({});

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setViewed(JSON.parse(raw));
    } catch (_) {}
  }, []);

  const persist = useCallback((next) => {
    setViewed(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch (_) {}
  }, []);

  /**
   * Clé unique pour un bien : prix + localisation + titre (hash simple)
   */
  const buildKey = (property) => {
    const raw = `${property.price || ''}|${property.location || ''}|${property.title || ''}`;
    let hash = 0;
    for (let i = 0; i < raw.length; i++) {
      hash = ((hash << 5) - hash) + raw.charCodeAt(i);
      hash |= 0;
    }
    return `p_${Math.abs(hash)}`;
  };

  const markAsViewed = useCallback((property, portal) => {
    const key = buildKey(property);
    setViewed((prev) => {
      const entry = prev[key] || [];
      if (entry.includes(portal)) return prev;
      const next = { ...prev, [key]: [...entry, portal] };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch (_) {}
      return next;
    });
  }, []);

  const isViewed = useCallback((property, portal) => {
    const key = buildKey(property);
    return (viewed[key] || []).includes(portal);
  }, [viewed]);

  const viewedPortals = useCallback((property) => {
    const key = buildKey(property);
    return viewed[key] || [];
  }, [viewed]);

  return { isViewed, markAsViewed, viewedPortals };
}