/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import About from './pages/About';
import AccessManagement from './pages/AccessManagement';
import ActionsPrioritaires from './pages/ActionsPrioritaires';
import Assistant from './pages/Assistant';
import BelgianServices from './pages/BelgianServices';
import Blog from './pages/Blog';
import BlogArticle5TachesAutomatiser from './pages/BlogArticle5TachesAutomatiser';
import BlogArticleAssistantVsIA from './pages/BlogArticleAssistantVsIA';
import BlogArticleDeclarationImpots from './pages/BlogArticleDeclarationImpots';
import BlogArticleIATransformation from './pages/BlogArticleIATransformation';
import BlogArticleINAMIOptimise from './pages/BlogArticleINAMIOptimise';
import BlogArticleONEMChomage from './pages/BlogArticleONEMChomage';
import Chat from './pages/Chat';
import ConfigurationGuide from './pages/ConfigurationGuide';
import Contact from './pages/Contact';
import Dashboard from './pages/Dashboard';
import DocumentAnalyzer from './pages/DocumentAnalyzer';
import DocumentGenerator from './pages/DocumentGenerator';
import FAQ from './pages/FAQ';
import GuideDemarchesBelgique from './pages/GuideDemarchesBelgique';
import Help from './pages/Help';
import Home from './pages/Home';
import INAMIBelgique from './pages/INAMIBelgique';
import ImpotsBelgique from './pages/ImpotsBelgique';
import MentionsLegales from './pages/MentionsLegales';
import MyAnalyses from './pages/MyAnalyses';
import ImmoScrapPro from './pages/MyClients';
import MyDocuments from './pages/MyDocuments';
import Pricing from './pages/Pricing';
import Redirections301Guide from './pages/Redirections301Guide';
import Referral from './pages/Referral';
import SEODiagnostic from './pages/SEODiagnostic';
import SEOValidation from './pages/SEOValidation';
import SearchConsoleGuide from './pages/SearchConsoleGuide';
import Services from './pages/Services';
import SignIn from './pages/SignIn';
import SubscriptionManagement from './pages/SubscriptionManagement';
import Templates from './pages/Templates';
import WhatsAppFlow from './pages/WhatsAppFlow';
import __Layout from './Layout.jsx';


export const PAGES = {
    "About": About,
    "AccessManagement": AccessManagement,
    "ActionsPrioritaires": ActionsPrioritaires,
    "Assistant": Assistant,
    "BelgianServices": BelgianServices,
    "Blog": Blog,
    "BlogArticle5TachesAutomatiser": BlogArticle5TachesAutomatiser,
    "BlogArticleAssistantVsIA": BlogArticleAssistantVsIA,
    "BlogArticleDeclarationImpots": BlogArticleDeclarationImpots,
    "BlogArticleIATransformation": BlogArticleIATransformation,
    "BlogArticleINAMIOptimise": BlogArticleINAMIOptimise,
    "BlogArticleONEMChomage": BlogArticleONEMChomage,
    "Chat": Chat,
    "ConfigurationGuide": ConfigurationGuide,
    "Contact": Contact,
    "Dashboard": Dashboard,
    "DocumentAnalyzer": DocumentAnalyzer,
    "DocumentGenerator": DocumentGenerator,
    "FAQ": FAQ,
    "GuideDemarchesBelgique": GuideDemarchesBelgique,
    "Help": Help,
    "Home": Home,
    "INAMIBelgique": INAMIBelgique,
    "ImpotsBelgique": ImpotsBelgique,
    "MentionsLegales": MentionsLegales,
    "MyAnalyses": MyAnalyses,
    "ImmoBoostScrap": ImmoScrapPro,
    "MyDocuments": MyDocuments,
    "Pricing": Pricing,
    "Redirections301Guide": Redirections301Guide,
    "Referral": Referral,
    "SEODiagnostic": SEODiagnostic,
    "SEOValidation": SEOValidation,
    "SearchConsoleGuide": SearchConsoleGuide,
    "Services": Services,
    "SignIn": SignIn,
    "SubscriptionManagement": SubscriptionManagement,
    "Templates": Templates,
    "WhatsAppFlow": WhatsAppFlow,
}

export const pagesConfig = {
    mainPage: "Services",
    Pages: PAGES,
    Layout: __Layout,
};