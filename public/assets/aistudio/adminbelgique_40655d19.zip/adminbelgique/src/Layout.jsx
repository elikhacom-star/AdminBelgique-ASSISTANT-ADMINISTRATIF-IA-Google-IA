import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { FileText, MessageSquare, BookOpen, Home, HelpCircle, Shield, LayoutDashboard, User as UserIcon, LogOut, LogIn, Phone, Crown, Gift, Search, MessageCircle, Users, TrendingDown, ArrowLeft, Siren } from "lucide-react";
import SOSFab from "./components/emergency/SOSFab";
import WhatsAppFloatButton from "./components/common/WhatsAppFloatButton";
import ElikaccesMegaMenu from "./components/nav/ElikaccesMegaMenu";
import { BookOpenText } from "lucide-react";
import { UserPlus, Rocket, Calculator, Receipt } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
  useSidebar } from
"@/components/ui/sidebar";
import { LanguageProvider } from "./components/localization/LanguageContext";
import { useTranslation } from "./components/localization/useTranslation";
import LanguageSwitcher from "./components/common/LanguageSwitcher";
import BottomTabs from "./components/navigation/BottomTabs";
import MenuButton from "./components/navigation/MenuButton";

import OnboardingTour from "./components/onboarding/OnboardingTour";
import GlobalSearch from "./components/search/GlobalSearch";
import PerformanceOptimizer from "./components/seo/PerformanceOptimizer";
import StructuredData from "./components/seo/StructuredData";
import ResourcePreloader from "./components/seo/ResourcePreloader";
import Footer from "./components/legal/Footer";

const SidebarNavLink = ({ item, isActive }) => {
  const { setOpenMobile, setOpen, isMobile } = useSidebar();
  const closeSidebar = () => {
    if (isMobile) setOpenMobile(false);
    else setOpen(false);
  };
  return (
    <SidebarMenuItem>
      <SidebarMenuButton
        asChild
        className={`hover:bg-accent hover:text-accent-foreground transition-colors duration-200 rounded-lg ${
          isActive ? 'bg-accent text-accent-foreground border border-primary/30' : ''} ${
          item.adminOnly ? 'bg-purple-50 hover:bg-purple-100' : ''}`}>
        <Link to={item.url} onClick={closeSidebar} className="flex items-center gap-3 px-3 py-2">
          <item.icon className={`w-4 h-4 ${item.adminOnly ? 'text-purple-600' : ''}`} />
          <span className={`font-medium ${item.adminOnly ? 'text-purple-800' : ''}`}>
            {item.title}
          </span>
          {item.adminOnly &&
            <Badge className="ml-auto bg-purple-600 text-white text-xs">Admin</Badge>
          }
        </Link>
      </SidebarMenuButton>
    </SidebarMenuItem>
  );
};

const NavigationWrapper = ({ children, currentPageName }) => {
  const location = useLocation();
  const { t } = useTranslation();
  const [currentUser, setCurrentUser] = useState(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showSearch, setShowSearch] = useState(false);



  useEffect(() => {
    // 🚨 PROTECTION REDIRECT LOOP
    if (location.pathname === '/login') {
      console.log("🚨 Détection de la page /login - Redirection vers auth");
      base44.auth.redirectToLogin(window.location.origin);
      return;
    }

    const loadUser = async () => {
      try {
        const user = await base44.auth.me();
        setCurrentUser(user);

        const hasSeenTour = localStorage.getItem('adminbelgique_onboarding_completed');
        if (!hasSeenTour) {
          setShowOnboarding(true);
        }
      } catch (error) {
        setCurrentUser(null);
      }
    };
    loadUser();
  }, [location.pathname]);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setShowSearch(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Auto-apply dark theme based on system preference
  useEffect(() => {
    const applyTheme = (e) => {
      const prefersDark = e?.matches ?? (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
      const root = document.documentElement;
      if (prefersDark) root.classList.add('dark');else root.classList.remove('dark');
    };
    try {
      const mql = window.matchMedia('(prefers-color-scheme: dark)');
      applyTheme(mql);
      if (mql.addEventListener) {
        mql.addEventListener('change', applyTheme);
        return () => mql.removeEventListener('change', applyTheme);
      } else if (mql.addListener) {
        mql.addListener(applyTheme);
        return () => mql.removeListener(applyTheme);
      }
    } catch (_) {}
  }, []);

  const baseNavigationItems = [
  { title: t("home"), url: createPageUrl("Home"), icon: Home },
  { title: t("dashboard"), url: createPageUrl("Dashboard"), icon: LayoutDashboard },
  { title: t("chat"), url: createPageUrl("Chat"), icon: MessageSquare },
  { title: "Services", url: createPageUrl("Services"), icon: Shield },
  { title: "Générateur Doc.", url: createPageUrl("DocumentGenerator"), icon: FileText },
  { title: "Mes Modèles", url: createPageUrl("Templates"), icon: FileText },
  { title: "Analyser Document", url: createPageUrl("DocumentAnalyzer"), icon: FileText },
  { title: "Mon Assistant (Simple)", url: createPageUrl("Assistant"), icon: MessageSquare },
  { title: t("mydocs"), url: createPageUrl("MyDocuments"), icon: BookOpen },
  { title: "Mes Analyses", url: createPageUrl("MyAnalyses"), icon: BookOpenText },
  { title: "🚀 ImmoBoost AI", url: "/ImmoBoost", icon: Rocket },
  { title: "🧮 Fiduciaires AI", url: "/FiduciaireAI", icon: Calculator },
  { title: "🧾 Factures récurrentes", url: "/FacturesRecurrentes", icon: Receipt },
  { title: "ImmoScrap Pro", url: createPageUrl("ImmoBoostScrap"), icon: UserPlus },
  { title: "🇧🇪 Services Belges", url: createPageUrl("BelgianServices"), icon: Shield },
  { title: "SOS Urgences", url: "/urgence", icon: Siren },
  { title: "À Propos", url: createPageUrl("About"), icon: Users },
  { title: "Blog", url: createPageUrl("Blog"), icon: BookOpen },
  { title: "FAQ", url: createPageUrl("FAQ"), icon: HelpCircle },
  { title: "Tarifs", url: createPageUrl("Pricing"), icon: Crown },
  { title: "Parrainage", url: createPageUrl("Referral"), icon: Gift },
  { title: "Contact", url: createPageUrl("Contact"), icon: Phone },
  { title: "Guide d'Aide", url: createPageUrl("Help"), icon: HelpCircle }];


  const navigationItems = [...baseNavigationItems];

  if (currentUser?.role === 'admin') {
    navigationItems.push({
      title: "Gestion des Accès",
      url: createPageUrl("AccessManagement"),
      icon: Shield,
      adminOnly: true
    });
    navigationItems.push({
      title: "💳 Gestion Abonnements",
      url: createPageUrl("SubscriptionManagement"),
      icon: Crown,
      adminOnly: true
    });
    navigationItems.push({
      title: "✍️ Rédaction Blog SEO",
      url: "/BlogAdmin",
      icon: BookOpen,
      adminOnly: true
    });

    navigationItems.push({
      title: "🔍 Validation SEO",
      url: createPageUrl("SEOValidation"),
      icon: Search,
      adminOnly: true
    });
    navigationItems.push({
      title: "🚨 Diagnostic SEO",
      url: createPageUrl("SEODiagnostic"),
      icon: TrendingDown,
      adminOnly: true
    });
  }

  const handleLogout = async () => {
    try {
      await base44.auth.logout();
      window.location.reload();
    } catch (error) {
      console.error("Erreur lors de la déconnexion:", error);
      window.location.reload();
    }
  };

  const handleLogin = () => {
    // ✅ CORRIGÉ : Utiliser redirectToLogin au lieu de login
    const nextUrl = window.location.pathname === '/login' ? window.location.origin : window.location.href;
    base44.auth.redirectToLogin(nextUrl);
  };

  return (
    <>
      <ElikaccesMegaMenu />

      {/* Global mobile refinements */}
      <style>{`
                body { overscroll-behavior-y: none; }
                button, [role="button"], .lucide, svg { user-select: none; -webkit-user-select: none; }
                .bottom-tabs-safe a { user-select: none; -webkit-user-select: none; }
                /* Allow text selection in content areas */
                main, .prose, .chat-content, .document-content { user-select: text; -webkit-user-select: text; }
                .header-safe { padding-top: env(safe-area-inset-top); }
                .bottom-tabs-safe { padding-bottom: env(safe-area-inset-bottom); }
                @media (max-width: 768px) {
                  button, [role="button"], a { min-height: 44px; }
                }
              `}</style>

      <SidebarProvider>
        <ResourcePreloader />
        {showOnboarding && <OnboardingTour onComplete={() => {
          setShowOnboarding(false);
          localStorage.setItem('adminbelgique_onboarding_completed', 'true');
        }} />}
        
        <GlobalSearch isOpen={showSearch} onClose={() => setShowSearch(false)} />
        
        <div className="min-h-screen flex w-full bg-muted">
          <Sidebar className="border-r border-border bg-background w-72 z-50 flex-shrink-0">
            
            <SidebarHeader className="border-b border-border p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-sm">BE</span>
                </div>
                <div>
                  <h1 className="sr-only">Assistant Administratif IA Belgique - Agent Administratif</h1>
                  <h2 className="font-bold text-foreground text-lg" aria-hidden="true">{t("header.title")}</h2>
                  <p className="text-xs text-muted-foreground">{t("header.subtitle")} 🇧🇪</p>
                </div>
              </div>
            </SidebarHeader>
            
            <SidebarContent className="flex min-h-0 flex-1 flex-col overflow-y-auto p-4">
              <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-medium text-gray-500 uppercase tracking-wider px-2 py-1 mb-2">
                  {t("services")}
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {navigationItems.map((item) => (
                      <SidebarNavLink
                        key={item.title}
                        item={item}
                        isActive={location.pathname === item.url} />
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            </SidebarContent>
          </Sidebar>

          <main className="flex-1 flex flex-col">
            <header className="bg-background border-b border-border px-4 sm:px-6 py-3 sticky top-0 z-10 header-safe">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  {/* Back button on mobile when not on home */}
                  {!['/', '/Home', '/Chat', '/DocumentGenerator', '/Dashboard', '/Services'].includes(location.pathname) &&
                  <Button variant="ghost" size="icon" className="md:hidden" onClick={() => {const nav = typeof window !== 'undefined' ? -1 : null;if (nav !== null) window.history.back();}} title="Retour">
                      <ArrowLeft className="w-5 h-5" />
                    </Button>
                  }
                  <MenuButton />
                  <span className="text-lg md:text-xl font-semibold hidden sm:block">
                    Assistant Administratif IA Belgique 🇧🇪
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowSearch(true)}
                    className="gap-2"
                    title="Rechercher (Ctrl+K)">
                    
                    <Search className="w-4 h-4" />
                    <span className="hidden md:inline">Rechercher</span>
                    <kbd className="hidden md:inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium opacity-100">
                      <span className="text-xs">⌘</span>K
                    </kbd>
                  </Button>

                  {currentUser &&
                  <Badge className="bg-green-100 text-green-800 border border-green-200 hidden sm:flex items-center gap-2">
                      <UserIcon className="w-4 h-4" />
                      <span>Connecté en tant que <strong>{currentUser.full_name}</strong></span>
                    </Badge>
                  }
                  {currentUser &&
                  <Badge className="bg-green-100 text-green-800 border border-green-200 sm:hidden flex items-center gap-1">
                      <UserIcon className="w-3 h-3" />
                      <span className="text-xs">{currentUser.full_name?.split(' ')[0]}</span>
                    </Badge>
                  }
                  <LanguageSwitcher />
                  {currentUser ?
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleLogout}
                    className="flex items-center gap-2 hover:bg-red-50 hover:border-red-200 hover:text-red-700"
                    title="Se déconnecter">
                    
                      <LogOut className="w-4 h-4" />
                      <span className="hidden sm:inline">Se déconnecter</span>
                    </Button> :

                  <Button
                    size="sm"
                    onClick={handleLogin}
                    className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg hover:shadow-xl transition-all duration-200"
                    title="Se connecter avec Google">
                    
                      <LogIn className="w-4 h-4" />
                      <span className="hidden sm:inline font-semibold">Se connecter</span>
                      <span className="sm:hidden font-semibold">Login</span>
                    </Button>
                  }
                </div>
              </div>
            </header>

            <div id="app-scroll-root" className="flex-1 overflow-auto pb-20 md:pb-0">
              {children}
            </div>
          </main>
        </div>
      <SOSFab />
      <WhatsAppFloatButton />
      <BottomTabs />
      </SidebarProvider>
    </>);

};

export default function Layout({ children, currentPageName }) {
  return (
    <LanguageProvider>
      <PerformanceOptimizer />
      <StructuredData pageType="organization" />
      <StructuredData pageType="software" />
      <NavigationWrapper currentPageName={currentPageName}>
        <div className="flex flex-col min-h-screen">
          <div className="flex-1">
            {children}
          </div>
          <Footer />
        </div>
      </NavigationWrapper>
    </LanguageProvider>);

}