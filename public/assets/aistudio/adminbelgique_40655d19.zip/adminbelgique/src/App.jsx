import './App.css'
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import VisualEditAgent from '@/lib/VisualEditAgent'
import NavigationTracker from '@/lib/NavigationTracker'
import { pagesConfig } from './pages.config'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ProtectedRoute from '@/components/ProtectedRoute';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import OAuthConsent from '@/pages/OAuthConsent';
import Urgence from '@/pages/Urgence';
import ArticleView from '@/pages/ArticleView';
import BlogAdmin from '@/pages/BlogAdmin';
import ImmoBoostLanding from '@/pages/ImmoBoostLanding';
import FiduciaireAI from '@/pages/FiduciaireAI';
import RecurringInvoices from '@/pages/RecurringInvoices';
import SeoMeta from '@/components/seo/SeoMeta';
import DynamicPageTitle from '@/components/seo/DynamicPageTitle';

const { Pages, Layout, mainPage } = pagesConfig;
const mainPageKey = mainPage ?? Object.keys(Pages)[0];
const MainPage = mainPageKey ? Pages[mainPageKey] : <></>;

const LayoutWrapper = ({ children, currentPageName }) => Layout ?
  <Layout currentPageName={currentPageName}>{children}</Layout>
  : <>{children}</>;

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Render the app. Auth gating is handled per-route by ProtectedRoute,
  // which redirects unauthenticated users to /login.
  return (
    <Routes>
      {/* Public auth routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      {/* MCP OAuth consent page: must stay outside ProtectedRoute (it handles the signed-out case) */}
      <Route path="/oauth/consent" element={<OAuthConsent />} />

      {/* Public content pages (SEO): Home, Blog, FAQ, and blog articles */}
      <Route path="/" element={
        <LayoutWrapper currentPageName={mainPageKey}>
          <MainPage />
        </LayoutWrapper>
      } />
      {Object.entries(Pages)
        .filter(([path]) => [
          'Home', 'Blog', 'FAQ','MentionsLegales','Help',
          'About', 'Contact', 'GuideDemarchesBelgique',
          'Services', 'Pricing', 'BelgianServices',
          'BlogArticle5TachesAutomatiser',
          'BlogArticleIATransformation',
          'BlogArticleAssistantVsIA',
          'BlogArticleDeclarationImpots',
          'BlogArticleINAMIOptimise',
          'BlogArticleONEMChomage'
        ].includes(path))
        .map(([path, Page]) => (
          <Route
            key={path}
            path={`/${path}`}
            element={
              <LayoutWrapper currentPageName={path}>
                <Page />
              </LayoutWrapper>
            }
          />
        ))}
      <Route path="/ImmoBoost" element={
        <LayoutWrapper currentPageName="ImmoBoost">
          <ImmoBoostLanding />
        </LayoutWrapper>
      } />
      <Route path="/FiduciaireAI" element={
        <LayoutWrapper currentPageName="FiduciaireAI">
          <FiduciaireAI />
        </LayoutWrapper>
      } />
      <Route path="/blog/:slug" element={
        <LayoutWrapper currentPageName="ArticleView">
          <ArticleView />
        </LayoutWrapper>
      } />

      {/* All other app routes are gated by ProtectedRoute */}
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        {Object.entries(Pages)
        .filter(([path]) => ![
          'Home', 'Blog', 'FAQ',
          'About', 'Contact', 'GuideDemarchesBelgique',
          'Services', 'Pricing', 'BelgianServices',
          'BlogArticle5TachesAutomatiser',
          'BlogArticleIATransformation',
          'BlogArticleAssistantVsIA',
          'BlogArticleDeclarationImpots',
          'BlogArticleINAMIOptimise',
          'BlogArticleONEMChomage'
        ].includes(path))
          .map(([path, Page]) => (
            <Route
              key={path}
              path={`/${path}`}
              element={
                <LayoutWrapper currentPageName={path}>
                  <Page />
                </LayoutWrapper>
              }
            />
          ))}
        <Route path="/urgence" element={
          <LayoutWrapper currentPageName="Urgence">
            <Urgence />
          </LayoutWrapper>
        } />
        <Route path="/BlogAdmin" element={
          <LayoutWrapper currentPageName="BlogAdmin">
            <BlogAdmin />
          </LayoutWrapper>
        } />
        <Route path="/FacturesRecurrentes" element={
          <LayoutWrapper currentPageName="RecurringInvoices">
            <RecurringInvoices />
          </LayoutWrapper>
        } />
      </Route>

      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <NavigationTracker />
          <SeoMeta />
          <DynamicPageTitle />
          <AuthenticatedApp />
        </Router>
        <Toaster />
        <VisualEditAgent />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App