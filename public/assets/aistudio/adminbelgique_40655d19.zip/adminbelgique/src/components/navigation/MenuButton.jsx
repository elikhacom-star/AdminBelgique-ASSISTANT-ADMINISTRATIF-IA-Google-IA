import React from "react";
import { Menu } from "lucide-react";
import { useSidebar } from "@/components/ui/sidebar";

export default function MenuButton() {
  const { toggleSidebar } = useSidebar();

  return (
    <button
      onClick={toggleSidebar}
      aria-label="Ouvrir le menu"
      title="Ouvrir le menu"
      className="flex items-center gap-2 -ml-1 p-2 rounded-xl transition-transform active:scale-95 hover:scale-105 focus:outline-none focus-visible:ring-2 focus-visible:ring-yellow-400">
      {/* Drapeau belge : 3 bandes verticales nettes */}
      <span
        className="flex items-center justify-center rounded-lg shadow-md overflow-hidden"
        style={{
          width: '44px',
          height: '44px',
          background:
            'linear-gradient(to right, #000000 33.3%, #FDDA24 33.3%, #FDDA24 66.6%, #ED2939 66.6%)'
        }}>
        <Menu
          className="w-6 h-6 text-white"
          strokeWidth={2.5}
          style={{ filter: 'drop-shadow(0 1px 2px rgba(0,0,0,0.4))' }}
        />
      </span>
      <span className="text-sm font-bold text-black">Menu</span>
    </button>
  );
}