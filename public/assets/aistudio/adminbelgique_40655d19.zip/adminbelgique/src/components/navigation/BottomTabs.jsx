import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Home, MessageSquare, FileText, LayoutDashboard } from "lucide-react";

const TABS = [
  { key: 'home', root: createPageUrl('Home'), storageKey: 'lastPath_home', label: 'Accueil', Icon: Home, rootPaths: [createPageUrl('Home'), '/', '/Services'] },
  { key: 'chat', root: createPageUrl('Chat'), storageKey: 'lastPath_chat', label: 'Chat', Icon: MessageSquare, rootPaths: [createPageUrl('Chat')] },
  { key: 'docs', root: createPageUrl('DocumentGenerator'), storageKey: 'lastPath_docs', label: 'Docs', Icon: FileText, rootPaths: [createPageUrl('DocumentGenerator')] },
  { key: 'tableau', root: createPageUrl('Dashboard'), storageKey: 'lastPath_tableau', label: 'Tableau', Icon: LayoutDashboard, rootPaths: [createPageUrl('Dashboard')] },
];

const getTabForPath = (p) => {
  for (const tab of TABS) {
    if (tab.rootPaths.includes(p)) return tab;
    if (p.startsWith(tab.root + '/')) return tab;
  }
  return null;
};

const Tab = ({ to, label, Icon, active, onClick }) => (
  <Link
    to={to}
    className={`flex-1 flex flex-col items-center justify-center py-2 ${active ? 'text-blue-600' : 'text-gray-600'} hover:text-blue-700`}
    role="button"
    aria-label={label}
    onClick={(e) => {
      e.preventDefault();
      onClick();
    }}
  >
    <Icon className="w-5 h-5" />
    <span className="text-xs mt-0.5">{label}</span>
  </Link>
);

export default function BottomTabs() {
  const location = useLocation();
  const navigate = useNavigate();
  const path = location.pathname;

  const positionsRef = React.useRef({});
  const formsRef = React.useRef({});
  const POS_KEY = 'tabScrollPositions';
  const FORM_KEY = 'tabFormState';

  React.useEffect(() => {
    try {
      const saved = sessionStorage.getItem(POS_KEY);
      if (saved) positionsRef.current = JSON.parse(saved);
      const savedForms = sessionStorage.getItem(FORM_KEY);
      if (savedForms) formsRef.current = JSON.parse(savedForms);
    } catch {}
  }, []);

  const savePositions = () => {
    try {
      sessionStorage.setItem(POS_KEY, JSON.stringify(positionsRef.current));
      sessionStorage.setItem(FORM_KEY, JSON.stringify(formsRef.current));
    } catch {}
  };

  const getScrollEl = () => document.getElementById('app-scroll-root') || document.scrollingElement || document.documentElement;
  const getRoot = () => document.getElementById('app-scroll-root') || document;

  const saveFormForPath = (p) => {
    const root = getRoot();
    const data = {};
    root.querySelectorAll('input, textarea, select').forEach((el) => {
      const key = el.id || el.name;
      if (!key) return;
      const tag = el.tagName;
      if (tag === 'INPUT') {
        const type = el.type;
        if (type === 'checkbox' || type === 'radio') {
          data[key] = { type, checked: el.checked, value: el.value };
        } else {
          data[key] = { type, value: el.value };
        }
      } else if (tag === 'TEXTAREA') {
        data[key] = { type: 'textarea', value: el.value };
      } else if (tag === 'SELECT') {
        data[key] = { type: 'select', value: el.value };
      }
    });
    formsRef.current[p] = data;
    savePositions();
  };

  const restoreFormForPath = (p) => {
    const state = formsRef.current[p];
    if (!state) return;
    const root = getRoot();
    Object.entries(state).forEach(([key, meta]) => {
      const byId = root.querySelector(`#${CSS && CSS.escape ? CSS.escape(key) : key}`);
      const el = byId || root.querySelector(`[name="${key}"]`);
      if (!el) return;
      if (meta.type === 'checkbox' || meta.type === 'radio') {
        el.checked = !!meta.checked;
        if (meta.type === 'radio' && meta.value !== undefined && el.value === meta.value) {
          el.checked = !!meta.checked;
        }
      } else {
        el.value = meta.value ?? '';
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      }
    });
  };

  const saveScrollForPath = (p) => {
    const el = getScrollEl();
    const y = el?.scrollTop || 0;
    positionsRef.current[p] = y;
    savePositions();
  };

  const restoreScrollForPath = (p) => {
    const y = positionsRef.current[p] ?? 0;
    requestAnimationFrame(() => {
      const el = getScrollEl();
      if (el && typeof el.scrollTo === 'function') el.scrollTo({ top: y, behavior: 'auto' });
      else window.scrollTo(0, y);
    });
  };

  React.useEffect(() => {
    restoreScrollForPath(path);
    restoreFormForPath(path);
  }, [path]);

  // Save current path to the active tab's storage
  React.useEffect(() => {
    const tab = getTabForPath(path);
    if (tab) {
      try {
        sessionStorage.setItem(tab.storageKey, path);
      } catch {}
    }
  }, [path]);

  const scrollToTop = () => {
    const el = getScrollEl();
    if (el && typeof el.scrollTo === 'function') {
      el.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const activeTab = getTabForPath(path);

  const handleTabClick = (tab) => {
    const isActive = activeTab?.key === tab.key;
    saveScrollForPath(path);
    saveFormForPath(path);
    if (isActive) {
      try { sessionStorage.removeItem(tab.storageKey); } catch {}
      navigate(tab.root);
      scrollToTop();
    } else {
      let target = tab.root;
      try {
        const saved = sessionStorage.getItem(tab.storageKey);
        if (saved) target = saved;
      } catch {}
      navigate(target);
    }
  };

  const getTabTarget = (tab) => {
    try {
      return sessionStorage.getItem(tab.storageKey) || tab.root;
    } catch {
      return tab.root;
    }
  };

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 shadow-sm bottom-tabs-safe">
      <nav className="flex">
        {TABS.map((tab) => (
          <Tab
            key={tab.key}
            to={getTabTarget(tab)}
            label={tab.label}
            Icon={tab.Icon}
            active={activeTab?.key === tab.key}
            onClick={() => handleTabClick(tab)}
          />
        ))}
      </nav>
    </div>
  );
}