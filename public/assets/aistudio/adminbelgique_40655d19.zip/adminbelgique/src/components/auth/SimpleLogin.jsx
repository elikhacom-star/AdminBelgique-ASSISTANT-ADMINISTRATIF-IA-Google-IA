import React, { useState } from "react";
import { db, auth } from "@/components/api/wrapper";
const User = db.User;
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Shield, Mail, CheckCircle, AlertCircle, ArrowRight, Clock, Phone } from "lucide-react";
import { useTranslation } from "@/components/localization/useTranslation";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

// Helper function to create URLs for internal pages
// In a real application, this might come from a router utility or a centralized config.
const createPageUrl = (pageName) => {
  switch (pageName) {
    case "ConfigurationGuide":
      return "/configuration-guide"; // Updated name and example path
    default:
      return `/${pageName.toLowerCase().replace(/\s/g, '-')}`;
  }
};

export default function SimpleLogin({ actionText = "utiliser cette fonctionnalité" }) {
  const [isLogging, setIsLogging] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  const [user, setUser] = useState(null); // New state as per outline
  const [showLogin, setShowLogin] = useState(false); // New state as per outline
  const { t } = useTranslation();

  const handleLogin = async () => {
    setIsLogging(true);
    try {
      // Rediriger vers la page courante après connexion (sauf si c'est /login qui est buggé)
      const nextUrl = window.location.pathname === '/login' ? window.location.origin : window.location.href;
      await auth.redirectToLogin(nextUrl);
    } catch (error) {
      console.error("Login failed:", error);
      setIsLogging(false);
    }
  };

  if (showGuide) {
    return (
      <div className="min-h-screen p-4 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="max-w-4xl mx-auto">
          <Card className="border-2 border-blue-300 shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
              <CardTitle className="text-2xl">
                🔗 Comment se connecter avec Hotmail, Outlook, ou un email professionnel
              </CardTitle>
              <CardDescription className="text-white/90">
                Guide complet en 7 étapes simples (2 minutes)
              </CardDescription>
            </CardHeader>

            <CardContent className="p-8 space-y-6">
              <Alert className="bg-green-50 border-green-300">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <AlertTitle className="text-green-900 font-bold">
                  ✅ C'est GRATUIT et RAPIDE (2 minutes)
                </AlertTitle>
                <AlertDescription className="text-green-800">
                  Vous allez créer un "compte Google" avec VOTRE email actuel.<br/>
                  <strong>Vous ne créerez PAS de nouvelle adresse @gmail.com</strong>
                </AlertDescription>
              </Alert>

              <div className="space-y-6">
                <div className="flex gap-4 p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
                  <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                    1
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-blue-900 mb-2">Ouvrez cette page dans un nouvel onglet</h3>
                    <a
                      href="https://accounts.google.com/signup"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800 font-semibold underline text-lg"
                    >
                      👉 accounts.google.com/signup
                    </a>
                    <p className="text-sm text-blue-700 mt-2">
                      (Cliquez pour ouvrir dans un nouvel onglet, puis revenez ici pour suivre le guide)
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 p-4 bg-purple-50 rounded-lg border-2 border-purple-200">
                  <div className="flex-shrink-0 w-10 h-10 bg-purple-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                    2
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-purple-900 mb-2">Entrez votre prénom et nom</h3>
                    <p className="text-purple-800">
                      Remplissez simplement les champs "Prénom" et "Nom", puis cliquez sur "Suivant"
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 p-4 bg-indigo-50 rounded-lg border-2 border-indigo-200">
                  <div className="flex-shrink-0 w-10 h-10 bg-indigo-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                    3
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-indigo-900 mb-2">Entrez votre date de naissance et genre</h3>
                    <p className="text-indigo-800">
                      Remplissez ces informations, puis cliquez sur "Suivant"
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 p-4 bg-yellow-50 rounded-lg border-2 border-yellow-300">
                  <div className="flex-shrink-0 w-10 h-10 bg-yellow-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                    4
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-yellow-900 mb-3">
                      🎯 ÉTAPE IMPORTANTE : Utilisez votre email actuel
                    </h3>
                    <div className="bg-white p-4 rounded border border-yellow-400">
                      <p className="text-yellow-900 font-semibold mb-2">
                        Google vous propose plusieurs options :
                      </p>
                      <ul className="list-disc list-inside space-y-2 text-yellow-800">
                        <li>Créer une adresse Gmail</li>
                        <li><strong className="text-red-600">👉 Utiliser une adresse e-mail existante à la place</strong></li>
                      </ul>
                      <div className="mt-4 p-3 bg-red-50 border border-red-300 rounded">
                        <p className="font-bold text-red-900 mb-2">
                          ⚠️ CLIQUEZ SUR : "Utiliser une adresse e-mail existante à la place"
                        </p>
                        <p className="text-sm text-red-800">
                          Puis entrez VOTRE email : khalil@outlook.com, marie@hotmail.com, etc.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 p-4 bg-green-50 rounded-lg border-2 border-green-200">
                  <div className="flex-shrink-0 w-10 h-10 bg-green-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                    5
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-green-900 mb-2">Choisissez un mot de passe</h3>
                    <p className="text-green-800 mb-2">
                      Créez un mot de passe sécurisé pour votre compte Google.
                    </p>
                    <Alert className="bg-white border-green-300">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription className="text-xs">
                        <strong>Important :</strong> Ce mot de passe est différent de celui de votre boîte email Hotmail/Outlook.
                        C'est un nouveau mot de passe uniquement pour vous connecter aux services Google.
                      </AlertDescription>
                    </Alert>
                  </div>
                </div>

                <div className="flex gap-4 p-4 bg-cyan-50 rounded-lg border-2 border-cyan-200">
                  <div className="flex-shrink-0 w-10 h-10 bg-cyan-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                    6
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-cyan-900 mb-2">Vérification par code</h3>
                    <p className="text-cyan-800">
                      Google va envoyer un code de vérification à <strong>votre email</strong>.<br/>
                      Allez dans votre boîte Hotmail/Outlook, copiez le code et collez-le.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 p-4 bg-emerald-50 rounded-lg border-2 border-emerald-300">
                  <div className="flex-shrink-0 w-10 h-10 bg-emerald-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                    7
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-emerald-900 mb-2">
                      🎉 Terminé ! Revenez sur AdminBelgique
                    </h3>
                    <p className="text-emerald-800 mb-3">
                      Maintenant, cliquez sur le bouton "Se connecter avec Google" ci-dessous.<br/>
                      Utilisez votre email Hotmail/Outlook + le mot de passe Google que vous venez de créer.
                    </p>
                    <Button
                      onClick={() => setShowGuide(false)}
                      className="w-full bg-emerald-600 hover:bg-emerald-700"
                      size="lg"
                    >
                      <ArrowRight className="w-5 h-5 mr-2" />
                      Retour à la connexion
                    </Button>
                  </div>
                </div>
              </div>

              <Alert className="bg-blue-50 border-blue-300">
                <Mail className="h-5 w-5 text-blue-600" />
                <AlertTitle className="text-blue-900 font-bold">
                  🔒 Pourquoi Google demande ça ?
                </AlertTitle>
                <AlertDescription className="text-blue-800">
                  Google sert uniquement de <strong>système d'authentification sécurisé</strong> (comme un "gardien").<br/>
                  Votre adresse email reste <strong>inchangée</strong>, aucune donnée n'est partagée.<br/>
                  C'est le standard utilisé par la plupart des applications professionnelles modernes.
                </AlertDescription>
              </Alert>

              <div className="flex gap-3">
                <Button
                  onClick={() => setShowGuide(false)}
                  variant="outline"
                  className="flex-1"
                  size="lg"
                >
                  Retour
                </Button>
                <Button
                  onClick={handleLogin}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                  disabled={isLogging}
                  size="lg"
                >
                  {isLogging ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Connexion...
                    </>
                  ) : (
                    <>
                      <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                      </svg>
                      Se connecter avec Google
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-yellow-600" />
          </div>
          <CardTitle className="text-2xl">Connexion Requise</CardTitle>
          <CardDescription>
            Vous devez être connecté pour {actionText}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">

          <div className="text-center text-gray-600">
            <p>{t("login.login_to")} <span className="font-semibold text-gray-800">{t("login.continue")}</span></p>
          </div>

          {/* NOUVELLE SECTION - ÉTAPES NUMÉROTEES */}
          <div className="bg-gradient-to-br from-orange-50 to-red-50 border-2 border-orange-400 rounded-lg p-6 space-y-4">
            <div className="flex items-start gap-3">
              <Clock className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-orange-900 text-xl mb-2">
                  ⚠️ AVANT DE CLIQUER SUR "SE CONNECTER"
                </h3>
                <p className="text-orange-800 mb-4">
                  Si vous avez un email <strong>Hotmail, Outlook, ou professionnel</strong>, suivez ces 2 étapes :
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="bg-white rounded-lg p-4 border-2 border-orange-300">
                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-orange-500 text-white rounded-full flex items-center justify-center font-bold">
                    1
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-orange-900 mb-1">Créez d'abord un compte Google avec VOTRE email</h4>
                    <p className="text-sm text-orange-800">
                      Cliquez ci-dessous pour voir le guide détaillé (2 minutes)
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg p-4 border-2 border-green-300">
                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center font-bold">
                    2
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-green-900 mb-1">Revenez ici et connectez-vous</h4>
                    <p className="text-sm text-green-800">
                      Utilisez VOTRE email + le mot de passe Google que vous aurez créé
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <Button
              onClick={() => setShowGuide(true)}
              className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
              size="lg"
            >
              <CheckCircle className="w-5 h-5 mr-2" />
              📖 Voir le guide étape par étape (2 minutes)
            </Button>
          </div>

          {/* BOUTON DE CONNEXION PRINCIPAL */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">ou si vous avez déjà un compte Google</span>
            </div>
          </div>

          <Button
            onClick={handleLogin}
            className="w-full bg-blue-500 hover:bg-blue-600 text-lg py-6"
            disabled={isLogging}
          >
            {isLogging ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                {t("login.checking")}
              </>
            ) : (
              <>
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                <span className="font-semibold">{t("login.connect_google")}</span>
              </>
            )}
          </Button>

          <div className="text-center text-xs text-gray-500 space-y-1">
            <p className="font-semibold">{t("login.secure_info")}</p>
            <p>{t("login.auto_check")}</p>
          </div>

          <div className="text-center space-y-3">
            <div className="flex items-center gap-2 justify-center">
              <Mail className="w-4 h-4 text-blue-600" />
              <a href="mailto:contact@adminbelgique.com" className="text-blue-600 hover:underline text-sm">
                contact@adminbelgique.com
              </a>
            </div>
            <div className="flex items-center gap-2 justify-center">
              <Phone className="w-4 h-4 text-blue-600" />
              <a href="tel:+32467801041" className="text-blue-600 hover:underline text-sm">
                +32 467 80 10 41
              </a>
            </div>
          </div>

        </CardContent>
      </Card>
    </div>
  );
}