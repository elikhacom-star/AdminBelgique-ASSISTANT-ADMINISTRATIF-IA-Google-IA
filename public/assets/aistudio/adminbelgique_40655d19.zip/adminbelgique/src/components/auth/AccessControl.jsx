import React, { useState, useEffect } from "react";
import { User } from "@/entities/User";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Shield, AlertTriangle, Mail, Phone } from "lucide-react";

export default function AccessControl({ children }) {
  const [user, setUser] = useState(null);
  const [hasAccess, setHasAccess] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkAccess();
  }, []);

  const checkAccess = async () => {
    try {
      const currentUser = await User.me();
      
      if (!currentUser) {
        setIsLoading(false);
        return;
      }

      setUser(currentUser);

      // 🔥 MODIFICATION IMPORTANTE : Permettre accès à TOUS les utilisateurs authentifiés
      // Option 1 : Accès libre pour tous (RECOMMANDÉ pour une app publique)
      setHasAccess(true);
      setIsLoading(false);
      
      /* Option 2 : Si vous voulez garder la liste blanche, décommentez ce code :
      
      try {
        const accessList = await UserAccess.filter({ email: currentUser.email });
        
        if (accessList.length > 0 && accessList[0].active) {
          setHasAccess(true);
        } else {
          // Auto-créer l'accès pour les nouveaux utilisateurs
          await UserAccess.create({
            email: currentUser.email,
            role: "user",
            active: true,
            notes: "Auto-créé lors de la première connexion"
          });
          setHasAccess(true);
        }
      } catch (accessError) {
        console.error("Erreur vérification accès:", accessError);
        // En cas d'erreur, autoriser quand même (fail-open)
        setHasAccess(true);
      }
      
      */

    } catch (error) {
      console.error("Erreur checkAccess:", error);
      // En cas d'erreur d'authentification, permettre quand même l'accès à l'app publique
      setHasAccess(true);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-500 mx-auto mb-4" />
          <p className="text-gray-600">Vérification des accès...</p>
        </div>
      </div>
    );
  }

  // Si l'utilisateur n'a pas accès (ne devrait plus arriver avec accès libre)
  if (!hasAccess && user) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center bg-gradient-to-br from-red-50 to-orange-50">
        <Card className="max-w-2xl border-2 border-red-300">
          <CardHeader className="bg-red-100">
            <CardTitle className="flex items-center gap-3 text-red-900">
              <Shield className="w-8 h-8" />
              Accès Refusé
            </CardTitle>
          </CardHeader>
          <CardContent className="p-8 space-y-6">
            <Alert variant="destructive" className="bg-red-50 border-red-200">
              <AlertTriangle className="h-5 w-5" />
              <AlertTitle className="text-red-800 font-bold">
                Votre compte n'est pas encore autorisé
              </AlertTitle>
              <AlertDescription className="text-red-700">
                <p className="mb-2">
                  Votre email <strong>{user.email}</strong> n'est pas dans la liste des utilisateurs autorisés.
                </p>
              </AlertDescription>
            </Alert>

            <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-6">
              <h3 className="font-bold text-blue-900 mb-3 text-lg">
                📧 Contactez-nous pour activer votre compte
              </h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 bg-white rounded p-3">
                  <Mail className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-gray-600">Email :</p>
                    <a 
                      href={`mailto:elikaccesit@gmail.com?subject=Demande d'accès AdminBelgique&body=Bonjour,%0D%0A%0D%0AJe souhaite obtenir l'accès à AdminBelgique.%0D%0AMon email : ${user.email}%0D%0A%0D%0AMerci !`}
                      className="font-semibold text-blue-600 hover:underline"
                    >
                      elikaccesit@gmail.com
                    </a>
                  </div>
                </div>
                
                <div className="flex items-center gap-3 bg-white rounded p-3">
                  <Phone className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-gray-600">Téléphone :</p>
                    <a 
                      href="tel:+32467801041"
                      className="font-semibold text-blue-600 hover:underline"
                    >
                      +32 467 80 10 41
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-yellow-50 border-2 border-yellow-200 rounded-lg p-4">
              <p className="text-sm text-yellow-900">
                <strong>💡 Astuce :</strong> L'activation est généralement effectuée sous 24h maximum. 
                Nous vous enverrons un email de confirmation.
              </p>
            </div>

            <Button
              onClick={() => User.logout()}
              variant="outline"
              className="w-full"
            >
              Se déconnecter
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <>{children}</>;
}