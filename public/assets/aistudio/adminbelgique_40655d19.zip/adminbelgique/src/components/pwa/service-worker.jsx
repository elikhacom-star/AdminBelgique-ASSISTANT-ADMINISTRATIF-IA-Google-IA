const CACHE_NAME = 'adminbelgique-cache-v1';
// Fichiers essentiels à mettre en cache pour que l'application fonctionne hors ligne.
const urlsToCache = [
  '/',
  '/index.html', // Souvent, la racine '/' sert '/index.html'
  // NOTE: Les chemins vers les fichiers CSS et JS sont souvent dynamiques.
  // Un service worker plus complexe pourrait les ajouter au cache dynamiquement.
  // Pour commencer, on cache les points d'entrée principaux.
];

// Étape 1: Installation du Service Worker et mise en cache des ressources
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

// Étape 2: Activation du Service Worker et nettoyage des anciens caches
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Étape 3: Interception des requêtes réseau (Fetch)
self.addEventListener('fetch', event => {
  // Stratégie: "Cache d'abord, puis réseau"
  // Idéal pour les ressources statiques qui ne changent pas souvent.
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Si la ressource est dans le cache, on la retourne
        if (response) {
          return response;
        }

        // Sinon, on effectue la requête réseau
        return fetch(event.request).then(
          networkResponse => {
            // Si la requête réussit, on peut la mettre en cache pour plus tard
            // (Optionnel, mais utile pour les pages visitées)
            if(!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
              return networkResponse;
            }

            const responseToCache = networkResponse.clone();

            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });

            return networkResponse;
          }
        );
      })
  );
});