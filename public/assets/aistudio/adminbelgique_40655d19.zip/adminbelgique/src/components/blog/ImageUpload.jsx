import React, { useState, useRef } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Upload, Loader2, X, ImageIcon } from 'lucide-react';
import { integrations } from '@/components/api/wrapper';

const { UploadFile } = integrations.Core;

export default function ImageUpload({ value, onChange, id, label }) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const inputRef = useRef(null);

  const handleFile = async (file) => {
    if (!file) return;
    setError('');
    if (!file.type.startsWith('image/')) {
      setError('Veuillez sélectionner un fichier image.');
      return;
    }
    setUploading(true);
    try {
      const res = await UploadFile({ file });
      if (res?.file_url) {
        onChange({ target: { value: res.file_url } });
      } else {
        setError("L'upload a échoué.");
      }
    } catch (e) {
      setError("Erreur lors de l'upload de l'image.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label || 'Image de couverture'}</Label>
      <div className="flex flex-col gap-2">
        {value ? (
          <div className="relative group rounded-md overflow-hidden border border-border bg-muted">
            <img src={value} alt="aperçu" className="w-full h-32 object-cover" />
            <Button
              type="button"
              variant="destructive"
              size="icon"
              className="absolute top-1 right-1 h-7 w-7"
              onClick={() => onChange({ target: { value: '' } })}
              title="Supprimer l'image"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            disabled={uploading}
            className="flex flex-col items-center justify-center gap-2 h-32 w-full rounded-md border-2 border-dashed border-border hover:border-primary hover:bg-muted/50 transition-colors text-muted-foreground"
          >
            {uploading ? (
              <Loader2 className="w-6 h-6 animate-spin" />
            ) : (
              <>
                <ImageIcon className="w-6 h-6" />
                <span className="text-xs">Cliquez pour téléverser une image</span>
              </>
            )}
          </button>
        )}
        <input
          ref={inputRef}
          id={id}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            handleFile(file);
            e.target.value = '';
          }}
        />
        <Input
          value={value}
          onChange={onChange}
          placeholder="https://… (ou téléversez une image ci-dessus)"
          className="text-xs"
        />
        {error && <p className="text-xs text-red-500">{error}</p>}
      </div>
    </div>
  );
}