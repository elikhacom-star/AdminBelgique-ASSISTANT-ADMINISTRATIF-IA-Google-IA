import React from 'react';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, AlertTriangle, MinusCircle, Search } from 'lucide-react';

const VERDICTS = {
  fort: { label: 'Gain SEO significatif', cls: 'bg-green-100 text-green-800 border-green-200', Icon: CheckCircle2 },
  modere: { label: 'Gain SEO modéré', cls: 'bg-amber-100 text-amber-800 border-amber-200', Icon: AlertTriangle },
  aucun: { label: 'Aucun gain réel — gardez votre version', cls: 'bg-gray-100 text-gray-700 border-gray-200', Icon: MinusCircle }
};

export default function SeoGainsPanel({ verdict, summary, gains = [] }) {
  const v = VERDICTS[verdict] || VERDICTS.modere;
  const { Icon } = v;

  return (
    <div className="rounded-lg border bg-white p-4">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <Search className="w-4 h-4 text-blue-600" />
        <span className="text-sm font-semibold text-gray-900">Analyse SEO Google</span>
        <Badge className={`gap-1 border ${v.cls}`}>
          <Icon className="w-3 h-3" />
          {v.label}
        </Badge>
      </div>
      {summary && <p className="mb-3 text-sm text-gray-700">{summary}</p>}
      {gains.length > 0 &&
        <ul className="space-y-1.5">
          {gains.map((g, i) =>
            <li key={i} className="flex gap-2 text-sm text-gray-700">
              <CheckCircle2 className="mt-0.5 w-4 h-4 flex-shrink-0 text-green-600" />
              <span>{g}</span>
            </li>
          )}
        </ul>
      }
    </div>
  );
}