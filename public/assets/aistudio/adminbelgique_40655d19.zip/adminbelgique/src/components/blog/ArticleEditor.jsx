import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Save, X, Eye, Loader2, Sparkles, Heading2, Heading3, TrendingUp } from 'lucide-react';
import ImageUpload from './ImageUpload';
import ContentDiffDialog from './ContentDiffDialog';
import { api as base44 } from '@/components/api/wrapper';

export default function ArticleEditor({ article, onSave, onCancel, isSaving }) {
  const [form, setForm] = useState({
    title: article.title || '',
    slug: article.slug || '',
    excerpt: article.excerpt || '',
    category: article.category || '',
    meta_title: article.meta_title || '',
    meta_description: article.meta_description || '',
    image_url: article.image_url || '',
    image_alt: article.image_alt || '',
    read_time: article.read_time || '',
    content: article.content || ''
  });

  const set = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const [generating, setGenerating] = useState(false);
  const [structuring, setStructuring] = useState(false);
  const [optimizing, setOptimizing] = useState(false);
  const [diff, setDiff] = useState(null);

  const handleStructureHeadings = async () => {
    if (!form.content?.trim()) return;
    setStructuring(true);
    try {
      // 🔒 Optimisation exécutée côté serveur (fonction réservée aux administrateurs).
      const structureCall = await base44.functions.invoke('optimizeArticleStructure', {
        mode: 'structure',
        content: form.content,
        title: form.title,
        category: form.category
      });
      const result = structureCall?.data?.result || structureCall?.result;
      if (result?.markdown) {
        setDiff({
          title: 'Structuration H2/H3 via IA — avant / après',
          before: form.content,
          after: result.markdown,
          analysis: { verdict: result.verdict, summary: result.summary, gains: result.gains || [] }
        });
      }
    } catch (e) {
      console.error('Heading structuring failed', e);
    } finally {
      setStructuring(false);
    }
  };

  const handleOptimizeSeo = async () => {
    if (!form.content?.trim()) return;
    setOptimizing(true);
    try {
      // 🔒 Optimisation exécutée côté serveur (fonction réservée aux administrateurs).
      const seoCall = await base44.functions.invoke('optimizeArticleStructure', {
        mode: 'seo',
        content: form.content,
        title: form.title,
        category: form.category
      });
      const result = seoCall?.data?.result || seoCall?.result;
      if (result?.markdown) {
        setDiff({
          title: 'Optimisation SEO Google (H2/H3) — avant / après',
          before: form.content,
          after: result.markdown,
          analysis: { verdict: result.verdict, summary: result.summary, gains: result.gains || [] }
        });
      }
    } catch (e) {
      console.error('SEO optimization failed', e);
    } finally {
      setOptimizing(false);
    }
  };

  const handleGenerateImage = async () => {
    const prompt = form.image_alt?.trim();
    if (!prompt) return;
    setGenerating(true);
    try {
      // 🔒 Génération d'image exécutée côté serveur (fonction réservée aux administrateurs).
      const imageCall = await base44.functions.invoke('generateArticleCoverImage', { imageAlt: prompt });
      const res = imageCall?.data || imageCall;
      if (res?.url) {
        setForm((f) => ({ ...f, image_url: res.url }));
      }
    } catch (e) {
      console.error('Image generation failed', e);
    } finally {
      setGenerating(false);
    }
  };

  const insertHeading = (level) => {
    const el = document.getElementById('a-content');
    const prefix = level === 2 ? '## ' : '### ';
    const placeholder = level === 2 ? 'Nouveau titre H2' : 'Nouveau sous-titre H3';
    const text = form.content || '';
    const pos = el && typeof el.selectionStart === 'number' ? el.selectionStart : text.length;
    const before = text.slice(0, pos);
    const after = text.slice(pos);
    const snippet = `${before.endsWith('\n') || before === '' ? '' : '\n\n'}${prefix}${placeholder}\n\n`;
    const next = before + snippet + after;
    setForm((f) => ({ ...f, content: next }));
    if (el) {
      const caret = before.length + snippet.length - 2;
      requestAnimationFrame(() => {
        el.focus();
        el.setSelectionRange(caret - placeholder.length - 1, caret - 1);
      });
    }
  };

  const wordCount = form.content.trim().split(/\s+/).filter(Boolean).length;
  const h2Count = (form.content.match(/^## .+/gm) || []).length;
  const h3Count = (form.content.match(/^### .+/gm) || []).length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex flex-wrap items-center justify-between gap-2 text-lg">
          <span>Relecture et édition</span>
          <div className="flex items-center gap-2">
            <Badge variant="secondary">{wordCount} mots</Badge>
            <Badge variant={h2Count > 0 ? 'default' : 'destructive'} className="gap-1"><Heading2 className="w-3 h-3" />{h2Count} H2</Badge>
            <Badge variant={h3Count > 0 ? 'default' : 'outline'} className="gap-1"><Heading3 className="w-3 h-3" />{h3Count} H3</Badge>
            {article.faq?.length > 0 && <Badge variant="secondary">{article.faq.length} FAQ</Badge>}
            <Button
              type="button"
              size="sm"
              onClick={handleOptimizeSeo}
              disabled={optimizing || !form.content?.trim()}
              className="gap-2 bg-blue-600 text-white hover:bg-blue-700"
            >
              {optimizing ? <Loader2 className="w-4 h-4 animate-spin" /> : <TrendingUp className="w-4 h-4" />}
              {optimizing ? 'Optimisation…' : 'Optimiser pour Google'}
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="a-title">Titre (H1)</Label>
            <Input id="a-title" value={form.title} onChange={set('title')} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="a-slug">Slug URL</Label>
            <Input id="a-slug" value={form.slug} onChange={set('slug')} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="a-cat">Catégorie</Label>
            <Input id="a-cat" value={form.category} onChange={set('category')} />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="a-excerpt">Résumé</Label>
            <Textarea id="a-excerpt" value={form.excerpt} onChange={set('excerpt')} rows={2} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="a-mt">
              Meta title <span className="text-xs text-gray-500">({form.meta_title.length}/60)</span>
            </Label>
            <Input id="a-mt" value={form.meta_title} onChange={set('meta_title')} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="a-rt">Temps de lecture</Label>
            <Input id="a-rt" value={form.read_time} onChange={set('read_time')} placeholder="8 min" />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="a-md">
              Meta description <span className="text-xs text-gray-500">({form.meta_description.length}/160)</span>
            </Label>
            <Textarea id="a-md" value={form.meta_description} onChange={set('meta_description')} rows={2} />
          </div>
          <div className="space-y-2">
            <ImageUpload
              id="a-img"
              label="Image de couverture"
              value={form.image_url}
              onChange={set('image_url')}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="a-alt">Texte alternatif de l'image</Label>
            <Input id="a-alt" value={form.image_alt} onChange={set('image_alt')} />
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleGenerateImage}
              disabled={generating || !form.image_alt?.trim()}
              className="mt-1 gap-2"
            >
              {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {generating ? 'Génération…' : 'Générer l\'image via IA'}
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <Label htmlFor="a-content">Contenu (Markdown)</Label>
            <div className="flex flex-wrap items-center gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => insertHeading(2)} className="gap-1">
                <Heading2 className="w-4 h-4" /> Titre H2
              </Button>
              <Button type="button" variant="outline" size="sm" onClick={() => insertHeading(3)} className="gap-1">
                <Heading3 className="w-4 h-4" /> Titre H3
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleStructureHeadings}
                disabled={structuring || !form.content?.trim()}
                className="gap-2"
              >
                {structuring ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                {structuring ? 'Structuration…' : 'Structurer H2/H3 via IA'}
              </Button>
            </div>
          </div>
          <Textarea id="a-content" value={form.content} onChange={set('content')} rows={20} className="font-mono text-xs" />
        </div>

        <div className="flex flex-wrap gap-2">
          <Button onClick={() => onSave(form, false)} disabled={isSaving} variant="outline">
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Enregistrer en brouillon
          </Button>
          <Button onClick={() => onSave(form, true)} disabled={isSaving} className="bg-green-600 hover:bg-green-700 text-white">
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Eye className="w-4 h-4" />}
            Publier
          </Button>
          <Button onClick={onCancel} variant="ghost" disabled={isSaving}>
            <X className="w-4 h-4" />
            Annuler
          </Button>
        </div>
      </CardContent>
      <ContentDiffDialog
        open={!!diff}
        title={diff?.title || ''}
        before={diff?.before || ''}
        after={diff?.after || ''}
        analysis={diff?.analysis}
        onApply={() => {
          setForm((f) => ({ ...f, content: diff.after }));
          setDiff(null);
        }}
        onCancel={() => setDiff(null)}
      />
    </Card>
  );
}