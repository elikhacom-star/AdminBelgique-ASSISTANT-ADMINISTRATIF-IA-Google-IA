import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, X, Heading2, Heading3 } from 'lucide-react';
import SeoGainsPanel from './SeoGainsPanel';

const countH = (text, level) =>
  (text.match(level === 2 ? /^## .+/gm : /^### .+/gm) || []).length;

const HeadingStats = ({ text }) => (
  <div className="flex items-center gap-2">
    <Badge variant="secondary" className="gap-1"><Heading2 className="w-3 h-3" />{countH(text, 2)} H2</Badge>
    <Badge variant="outline" className="gap-1"><Heading3 className="w-3 h-3" />{countH(text, 3)} H3</Badge>
  </div>
);

const highlight = (text) =>
  text.split('\n').map((line, i) => {
    const isH2 = /^## /.test(line);
    const isH3 = /^### /.test(line);
    return (
      <div
        key={i}
        className={
          isH2
            ? 'bg-blue-50 text-blue-900 font-semibold px-1 rounded'
            : isH3
            ? 'bg-amber-50 text-amber-900 font-medium px-1 rounded'
            : ''
        }
      >
        {line || '\u00A0'}
      </div>
    );
  });

export default function ContentDiffDialog({ open, title, before, after, analysis, onApply, onCancel }) {
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onCancel()}>
      <DialogContent className="max-w-5xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        {analysis &&
          <SeoGainsPanel verdict={analysis.verdict} summary={analysis.summary} gains={analysis.gains} />
        }
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-sm font-semibold text-gray-600">Avant</span>
              <HeadingStats text={before} />
            </div>
            <div className="h-[50vh] overflow-auto rounded-lg border bg-gray-50 p-3 font-mono text-xs leading-relaxed">
              {highlight(before)}
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-sm font-semibold text-green-700">Après</span>
              <HeadingStats text={after} />
            </div>
            <div className="h-[50vh] overflow-auto rounded-lg border border-green-200 bg-green-50/40 p-3 font-mono text-xs leading-relaxed">
              {highlight(after)}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onCancel}>
            <X className="w-4 h-4" /> Garder l'ancienne version
          </Button>
          <Button onClick={onApply} className="bg-green-600 text-white hover:bg-green-700">
            <Check className="w-4 h-4" /> Appliquer les changements
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}