import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Sparkles, Loader2 } from 'lucide-react';

export default function ArticleGeneratorForm({ onGenerate, isGenerating }) {
  const [keyword, setKeyword] = useState('');
  const [brief, setBrief] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!keyword.trim()) return;
    onGenerate(keyword.trim(), brief.trim());
  };

  return (
    <Card className="border-yellow-200 bg-gradient-to-br from-yellow-50 to-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Sparkles className="w-5 h-5 text-yellow-600" />
          Générer un nouvel article SEO
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="keyword">Mot-clé principal *</Label>
            <Input
              id="keyword"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="ex : démarches administratives PME belge"
              disabled={isGenerating}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="brief">Consignes supplémentaires (optionnel)</Label>
            <Textarea
              id="brief"
              value={brief}
              onChange={(e) => setBrief(e.target.value)}
              placeholder="ex : cibler les indépendants wallons, insister sur les délais de recours…"
              rows={3}
              disabled={isGenerating}
            />
          </div>
          <Button
            type="submit"
            disabled={isGenerating || !keyword.trim()}
            className="w-full bg-yellow-500 hover:bg-yellow-600 text-white"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Rédaction en cours (1 à 2 minutes)…
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Générer l'article
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}