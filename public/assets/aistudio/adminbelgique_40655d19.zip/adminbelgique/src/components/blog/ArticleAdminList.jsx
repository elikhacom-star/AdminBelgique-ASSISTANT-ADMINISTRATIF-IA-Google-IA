import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { Pencil, Trash2, ExternalLink, FileText, ArrowUp, ArrowDown } from 'lucide-react';

export default function ArticleAdminList({ articles, onEdit, onDelete, onTogglePublish, onMove }) {
  if (articles.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-gray-500">
          <FileText className="mx-auto mb-3 h-10 w-10 text-gray-300" />
          Aucun article pour le moment. Générez votre premier article ci-dessus.
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Articles ({articles.length})</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-xs text-gray-500">
          Utilisez les flèches pour changer l'ordre d'affichage sur la page Blog publique (le premier de la liste apparaît en premier).
        </p>
        {articles.map((article, index) => (
          <div key={article.id} className="flex flex-col gap-3 rounded-lg border p-3 sm:flex-row sm:items-center">
            <div className="flex shrink-0 gap-1 sm:flex-col">
              <Button size="icon" variant="outline" className="h-7 w-7" disabled={index === 0} onClick={() => onMove(index, -1)} title="Monter">
                <ArrowUp className="h-3.5 w-3.5" />
              </Button>
              <Button size="icon" variant="outline" className="h-7 w-7" disabled={index === articles.length - 1} onClick={() => onMove(index, 1)} title="Descendre">
                <ArrowDown className="h-3.5 w-3.5" />
              </Button>
            </div>
            <div className="min-w-0 flex-1">
              <div className="mb-1 flex flex-wrap items-center gap-2">
                {article.published ? (
                  <Badge className="bg-green-100 text-green-800">Publié</Badge>
                ) : (
                  <Badge variant="secondary">Brouillon</Badge>
                )}
                {article.category && <Badge variant="outline">{article.category}</Badge>}
                {article.read_time && <span className="text-xs text-gray-500">{article.read_time}</span>}
              </div>
              <p className="truncate font-medium text-gray-900">{article.title}</p>
              <p className="truncate text-xs text-gray-500">/blog/{article.slug}</p>
            </div>
            <div className="flex shrink-0 flex-wrap gap-2">
              <Button size="sm" variant="outline" asChild>
                <Link to={`/blog/${article.slug}`}>
                  <ExternalLink className="h-4 w-4" />
                </Link>
              </Button>
              <Button size="sm" variant="outline" onClick={() => onEdit(article)}>
                <Pencil className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="outline" onClick={() => onTogglePublish(article)}>
                {article.published ? 'Dépublier' : 'Publier'}
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="text-red-600 hover:bg-red-50"
                onClick={() => onDelete(article)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}