import React from 'react';
import { AlertTriangle, Scale, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';

const items = [
  {
    label: '🚨 Urgence Papiers',
    value: "Urgence papiers perdus en Belgique : j'ai perdu mes documents, aide-moi immédiatement.",
    icon: AlertTriangle
  },
  {
    label: '⚖️ Contester une amende',
    value: 'Je veux contester une amende disproportionnée en Belgique.',
    icon: Scale
  },
  {
    label: '🏠 Problème de bail',
    value: 'J’ai un problème urgent de bail ou de logement en Belgique.',
    icon: Home
  }
];

export default function EmergencyQuickReplies({ onSelect }) {
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <Button
            key={item.label}
            type="button"
            variant="outline"
            onClick={() => onSelect(item.value)}
            className="rounded-full border-red-200 bg-red-50 text-red-700 hover:bg-red-100 hover:text-red-800"
          >
            <Icon className="w-4 h-4" />
            {item.label}
          </Button>
        );
      })}
    </div>
  );
}