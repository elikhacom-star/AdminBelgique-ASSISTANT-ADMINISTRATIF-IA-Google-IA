import React, { useState } from 'react';
import { Siren, ChevronDown, ChevronUp, X, Phone, Link as LinkIcon, ExternalLink, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { sanitizeActionUrl } from '@/lib/sanitizeUrl';

export default function PinnedEmergencyBar({ data, onDismiss }) {
  const [expanded, setExpanded] = useState(false);

  if (!data || data.status !== 'EMERGENCY_ACTIVE') return null;

  const { immediate_action, document_draft, steps, breadcrumb, branding_phrase } = data;
  const isPhone = immediate_action?.type === 'phone';
  const safeHref = sanitizeActionUrl(immediate_action?.value);
  const actionProps = isPhone
    ? { href: safeHref }
    : { href: safeHref, target: '_blank', rel: 'noopener noreferrer' };

  // Extract a short label from breadcrumb (last segment)
  const shortLabel = breadcrumb ? breadcrumb.split('>').pop().trim() : 'Urgence active';

  return (
    <div className="sticky top-0 z-10 mb-3 rounded-xl border border-red-200 bg-gradient-to-r from-red-50 to-white shadow-sm overflow-hidden">
      {/* Compact bar — always visible */}
      <div className="flex items-center gap-2 px-3 py-2">
        <Siren className="w-4 h-4 text-red-600 shrink-0" />
        <span className="text-sm font-semibold text-red-700 truncate flex-1">
          🚨 {shortLabel}
        </span>
        {immediate_action && (
          <a {...actionProps} className="shrink-0" aria-label={immediate_action.label}>
            <Button size="sm" className="h-7 px-2 py-0 text-xs bg-red-600 hover:bg-red-700 text-white gap-1">
              {isPhone ? <Phone className="w-3 h-3" /> : <LinkIcon className="w-3 h-3" />}
              <span className="hidden sm:inline">{isPhone ? 'Appeler' : 'Agir'}</span>
            </Button>
          </a>
        )}
        <button
          onClick={() => setExpanded((v) => !v)}
          className="shrink-0 w-7 h-7 flex items-center justify-center rounded-md hover:bg-red-100 text-red-600"
          aria-label={expanded ? 'Réduire' : 'Voir détails'}
        >
          {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
        {onDismiss && (
          <button
            onClick={onDismiss}
            className="shrink-0 w-7 h-7 flex items-center justify-center rounded-md hover:bg-red-100 text-red-600"
            aria-label="Fermer"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Expanded details — only when expanded */}
      {expanded && (
        <div className="px-3 pb-3 space-y-3 border-t border-red-100">
          {steps?.length > 0 && (
            <div>
              <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-red-700">Priorités des 24h</p>
              <ul className="space-y-1.5 text-sm text-slate-700">
                {steps.map((step, index) => (
                  <li key={index} className="flex gap-2">
                    <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-red-100 text-[10px] font-bold text-red-700">
                      {index + 1}
                    </span>
                    <span>{step}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {document_draft && (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-2.5">
              <div className="flex items-start gap-2">
                <FileText className="mt-0.5 h-3.5 w-3.5 text-amber-700 shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-amber-900">{document_draft.title}</p>
                  <p className="text-xs text-amber-800">Modèle prêt à lancer depuis AdminBelgique.</p>
                </div>
              </div>
            </div>
          )}

          {branding_phrase && <p className="text-xs font-semibold italic text-red-800">{branding_phrase}</p>}
        </div>
      )}
    </div>
  );
}