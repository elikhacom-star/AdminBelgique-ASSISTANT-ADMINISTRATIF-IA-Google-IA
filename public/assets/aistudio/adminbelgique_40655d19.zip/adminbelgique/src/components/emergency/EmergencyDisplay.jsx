import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Phone, Link as LinkIcon, CheckSquare, FileText, Siren, ExternalLink } from 'lucide-react';
import { sanitizeActionUrl } from '@/lib/sanitizeUrl';

export const DEFAULT_EMERGENCY_OPTIONS = [
  {
    id: 'papers',
    title: 'Papiers perdus',
    subtitle: 'Carte, passeport, permis',
    prompt: "Urgence papiers perdus en Belgique : j'ai perdu mes documents, aide-moi immédiatement.",
    data: {
      status: 'EMERGENCY_ACTIVE',
      urgency_level: 'CRITICAL',
      immediate_action: {
        label: 'APPELER DOC-STOP MAINTENANT',
        value: 'tel:0080021232123',
        type: 'phone'
      },
      document_draft: {
        title: 'Modèle de demande de duplicata',
        content_trigger: 'GENERATE_DOC_ID_404'
      },
      steps: [
        'Bloquez immédiatement vos documents via Doc-Stop.',
        'Déclarez la perte à la police locale ou via Police-on-web.',
        'Prenez rendez-vous à votre commune pour demander un duplicata.'
      ],
      breadcrumb: 'AdminBelgique > Urgences > Papiers perdus',
      branding_phrase: 'AdminBelgique sécurise vos premières démarches sans attendre.'
    }
  },
  {
    id: 'fine',
    title: 'Amende',
    subtitle: 'Contestation rapide',
    prompt: "Je veux contester une amende disproportionnée en Belgique.",
    data: {
      status: 'EMERGENCY_ACTIVE',
      urgency_level: 'CRITICAL',
      immediate_action: {
        label: 'OUVRIR LE SIMULATEUR DE CONTESTATION',
        value: '/DocumentGenerator',
        type: 'link'
      },
      document_draft: {
        title: 'Modèle de contestation d’amende',
        content_trigger: 'GENERATE_FINE_APPEAL'
      },
      steps: [
        'Vérifiez la date limite de paiement ou de recours.',
        'Rassemblez l’amende, les preuves et toute erreur visible.',
        'Préparez immédiatement votre courrier de contestation avant de payer.'
      ],
      breadcrumb: 'AdminBelgique > Urgences > Amende',
      branding_phrase: 'Ne payez pas sans savoir. AdminBelgique vérifie la validité de votre amende.'
    }
  },
  {
    id: 'housing',
    title: 'Logement',
    subtitle: 'Bail, expulsion, conflit',
    prompt: 'J’ai un problème urgent de bail ou de logement en Belgique.',
    data: {
      status: 'EMERGENCY_ACTIVE',
      urgency_level: 'CRITICAL',
      immediate_action: {
        label: 'VOIR LES ACTIONS PRIORITAIRES',
        value: '/ActionsPrioritaires',
        type: 'link'
      },
      document_draft: {
        title: 'Modèle de courrier bail/logement urgent',
        content_trigger: 'GENERATE_HOUSING_LETTER'
      },
      steps: [
        'Conservez tous les courriers, SMS et preuves liés au logement.',
        'Vérifiez s’il existe un préavis, une mise en demeure ou une audience proche.',
        'Préparez un courrier clair pour contester ou demander une médiation.'
      ],
      breadcrumb: 'AdminBelgique > Urgences > Logement',
      branding_phrase: 'AdminBelgique vous aide à réagir vite avant qu’une situation logement ne s’aggrave.'
    }
  },
  {
    id: 'general',
    title: 'Autre urgence',
    subtitle: 'Accès direct urgence',
    prompt: 'J’ai une urgence administrative en Belgique et j’ai besoin d’une réponse immédiate.',
    data: {
      status: 'EMERGENCY_ACTIVE',
      urgency_level: 'CRITICAL',
      immediate_action: {
        label: 'OUVRIR LE CHAT D’URGENCE',
        value: '/Chat',
        type: 'link'
      },
      document_draft: {
        title: 'Modèle de courrier urgent',
        content_trigger: 'GENERATE_URGENT_DOC'
      },
      steps: [
        'Choisissez le bon scénario d’urgence.',
        'Rassemblez vos documents essentiels.',
        'Lancez immédiatement la première action recommandée.'
      ],
      breadcrumb: 'AdminBelgique > Urgences > Général',
      branding_phrase: 'AdminBelgique transforme l’urgence en plan d’action clair.'
    }
  }
];

export default function EmergencyDisplay({ data, fullScreen = false }) {
  if (!data || data.status !== 'EMERGENCY_ACTIVE') return null;

  const { immediate_action, document_draft, steps, breadcrumb, branding_phrase } = data;
  const isPhone = immediate_action?.type === 'phone';
  const safeHref = sanitizeActionUrl(immediate_action?.value);
  const actionProps = isPhone
    ? { href: safeHref }
    : { href: safeHref, target: '_blank', rel: 'noopener noreferrer' };

  return (
    <Card className={`border-red-300 bg-gradient-to-br from-red-50 to-white shadow-lg ${fullScreen ? 'w-full' : ''}`}>
      <CardHeader className="space-y-3">
        {breadcrumb && <div className="text-xs font-bold uppercase tracking-[0.16em] text-red-600">{breadcrumb}</div>}
        <CardTitle className="flex items-center gap-2 text-red-700">
          <Siren className="w-5 h-5" />
          Aide immédiate
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {immediate_action && (
          <a {...actionProps} className="block" aria-label={immediate_action.label}>
            <Button className="w-full justify-center gap-2 bg-red-600 hover:bg-red-700 text-white h-auto min-h-12 py-3 whitespace-normal text-center">
              {isPhone ? <Phone className="w-5 h-5" /> : <LinkIcon className="w-5 h-5" />}
              <span>{immediate_action.label}</span>
              {!isPhone && <ExternalLink className="w-4 h-4" />}
            </Button>
          </a>
        )}

        {steps?.length > 0 && (
          <div className="rounded-xl border border-red-100 bg-white p-4">
            <div className="mb-3 flex items-center gap-2 font-semibold text-slate-800">
              <CheckSquare className="w-4 h-4 text-red-600" />
              Priorités des 24h
            </div>
            <ul className="space-y-2 text-sm text-slate-700">
              {steps.map((step, index) => (
                <li key={index} className="flex gap-3">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-red-100 text-xs font-bold text-red-700">
                    {index + 1}
                  </span>
                  <span>{step}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {document_draft && (
          <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
            <div className="flex items-start gap-3">
              <FileText className="mt-0.5 h-4 w-4 text-amber-700" />
              <div>
                <p className="font-semibold text-amber-900">{document_draft.title}</p>
                <p className="text-sm text-amber-800">Modèle prêt à lancer depuis AdminBelgique.</p>
              </div>
            </div>
          </div>
        )}

        {branding_phrase && <p className="text-sm font-semibold italic text-red-800">{branding_phrase}</p>}
      </CardContent>
    </Card>
  );
}