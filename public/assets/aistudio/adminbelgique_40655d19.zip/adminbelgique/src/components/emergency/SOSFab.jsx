import React from 'react';
import { Link } from 'react-router-dom';
import { Siren } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function SOSFab() {
  return (
    <Link to="/urgence" className="fixed bottom-24 right-4 z-50 md:bottom-6 md:right-6">
      <Button className="h-14 rounded-full bg-red-600 px-5 text-white shadow-xl hover:bg-red-700">
        <Siren className="w-5 h-5" />
        SOS Urgences
      </Button>
    </Link>
  );
}