import React, { useState } from "react";
import { Link } from "react-router-dom";

const COLUMNS = [
  {
    icon: "📁",
    title: "adminbelgique.com",
    subtitle: "Assistance Administrative",
    links: [
      { label: "Assistant IA", desc: "Réponses à vos questions administratives", href: "/Assistant" },
      { label: "Générateur de documents", desc: "Courriers & formalités", href: "/DocumentGenerator" },
      { label: "Tableau de bord", desc: "Gestion quotidienne de vos démarches", href: "/Dashboard" }
    ]
  },
  {
    icon: "🏠",
    title: "ImmoBoost App Immo",
    subtitle: "Immo",
    links: [
      { label: "ImmoBoost AI", desc: "Publiez & suivez vos annonces", href: "/ImmoBoost" },
      { label: "ImmoScrap Pro", desc: "Recherche multiplateformes immobilier", href: "/ImmoBoostScrap" },
      { label: "Fiduciaires AI", desc: "Fiscalité & comptabilité", href: "/FiduciaireAI" }
    ]
  },
  {
    icon: "⚖️",
    title: "JuristAssist",
    subtitle: "Juridique",
    links: [
      { label: "Modèles de contrats", desc: "Rédaction & relecture", href: "/Templates" },
      { label: "Analyse de documents", desc: "Accompagnement juridique", href: "/DocumentAnalyzer" },
      { label: "Conseil IA", desc: "Conseil expert & stratégie", href: "/Chat" }
    ]
  }
];

const MENU_ITEMS = [
  { label: "Accueil", href: "/" },
  { label: "Services", mega: true },
  { label: "Solutions", href: "/BelgianServices" },
  { label: "Tarifs", href: "/Pricing" },
  { label: "Ressources", href: "/Blog" },
  { label: "À propos", href: "/About" }
];

export default function ElikaccesMegaMenu() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [megaOpen, setMegaOpen] = useState(false);
  const close = () => {
    setMenuOpen(false);
    setMegaOpen(false);
  };

  return (
    <nav className="elika-nav">
      <div className="elika-container">
        <Link to="/" className="elika-logo" onClick={close} aria-label="Retour à l'accueil">
          <span className="elika-hex">e</span>
          <div>
            <strong>elikacces</strong>
            <small>IT Solutions · maison mère</small>
          </div>
        </Link>

        <button
          type="button"
          className="elika-burger"
          aria-label="Ouvrir le menu"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((v) => !v)}
        >
          ☰
        </button>

        <ul className={`elika-menu ${menuOpen ? "elika-menu-open" : ""}`}>
          {MENU_ITEMS.map((item) =>
            item.mega ? (
              <li key={item.label} className="elika-has-mega">
                <button
                  type="button"
                  className="elika-trigger"
                  aria-expanded={megaOpen}
                  aria-haspopup="true"
                  onClick={() => setMegaOpen((v) => !v)}
                >
                  {item.label} ▾
                </button>
                <div className={`elika-mega ${megaOpen ? "elika-mega-open" : ""}`}>
                  {COLUMNS.map((col) => (
                    <div key={col.title} className="elika-col">
                      <h4>
                        <span>{col.icon}</span> {col.title}
                        <br />
                        <small>{col.subtitle}</small>
                      </h4>
                      {col.links.map((link) => (
                        <Link key={link.label} to={link.href} onClick={close}>
                          <b>{link.label}</b>
                          <span>{link.desc}</span>
                        </Link>
                      ))}
                    </div>
                  ))}
                  <div className="elika-mega-footer">
                    <span>Besoin d'un accompagnement sur-mesure ?</span>
                    <Link className="elika-btn-outline" to="/Services" onClick={close}>
                      Découvrir tous les services →
                    </Link>
                  </div>
                </div>
              </li>
            ) : (
              <li key={item.label}>
                <Link to={item.href} onClick={close}>{item.label}</Link>
              </li>
            )
          )}
        </ul>

        <a className="elika-contact" href="tel:+32467801041">
          📞 Contact
          <br />
          <small>+32 467 80 10 41</small>
        </a>
      </div>

      <style>{`
        .elika-nav{background:#0B1E36;color:#fff;padding:15px 0;font-family:Inter,sans-serif;position:relative}
        .elika-container{max-width:1250px;margin:auto;display:flex;align-items:center;justify-content:space-between;padding:0 20px;gap:16px;flex-wrap:wrap}
        .elika-logo{display:flex;align-items:center;gap:10px;text-decoration:none}
        .elika-logo strong{font-size:26px;line-height:1.1;display:block;color:#fff}
        .elika-logo small{color:#D4AF37;display:block;font-size:13px}
        .elika-hex{width:48px;height:48px;background:linear-gradient(#D4AF37,#B8962E);display:grid;place-items:center;font-weight:800;font-size:28px;color:#0B1E36;clip-path:polygon(25% 0,75% 0,100% 50%,75% 100%,25% 100%,0 50%);flex-shrink:0}
        .elika-menu{list-style:none;display:flex;gap:28px;margin:0;padding:0}
        .elika-menu a,.elika-trigger{color:#fff;text-decoration:none;font-size:15px}
        .elika-trigger{background:transparent;border:0;font-family:inherit;cursor:pointer;padding:0}
        .elika-burger{display:none;background:transparent;border:0;color:#fff;font-size:26px;cursor:pointer;padding:4px 10px}
        .elika-has-mega:hover .elika-mega{display:grid}
        .elika-mega{position:absolute;left:50%;top:100%;transform:translateX(-50%);width:92%;max-width:1150px;background:#fff;color:#111;display:none;grid-template-columns:1fr 1fr 1fr;border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.2);overflow:hidden;z-index:99}
        .elika-mega.elika-mega-open{display:grid}
        .elika-col{padding:26px;border-right:1px solid #eee}
        .elika-col:last-of-type{border:none}
        .elika-col h4{margin:0 0 18px;line-height:1.2;font-size:17px;color:#111;font-weight:700}
        .elika-col h4 small{color:#8B7D6B;font-weight:400}
        .elika-col a{display:block;padding:12px 0;text-decoration:none;color:#111;border-bottom:1px solid #f5f5f5}
        .elika-col a b{display:block}
        .elika-col a span{font-size:13px;color:#666}
        .elika-mega-footer{grid-column:1/-1;background:linear-gradient(90deg,#EDE8DC,#C8D8F0);display:flex;justify-content:space-between;align-items:center;padding:16px 26px;gap:12px;flex-wrap:wrap}
        .elika-btn-outline{border:1.5px solid #D4AF37;padding:10px 18px;border-radius:24px;color:#111;text-decoration:none}
        .elika-contact{background:#FF7A18;color:#fff;padding:10px 18px;border-radius:12px;text-decoration:none;line-height:1.1;text-align:center;font-weight:600}
        .elika-contact small{font-size:13px;font-weight:400}
        @media(max-width:900px){
          .elika-burger{display:block}
          .elika-menu{display:none;flex-direction:column;gap:6px;width:100%;order:3}
          .elika-menu.elika-menu-open{display:flex}
          .elika-has-mega:hover .elika-mega{display:none}
          .elika-mega{position:static;transform:none;width:100%;max-width:none;grid-template-columns:1fr;box-shadow:none;border-radius:12px;margin-top:8px}
          .elika-mega.elika-mega-open{display:grid}
          .elika-col{border-right:none;border-bottom:1px solid #eee}
          .elika-col a{padding:10px 0}
        }
      `}</style>
    </nav>
  );
}