import React, { useEffect } from "react";
import { useForm, Controller } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";
import { motion } from "framer-motion";

export default function DemarcheForm({ demarche, onSubmit, onCancel }) {
    const { register, handleSubmit, control, reset, setValue, watch, formState: { errors } } = useForm({
        defaultValues: demarche || {
            title: "",
            category: "finances",
            status: "a_faire",
            due_date: null,
            description: ""
        }
    });
    
    const dueDate = watch("due_date");

    useEffect(() => {
        reset(demarche || {
            title: "",
            category: "finances",
            status: "a_faire",
            due_date: null,
            description: ""
        });
    }, [demarche, reset]);

    const handleFormSubmit = (data) => {
        onSubmit(data);
    };

    return (
        <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white rounded-xl shadow-lg p-6 mb-8 border"
        >
            <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
                <h3 className="text-lg font-semibold">{demarche ? "Modifier la démarche" : "Nouvelle démarche"}</h3>
                <div>
                    <Label htmlFor="title">Titre *</Label>
                    <Input id="title" {...register("title", { required: "Le titre est requis" })} />
                    {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title.message}</p>}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <Label htmlFor="category">Catégorie *</Label>
                        <Controller name="category" control={control} render={({ field }) => (
                            <Select onValueChange={field.onChange} value={field.value}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="finances">Finances</SelectItem>
                                    <SelectItem value="emploi">Emploi</SelectItem>
                                    <SelectItem value="sante">Santé</SelectItem>
                                    <SelectItem value="logement">Logement</SelectItem>
                                    <SelectItem value="famille">Famille</SelectItem>
                                    <SelectItem value="identite">Identité</SelectItem>
                                </SelectContent>
                            </Select>
                        )} />
                    </div>
                     <div>
                        <Label htmlFor="status">Statut *</Label>
                        <Controller name="status" control={control} render={({ field }) => (
                            <Select onValueChange={field.onChange} value={field.value}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="a_faire">À faire</SelectItem>
                                    <SelectItem value="en_cours">En cours</SelectItem>
                                    <SelectItem value="termine">Terminé</SelectItem>
                                </SelectContent>
                            </Select>
                        )} />
                    </div>
                </div>

                 <div>
                    <Label>Date d'échéance</Label>
                    <Controller name="due_date" control={control} render={({ field }) => (
                         <Popover>
                            <PopoverTrigger asChild>
                                <Button variant="outline" className="w-full justify-start text-left font-normal">
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {dueDate ? format(new Date(dueDate), 'PPP') : 'Sélectionner une date'}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                                <Calendar mode="single" selected={dueDate ? new Date(dueDate) : null} onSelect={field.onChange} initialFocus />
                            </PopoverContent>
                        </Popover>
                    )} />
                </div>
                
                <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea id="description" {...register("description")} />
                </div>

                <div className="flex justify-end gap-3 pt-4">
                    <Button type="button" variant="outline" onClick={onCancel}>Annuler</Button>
                    <Button type="submit">{demarche ? 'Modifier' : 'Créer'}</Button>
                </div>
            </form>
        </motion.div>
    );
}