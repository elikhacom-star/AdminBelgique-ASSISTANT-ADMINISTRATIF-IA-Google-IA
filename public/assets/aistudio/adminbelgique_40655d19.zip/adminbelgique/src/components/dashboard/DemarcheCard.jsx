import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { format, differenceInDays, isPast } from "date-fns";
import { fr } from "date-fns/locale";
import { Calendar, AlertTriangle } from "lucide-react";

export default function DemarcheCard({ demarche, onEdit }) {
  const statusConfig = {
    a_faire: { label: "À faire", color: "bg-orange-100 text-orange-800", progress: 10, variant: "destructive" },
    en_cours: { label: "En cours", color: "bg-blue-100 text-blue-800", progress: 50, variant: "default" },
    termine: { label: "Terminé", color: "bg-green-100 text-green-800", progress: 100, variant: "secondary" },
  };

  const categoryConfig = {
    finances: "Finances",
    emploi: "Emploi",
    sante: "Santé",
    logement: "Logement",
    famille: "Famille",
    identite: "Identité",
  };
  
  const config = statusConfig[demarche.status];
  const daysLeft = demarche.due_date ? differenceInDays(new Date(demarche.due_date), new Date()) : null;
  const isOverdue = demarche.due_date && isPast(new Date(demarche.due_date)) && demarche.status !== 'termine';

  return (
    <Card className="flex flex-col h-full">
      <CardHeader>
        <div className="flex justify-between items-start gap-2">
          <CardTitle className="text-lg">{demarche.title}</CardTitle>
          <Badge className={config.color}>{config.label}</Badge>
        </div>
        <CardDescription>{categoryConfig[demarche.category] || demarche.category}</CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-sm text-gray-600 mb-4">{demarche.description}</p>
        <div className="space-y-2">
          <Progress value={config.progress} />
          {demarche.due_date && (
            <div className={`flex items-center gap-2 text-sm ${isOverdue ? "text-red-600" : "text-gray-500"}`}>
              <Calendar className="w-4 h-4" />
              <span>Échéance : {format(new Date(demarche.due_date), 'd MMMM yyyy', { locale: fr })}</span>
            </div>
          )}
          {isOverdue && (
            <div className="flex items-center gap-2 text-xs text-red-700 p-2 bg-red-50 rounded-md">
              <AlertTriangle className="w-4 h-4" />
              <span>Cette démarche est en retard de {-daysLeft} jour(s).</span>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter>
        <Button className="w-full" onClick={() => onEdit(demarche)}>Ouvrir la démarche</Button>
      </CardFooter>
    </Card>
  );
}