import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, AlertCircle, Clock } from "lucide-react";

export default function SummaryStats({ stats }) {
  const statItems = [
    {
      title: "Démarches en cours",
      value: stats.inProgress,
      icon: Clock,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      title: "Actions requises",
      value: stats.toDo,
      icon: AlertCircle,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
    },
    {
      title: "Démarches terminées",
      value: stats.completed,
      icon: CheckCircle,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {statItems.map((item, index) => (
        <Card key={index}>
          <CardContent className="p-4 flex items-center gap-4">
            <div className={`p-3 rounded-lg ${item.bgColor}`}>
              <item.icon className={`w-6 h-6 ${item.color}`} />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{item.value}</p>
              <p className="text-sm font-medium text-gray-500">{item.title}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}