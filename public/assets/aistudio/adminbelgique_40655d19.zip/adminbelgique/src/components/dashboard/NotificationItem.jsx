import React from "react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Bell, Info, AlertTriangle, X } from "lucide-react";
import { Link } from "react-router-dom";

export default function NotificationItem({ notification, onDismiss }) {
  const iconConfig = {
    deadline: { icon: Bell, color: "text-red-600" },
    info: { icon: Info, color: "text-blue-600" },
    action_requise: { icon: AlertTriangle, color: "text-orange-600" },
    securite: { icon: AlertTriangle, color: "text-yellow-600" },
  };

  const Icon = iconConfig[notification.type]?.icon || Bell;
  const color = iconConfig[notification.type]?.color || "text-gray-600";

  return (
    <Alert className="relative pr-12">
      <Icon className={`h-4 w-4 ${color}`} />
      <AlertTitle className="font-semibold">{notification.title}</AlertTitle>
      <AlertDescription>
        {notification.description}
        {notification.link && (
          <Button asChild variant="link" className="p-0 h-auto ml-2">
            <Link to={notification.link}>Voir détails</Link>
          </Button>
        )}
      </AlertDescription>
      <Button
        variant="ghost"
        size="icon"
        className="absolute top-2 right-2 h-6 w-6"
        onClick={() => onDismiss(notification.id)}
      >
        <X className="w-4 h-4" />
      </Button>
    </Alert>
  );
}