import React from "react";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, AlertTriangle, Globe } from "lucide-react";

const formatDate = (value) => {
  if (!value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return null;
  return date.toLocaleDateString("fr-BE", { day: "2-digit", month: "2-digit", year: "numeric" });
};

export default function VerificationBadges({ property }) {
  const verifiedDate = formatDate(property?.verified_at);
  const publishedRaw = typeof property?.published_date === "string" ? property.published_date.trim() : "";
  const published = publishedRaw && !/^(n\/?a|non communiqué|-)$/i.test(publishedRaw) ? publishedRaw : null;
  const confirmed = Array.isArray(property?.confirmed_fields) ? property.confirmed_fields : [];
  const missing = Array.isArray(property?.missing_fields) ? property.missing_fields : [];
  const hasFieldInfo = confirmed.length > 0 || missing.length > 0;

  return (
    <div className="space-y-1.5">
      <div className="flex flex-wrap items-center gap-2">
        {property?.verified ? (
          <Badge className="bg-green-100 text-green-800 border border-green-200 gap-1">
            <CheckCircle2 className="w-3 h-3" /> Annonce vérifiée
          </Badge>
        ) : (
          <Badge className="bg-amber-100 text-amber-900 border border-amber-200 gap-1">
            <AlertTriangle className="w-3 h-3" /> À reconfirmer
          </Badge>
        )}
        {property?.source && (
          <Badge variant="secondary" className="gap-1">
            <Globe className="w-3 h-3" /> {property.source}
          </Badge>
        )}
        {property?.verified && verifiedDate && (
          <span className="text-xs text-gray-500">Contrôlée le {verifiedDate}</span>
        )}
        {published && <span className="text-xs text-gray-500">Publiée : {published}</span>}
      </div>

      {hasFieldInfo && (
        <p className="text-xs text-gray-500">
          {confirmed.length > 0 && (
            <>
              Confirmé : <span className="font-medium text-gray-700">{confirmed.join(", ")}</span>
            </>
          )}
          {confirmed.length > 0 && missing.length > 0 && " • "}
          {missing.length > 0 && (
            <>
              Non communiqué : <span className="text-amber-700">{missing.join(", ")}</span>
            </>
          )}
        </p>
      )}
    </div>
  );
}