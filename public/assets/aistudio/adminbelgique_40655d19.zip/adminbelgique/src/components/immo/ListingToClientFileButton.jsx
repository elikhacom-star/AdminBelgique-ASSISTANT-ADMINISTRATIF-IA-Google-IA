import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { FolderInput, Loader2 } from "lucide-react";
import { convertListingToClientFile } from "@/lib/listingToClientFile";

export default function ListingToClientFileButton({ property, client, onClientUpdated }) {
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);

  const handleClick = async () => {
    if (!client?.id) return;
    setBusy(true);
    try {
      const updated = await convertListingToClientFile(property, client);
      if (onClientUpdated) onClientUpdated(updated);
      navigate("/DocumentGenerator");
    } catch (error) {
      alert(error?.message || "Impossible de créer la fiche client.");
      setBusy(false);
    }
  };

  return (
    <Button
      size="sm"
      variant="outline"
      className="w-full border-purple-300 text-purple-800 hover:bg-purple-50"
      disabled={busy}
      onClick={handleClick}
    >
      {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FolderInput className="w-4 h-4 mr-2" />}
      Créer la fiche client + documents
    </Button>
  );
}