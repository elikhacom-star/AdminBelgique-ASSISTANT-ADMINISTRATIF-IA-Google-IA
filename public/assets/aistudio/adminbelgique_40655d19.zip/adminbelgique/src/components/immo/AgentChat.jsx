import React, { useState, useEffect, useRef, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Send, Rocket } from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function AgentChat({
  agentName,
  title,
  subtitle,
  accentColor = "blue",
  onConversationCreated,
  onMessagesUpdate,
  initialMessage,
  onPropelToMarketing,
  propelLabel = "Propulser en Marketing",
  placeholder = "Écrivez votre message..."
}) {
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState(null);
  const messagesEndRef = useRef(null);
  const initialMessageSent = useRef(false);

  const accentClasses = {
    blue: { bg: "bg-blue-50", border: "border-blue-200", text: "text-blue-800", btn: "bg-blue-600 hover:bg-blue-700" },
    purple: { bg: "bg-purple-50", border: "border-purple-200", text: "text-purple-800", btn: "bg-purple-600 hover:bg-purple-700" },
    emerald: { bg: "bg-emerald-50", border: "border-emerald-200", text: "text-emerald-800", btn: "bg-emerald-600 hover:bg-emerald-700" }
  };
  const c = accentClasses[accentColor] || accentClasses.blue;

  useEffect(() => {
    let unsub = null;
    const init = async () => {
      try {
        const conv = await base44.agents.createConversation({
          agent_name: agentName,
          metadata: { name: title || agentName }
        });
        setConversation(conv);
        onConversationCreated?.(conv);

        // 🔧 FIX : on s'abonne AVANT d'envoyer le message initial, pour ne pas
        // rater la réponse de l'agent si elle arrive avant que l'abonnement
        // ne soit actif (cause du bug "il faut taper soi-même pour voir la réponse").
        unsub = base44.agents.subscribeToConversation(conv.id, (data) => {
          const msgs = data.messages || [];
          setMessages(msgs);
          onMessagesUpdate?.(msgs);
        });

        if (initialMessage && !initialMessageSent.current) {
          initialMessageSent.current = true;
          setIsSending(true);
          await base44.agents.addMessage(conv, { role: "user", content: initialMessage });
          setIsSending(false);
        }
      } catch (err) {
        setError(err.message || "Erreur lors de l'initialisation du chat");
      }
    };
    init();
    return () => {if (unsub) unsub();};
  }, [agentName]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = useCallback(async () => {
    if (!input.trim() || !conversation || isSending) return;
    const content = input.trim();
    setInput("");
    setIsSending(true);
    setError(null);
    try {
      await base44.agents.addMessage(conversation, { role: "user", content });
    } catch (err) {
      setError(err.message || "Erreur lors de l'envoi");
    } finally {
      setIsSending(false);
    }
  }, [input, conversation, isSending]);

  const hasAssistantResponse = messages.some((m) => m.role === "assistant" && m.content);

  return (
    <Card className={`flex flex-col h-[600px] ${c.border}`}>
      <CardHeader className={`pb-3 ${c.bg} ${c.border} border-b`}>
        <CardTitle className={`flex items-center justify-between ${c.text}`}>
          <div>
            <span className="text-base">{title}</span>
            {subtitle && <p className="text-xs font-normal text-gray-500 mt-0.5">{subtitle}</p>}
          </div>
          {onPropelToMarketing && hasAssistantResponse &&
          <Button
            size="sm"
            onClick={onPropelToMarketing}
            className={`${c.btn} text-white`}
            disabled={isSending}>
            
              <Rocket className="w-4 h-4 mr-1" />
              {propelLabel}
            </Button>
          }
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto space-y-3 pt-4 pr-4 pb-10 pl-6">
        {error &&
        <div className="text-sm text-red-600 bg-red-50 p-2 rounded">{error}</div>
        }
        {messages.length === 0 && !isSending &&
        <div className="text-center text-gray-400 py-12">
            <p className="text-sm">Démarrez une conversation avec l'assistant...</p>
          </div>
        }
        {messages.map((msg, idx) =>
        <div key={idx} className={msg.role === "user" ? "flex justify-end" : "flex justify-start"}>
            <div className={`max-w-[85%] rounded-lg p-3 text-sm ${
          msg.role === "user" ?
          "bg-blue-600 text-white" :
          "bg-gray-100 text-gray-800"}`
          }>
              {msg.role === "user" ?
            <p className="whitespace-pre-wrap">{msg.content}</p> :
            <ReactMarkdown className="prose prose-sm max-w-none">{msg.content || ""}</ReactMarkdown>
            }
              {msg.tool_calls?.map((tc, i) =>
            <div key={i} className="mt-2 text-xs opacity-70 border-t pt-1">
                  🔧 {tc.name} — {tc.status}
                </div>
            )}
            </div>
          </div>
        )}
        {isSending &&
        <div className="flex justify-start">
            <div className="bg-gray-100 rounded-lg p-3">
              <Loader2 className="w-4 h-4 animate-spin text-gray-500" />
            </div>
          </div>
        }
        <div ref={messagesEndRef} />
      </CardContent>
      <div className="p-3 border-t flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSend();
            }
          }}
          placeholder={placeholder}
          disabled={isSending || !conversation} />
        
        <Button onClick={handleSend} disabled={isSending || !input.trim() || !conversation} className={c.btn}>
          {isSending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </Button>
      </div>
    </Card>);

}
