import React, { useState, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Brain, PenTool, Rocket, Info, Lock, Eye, EyeOff, RefreshCw, ExternalLink, TrendingUp } from "lucide-react";
import AgentChat from "@/components/immo/AgentChat";
import { buildMarketingTransfer, formatTransferForMarketing, filterComparables } from "@/lib/marketingTransfer";

export default function ImmoBoostStudioTool() {
  const [activeTab, setActiveTab] = useState("immobilier");
  const [reConversation, setReConversation] = useState(null);
  const [marketingKey, setMarketingKey] = useState(0);
  const [marketingInitialMessage, setMarketingInitialMessage] = useState(null);
  const [transferInfo, setTransferInfo] = useState(null);

  // 🆕 GLASS-BOX : État pour la validation des comparables
  const [allComparables, setAllComparables] = useState([]);
  const [excludedIds, setExcludedIds] = useState([]);
  const [showGlassBox, setShowGlassBox] = useState(false);

  // 🆕 GLASS-BOX : Détection des comparables dans la conversation
  const handleConversationCreated = useCallback((conv) => {
    setReConversation(conv);
    if (conv && conv.messages) {
      const transfer = buildMarketingTransfer(conv.messages);
      setAllComparables(transfer.comparables || []);
    }
  }, []);

  // 🆕 GLASS-BOX : Recalcule les comparables à chaque mise à jour des messages (fix)
  const handleMessagesUpdate = useCallback((messages) => {
    const transfer = buildMarketingTransfer(messages);
    setAllComparables(transfer.comparables || []);
  }, []);

  // 🆕 GLASS-BOX : Toggle d'un comparable
  const toggleComparable = (compId) => {
    setExcludedIds((prev) =>
    prev.includes(compId) ?
    prev.filter((id) => id !== compId) :
    [...prev, compId]
    );
  };

  // 🆕 GLASS-BOX : Tout sélectionner / Tout désélectionner
  const selectAll = () => setExcludedIds([]);
  const deselectAll = () => setExcludedIds(allComparables.map((c) => c.id));

  // 🆕 GLASS-BOX : Recalculer le transfert marketing avec la liste filtrée
  const handlePropelToMarketing = useCallback(async () => {
    if (!reConversation) return;
    try {
      const conv = await base44.agents.getConversation(reConversation.id);
      const rawTransfer = buildMarketingTransfer(conv.messages);

      // 🆕 GLASS-BOX : Filtre les comparables exclus par l'agent
      const filteredTransfer = filterComparables(rawTransfer, excludedIds);

      const formattedMessage = formatTransferForMarketing(filteredTransfer);

      setMarketingInitialMessage(formattedMessage);
      setTransferInfo({
        propertyTitle: filteredTransfer.property?.title || "Bien",
        comparablesCount: filteredTransfer.comparables?.length || 0,
        excludedCount: excludedIds.length,
        timestamp: new Date().toLocaleTimeString("fr-BE")
      });
      setMarketingKey((k) => k + 1);
      setActiveTab("marketing");
    } catch (err) {
      console.error("Erreur transfert marketing:", err);
    }
  }, [reConversation, excludedIds]);

  // 🆕 GLASS-BOX : Statistiques en temps réel
  const selectedCount = allComparables.length - excludedIds.length;
  const avgPrice = allComparables.length > 0 ?
  allComparables.
  filter((c) => !excludedIds.includes(c.id)).
  map((c) => parseInt((c.price || "0").replace(/[^\d]/g, "")) || 0).
  filter((p) => p > 0).
  reduce((a, b) => a + b, 0) /
  Math.max(1, allComparables.filter((c) => !excludedIds.includes(c.id) && parseInt((c.price || "0").replace(/[^\d]/g, "")) > 0).length) :
  0;

  return (
    <div className="space-y-4 pb-20">
      <div className="text-center mb-6 mt-1">
        <h2 className="text-3xl font-bold text-gray-900 flex items-center justify-center gap-3 pb-1 my-2">ImmoBoost AI Studio


        </h2>
        <p className="text-gray-600 mt-2">
          Deux cerveaux IA connectés — estimez, puis propulsez en marketing trilingue.
        </p>
      </div>

      {transferInfo && activeTab === "marketing" &&
      <Alert className="bg-emerald-50 border-emerald-200">
          <Rocket className="w-4 h-4 text-emerald-600" />
          <AlertTitle className="text-emerald-800">Contexte transféré avec succès !</AlertTitle>
          <AlertDescription className="text-emerald-700">
            Bien « {transferInfo.propertyTitle} » — <strong>{transferInfo.comparablesCount} comparables</strong>
            {transferInfo.excludedCount > 0 && <span> ({transferInfo.excludedCount} exclus par l'agent)</span>}
            — transféré à {transferInfo.timestamp}.
            L'assistant marketing a reçu toutes les données techniques et juridiques.
          </AlertDescription>
        </Alert>
      }

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full pb-64 my-24">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="immobilier" className="flex items-center gap-2">
            <Brain className="w-4 h-4" />
            <span className="hidden sm:inline">Assistant Immobilier</span>
            <span className="sm:hidden">Immobilier</span>
          </TabsTrigger>
          <TabsTrigger value="marketing" className="flex items-center gap-2">
            <PenTool className="w-4 h-4" />
            <span className="hidden sm:inline">Assistant Marketing</span>
            <span className="sm:hidden">Marketing</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="immobilier">
          <div className="space-y-4">
            <Alert className="bg-blue-50 border-blue-200">
              <Info className="w-4 h-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                <strong>Étape 1 :</strong> Décrivez un bien à l'assistant immobilier.
                Il extraira 12 comparables, analysera le PEB/EPC et fournira une estimation.
                Cliquez ensuite sur « Propulser en Marketing » pour transférer le contexte.
              </AlertDescription>
            </Alert>
            <AgentChat
              agentName="real_estate_assistant"
              title="🧠 Cerveau Commercial & Juridique"
              subtitle="Estimation • 12 comparables • Analyse PEB/EPC"
              accentColor="blue"
              onConversationCreated={handleConversationCreated}
              onMessagesUpdate={handleMessagesUpdate}
              onPropelToMarketing={handlePropelToMarketing}
              placeholder="Ex: Estimez une maison 3 chambres à Uccle, 120m²..." />
            

            {/* 🆕 GLASS-BOX : Bouton pour afficher la validation des comparables */}
            {allComparables.length > 0 &&
            <div className="mt-4 flex justify-center">
                <Button
                variant="outline"
                onClick={() => setShowGlassBox(!showGlassBox)}
                className="gap-2">
                
                  {showGlassBox ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  {showGlassBox ? "Masquer" : "Valider"} les {allComparables.length} comparables (Glass-Box)
                </Button>
              </div>
            }

            {/* 🆕 GLASS-BOX : Interface de validation des comparables */}
            {showGlassBox && allComparables.length > 0 &&
            <Card className="mt-4 border-2 border-blue-200 bg-blue-50/30">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-blue-900">
                    <Eye className="w-5 h-5" />
                    Glass-Box : Validation des comparables
                  </CardTitle>
                  <p className="text-sm text-gray-600">
                    Cochez/décochez les comparables à inclure dans l'estimation finale.
                    Les comparables décochés seront exclus du calcul et du transfert marketing.
                  </p>
                </CardHeader>
                <CardContent className="space-y-3">
                  {/* Statistiques en temps réel */}
                  <div className="grid grid-cols-3 gap-3">
                    <div className="text-center p-3 bg-white rounded-lg border">
                      <div className="text-2xl font-bold text-blue-600">{selectedCount}</div>
                      <div className="text-xs text-gray-600">Sélectionnés</div>
                    </div>
                    <div className="text-center p-3 bg-white rounded-lg border">
                      <div className="text-2xl font-bold text-red-600">{excludedIds.length}</div>
                      <div className="text-xs text-gray-600">Exclus</div>
                    </div>
                    <div className="text-center p-3 bg-white rounded-lg border">
                      <div className="text-2xl font-bold text-green-600">
                        {avgPrice > 0 ? Math.round(avgPrice).toLocaleString("fr-BE") + "€" : "—"}
                      </div>
                      <div className="text-xs text-gray-600">Prix moyen</div>
                    </div>
                  </div>

                  {/* Boutons de masse */}
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={selectAll}>
                      Tout sélectionner
                    </Button>
                    <Button size="sm" variant="outline" onClick={deselectAll}>
                      Tout désélectionner
                    </Button>
                  </div>

                  {/* Liste des comparables */}
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {allComparables.map((comp) => {
                    const isExcluded = excludedIds.includes(comp.id);
                    return (
                      <div
                        key={comp.id}
                        className={`p-3 rounded-lg border-2 transition-all ${
                        isExcluded ?
                        "bg-gray-50 border-gray-200 opacity-60" :
                        "bg-white border-blue-300"}`
                        }>
                        
                          <div className="flex items-start gap-3">
                            <Checkbox
                            id={comp.id}
                            checked={!isExcluded}
                            onCheckedChange={() => toggleComparable(comp.id)}
                            className="mt-1" />
                          
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex-1 min-w-0">
                                  <p className={`font-medium text-sm ${isExcluded ? "line-through text-gray-500" : "text-gray-900"}`}>
                                    {comp.title}
                                  </p>
                                  <div className="flex items-center gap-2 mt-1 text-xs text-gray-600">
                                    {comp.price && <span>💰 {comp.price}</span>}
                                    {comp.surface && <span>📐 {comp.surface}</span>}
                                    {comp.location && <span>📍 {comp.location}</span>}
                                  </div>
                                </div>
                                <Badge variant="outline" className="text-xs">
                                  {comp.source || "immoweb"}
                                </Badge>
                              </div>
                              {comp.url &&
                            <a
                              href={comp.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-xs text-blue-600 hover:underline mt-1">
                              
                                  <ExternalLink className="w-3 h-3" />
                                  Voir l'annonce
                                </a>
                            }
                            </div>
                          </div>
                        </div>);

                  })}
                  </div>

                  {excludedIds.length > 0 &&
                <Alert className="bg-amber-50 border-amber-200">
                      <Info className="w-4 h-4 text-amber-600" />
                      <AlertDescription className="text-amber-800 text-sm">
                        ⚠️ {excludedIds.length} comparable(s) seront exclus de l'estimation et du transfert marketing.
                        Le prix moyen est recalculé en temps réel.
                      </AlertDescription>
                    </Alert>
                }
                </CardContent>
              </Card>
            }
          </div>
        </TabsContent>

        <TabsContent value="marketing">
          <div className="space-y-4">
            {!marketingInitialMessage &&
            <Alert className="bg-purple-50 border-purple-200">
                <Lock className="w-4 h-4 text-purple-600" />
                <AlertDescription className="text-purple-800">
                  <strong>Étape 2 :</strong> L'assistant marketing attend un contexte transféré depuis l'assistant immobilier.
                  Utilisez l'onglet « Immobilier » d'abord, puis cliquez sur « Propulser en Marketing ».
                </AlertDescription>
              </Alert>
            }
            <AgentChat
              key={marketingKey}
              agentName="marketing_assistant"
              title="✍️ Plume Marketing Trilingue"
              subtitle="Annonces FR / NL / EN • Adaptation PEB/EPC • Envoi email"
              accentColor="purple"
              initialMessage={marketingInitialMessage}
              placeholder="Demandez à l'assistant de générer ou d'envoyer l'annonce..." />
            
          </div>
        </TabsContent>
      </Tabs>

      <Card className="bg-gray-50 border-gray-200 mt-1 pt-8">
        <CardContent className="pt-6 pr-6 pb-12 pl-6 mx-1 my-2">
          <p className="text-xs text-gray-500 text-center">
            🔒 <strong>Sécurité :</strong> Protection SSRF active sur les URLs d'images •
            Validation same-origin des redirections • Données chiffrées en transit.
            <br />
            🏗️ <strong>Architecture plug-and-play :</strong> chaque nouvel agent (Assurances, Fiduciaires, Crédit)
            réutilisera les fonctions <code>sendMarketingEmail</code> et le protocole de transfert JSON.
            <br />
            👁️ <strong>Glass-Box :</strong> L'agent immo peut désormais valider manuellement les comparables avant transfert.
          </p>
        </CardContent>
      </Card>
    </div>);

}