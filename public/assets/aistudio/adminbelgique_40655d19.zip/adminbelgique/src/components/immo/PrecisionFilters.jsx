import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SlidersHorizontal, RotateCcw } from "lucide-react";

const formatEuro = (amount) => `${Math.round(Number(amount) || 0).toLocaleString("fr-BE")} €`;

export default function PrecisionFilters({ sources, value, onChange, onReset, shownCount, totalCount, budgetCeiling, clientBudget }) {
  const update = (patch) => onChange({ ...value, ...patch });
  const budgetLimit = Number(value.maxBudget) > 0 ? Number(value.maxBudget) : 0;
  const budgetValue = budgetLimit > 0 ? budgetLimit : budgetCeiling;
  const budgetStep = budgetCeiling <= 5000 ? 50 : 5000;
  const hasActiveFilter =
    value.directOnly || value.completeOnly || value.source !== "all" || (budgetLimit > 0 && budgetCeiling > budgetLimit);

  return (
    <div className="mb-4 rounded-lg border border-gray-200 bg-white p-3 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="text-xs font-semibold text-gray-800 flex items-center gap-1.5">
          <SlidersHorizontal className="w-3.5 h-3.5" /> Filtres de précision
        </span>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {shownCount} / {totalCount} affichée{shownCount > 1 ? "s" : ""}
          </Badge>
          {hasActiveFilter && (
            <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={onReset}>
              <RotateCcw className="w-3 h-3 mr-1" /> Réinitialiser
            </Button>
          )}
        </div>
      </div>

      <p className="text-xs text-gray-500">
        Isolez uniquement les annonces dont la source est identifiable et dont le lien direct fonctionne.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="flex items-center gap-2">
          <Checkbox
            id="precision-direct"
            checked={value.directOnly}
            onCheckedChange={(checked) => update({ directOnly: checked === true })}
          />
          <label htmlFor="precision-direct" className="text-sm text-gray-700 cursor-pointer">
            Liens directs vérifiés uniquement
          </label>
        </div>
        <div className="flex items-center gap-2">
          <Checkbox
            id="precision-complete"
            checked={value.completeOnly}
            onCheckedChange={(checked) => update({ completeOnly: checked === true })}
          />
          <label htmlFor="precision-complete" className="text-sm text-gray-700 cursor-pointer">
            Informations complètes (prix, chambres, surface, adresse)
          </label>
        </div>
      </div>

      {budgetCeiling > 0 && (
        <div className="pt-1">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <Label className="text-xs text-gray-500">Budget maximum</Label>
            <div className="flex items-center gap-2">
              {clientBudget > 0 && (
                <span className="text-xs text-gray-500">Budget client : {formatEuro(clientBudget)}</span>
              )}
              <span className="text-sm font-semibold text-gray-900">{formatEuro(budgetValue)}</span>
            </div>
          </div>
          <Slider
            className="mt-3"
            min={0}
            max={budgetCeiling}
            step={budgetStep}
            value={[budgetValue]}
            onValueChange={([next]) => update({ maxBudget: next })}
          />
          <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>0 €</span>
            <span>{formatEuro(budgetCeiling)}</span>
          </div>
        </div>
      )}

      {sources.length > 0 && (
        <div>
          <Label htmlFor="precision-source" className="text-xs text-gray-500">
            Source vérifiable
          </Label>
          <Select value={value.source} onValueChange={(source) => update({ source })}>
            <SelectTrigger id="precision-source" className="mt-1">
              <SelectValue placeholder="Toutes les sources" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toutes les sources</SelectItem>
              {sources.map((source) => (
                <SelectItem key={source} value={source}>
                  {source}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
    </div>
  );
}