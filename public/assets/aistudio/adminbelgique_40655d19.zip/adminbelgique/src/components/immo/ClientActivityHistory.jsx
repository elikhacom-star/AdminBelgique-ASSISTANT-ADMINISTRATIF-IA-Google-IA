import React, { useState } from "react";
import { db, api as base44 } from "@/components/api/wrapper";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { History, Home, FileText, MessageCircle, Mail, ExternalLink, Share2, Loader2 } from "lucide-react";
import { appendClientActivities } from "@/lib/clientActivity";
import ClientTimeline from "@/components/immo/ClientTimeline";

const formatActivityDate = (iso) => {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleString("fr-BE", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
};

export default function ClientActivityHistory({ client, onClientUpdated, matches = [] }) {
  const [openDocDialog, setOpenDocDialog] = useState(false);
  const [documents, setDocuments] = useState([]);
  const [loadingDocs, setLoadingDocs] = useState(false);
  const [selectedDocId, setSelectedDocId] = useState("");
  const [sharingChannel, setSharingChannel] = useState(null);

  const activities = Array.isArray(client?.activity_history) ? client.activity_history : [];

  const handleOpenShareDoc = async (open) => {
    setOpenDocDialog(open);
    if (open && documents.length === 0) {
      setLoadingDocs(true);
      try {
        const list = await db.Document.list("-created_date", 50);
        const docs = Array.isArray(list) ? list : list?.items || [];
        setDocuments(docs);
        if (docs[0]?.id) setSelectedDocId(docs[0].id);
      } finally {
        setLoadingDocs(false);
      }
    }
  };

  const handleShareDocument = async (channel) => {
    const doc = documents.find((d) => d.id === selectedDocId);
    if (!doc) return;

    setSharingChannel(channel);
    try {
      if (channel === "email") {
        if (!client?.email) {
          alert("Ajoutez une adresse email sur la fiche de ce client avant d'envoyer par email.");
          return;
        }
        await base44.functions.invoke("sendDocumentEmail", {
          documentId: doc.id,
          clientId: client.id,
          to: client.email,
          subject: `Document administratif : ${doc.title}`
        });
        const refreshed = await db.Client.get(client.id);
        if (refreshed && onClientUpdated) onClientUpdated(refreshed);
      } else {
        const cleanPhone = String(client?.phone || "").replace(/[^\d+]/g, "").replace(/^\+/, "");
        const text = `Bonjour ${client?.name || ""},\n\nVoici votre document « ${doc.title} » :\n\n${String(doc.content || "").slice(0, 1500)}`;
        const waUrl = cleanPhone
          ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`
          : `https://wa.me/?text=${encodeURIComponent(text)}`;
        window.open(waUrl, "_blank");

        const updated = await appendClientActivities(client, {
          type: "document",
          channel: "whatsapp",
          title: doc.title,
          details: client?.phone ? `WhatsApp (${client.phone})` : "Partagé sur WhatsApp"
        });
        if (onClientUpdated) onClientUpdated(updated);
      }
      setOpenDocDialog(false);
    } catch (error) {
      alert(error?.response?.data?.error || error?.message || "Erreur lors du partage du document.");
    } finally {
      setSharingChannel(null);
    }
  };

  return (
    <div className="mt-4 pt-3 border-t border-gray-200">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-1.5 text-sm font-semibold text-gray-800">
          <History className="w-4 h-4 text-blue-600" />
          <span>Historique d'activités</span>
          <Badge variant="secondary" className="text-xs">{activities.length}</Badge>
        </div>

        <Dialog open={openDocDialog} onOpenChange={handleOpenShareDoc}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" className="h-7 px-2 text-xs">
              <Share2 className="w-3 h-3 mr-1" /> Partager un document
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Partager un document avec {client?.name}</DialogTitle>
            </DialogHeader>
            {loadingDocs ? (
              <div className="py-6 text-center">
                <Loader2 className="w-5 h-5 animate-spin mx-auto text-blue-600" />
              </div>
            ) : documents.length === 0 ? (
              <p className="text-sm text-gray-500 py-4">Aucun document enregistré dans « Mes Documents ».</p>
            ) : (
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-gray-600">Document à partager</label>
                  <Select value={selectedDocId} onValueChange={setSelectedDocId}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Choisir un document" />
                    </SelectTrigger>
                    <SelectContent>
                      {documents.map((doc) => (
                        <SelectItem key={doc.id} value={doc.id}>
                          {doc.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex flex-col sm:flex-row gap-2">
                  <Button
                    variant="outline"
                    className="flex-1 text-green-700 border-green-200 hover:bg-green-50"
                    disabled={!selectedDocId || !!sharingChannel}
                    onClick={() => handleShareDocument("whatsapp")}
                  >
                    {sharingChannel === "whatsapp" ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <MessageCircle className="w-4 h-4 mr-2" />}
                    WhatsApp
                  </Button>
                  <Button
                    className="flex-1"
                    disabled={!selectedDocId || !!sharingChannel}
                    onClick={() => handleShareDocument("email")}
                  >
                    {sharingChannel === "email" ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Mail className="w-4 h-4 mr-2" />}
                    Email {client?.email ? `(${client.email})` : ""}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>

      <ClientTimeline activities={activities} matches={matches} />
    </div>
  );
}