import React, { useMemo, useState } from "react";
import { FileText, Home, FilePlus2, Send, Search, ExternalLink } from "lucide-react";

const KINDS = {
  generated: { label: "Document généré", icon: FilePlus2, dot: "bg-purple-600", text: "text-purple-700" },
  doc_shared: { label: "Document partagé", icon: FileText, dot: "bg-indigo-500", text: "text-indigo-700" },
  listing_shared: { label: "Annonce partagée", icon: Send, dot: "bg-blue-600", text: "text-blue-700" },
  listing_found: { label: "Annonce trouvée", icon: Search, dot: "bg-green-600", text: "text-green-700" }
};

const FILTERS = [
  { key: "all", label: "Tout" },
  { key: "generated", label: "Générés" },
  { key: "doc_shared", label: "Documents" },
  { key: "listing_shared", label: "Annonces" }
];

const formatDate = (iso) => {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleString("fr-BE", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
};

const kindOf = (act) => {
  if (act.type === "document") return String(act.details || "").startsWith("Document généré") ? "generated" : "doc_shared";
  return "listing_shared";
};

export default function ClientTimeline({ activities = [], matches = [] }) {
  const [filter, setFilter] = useState("all");

  const events = useMemo(() => {
    const fromActivities = activities.map((a) => ({
      kind: kindOf(a), title: a.title, details: a.details, url: a.url, date: a.date
    }));
    const fromMatches = matches.map((m) => ({
      kind: "listing_found", title: m.property_title, details: [m.property_price, m.property_location].filter(Boolean).join(" • "),
      url: /^https?:/.test(m.property_url || "") ? m.property_url : "", date: m.created_date
    }));
    return [...fromActivities, ...fromMatches]
      .filter((e) => e.date)
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [activities, matches]);

  const counts = {
    generated: events.filter((e) => e.kind === "generated").length,
    doc_shared: events.filter((e) => e.kind === "doc_shared").length,
    listing_shared: events.filter((e) => e.kind === "listing_shared").length
  };
  const visible = (filter === "all" ? events : events.filter((e) => e.kind === filter)).slice(0, 30);

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-2">
        {[["generated", "Générés"], ["doc_shared", "Docs partagés"], ["listing_shared", "Annonces"]].map(([k, label]) => (
          <div key={k} className="rounded-lg border bg-white p-2 text-center">
            <p className={`text-lg font-bold ${KINDS[k].text}`}>{counts[k]}</p>
            <p className="text-[10px] text-gray-500 leading-tight">{label}</p>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-1">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            type="button"
            onClick={() => setFilter(f.key)}
            className={`px-2 py-0.5 rounded-full text-[11px] border ${filter === f.key ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-600 border-gray-200"}`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <p className="text-xs text-gray-500 italic">Aucune activité à afficher pour ce filtre.</p>
      ) : (
        <ol className="relative border-l-2 border-gray-200 ml-2 space-y-3 max-h-64 overflow-y-auto pr-1">
          {visible.map((e, i) => {
            const k = KINDS[e.kind];
            const Icon = k.icon;
            return (
              <li key={i} className="ml-4 relative">
                <span className={`absolute -left-[25px] top-1 w-4 h-4 rounded-full ${k.dot} flex items-center justify-center ring-2 ring-white`}>
                  <Icon className="w-2.5 h-2.5 text-white" />
                </span>
                <div className="rounded-md bg-gray-50 border px-2.5 py-1.5 text-xs">
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-medium text-gray-900 truncate">{e.title}</span>
                    <span className={`shrink-0 text-[10px] font-semibold ${k.text}`}>{k.label}</span>
                  </div>
                  {e.details && <p className="text-[11px] text-gray-500 mt-0.5">{e.details}</p>}
                  <div className="flex items-center justify-between mt-0.5 text-[10px] text-gray-400">
                    <span>{formatDate(e.date)}</span>
                    {e.url && (
                      <a href={e.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline inline-flex items-center gap-0.5">
                        Voir <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}