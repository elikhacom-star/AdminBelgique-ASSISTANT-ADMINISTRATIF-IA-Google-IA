import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, ExternalLink, Copy } from "lucide-react";

function buildGoogleQuery(criteria) {
  const terms = [];
  if (criteria?.property_type) terms.push(criteria.property_type);
  terms.push(criteria?.transaction_type === 'location' ? 'à louer' : 'à vendre');
  if (criteria?.location) terms.push(criteria.location);
  if (criteria?.max_budget) terms.push(`max ${criteria.max_budget}€`);
  if (criteria?.min_bedrooms) terms.push(`${criteria.min_bedrooms} chambres`);
  terms.push('site:immoweb.be OR site:logic-immo.be OR site:zimmo.be');
  return terms.join(' ');
}

export default function ManualSearchAssistant({ criteria }) {
  const query = buildGoogleQuery(criteria || {});
  const encoded = encodeURIComponent(query);
  const googleUrl = `https://www.google.com/search?q=${encoded}`;

  const copyQuery = async () => {
    try {
      await navigator.clipboard.writeText(query);
      // simple feedback via title change
    } catch (e) {}
  };

  return (
    <div className="mt-4 p-4 border rounded-lg bg-white">
      <div className="flex items-center gap-2 mb-3">
        <Search className="w-4 h-4 text-blue-600" />
        <span className="font-semibold text-gray-900">Assistant de recherche manuelle</span>
        <Badge className="bg-blue-100 text-blue-800 border-blue-200">Immo</Badge>
      </div>

      <div className="grid gap-2 text-sm text-gray-700">
        <div className="flex items-center gap-2">
          <Input readOnly value={query} className="text-xs" />
          <Button variant="outline" size="sm" onClick={copyQuery} title="Copier la requête">
            <Copy className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          <Button asChild variant="outline" size="sm">
            <a href={googleUrl} target="_blank" rel="noopener noreferrer">
              Google ciblé <ExternalLink className="w-3 h-3 ml-1" />
            </a>
          </Button>
          <Button asChild variant="outline" size="sm">
            <a href={`https://www.google.com/search?q=${encodeURIComponent(criteria?.location ? `${criteria.location} site:immoweb.be` : 'site:immoweb.be')}`} target="_blank" rel="noopener noreferrer">
              Immoweb <ExternalLink className="w-3 h-3 ml-1" />
            </a>
          </Button>
          <Button asChild variant="outline" size="sm">
            <a href={`https://www.google.com/search?q=${encodeURIComponent(criteria?.location ? `${criteria.location} site:logic-immo.be` : 'site:logic-immo.be')}`} target="_blank" rel="noopener noreferrer">
              Logic-Immo <ExternalLink className="w-3 h-3 ml-1" />
            </a>
          </Button>
          <Button asChild variant="outline" size="sm">
            <a href={`https://www.google.com/search?q=${encodeURIComponent(criteria?.location ? `${criteria.location} site:zimmo.be` : 'site:zimmo.be')}`} target="_blank" rel="noopener noreferrer">
              Zimmo <ExternalLink className="w-3 h-3 ml-1" />
            </a>
          </Button>
        </div>
      </div>
    </div>
  );
}