import React from "react";
import { Wand2, Loader2, Sparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

/**
 * Bouton "Baguette Magique" avec infobulle Popover.
 * - Sur mobile : un tap ouvre le popover (ne déclenche PAS l'action).
 * - Le popover explique la fonction et offre deux choix :
 *     • "Utiliser"  → déclenche onConfirm
 *     • "Pas maintenant" → ferme le popover sans rien faire
 * - Sur desktop : même comportement (le survol n'est plus nécessaire).
 */
export default function WandRefineButton({ onConfirm, disabled }) {
  const [open, setOpen] = React.useState(false);

  const handleConfirm = () => {
    setOpen(false);
    onConfirm?.();
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          size="icon"
          variant="outline"
          className="bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100 h-9 w-9"
          disabled={disabled}
          aria-label="Baguette Magique IA"
        >
          {disabled ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
        </Button>
      </PopoverTrigger>
      <PopoverContent
        side="bottom"
        align="end"
        className="w-[280px] p-4"
        sideOffset={8}
      >
        <div className="space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-1.5 font-semibold text-purple-800">
              <Wand2 className="w-4 h-4" />
              Baguette Magique IA
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-6 w-6 shrink-0"
              onClick={() => setOpen(false)}
              aria-label="Fermer"
            >
              <X className="w-3.5 h-3.5" />
            </Button>
          </div>
          <p className="text-sm text-gray-600 leading-relaxed">
            L'IA analyse les critères de votre client et les affine automatiquement :
            budget précis, rayon de recherche, code postal et coordonnées GPS.
          </p>
          <div className="flex flex-col gap-2 pt-1">
            <Button
              type="button"
              size="sm"
              onClick={handleConfirm}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              <Sparkles className="w-4 h-4 mr-1.5" />
              Utiliser la Baguette Magique
            </Button>
            <Button
              type="button"
              size="sm"
              variant="ghost"
              onClick={() => setOpen(false)}
            >
              Pas maintenant
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}