import React, { useState } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, ExternalLink, MapPin, BedDouble, Home, Euro, Sparkles } from "lucide-react";

/**
 * Popover de pré-visualisation rapide d'une annonce.
 * Affiche les détails connus du bien (titre, prix, localisation, chambres, surface, analyse IA)
 * sans tenter d'embarquer le site externe dans un iframe (bloqué par X-Frame-Options).
 */
export default function QuickLookPopover({ url, property = {}, label = "Aperçu rapide" }) {
  const [open, setOpen] = useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="w-full mt-2 text-xs">
          <Eye className="w-3.5 h-3.5 mr-1.5" />
          {label}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[360px] p-0" align="center">
        <div className="p-4 space-y-3">
          <div className="flex items-start justify-between gap-2">
            <h4 className="font-semibold text-sm leading-tight">{property.title || "Bien immobilier"}</h4>
            {property.correspondence_score && property.correspondence_score !== 'N/A' && (
              <Badge className="bg-green-100 text-green-800 shrink-0">Match: {property.correspondence_score}</Badge>
            )}
          </div>

          <div className="flex items-center gap-1.5 text-sm text-gray-600">
            <Euro className="w-4 h-4 text-gray-400" />
            <span className="font-bold text-blue-600">{property.price || 'Prix non disponible'}</span>
          </div>

          {property.location && (
            <div className="flex items-center gap-1.5 text-sm text-gray-600">
              <MapPin className="w-4 h-4 text-gray-400" />
              <span>{property.location}</span>
            </div>
          )}

          {(property.bedrooms || property.surface) && (
            <div className="flex gap-4 text-sm text-gray-600">
              {property.bedrooms && (
                <span className="flex items-center gap-1">
                  <BedDouble className="w-4 h-4 text-gray-400" />
                  {property.bedrooms} ch.
                </span>
              )}
              {property.surface && (
                <span className="flex items-center gap-1">
                  <Home className="w-4 h-4 text-gray-400" />
                  {property.surface}
                </span>
              )}
            </div>
          )}

          {property.features && (
            <p className="text-sm text-green-700 font-medium">✨ {property.features}</p>
          )}

          {property.summary && (
            <p className="text-xs text-gray-600 line-clamp-3">{property.summary}</p>
          )}

          {property.match_analysis && (
            <div className="bg-blue-50 p-2.5 rounded-lg border border-blue-200">
              <p className="text-xs font-medium text-blue-800 mb-1 flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> Analyse IA
              </p>
              <p className="text-xs text-blue-700">{property.match_analysis}</p>
            </div>
          )}
        </div>

        <div className="p-2 border-t bg-gray-50 rounded-b-md">
          <Button asChild size="sm" className="w-full text-xs">
            <a href={url} target="_blank" rel="noopener noreferrer">
              <ExternalLink className="w-3.5 h-3.5 mr-1.5" />
              Ouvrir l'annonce complète
            </a>
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}