import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SearchX, ExternalLink, ShieldCheck } from "lucide-react";

const PORTAL_TYPE_PATH = {
  maison: "house",
  appartement: "apartment",
  terrain: "land",
  commerce: "commercial"
};

const buildPortalSearchUrl = (criteria = {}) => {
  const transaction = criteria.transaction_type === "location" ? "a-louer" : "a-vendre";
  const type = PORTAL_TYPE_PATH[criteria.property_type] || criteria.property_type || "house";
  let url = `https://www.immoweb.be/fr/recherche/${type}/${transaction}?countries=BE`;

  const postal = String(criteria.location || "").match(/\b(\d{4})\b/);
  if (postal) url += `&postalCodes=${postal[1]}`;
  else if (criteria.location) url += `&query=${encodeURIComponent(String(criteria.location))}`;

  if (criteria.max_budget) url += `&maxPrice=${criteria.max_budget}`;
  if (criteria.min_bedrooms) url += `&minBedroomCount=${criteria.min_bedrooms}`;

  return url;
};

export default function StrictEmptyState({ criteria = {}, reason, discardedCount = 0 }) {
  return (
    <Card className="border-2 border-dashed border-amber-300 bg-amber-50/50">
      <CardContent className="py-8 px-4 text-center space-y-4">
        <div className="w-14 h-14 mx-auto rounded-full bg-amber-100 flex items-center justify-center">
          <SearchX className="w-7 h-7 text-amber-700" />
        </div>

        <div>
          <h3 className="text-base sm:text-lg font-semibold text-amber-900 leading-tight">
            Aucune annonce vérifiable ne correspond strictement à vos critères
          </h3>
          <p className="text-sm text-amber-800 mt-2">
            {reason || "Aucune annonce avec lien direct vérifiable n'a été trouvée pour ces critères."}
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-2">
          {criteria.transaction_type && (
            <Badge variant="secondary">
              {criteria.transaction_type === "location" ? "À louer" : "À vendre"}
            </Badge>
          )}
          {criteria.property_type && <Badge variant="secondary">{criteria.property_type}</Badge>}
          {criteria.location && <Badge variant="secondary">{criteria.location}</Badge>}
          {criteria.max_budget ? <Badge variant="secondary">Max {criteria.max_budget} €</Badge> : null}
          {criteria.min_bedrooms ? (
            <Badge variant="secondary">{criteria.min_bedrooms} ch. min</Badge>
          ) : null}
        </div>

        <p className="text-xs text-amber-800 flex items-start sm:items-center justify-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 shrink-0 mt-0.5 sm:mt-0" />
          <span>
            Aucun critère n'a été élargi automatiquement.
            {discardedCount > 0
              ? ` ${discardedCount} annonce${discardedCount > 1 ? "s" : ""} écartée${discardedCount > 1 ? "s" : ""} faute de lien direct vérifiable.`
              : ""}
          </span>
        </p>

        <Button asChild variant="outline" className="bg-white">
          <a href={buildPortalSearchUrl(criteria)} target="_blank" rel="noopener noreferrer">
            <ExternalLink className="w-4 h-4 mr-2" />
            Chercher moi-même sur Immoweb
          </a>
        </Button>
      </CardContent>
    </Card>
  );
}