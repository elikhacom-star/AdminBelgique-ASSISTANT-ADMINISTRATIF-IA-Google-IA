import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, ArrowRight, ArrowLeft, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const ONBOARDING_STEPS = [
  {
    target: "dashboard",
    title: "🎯 Bienvenue sur AdminBelgique !",
    description: "Votre assistant administratif IA pour simplifier toutes vos démarches en Belgique. Laissez-nous vous faire découvrir les fonctionnalités principales.",
    position: "center"
  },
  {
    target: "chat",
    title: "💬 Agent IA Intelligent",
    description: "Posez toutes vos questions administratives. L'IA garde en mémoire votre conversation et vous guide étape par étape.",
    highlight: true
  },
  {
    target: "document-generator",
    title: "📝 Générateur de Documents",
    description: "Créez des lettres de réclamation, demandes de remboursement, recours... en quelques clics. L'IA rédige pour vous !",
    highlight: true
  },
  {
    target: "document-analyzer",
    title: "🔍 Analyseur de Documents",
    description: "Uploadez un courrier administratif et obtenez une analyse complète avec les actions à effectuer.",
    highlight: true
  },
  {
    target: "my-documents",
    title: "📚 Mes Documents",
    description: "Tous vos documents générés sont automatiquement sauvegardés ici. Téléchargez-les ou envoyez-les par email.",
    highlight: true
  },
  {
    target: "usage-stats",
    title: "📊 Vos Limites",
    description: "En plan gratuit, vous avez des limites mensuelles. Passez à Pro pour un accès illimité !",
    highlight: true
  },
  {
    target: "complete",
    title: "🎉 C'est parti !",
    description: "Vous êtes prêt ! Commencez par poser une question ou générer votre premier document. Bonne découverte !",
    position: "center"
  }
];

export default function OnboardingTour({ onComplete, steps, storageKey = 'adminbelgique_onboarding_completed', forceShow = false }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  
  const activeSteps = steps || ONBOARDING_STEPS;

  useEffect(() => {
    if (forceShow) {
      setIsVisible(true);
      setCurrentStep(0);
    } else {
      // Vérifier si l'utilisateur a déjà vu le tour
      const hasSeenTour = localStorage.getItem(storageKey);
      if (hasSeenTour) {
        setIsVisible(false);
      }
    }
  }, [forceShow, storageKey]);

  const handleNext = () => {
    if (currentStep < activeSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSkip = () => {
    handleComplete();
  };

  const handleComplete = () => {
    localStorage.setItem(storageKey, 'true');
    setIsVisible(false);
    if (onComplete) onComplete();
  };

  if (!isVisible) return null;

  const step = activeSteps[currentStep];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        {/* Overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          onClick={handleSkip}
        />

        {/* Tooltip Card */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className="relative z-10 max-w-lg mx-4"
        >
          <Card className="border-2 border-yellow-400 shadow-2xl">
            <CardContent className="p-6 space-y-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    {step.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {step.description}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleSkip}
                  className="flex-shrink-0 ml-2"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>

              {/* Progress */}
              <div className="flex gap-1">
                {activeSteps.map((_, idx) => (
                  <div
                    key={idx}
                    className={`h-1 flex-1 rounded-full transition-colors ${
                      idx === currentStep
                        ? 'bg-yellow-500'
                        : idx < currentStep
                        ? 'bg-yellow-300'
                        : 'bg-gray-200'
                    }`}
                  />
                ))}
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between pt-2">
                <Button
                  variant="ghost"
                  onClick={handlePrev}
                  disabled={currentStep === 0}
                  className="text-gray-600"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Précédent
                </Button>

                <span className="text-sm text-gray-500">
                  {currentStep + 1} / {activeSteps.length}
                </span>

                <Button
                  onClick={handleNext}
                  className="bg-yellow-500 hover:bg-yellow-600"
                >
                  {currentStep === activeSteps.length - 1 ? (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Commencer
                    </>
                  ) : (
                    <>
                      Suivant
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              </div>

              <Button
                variant="link"
                onClick={handleSkip}
                className="w-full text-gray-500 text-sm"
              >
                Passer le tutoriel
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}