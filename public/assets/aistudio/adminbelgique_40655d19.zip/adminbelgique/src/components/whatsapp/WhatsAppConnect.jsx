import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Smartphone, CheckCircle, Zap, QrCode, ArrowRight } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function WhatsAppConnect() {
  const [showGuide, setShowGuide] = useState(false);

  // 🔥 URL WHATSAPP DIRECTE QUI MARCHE À TOUS LES COUPS
  const WHATSAPP_NUMBER = "32467801041"; // Votre numéro WhatsApp Business
  const WHATSAPP_MESSAGE = encodeURIComponent(
    "Bonjour AdminBelgique ! 👋\n\nJe viens d'activer l'assistant IA sur WhatsApp.\nJe souhaite de l'aide pour mes démarches administratives en Belgique."
  );
  
  const directWhatsAppUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MESSAGE}`;

  const handleConnect = () => {
    // Ouvrir le guide avant de rediriger
    setShowGuide(true);
  };

  const handleProceed = () => {
    // 🎯 SOLUTION QUI MARCHE : Utiliser l'URL directe
    console.log('Opening WhatsApp with URL:', directWhatsAppUrl);
    
    // Essayer de rediriger
    const newWindow = window.open(directWhatsAppUrl, '_blank');
    
    if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
      // Si le popup est bloqué, essayer window.location
      console.log('Popup blocked, trying window.location');
      window.location.href = directWhatsAppUrl;
    }
    
    setShowGuide(false);
  };

  return (
    <>
      <Card className="border-2 border-green-300 bg-gradient-to-br from-green-50 to-emerald-50">
        <CardHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-xl">Assistant WhatsApp Business</CardTitle>
              <CardDescription>Votre agent administratif dans votre poche</CardDescription>
            </div>
          </div>
          <Badge className="bg-green-600 text-white w-fit">
            <Zap className="w-3 h-3 mr-1" />
            Disponible Maintenant !
          </Badge>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <Alert className="bg-white border-green-200">
            <Smartphone className="h-5 w-5 text-green-600" />
            <AlertTitle className="text-green-900 font-bold">
              💬 Posez vos questions par WhatsApp !
            </AlertTitle>
            <AlertDescription className="text-green-800">
              L'assistant IA AdminBelgique est disponible sur WhatsApp. 
              Réponses instantanées à vos questions administratives belges.
            </AlertDescription>
          </Alert>

          <div className="space-y-3">
            <h4 className="font-semibold text-gray-900">✨ Avantages WhatsApp :</h4>
            <div className="space-y-2">
              {[
                "Réponses instantanées 24/7",
                "Notifications en temps réel sur votre téléphone",
                "Historique complet de vos conversations",
                "Partage de documents et photos facile",
                "Accessible depuis mobile ET ordinateur",
                "Connexion sécurisée et chiffrée"
              ].map((feature, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          <Button 
            onClick={handleConnect} 
            className="w-full bg-green-500 hover:bg-green-600 text-white text-lg py-6 shadow-lg hover:shadow-xl transition-all"
          >
            <MessageCircle className="w-5 h-5 mr-2" />
            Connecter WhatsApp Business
          </Button>

          <p className="text-xs text-center text-gray-500">
            🔒 Conversations chiffrées de bout en bout • 🇧🇪 Support français/néerlandais
          </p>
        </CardContent>
      </Card>

      {/* Guide étape par étape */}
      <Dialog open={showGuide} onOpenChange={setShowGuide}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl flex items-center gap-2">
              <MessageCircle className="w-6 h-6 text-green-600" />
              Comment connecter WhatsApp Business ?
            </DialogTitle>
            <DialogDescription>
              Suivez ces 3 étapes simples pour activer l'assistant IA sur WhatsApp
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            
            {/* Étape 1 */}
            <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold text-xl flex-shrink-0">
                  1
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-blue-900 mb-3">
                    Cliquez sur "Ouvrir WhatsApp"
                  </h3>
                  <p className="text-blue-800 mb-4">
                    Quand vous cliquerez sur le bouton ci-dessous, WhatsApp s'ouvrira automatiquement.
                  </p>
                  <Alert className="bg-white border-blue-300">
                    <Smartphone className="h-5 w-5 text-green-600" />
                    <AlertTitle className="text-blue-900 font-bold">
                      📱 Sur MOBILE
                    </AlertTitle>
                    <AlertDescription className="text-blue-800">
                      L'application WhatsApp s'ouvrira <strong>automatiquement</strong>.<br/>
                      Vous verrez directement la conversation avec AdminBelgique avec un message pré-rempli.
                    </AlertDescription>
                  </Alert>
                  <Alert className="bg-white border-blue-300 mt-3">
                    <QrCode className="h-5 w-5 text-blue-600" />
                    <AlertTitle className="text-blue-900 font-bold">
                      💻 Sur ORDINATEUR
                    </AlertTitle>
                    <AlertDescription className="text-blue-800">
                      <strong>Option 1 - WhatsApp Web :</strong> Vous verrez un QR CODE à scanner.<br/>
                      Sur votre téléphone : WhatsApp → Menu (⋮) → "Appareils connectés" → "Connecter un appareil" → Scannez le QR<br/><br/>
                      <strong>Option 2 - App WhatsApp Desktop :</strong> Si installée, elle s'ouvrira automatiquement.
                    </AlertDescription>
                  </Alert>
                </div>
              </div>
            </div>

            {/* Étape 2 */}
            <div className="bg-purple-50 border-2 border-purple-200 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-purple-500 text-white rounded-full flex items-center justify-center font-bold text-xl flex-shrink-0">
                  2
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-purple-900 mb-3">
                    Envoyez le message de bienvenue
                  </h3>
                  <p className="text-purple-800 mb-4">
                    Un message est déjà pré-rempli pour vous ! Il suffit d'appuyer sur "Envoyer".
                  </p>
                  <div className="bg-white rounded-lg p-4 border-2 border-purple-300">
                    <p className="text-sm font-semibold text-purple-900 mb-2">
                      💬 Vous verrez ce message pré-rempli :
                    </p>
                    <div className="bg-gray-50 rounded p-3 border border-gray-200">
                      <p className="text-sm text-gray-800 whitespace-pre-line">
                        Bonjour AdminBelgique ! 👋{'\n\n'}
                        Je viens d'activer l'assistant IA sur WhatsApp.{'\n'}
                        Je souhaite de l'aide pour mes démarches administratives en Belgique.
                      </p>
                    </div>
                    <p className="text-sm text-purple-800 mt-3">
                      👉 <strong>Cliquez simplement sur le bouton "Envoyer"</strong> (icône ✈️)
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Étape 3 */}
            <div className="bg-green-50 border-2 border-green-200 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-green-500 text-white rounded-full flex items-center justify-center font-bold text-xl flex-shrink-0">
                  3
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-green-900 mb-3">
                    Recevez votre première réponse IA ! 🎉
                  </h3>
                  <p className="text-green-800 mb-4">
                    L'assistant IA vous répondra en quelques secondes. Vous pouvez maintenant poser toutes vos questions !
                  </p>
                  <div className="bg-white rounded-lg p-4 border-2 border-green-300">
                    <p className="text-sm font-semibold text-green-900 mb-3">
                      💡 Exemples de questions que vous pouvez poser :
                    </p>
                    <div className="space-y-2">
                      {[
                        "Comment faire ma déclaration d'impôts en Belgique ?",
                        "Je veux contester une décision de l'ONEM",
                        "Quels documents pour un remboursement INAMI ?",
                        "Comment calculer ma future pension ?",
                        "Aide pour une demande de prime régionale en Wallonie"
                      ].map((example, idx) => (
                        <div key={idx} className="flex items-center gap-2 bg-green-50 rounded p-2">
                          <MessageCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                          <span className="text-sm text-green-800">"{example}"</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Bouton final */}
            <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-lg p-6 text-center">
              <h3 className="text-2xl font-bold text-white mb-3">
                Prêt à commencer ? 🚀
              </h3>
              <p className="text-white/90 mb-6">
                Cliquez ci-dessous pour ouvrir WhatsApp et commencer à discuter avec l'assistant IA
              </p>
              <Button 
                onClick={handleProceed}
                size="lg"
                className="bg-white text-green-700 hover:bg-gray-100 text-xl px-8 py-6 shadow-xl"
              >
                <MessageCircle className="w-6 h-6 mr-3" />
                Ouvrir WhatsApp MAINTENANT
                <ArrowRight className="w-6 h-6 ml-3" />
              </Button>
              <p className="text-xs text-white/75 mt-4">
                🔒 Connexion 100% sécurisée et chiffrée par WhatsApp
              </p>
            </div>

            {/* Troubleshooting */}
            <Alert>
              <AlertTitle className="font-bold">
                ❓ WhatsApp ne s'ouvre pas ?
              </AlertTitle>
              <AlertDescription>
                <div className="space-y-2 mt-2 text-sm">
                  <p><strong>✅ Solution rapide :</strong> Copiez ce numéro <code className="bg-gray-100 px-2 py-1 rounded">+32 467 80 10 41</code> et ouvrez WhatsApp manuellement pour nous contacter.</p>
                  <p><strong>📱 Sur mobile :</strong> Assurez-vous que WhatsApp est installé et à jour.</p>
                  <p><strong>💻 Sur ordinateur :</strong> Installez WhatsApp Desktop ou utilisez web.whatsapp.com</p>
                  <p><strong>🆘 Besoin d'aide :</strong> Email <a href="mailto:elikaccesit@gmail.com" className="text-blue-600 underline font-semibold">elikaccesit@gmail.com</a></p>
                </div>
              </AlertDescription>
            </Alert>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}