import React, { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Save } from "lucide-react";
import { FREQUENCIES, VAT_RATES, todayBrussels, computeAmounts, formatEuro } from "@/lib/recurringInvoices";

const emptyForm = {
  client_name: "",
  client_email: "",
  client_address: "",
  client_vat: "",
  description: "",
  quantity: 1,
  unit_price: "",
  vat_rate: 21,
  frequency: "mensuelle",
  next_issue_date: "",
  payment_terms_days: 30,
  sender_name: "",
  sender_details: "",
  notes: "",
  active: true,
};

const editableFields = Object.keys(emptyForm);

const pickFields = (source) =>
  editableFields.reduce((acc, key) => {
    acc[key] = source?.[key] ?? emptyForm[key];
    return acc;
  }, {});

export default function RecurringInvoiceForm({ open, onOpenChange, plan, defaults, onSubmit, isSaving }) {
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    if (plan) {
      setForm({ ...emptyForm, ...pickFields(plan) });
    } else {
      setForm({
        ...emptyForm,
        next_issue_date: todayBrussels(),
        sender_name: defaults?.sender_name || "",
        sender_details: defaults?.sender_details || "",
      });
    }
    setError("");
  }, [open, plan, defaults]);

  const set = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  const totals = computeAmounts(form);

  const handleSubmit = () => {
    if (!form.client_name.trim()) {
      setError("Le nom du client est obligatoire.");
      return;
    }
    if (!form.description.trim()) {
      setError("Indiquez la prestation ou le produit facturé.");
      return;
    }
    if (form.unit_price === "" || Number(form.unit_price) < 0) {
      setError("Indiquez un prix unitaire valide.");
      return;
    }
    if (!form.next_issue_date) {
      setError("Choisissez la date de la prochaine facture.");
      return;
    }
    setError("");

    onSubmit({
      ...form,
      client_name: form.client_name.trim(),
      description: form.description.trim(),
      quantity: Number(form.quantity) > 0 ? Number(form.quantity) : 1,
      unit_price: Number(form.unit_price) || 0,
      vat_rate: Number(form.vat_rate) || 0,
      payment_terms_days: Number(form.payment_terms_days) >= 0 ? Number(form.payment_terms_days) : 30,
      active: !!form.active,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{plan ? "Modifier l'échéancier" : "Nouvelle facture récurrente"}</DialogTitle>
          <DialogDescription>
            Une facture sera créée automatiquement à chaque échéance, sans intervention de votre part.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-2">
          <div className="space-y-4">
            <h4 className="font-semibold text-sm text-gray-700">Client facturé</h4>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <Label htmlFor="client_name">Nom du client *</Label>
                <Input
                  id="client_name"
                  value={form.client_name}
                  onChange={(e) => set("client_name", e.target.value)}
                  placeholder="SPRL Dupont"
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="client_email">Email</Label>
                <Input
                  id="client_email"
                  type="email"
                  value={form.client_email}
                  onChange={(e) => set("client_email", e.target.value)}
                  placeholder="compta@client.be"
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="client_vat">TVA / BCE</Label>
                <Input
                  id="client_vat"
                  value={form.client_vat}
                  onChange={(e) => set("client_vat", e.target.value)}
                  placeholder="BE0123456789"
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="client_address">Adresse de facturation</Label>
                <Textarea
                  id="client_address"
                  rows={2}
                  value={form.client_address}
                  onChange={(e) => set("client_address", e.target.value)}
                  placeholder="Rue de la Loi 16, 1000 Bruxelles"
                />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-semibold text-sm text-gray-700">Prestation facturée</h4>
            <div className="grid gap-1.5">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                rows={2}
                value={form.description}
                onChange={(e) => set("description", e.target.value)}
                placeholder="Accompagnement administratif mensuel"
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="grid gap-1.5">
                <Label htmlFor="quantity">Quantité</Label>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  step="1"
                  value={form.quantity}
                  onChange={(e) => set("quantity", e.target.value)}
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="unit_price">Prix unitaire HT (€) *</Label>
                <Input
                  id="unit_price"
                  type="number"
                  min="0"
                  step="0.01"
                  value={form.unit_price}
                  onChange={(e) => set("unit_price", e.target.value)}
                  placeholder="250"
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="vat_rate">TVA</Label>
                <Select value={String(form.vat_rate)} onValueChange={(value) => set("vat_rate", Number(value))}>
                  <SelectTrigger id="vat_rate">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {VAT_RATES.map((rate) => (
                      <SelectItem key={rate} value={String(rate)}>
                        {rate} %
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <p className="text-sm text-gray-600">
              Total facturé à chaque échéance : <strong>{formatEuro(totals.incl)}</strong> TVA comprise (
              {formatEuro(totals.excl)} HT + {formatEuro(totals.vat)} de TVA)
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="font-semibold text-sm text-gray-700">Rythme de facturation</h4>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="grid gap-1.5">
                <Label htmlFor="frequency">Fréquence</Label>
                <Select value={form.frequency} onValueChange={(value) => set("frequency", value)}>
                  <SelectTrigger id="frequency">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {FREQUENCIES.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="next_issue_date">Prochaine facture le *</Label>
                <Input
                  id="next_issue_date"
                  type="date"
                  value={form.next_issue_date}
                  onChange={(e) => set("next_issue_date", e.target.value)}
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="payment_terms_days">Délai de paiement (jours)</Label>
                <Input
                  id="payment_terms_days"
                  type="number"
                  min="0"
                  step="1"
                  value={form.payment_terms_days}
                  onChange={(e) => set("payment_terms_days", e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-semibold text-sm text-gray-700">Vos coordonnées d'émetteur</h4>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <Label htmlFor="sender_name">Nom ou société</Label>
                <Input
                  id="sender_name"
                  value={form.sender_name}
                  onChange={(e) => set("sender_name", e.target.value)}
                  placeholder="AdminBelgique SRL"
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="sender_details">Adresse, TVA, IBAN</Label>
                <Textarea
                  id="sender_details"
                  rows={2}
                  value={form.sender_details}
                  onChange={(e) => set("sender_details", e.target.value)}
                  placeholder={"Rue Exemple 1, 1000 Bruxelles\nTVA BE0123456789\nIBAN BE00 0000 0000 0000"}
                />
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="notes">Mentions sur la facture</Label>
              <Textarea
                id="notes"
                rows={2}
                value={form.notes}
                onChange={(e) => set("notes", e.target.value)}
                placeholder="Paiement par virement uniquement."
              />
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                id="plan-active"
                checked={!!form.active}
                onCheckedChange={(checked) => set("active", !!checked)}
              />
              <Label htmlFor="plan-active" className="text-sm text-gray-600 font-normal cursor-pointer">
                Échéancier actif (facturation automatique)
              </Label>
            </div>
          </div>
        </div>

        {error && <p className="text-sm text-red-600">{error}</p>}

        <DialogFooter className="flex-col sm:flex-row gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="w-full sm:w-auto">
            Annuler
          </Button>
          <Button onClick={handleSubmit} disabled={isSaving} className="w-full sm:w-auto">
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Enregistrement...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                {plan ? "Enregistrer" : "Créer l'échéancier"}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}