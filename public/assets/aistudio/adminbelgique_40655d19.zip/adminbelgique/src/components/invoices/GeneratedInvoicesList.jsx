import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileDown, Check, Trash2, AlertTriangle } from "lucide-react";
import { INVOICE_STATUS, formatEuro, formatDateFr, isOverdue } from "@/lib/recurringInvoices";

export default function GeneratedInvoicesList({ invoices, onDownloadPdf, onMarkPaid, onDelete }) {
  return (
    <div className="space-y-3">
      {invoices.map((invoice) => {
        const status = INVOICE_STATUS[invoice.status] || INVOICE_STATUS.emise;
        const overdue = isOverdue(invoice);

        return (
          <Card key={invoice.id}>
            <CardContent className="p-5">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-gray-900">{invoice.invoice_number}</h3>
                    <Badge className={status.className}>{status.label}</Badge>
                    {overdue && (
                      <Badge className="bg-red-100 text-red-700 border border-red-200 gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        En retard
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-600">{invoice.client_name}</p>
                  <p className="text-sm text-gray-500">
                    Émise le {formatDateFr(invoice.issue_date)} — échéance {formatDateFr(invoice.due_date)} —{" "}
                    <strong className="text-gray-900">{formatEuro(invoice.amount_incl_vat)}</strong> TTC
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <Button size="sm" variant="outline" onClick={() => onDownloadPdf(invoice)} className="gap-2">
                    <FileDown className="w-4 h-4" />
                    PDF
                  </Button>
                  {invoice.status !== "payee" && (
                    <Button size="sm" variant="outline" onClick={() => onMarkPaid(invoice)} className="gap-2">
                      <Check className="w-4 h-4" />
                      Marquer payée
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onDelete(invoice)}
                    title="Supprimer"
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}