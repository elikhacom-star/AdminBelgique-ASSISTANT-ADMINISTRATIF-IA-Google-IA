import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Pause, Play, Pencil, Trash2, RefreshCw, CalendarClock, Repeat, Loader2 } from "lucide-react";
import { FREQUENCY_LABELS, formatEuro, formatDateFr, computeAmounts } from "@/lib/recurringInvoices";

export default function RecurringInvoiceCard({ plan, onEdit, onToggleActive, onDelete, onGenerateNow, isGenerating }) {
  const totals = computeAmounts(plan);

  return (
    <Card className={plan.active ? "" : "opacity-75"}>
      <CardContent className="p-5">
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
          <div className="space-y-2 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-semibold text-gray-900">{plan.client_name}</h3>
              <Badge className="bg-yellow-100 text-yellow-800 border border-yellow-200">
                {FREQUENCY_LABELS[plan.frequency] || plan.frequency}
              </Badge>
              {!plan.active && <Badge variant="outline">En pause</Badge>}
            </div>
            <p className="text-sm text-gray-600">{plan.description}</p>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-gray-500">
              <span className="font-semibold text-gray-900">{formatEuro(totals.incl)} TTC</span>
              <span className="inline-flex items-center gap-1">
                <CalendarClock className="w-3.5 h-3.5" />
                Prochaine : {formatDateFr(plan.next_issue_date)}
              </span>
              <span className="inline-flex items-center gap-1">
                <Repeat className="w-3.5 h-3.5" />
                {plan.generated_count || 0} facture(s) émise(s)
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <Button
              size="sm"
              variant="outline"
              onClick={() => onGenerateNow(plan)}
              disabled={isGenerating}
              className="gap-2"
            >
              {isGenerating ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4" />
              )}
              Générer maintenant
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onToggleActive(plan)}
              title={plan.active ? "Mettre en pause" : "Réactiver"}
            >
              {plan.active ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </Button>
            <Button size="sm" variant="ghost" onClick={() => onEdit(plan)} title="Modifier">
              <Pencil className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onDelete(plan)}
              title="Supprimer"
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}