import React, { useState, useEffect } from "react";
import { db } from "@/components/api/wrapper";
const User = db.User;
const UsageLimit = db.UsageLimit;
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Crown, AlertTriangle, Sparkles, Loader2, X } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { api as base44 } from "@/components/api/wrapper";

const PLAN_LIMITS = {
  free: {
    research_count: 1,
    analysis_count: 1,
    document_count: 1,
    ai_messages_count: 1,
    immo_search_count: 1
  },
  pro: {
    research_count: 999999,
    analysis_count: 999999,
    document_count: 999999,
    ai_messages_count: 999999,
    immo_search_count: 999999
  },
  cabinet: {
    research_count: 999999,
    analysis_count: 999999,
    document_count: 999999,
    ai_messages_count: 999999,
    immo_search_count: 999999
  },
  enterprise: {
    research_count: 999999,
    analysis_count: 999999,
    document_count: 999999,
    ai_messages_count: 999999,
    immo_search_count: 999999
  }
};

const FEATURE_LABELS = {
  research_count: "questions posées",
  analysis_count: "analyses de documents",
  document_count: "documents générés",
  ai_messages_count: "messages IA",
  immo_search_count: "recherches Immo Boost"
};

export default function LimitChecker({ children, feature }) {
  const [usageLimit, setUsageLimit] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [showPaywall, setShowPaywall] = useState(false);

  useEffect(() => {
    loadUsageLimit();
  }, []);

  const loadUsageLimit = async () => {
    setIsLoading(true);
    
    try {
      let user;
      try {
        user = await base44.auth.me();
      } catch (authError) {
        console.log("Utilisateur non authentifié");
        setIsLoading(false);
        return;
      }
      
      if (!user || !user.email) {
        setIsLoading(false);
        return;
      }
      
      setCurrentUser(user);

      // 🔥 SI ADMIN, PAS DE LIMITES !
      if (user.role === 'admin') {
        console.log(`[LimitChecker] 👑 Admin détecté: ${user.email} - Aucune limite appliquée`);
        setUsageLimit({
        user_email: user.email,
        plan: 'admin',
        research_count: 0,
        analysis_count: 0,
        document_count: 0,
        ai_messages_count: 0,
        immo_search_count: 0
        });
        setIsLoading(false);
        return;
      }

      try {
        const limits = await UsageLimit.filter({ user_email: user.email });
        
        let userLimit;
        if (limits.length === 0) {
          // 🔒 Aucune écriture depuis le navigateur (RLS) : les compteurs sont
          // créés et tenus à jour côté serveur, en rôle service.
          userLimit = {
            user_email: user.email,
            plan: "free",
            research_count: 0,
            analysis_count: 0,
            document_count: 0,
            ai_messages_count: 0,
            immo_search_count: 0
          };
        } else {
          userLimit = limits[0];
          
          const lastReset = new Date(userLimit.last_reset_date);
          const now = new Date();
          
          if (lastReset.getMonth() !== now.getMonth() || lastReset.getFullYear() !== now.getFullYear()) {
            // 🔒 La réinitialisation mensuelle est appliquée côté serveur, en rôle service.
            userLimit = {
              ...userLimit,
              research_count: 0,
              analysis_count: 0,
              document_count: 0,
              ai_messages_count: 0,
              immo_search_count: 0
            };
          }
        }

        // 🔒 État d'autorité : lu depuis le serveur, seul habilité à écrire les compteurs.
        try {
          const quotaResponse = await base44.functions.invoke('checkQuota', { feature });
          const quotaStatus = quotaResponse?.data || quotaResponse;
          if (quotaStatus?.plan) {
            userLimit = { ...userLimit, plan: quotaStatus.plan, [feature]: quotaStatus.used || 0 };
          }
        } catch (quotaError) {
          console.error("Erreur lors de la vérification du quota:", quotaError);
        }

        setUsageLimit(userLimit);
      } catch (limitError) {
        console.error("Erreur lors du chargement des limites:", limitError);
        setUsageLimit({
          user_email: user.email,
          plan: "free",
          research_count: 0,
          analysis_count: 0,
          document_count: 0,
          ai_messages_count: 0,
          immo_search_count: 0
        });
      }

    } catch (error) {
      console.error("Erreur chargement limites:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleActionStart = async () => {
    if (!usageLimit || !currentUser) {
      return true;
    }

    // 🔥 ADMIN = ILLIMITÉ
    if (currentUser.role === 'admin') {
      console.log(`[LimitChecker] 👑 Admin bypass - Action autorisée`);
      return true;
    }

    // 🔒 Autorité serveur : le décompte des quotas est effectué par les fonctions
    // backend qui exécutent réellement l'action IA facturable. On demande ici
    // l'autorisation avant de lancer l'action, pour afficher le mur payant.
    try {
      const quotaResponse = await base44.functions.invoke('checkQuota', { feature });
      const quotaStatus = quotaResponse?.data || quotaResponse;

      if (quotaStatus?.plan) {
        setUsageLimit((prev) => ({
          ...(prev || {}),
          plan: quotaStatus.plan,
          [feature]: quotaStatus.used ?? (prev?.[feature] || 0)
        }));
      }

      if (quotaStatus && quotaStatus.allowed === false) {
        console.log(`[LimitChecker] 🚫 LIMITE ATTEINTE pour ${currentUser.email}`);
        setShowPaywall(true);
        return false;
      }

      return true;
    } catch (quotaError) {
      console.error("[LimitChecker] ❌ Vérification du quota impossible:", quotaError);
    }

    const limit = PLAN_LIMITS[usageLimit.plan][feature];
    const currentUsage = usageLimit[feature] || 0;
    
    console.log(`[LimitChecker] User: ${currentUser.email}, Plan: ${usageLimit.plan}, Feature: ${feature}, Current: ${currentUsage}, Limit: ${limit}`);
    
    if (currentUsage >= limit) {
      console.log(`[LimitChecker] 🚫 LIMITE ATTEINTE pour ${currentUser.email}`);
      // Afficher le mur payant sans détruire la conversation
      setShowPaywall(true);
      return false;
    }

    try {
      // 🔒 Le compteur n'est plus incrémenté depuis le navigateur : le serveur
      // le décompte dans la fonction backend qui exécute l'action.
      
      // (compteur déjà mis à jour côté serveur, aucun accès en écriture requis ici)
      
      return true;
    } catch (error) {
      console.error("[LimitChecker] ❌ Erreur incrémentation:", error);
      return true;
    }
  };

  if (!isLoading && !currentUser) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <AlertTriangle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
            <h3 className="text-lg font-bold mb-2">Connexion requise</h3>
            <p className="text-gray-600 mb-4">
              Veuillez vous connecter pour utiliser cette fonctionnalité.
            </p>
            <Button onClick={() => base44.auth.redirectToLogin(window.location.pathname === '/login' ? window.location.origin : window.location.href)} className="w-full bg-blue-600 hover:bg-blue-700">
                Se connecter
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center py-4">
          <Loader2 className="h-8 w-8 animate-spin text-yellow-500 mx-auto mb-2" />
          <p className="text-gray-500">Chargement...</p>
        </div>
      </div>
    );
  }

  const remainingActions = usageLimit && currentUser.role !== 'admin' 
    ? Math.max(0, PLAN_LIMITS[usageLimit.plan][feature] - (usageLimit[feature] || 0)) 
    : Infinity;

  const limit = usageLimit && currentUser.role !== 'admin' ? PLAN_LIMITS[usageLimit.plan][feature] : Infinity;
  const currentUsage = usageLimit ? (usageLimit[feature] || 0) : 0;

  return (
    <>
      {typeof children === 'function' 
        ? children({ 
            onActionStart: handleActionStart,
            remainingActions: remainingActions,
            currentPlan: currentUser?.role === 'admin' ? 'admin' : (usageLimit?.plan || 'free'),
            usageLimit: usageLimit
          })
        : children
      }

      {/* Mur payant en fenêtre modale — n'écrase pas la conversation */}
      {showPaywall && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="relative w-full max-w-2xl">
            <button
              onClick={() => setShowPaywall(false)}
              className="absolute -top-4 -right-4 z-10 w-10 h-10 rounded-full bg-white shadow-lg flex items-center justify-center hover:bg-gray-100"
              aria-label="Fermer"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
            <Card className="border-2 border-yellow-400 bg-gradient-to-br from-yellow-50 to-orange-50 shadow-2xl max-h-[90vh] overflow-y-auto">
              <CardContent className="p-8">
                <div className="text-center space-y-6">
                  <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mx-auto">
                    <AlertTriangle className="w-10 h-10 text-yellow-600" />
                  </div>
                  
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-3">
                      Essai gratuit terminé ! 🎯
                    </h3>
                    <p className="text-lg text-gray-700 mb-2">
                      Vous avez utilisé votre <strong className="text-yellow-700">essai gratuit</strong> ({currentUsage}/{limit} {FEATURE_LABELS[feature]}).
                    </p>
                    <p className="text-gray-600">
                      Passez au <strong>Plan Pro</strong> pour continuer sans limites.
                    </p>
                  </div>

                  <Alert className="bg-blue-50 border-blue-200 text-left">
                    <Sparkles className="h-5 w-5 text-blue-600" />
                    <AlertTitle className="text-blue-900 font-bold text-lg mb-2">
                      Plan Pro - Illimité 🚀
                    </AlertTitle>
                    <AlertDescription className="text-blue-800 space-y-2">
                      <ul className="list-disc list-inside space-y-1 text-sm">
                        <li><strong>Questions illimitées</strong></li>
                        <li><strong>Analyses illimitées</strong></li>
                        <li><strong>Documents illimités</strong></li>
                        <li><strong>Messages IA illimités</strong></li>
                        <li><strong>Recherches Immo illimitées</strong></li>
                        <li><strong>Support prioritaire 24/7</strong></li>
                      </ul>
                      <div className="mt-4 pt-4 border-t border-blue-300">
                        <p className="font-bold text-xl text-blue-900">29€/mois</p>
                        <p className="text-xs text-blue-700">Sans engagement</p>
                      </div>
                    </AlertDescription>
                  </Alert>

                  <div className="flex flex-col gap-3">
                    <Button asChild size="lg" className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white">
                      <Link to={createPageUrl("Pricing")}>
                        <Crown className="w-5 h-5 mr-2" />
                        Passer au Plan Pro
                      </Link>
                    </Button>
                    
                    <Button variant="outline" size="lg" onClick={() => setShowPaywall(false)}>
                      Fermer
                    </Button>
                  </div>

                  <p className="text-sm text-gray-600">
                    📅 Réinitialisation le 1er du mois prochain
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </>
  );
}