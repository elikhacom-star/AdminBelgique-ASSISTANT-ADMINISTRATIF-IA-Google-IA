
import React, { useState, useEffect } from "react";
import { UsageLimit } from "@/entities/UsageLimit";
import { User } from "@/entities/User";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Crown, Zap, Calendar, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const PLAN_LIMITS = {
  free: {
    research_count: 3,
    analysis_count: 2,
    document_count: 5,
    ai_messages_count: 20
  }
};

const FEATURE_ICONS = {
  research_count: "❓",
  analysis_count: "📄",
  document_count: "📝",
  ai_messages_count: "💬"
};

const FEATURE_LABELS = {
  research_count: "Questions",
  analysis_count: "Analyses",
  document_count: "Documents",
  ai_messages_count: "Messages IA"
};

export default function UsageStats() {
  const [usageLimit, setUsageLimit] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUsageLimit();
  }, []);

  const loadUsageLimit = async () => {
    setIsLoading(true);
    try {
      const user = await User.me();
      const limits = await UsageLimit.filter({ user_email: user.email });
      
      if (limits.length > 0) {
        setUsageLimit(limits[0]);
      }
    } catch (error) {
      console.error("Erreur chargement limites:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-500 mx-auto" />
        </CardContent>
      </Card>
    );
  }

  if (!usageLimit) return null;

  const isPro = usageLimit.plan !== 'free';
  const nextReset = new Date(usageLimit.last_reset_date);
  nextReset.setMonth(nextReset.getMonth() + 1);
  nextReset.setDate(1);

  return (
    <Card className={isPro ? "border-yellow-400 bg-gradient-to-br from-yellow-50 to-orange-50" : ""}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            {isPro ? <Crown className="w-5 h-5 text-yellow-600" /> : <Zap className="w-5 h-5" />}
            Utilisation Mensuelle
          </span>
          <Badge className={isPro ? "bg-yellow-500 text-white" : "bg-gray-200"}>
            {usageLimit.plan === 'free' ? 'Gratuit' : usageLimit.plan.toUpperCase()}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {isPro ? (
          <div className="text-center py-4">
            <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-2" />
            <p className="text-lg font-semibold text-gray-900">Utilisation Illimitée</p>
            <p className="text-sm text-gray-600">Profitez de tous les services sans restriction</p>
          </div>
        ) : (
          <>
            {Object.keys(PLAN_LIMITS.free).map((feature) => {
              const limit = PLAN_LIMITS.free[feature];
              const used = usageLimit[feature] || 0;
              const percentage = (used / limit) * 100;
              const remaining = Math.max(0, limit - used);

              return (
                <div key={feature} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2">
                      <span>{FEATURE_ICONS[feature]}</span>
                      <span className="font-medium">{FEATURE_LABELS[feature]}</span>
                    </span>
                    <span className={remaining === 0 ? "text-red-600 font-bold" : "text-gray-600"}>
                      {used}/{limit}
                    </span>
                  </div>
                  <Progress 
                    value={percentage} 
                    className={`h-2 ${remaining === 0 ? 'bg-red-100' : ''}`}
                  />
                  {remaining === 0 && (
                    <p className="text-xs text-red-600">⚠️ Limite atteinte</p>
                  )}
                  {remaining > 0 && remaining <= 1 && (
                    <p className="text-xs text-orange-600">⚡ Plus que {remaining} restant</p>
                  )}
                </div>
              );
            })}

            <div className="pt-4 border-t space-y-3">
              <div className="flex items-center gap-2 text-xs text-gray-600">
                <Calendar className="w-4 h-4" />
                <span>Réinitialisation : {nextReset.toLocaleDateString('fr-BE', { day: 'numeric', month: 'long' })}</span>
              </div>

              <Button asChild className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600" size="sm">
                <Link to={createPageUrl("Pricing")}>
                  <Crown className="w-4 h-4 mr-2" />
                  Passer au Plan Pro - Illimité
                </Link>
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
