import React, { useState, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Brain, PenTool, Info } from "lucide-react";
import AgentChat from "@/components/immo/AgentChat";
import { buildFiduciaireTransfer, formatTransferForCommunication } from "@/lib/fiduciaireTransfer";

export default function FiduciaireStudioTool() {
  const [fiscalConversation, setFiscalConversation] = useState(null);
  const [commKey, setCommKey] = useState(0);
  const [commInitialMessage, setCommInitialMessage] = useState(null);
  const [transferInfo, setTransferInfo] = useState(null);

  const handleConversationCreated = useCallback((conv) => {
    setFiscalConversation(conv);
  }, []);

  const handlePropelToCommunication = useCallback(async () => {
    if (!fiscalConversation) return;
    try {
      const conv = await base44.agents.getConversation(fiscalConversation.id);
      const transfer = buildFiduciaireTransfer(conv.messages);
      const formatted = formatTransferForCommunication(transfer);

      setTransferInfo(transfer);
      setCommInitialMessage(formatted);
      setCommKey((k) => k + 1); // force le remontage du chat communication avec le nouveau message
    } catch (err) {
      console.error("Erreur lors du transfert :", err);
    }
  }, [fiscalConversation]);

  return (
    <div className="space-y-6">
      <Alert className="bg-blue-50 border-blue-200">
        <Info className="w-4 h-4" />
        <AlertTitle>Comment utiliser le Studio Fiduciaires</AlertTitle>
        <AlertDescription>
          Discutez avec l'assistant fiscal à gauche (échéances, bilan, conformité). Une fois
          l'analyse terminée, cliquez sur « Propulser en Communication » pour transférer
          automatiquement le dossier à l'assistant de droite, qui rédigera le message client.
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AgentChat
          agentName="fiduciaire_assistant"
          title="Assistant Fiscal"
          subtitle="Échéances TVA / IPP / ISOC, bilan, conformité"
          accentColor="blue"
          onConversationCreated={handleConversationCreated}
          onPropelToMarketing={handlePropelToCommunication}
          propelLabel="Propulser en Communication"
          placeholder="Ex : Quelles sont les prochaines échéances TVA pour une SRL en régime trimestriel ?" />


        <AgentChat
          key={commKey}
          agentName="fiduciaire_communication_assistant"
          title="Assistant Communication Client"
          subtitle="Rappels, synthèses, demandes de pièces"
          accentColor="emerald"
          initialMessage={commInitialMessage}
          placeholder="Ex : Rédige un rappel d'échéance pour ce client." />

      </div>

      {transferInfo &&
      <Card className="border-emerald-200 bg-emerald-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-emerald-800 flex items-center gap-2">
              <PenTool className="w-4 h-4" />
              Dossier transféré
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-emerald-900">
            Client : <strong>{transferInfo.client?.name || "N/A"}</strong> — {transferInfo.deadlines?.length || 0} échéance(s) transmise(s) à l'assistant communication.
          </CardContent>
        </Card>
      }
    </div>);

}
