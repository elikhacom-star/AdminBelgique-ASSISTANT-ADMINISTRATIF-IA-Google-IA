
import { base44 } from "@/api/base44Client";

/**
 * Service API générique.
 * Encapsule le client backend pour éviter les références directes dans le code UI.
 */
export const api = base44;
export const auth = base44.auth;
export const db = base44.entities;
export const agents = base44.agents;
export const functions = base44.functions;
export const integrations = base44.integrations;
// export const login = base44.auth.login; // Deprecated, use auth.redirectToLogin
