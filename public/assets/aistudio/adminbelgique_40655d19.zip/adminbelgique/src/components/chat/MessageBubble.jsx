import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Zap, CheckCircle2, AlertCircle, Loader2, ChevronRight, Clock, Bot, User as UserIcon, Phone, Link as LinkIcon, CheckSquare } from 'lucide-react';
import { cn } from "@/lib/utils";
import { sanitizeActionUrl } from "@/lib/sanitizeUrl";

const EmergencyDisplay = ({ data }) => {
  if (!data || data.status !== 'EMERGENCY_ACTIVE') return null;
  
  const { immediate_action, document_draft, steps, breadcrumb, branding_phrase, urgency_level } = data;
  const isPhone = immediate_action?.type === 'phone';
  const safeHref = sanitizeActionUrl(immediate_action?.value);

  return (
    <div className="bg-red-50 border-2 border-red-400 rounded-lg p-4 space-y-3 my-2">
      {/* Breadcrumb */}
      {breadcrumb && (
        <div className="text-xs text-red-600 font-semibold uppercase tracking-wider">
          {breadcrumb}
        </div>
      )}
      
      {/* Urgent Action Button */}
      {immediate_action && (
        <a
          href={safeHref}
          target={isPhone ? undefined : '_blank'}
          rel={isPhone ? undefined : 'noopener noreferrer'}
          aria-label={immediate_action.label}
          className="flex min-h-12 items-center gap-3 bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-lg transition-colors"
        >
          {isPhone ? <Phone className="w-5 h-5" /> : <LinkIcon className="w-5 h-5" />}
          <span>{immediate_action.label}</span>
        </a>
      )}
      
      {/* Steps Checklist */}
      {steps && steps.length > 0 && (
        <div className="bg-white rounded-lg p-3 space-y-2">
          <h4 className="font-semibold text-gray-800 flex items-center gap-2">
            <CheckSquare className="w-4 h-4 text-red-600" />
            Prochaines 24h
          </h4>
          <ul className="space-y-1 text-sm text-gray-700">
            {steps.map((step, idx) => (
              <li key={idx} className="flex gap-2">
                <span className="font-bold text-red-600 w-5">{idx + 1}.</span>
                <span>{step}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {/* Document Draft Trigger */}
      {document_draft && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
          <p className="text-sm font-semibold text-yellow-800">{document_draft.title}</p>
          <p className="text-xs text-yellow-700 mt-1">Modèle prêt à générer dans votre espace document.</p>
        </div>
      )}
      
      {/* Branding */}
      {branding_phrase && (
        <div className="border-t border-red-200 pt-2 text-sm font-semibold text-red-800 italic">
          ✓ {branding_phrase}
        </div>
      )}
    </div>
  );
};

const FunctionDisplay = ({ toolCall }) => {
  const [expanded, setExpanded] = useState(false);
  const name = toolCall?.name || 'Function';
  const status = toolCall?.status || 'pending';
  const results = toolCall?.results;

  const parsedResults = (() => {
    if (!results) return null;
    try {
      return typeof results === 'string' ? JSON.parse(results) : results;
    } catch {
      return results;
    }
  })();

  const isError = results && (
    (typeof results === 'string' && /error|failed/i.test(results)) ||
    (parsedResults?.success === false)
  );

  const statusConfig = {
    pending: { icon: Clock, color: 'text-slate-400', text: 'En attente' },
    running: { icon: Loader2, color: 'text-slate-500', text: 'En cours...', spin: true },
    in_progress: { icon: Loader2, color: 'text-slate-500', text: 'En cours...', spin: true },
    completed: isError ?
      { icon: AlertCircle, color: 'text-red-500', text: 'Échoué' } :
      { icon: CheckCircle2, color: 'text-green-600', text: 'Succès' },
    success: { icon: CheckCircle2, color: 'text-green-600', text: 'Succès' },
    failed: { icon: AlertCircle, color: 'text-red-500', text: 'Échoué' },
    error: { icon: AlertCircle, color: 'text-red-500', text: 'Échoué' }
  }[status] || { icon: Zap, color: 'text-slate-500', text: '' };

  const Icon = statusConfig.icon;
  const formattedName = name.split('.').reverse().join(' ').toLowerCase();

  return (
    <div className="mt-2 text-xs">
      <button
        onClick={() => setExpanded(!expanded)}
        className={cn(
          "flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-all",
          "hover:bg-slate-50",
          expanded ? "bg-slate-50 border-slate-300" : "bg-white border-slate-200"
        )}>
        <Icon className={cn("h-3 w-3", statusConfig.color, statusConfig.spin && "animate-spin")} />
        <span className="text-slate-700 capitalize">{formattedName}</span>
        {statusConfig.text &&
          <span className={cn("text-slate-500", isError && "text-red-600")}>
            • {statusConfig.text}
          </span>
        }
        {!statusConfig.spin && (toolCall.arguments_string || results) &&
          <ChevronRight className={cn("h-3 w-3 text-slate-400 transition-transform ml-auto",
            expanded && "rotate-90")} />
        }
      </button>
      
      {expanded && !statusConfig.spin &&
        <div className="mt-1.5 ml-3 pl-3 border-l-2 border-slate-200 space-y-2">
          {toolCall.arguments_string &&
            <div>
              <div className="text-xs text-slate-500 mb-1">Paramètres:</div>
              <pre className="bg-slate-50 rounded-md p-2 text-xs text-slate-600 whitespace-pre-wrap">
                {(() => {
                  try {
                    return JSON.stringify(JSON.parse(toolCall.arguments_string), null, 2);
                  } catch {
                    return toolCall.arguments_string;
                  }
                })()}
              </pre>
            </div>
          }
          {parsedResults &&
            <div>
              <div className="text-xs text-slate-500 mb-1">Résultat:</div>
              <pre className="bg-slate-50 rounded-md p-2 text-xs text-slate-600 whitespace-pre-wrap max-h-48 overflow-auto">
                {typeof parsedResults === 'object' ?
                  JSON.stringify(parsedResults, null, 2) : parsedResults}
              </pre>
            </div>
          }
        </div>
      }
    </div>
  );
};

export default function MessageBubble({ message }) {
  const isUser = message.role === 'user';

  if (message.role === 'system') return null;

  // Try to parse emergency JSON response
  let emergencyData = null;
  let displayContent = message.content ?
    message.content.replace(/\[(Instructie|Anweisung|Instruction):.*?\]/gi, '').trim() :
    '';

  try {
    const trimmed = displayContent.trim();
    if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
      const parsed = JSON.parse(trimmed);
      if (parsed.status === 'EMERGENCY_ACTIVE') {
        emergencyData = parsed;
        displayContent = ''; // Don't show raw JSON
      }
    }
  } catch (e) {
    // Not JSON, continue with markdown
  }

  return (
    <div className={cn("flex items-start gap-3", isUser ? "justify-end" : "justify-start")}>
      {!isUser &&
        <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 mt-0.5">
          <Bot className="w-5 h-5 text-blue-600" />
        </div>
      }
      <div className={cn("max-w-[85%] md:max-w-[75%]", isUser && "flex flex-col items-end")}>
        {/* Emergency Display */}
        {emergencyData && <EmergencyDisplay data={emergencyData} />}
        
        {displayContent &&
          <div className={cn(
            "rounded-2xl px-4 py-2.5",
            isUser ? "bg-yellow-500 text-white" : "bg-white border border-slate-200"
          )}>
            {isUser ?
              <p className="text-sm leading-relaxed">{displayContent}</p> :
              <ReactMarkdown
                className="text-sm prose prose-sm prose-slate max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0"
                components={{
                  p: ({ children }) => <p className="text-gray-800 my-1 leading-relaxed">{children}</p>,
                  a: ({ children, ...props }) => <a {...props} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">{children}</a>
                }}>
                {displayContent}
              </ReactMarkdown>
            }
          </div>
        }
        
        {message.tool_calls?.length > 0 &&
          <div className="space-y-1 mt-2">
            {message.tool_calls.map((toolCall, idx) =>
              <FunctionDisplay key={idx} toolCall={toolCall} />
            )}
          </div>
        }
      </div>
      {isUser &&
        <div className="h-8 w-8 rounded-full bg-yellow-100 flex items-center justify-center flex-shrink-0 mt-0.5">
          <UserIcon className="w-4 h-4 text-yellow-600" />
        </div>
      }
    </div>
  );
}