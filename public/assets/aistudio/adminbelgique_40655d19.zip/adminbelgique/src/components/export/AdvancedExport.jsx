import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Download, FileText, File, Table, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { downloadDocumentPdf } from "@/lib/pdfExport";

export default function AdvancedExport({ document }) {
  const [isExporting, setIsExporting] = useState(false);

  const exportAsPDF = async () => {
    setIsExporting(true);
    try {
      // Mise en page lettre A4 paginée, identique au bouton "Télécharger en PDF"
      await downloadDocumentPdf({ title: document.title, content: document.content });
      toast.success('PDF téléchargé avec succès !');
    } catch (error) {
      console.error('Error exporting PDF:', error);
      toast.error('Erreur lors de l\'export PDF');
    } finally {
      setIsExporting(false);
    }
  };

  const exportAsWord = async () => {
    setIsExporting(true);
    try {
      const { Document: DocxDocument, Packer, Paragraph, TextRun, HeadingLevel } = await import('docx');
      
      const doc = new DocxDocument({
        sections: [{
          properties: {},
          children: [
            new Paragraph({
              text: document.title,
              heading: HeadingLevel.HEADING_1,
            }),
            new Paragraph({
              children: [
                new TextRun({
                  text: `Type: ${document.type}`,
                  italics: true,
                  size: 20,
                }),
              ],
            }),
            new Paragraph({
              children: [
                new TextRun({
                  text: `Catégorie: ${document.category}`,
                  italics: true,
                  size: 20,
                }),
              ],
            }),
            new Paragraph({
              children: [
                new TextRun({
                  text: `Destinataire: ${document.recipient || 'N/A'}`,
                  italics: true,
                  size: 20,
                }),
              ],
            }),
            new Paragraph({
              children: [
                new TextRun({
                  text: `Créé le: ${new Date(document.created_date).toLocaleDateString('fr-BE')}`,
                  italics: true,
                  size: 20,
                }),
              ],
            }),
            new Paragraph({ text: '' }),
            new Paragraph({ text: '' }),
            ...document.content.split('\n').map(line => 
              new Paragraph({
                children: [new TextRun({ text: line, size: 24 })],
              })
            ),
          ],
        }],
      });

      const blob = await Packer.toBlob(doc);
      const url = window.URL.createObjectURL(blob);
      const a = window.document.createElement('a');
      a.href = url;
      a.download = `${document.title}.docx`;
      window.document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
      
      toast.success('Document Word téléchargé !');
    } catch (error) {
      console.error('Error exporting Word:', error);
      toast.error('Erreur lors de l\'export Word');
    } finally {
      setIsExporting(false);
    }
  };

  const exportAsText = () => {
    const content = `${document.title}\n\n` +
                   `Type: ${document.type}\n` +
                   `Catégorie: ${document.category}\n` +
                   `Destinataire: ${document.recipient || 'N/A'}\n` +
                   `Créé le: ${new Date(document.created_date).toLocaleDateString('fr-BE')}\n\n` +
                   `${'='.repeat(50)}\n\n` +
                   `${document.content}\n\n` +
                   `${'='.repeat(50)}\n` +
                   `Généré par AdminBelgique.com`;
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = window.document.createElement('a');
    a.href = url;
    a.download = `${document.title}.txt`;
    window.document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
    
    toast.success('Fichier texte téléchargé !');
  };

  const exportAsCSV = () => {
    const csvContent = [
      ['Champ', 'Valeur'],
      ['Titre', document.title],
      ['Type', document.type],
      ['Catégorie', document.category],
      ['Destinataire', document.recipient || 'N/A'],
      ['Date création', new Date(document.created_date).toLocaleDateString('fr-BE')],
      ['Contenu', document.content.replace(/\n/g, ' ')]
    ].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const a = window.document.createElement('a');
    a.href = url;
    a.download = `${document.title}.csv`;
    window.document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
    
    toast.success('Fichier CSV téléchargé !');
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" disabled={isExporting}>
          {isExporting ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Export...
            </>
          ) : (
            <>
              <Download className="w-4 h-4 mr-2" />
              Exporter
            </>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel className="flex items-center gap-2">
          <Download className="w-4 h-4" />
          Formats d'export
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        <DropdownMenuItem onClick={exportAsPDF} className="cursor-pointer">
          <FileText className="w-4 h-4 mr-2 text-red-600" />
          <span className="flex-1">PDF</span>
          <Badge variant="secondary" className="text-xs">Recommandé</Badge>
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={exportAsWord} className="cursor-pointer">
          <File className="w-4 h-4 mr-2 text-blue-600" />
          <span className="flex-1">Word (.docx)</span>
          <Badge variant="secondary" className="text-xs">Éditable</Badge>
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={exportAsText} className="cursor-pointer">
          <FileText className="w-4 h-4 mr-2 text-gray-600" />
          <span>Texte (.txt)</span>
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={exportAsCSV} className="cursor-pointer">
          <Table className="w-4 h-4 mr-2 text-green-600" />
          <span>CSV (.csv)</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}