import { useContext } from 'react';
import { LanguageContext } from './LanguageContext';
import { translations } from './strings';

export const useTranslation = () => {
  const { locale } = useContext(LanguageContext);

  const t = (key) => {
    if (translations[key] && translations[key][locale]) {
      return translations[key][locale];
    }
    // Fallback to the key if translation is not found
    console.warn(`Translation not found for key: ${key} and locale: ${locale}`);
    return key;
  };

  return { t, locale };
};