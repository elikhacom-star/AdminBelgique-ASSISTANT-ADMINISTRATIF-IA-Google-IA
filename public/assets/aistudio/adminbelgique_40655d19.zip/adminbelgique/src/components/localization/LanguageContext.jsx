import React, { createContext, useState, useEffect } from 'react';

export const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
  const [locale, setLocale] = useState('fr');

  useEffect(() => {
    const savedLocale = localStorage.getItem('app-locale');
    if (savedLocale && ['fr', 'nl', 'de'].includes(savedLocale)) {
      setLocale(savedLocale);
    }
  }, []);

  const changeLocale = (newLocale) => {
    if (['fr', 'nl', 'de'].includes(newLocale)) {
      setLocale(newLocale);
      localStorage.setItem('app-locale', newLocale);
    }
  };

  return (
    <LanguageContext.Provider value={{ locale, changeLocale }}>
      {children}
    </LanguageContext.Provider>
  );
};