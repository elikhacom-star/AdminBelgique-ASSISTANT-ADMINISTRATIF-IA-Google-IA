import React, { useState } from "react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info, X } from "lucide-react";
import { Button } from "@/components/ui/button";

/**
 * 🚨 Bannière de disclaimer pour clarifier que c'est un service PRIVÉ
 * Affichée en haut de toutes les pages principales
 */
export default function DisclaimerBanner() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <Alert className="rounded-none border-l-4 border-l-blue-600 bg-blue-50 border-blue-200 mb-0 p-2 md:p-4">
      <div className="flex items-start gap-3 max-w-7xl mx-auto">
        <Info className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
        <AlertDescription className="flex-1 text-xs md:text-sm text-blue-900 leading-tight">
          <strong>Information importante :</strong> AdminBelgique.com est un <strong>service privé d'assistance administrative</strong> propulsé par l'intelligence artificielle. 
          Nous ne sommes <strong>en aucun cas affiliés, soutenus ou mandatés</strong> par une entité gouvernementale ou administrative belge (SPF Finances, INAMI, ONEM, etc.).
        </AlertDescription>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsVisible(false)}
          className="text-blue-600 hover:text-blue-800 hover:bg-blue-100 -mt-1 -mr-2"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
    </Alert>
  );
}