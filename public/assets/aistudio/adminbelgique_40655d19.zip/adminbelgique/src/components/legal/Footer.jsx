import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Mail, Phone, Globe, Shield } from "lucide-react";
import { Separator } from "@/components/ui/separator";

/**
 * 🦶 Footer avec disclaimer légal et mentions obligatoires
 */
export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 mt-auto">
      {/* Disclaimer Section - TRÈS VISIBLE */}
      <div className="bg-blue-900 border-t-4 border-blue-500 my-24 pb-1">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-start gap-3">
            <Shield className="w-6 h-6 text-blue-300 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-white font-bold text-lg mb-2">
                ⚠️ Service Privé Indépendant
              </h3>
              <p className="text-blue-200 leading-relaxed">
                <strong>AdminBelgique.com</strong> est un <strong>service privé d'assistance administrative</strong> propulsé par l'intelligence artificielle. 
                Nous ne sommes <strong>en aucun cas affiliés, soutenus ou mandatés</strong> par une entité gouvernementale ou administrative belge telle que le SPF Finances, l'INAMI, l'ONEM, ou toute autre institution publique. 
                Notre plateforme est une <strong>initiative privée indépendante</strong> visant à simplifier les démarches administratives des citoyens et entreprises.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Company Info */}
          <div>
            <h4 className="text-white font-bold text-lg mb-4">AdminBelgique</h4>
            <p className="text-sm text-gray-400 mb-4">
              Plateforme privée d'assistance administrative intelligente pour la Belgique
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-gray-400" />
                <a href="mailto:contact@adminbelgique.com" className="hover:text-white transition-colors">
                  contact@adminbelgique.com
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-gray-400" />
                <a href="tel:+32467801041" className="hover:text-white transition-colors">
                  +32 467 80 10 41
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-gray-400" />
                <a href="https://adminbelgique.com" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                  www.adminbelgique.com
                </a>
              </div>
            </div>
          </div>

          {/* Legal Links */}
          <div>
            <h4 className="text-white font-bold text-lg mb-4">Informations Légales</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to={createPageUrl("MentionsLegales")} className="hover:text-white transition-colors">
                  Mentions Légales
                </Link>
              </li>
              <li>
                <Link to={createPageUrl("About")} className="hover:text-white transition-colors">
                  À Propos
                </Link>
              </li>
              <li>
                <Link to={createPageUrl("Contact")} className="hover:text-white transition-colors">
                  Nous Contacter
                </Link>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Politique de Confidentialité
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Conditions Générales
                </a>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-bold text-lg mb-4">Nos Services</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to={createPageUrl("Assistant")} className="hover:text-white transition-colors">
                  Assistant IA Simple
                </Link>
              </li>
              <li>
                <Link to={createPageUrl("Chat")} className="hover:text-white transition-colors">
                  Agent IA Avancé
                </Link>
              </li>
              <li>
                <Link to={createPageUrl("DocumentGenerator")} className="hover:text-white transition-colors">
                  Générateur de Documents
                </Link>
              </li>
              <li>
                <Link to={createPageUrl("DocumentAnalyzer")} className="hover:text-white transition-colors">
                  Analyse de Documents
                </Link>
              </li>
              <li>
                <Link to={createPageUrl("ImmoBoostScrap")} className="hover:text-white transition-colors">
                  ImmoScrap Pro
                </Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="text-white font-bold text-lg mb-4">Ressources</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to={createPageUrl("Help")} className="hover:text-white transition-colors">
                  Guide d'Aide
                </Link>
              </li>
              <li>
                <Link to={createPageUrl("FAQ")} className="hover:text-white transition-colors">
                  Questions Fréquentes
                </Link>
              </li>
              <li>
                <Link to={createPageUrl("Blog")} className="hover:text-white transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link to={createPageUrl("Pricing")} className="hover:text-white transition-colors">
                  Tarifs
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <Separator className="my-8 bg-gray-700" />

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-400">
          <p>
            © {new Date().getFullYear()} <strong className="text-white">AdminBelgique</strong> - Service Privé d'Assistance Administrative. Tous droits réservés.
          </p>
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            <span>Propulsé par Intelligence Artificielle</span>
          </div>
        </div>
      </div>
    </footer>);

}