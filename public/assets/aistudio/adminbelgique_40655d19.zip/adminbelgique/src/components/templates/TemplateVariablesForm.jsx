import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function TemplateVariablesForm({ placeholders, values, onChange }) {
  if (placeholders.length === 0) {
    return (
      <p className="text-sm text-gray-500 bg-gray-50 border rounded-lg p-3">
        Ce modèle ne contient aucune variable à compléter, il est prêt à être généré.
      </p>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {placeholders.map((key, index) => (
        <div key={key} className="grid gap-1.5">
          <Label htmlFor={`template-var-${index}`} className="text-xs text-gray-600">
            {key}
          </Label>
          <Input
            id={`template-var-${index}`}
            value={values[key] || ""}
            onChange={(e) => onChange(key, e.target.value)}
            placeholder={key}
            className="border-gray-200"
          />
        </div>
      ))}
    </div>
  );
}