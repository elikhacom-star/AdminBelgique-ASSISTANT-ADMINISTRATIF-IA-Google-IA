import { LOGEMENT_TEMPLATES } from "@/components/templates/starters/logement";
import { EMPLOI_TEMPLATES } from "@/components/templates/starters/emploi";
import { FINANCES_TEMPLATES } from "@/components/templates/starters/finances";
import { ADMINISTRATIF_TEMPLATES } from "@/components/templates/starters/administratif";

export const STARTER_CATEGORY_LABELS = {
  finances: "Finances",
  logement: "Logement",
  emploi: "Emploi",
  sante: "Santé",
  securite_sociale: "Sécurité sociale",
  pensions: "Pensions",
  etudes: "Études",
  autre: "Autres"
};

const BASE_STARTER_TEMPLATES = [
  {
    id: "starter-mise-en-demeure-payer",
    icon: "⚖️",
    title: "Mise en demeure de payer",
    description: "Sommation formelle de régler une facture ou une créance impayée.",
    category: "finances",
    type: "mise_en_demeure",
    content: `Madame, Monsieur,

Sauf erreur de ma part, la facture n° [NUMÉRO DE FACTURE] du [DATE DE FACTURE], d'un montant de [MONTANT] €, relative à [OBJET DE LA CRÉANCE], demeure impayée à ce jour.

Par la présente, je vous mets en demeure de procéder au paiement intégral de cette somme dans un délai de [DÉLAI] jours à compter de la réception de la présente.

Modalités de paiement :
- Montant à payer : [MONTANT] €
- IBAN : [IBAN]
- Communication : [COMMUNICATION]

À défaut de paiement dans le délai imparti, je serai contraint(e) d'entamer une procédure de recouvrement et, le cas échéant, une action judiciaire, avec demande des intérêts de retard et des frais y afférents.

Je vous prie d'agréer, Madame, Monsieur, l'expression de mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE DU CRÉANCIER]`
  },
  {
    id: "starter-mise-en-demeure-pro",
    icon: "💼",
    title: "Mise en demeure professionnelle (facture impayée)",
    description: "Courrier de recouvrement ferme pour une entreprise ou un indépendant.",
    category: "finances",
    type: "mise_en_demeure",
    content: `Madame, Monsieur,

Conformément à nos conditions générales de vente et à la commande n° [NUMÉRO DE COMMANDE] du [DATE], la facture n° [NUMÉRO DE FACTURE] d'un montant de [MONTANT] € HTVA reste impayée à son échéance.

Après plusieurs rappels amiables restés sans réponse, nous vous mettons en demeure de payer la somme totale de [MONTANT] € (principal et intérêts de retard) dans un délai de [DÉLAI] jours.

En cas de non-paiement, nous nous réservons le droit de :
- suspendre toute prestation ou livraison en cours ;
- transmettre le dossier à notre service de recouvrement ;
- introduire une action judiciaire devant le tribunal de [ARRONDISSEMENT].

Coordonnées bancaires : [IBAN] — Communication : [COMMUNICATION].

Veuillez agréer, Madame, Monsieur, l'expression de nos salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM DE L'ENTREPRISE ET SIGNATURE]`
  },
  {
    id: "starter-mise-en-demeure-garantie",
    icon: "🔑",
    title: "Mise en demeure de restituer la garantie locative",
    description: "Réclamez le remboursement de votre garantie locative après la sortie.",
    category: "logement",
    type: "mise_en_demeure",
    content: `Madame, Monsieur,

Je soussigné(e) [NOM DU LOCATAIRE], locataire du bien sis [ADRESSE DU BIEN], vous ai restitué les lieux le [DATE DE SORTIE], date à laquelle le contrat de bail a pris fin.

Conformément à [RÉFÉRENCE — ex. article 1731 du Code civil / contrat de bail], la garantie locative d'un montant de [MONTANT] € doit m'être restituée dans les [DÉLAI — ex. deux mois] suivant la remise des clés, déduction faite des éventuelles dégradations dûment justifiées.

À ce jour, je n'ai reçu ni la restitution de la garantie, ni la justification écrite d'une retenue.

Par la présente, je vous mets en demeure de me verser la somme de [MONTANT] € sur le compte [IBAN] dans un délai de [DÉLAI] jours.

À défaut, je me réserve le droit de saisir les instances compétentes (juge de paix).

Veuillez agréer, Madame, Monsieur, l'expression de mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-mise-en-demeure-travaux",
    icon: "🔧",
    title: "Mise en demeure d'exécuter des travaux",
    description: "Sommez le bailleur ou le syndic de réaliser des travaux convenus.",
    category: "logement",
    type: "mise_en_demeure",
    content: `Madame, Monsieur,

En ma qualité de [PROPRIÉTAIRE OU LOCATAIRE] du bien sis [ADRESSE DU BIEN], je vous signale que les travaux suivants restent à exécuter : [DESCRIPTION DES TRAVAUX].

Malgré ma demande du [DATE DE LA DEMANDE], ces travaux n'ont pas été réalisés à ce jour, ce qui entraîne [CONSÉQUENCES — ex. des infiltrations d'eau, une perte de jouissance].

Par la présente, je vous mets en demeure d'exécuter ces travaux dans un délai de [DÉLAI] jours à compter de la réception de la présente.

À défaut, je me réserve le droit de faire exécuter les travaux par une entreprise tierce, à vos frais, et de saisir les instances compétentes.

Veuillez agréer, Madame, Monsieur, l'expression de mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-bail-residence-principale",
    icon: "🏠",
    title: "Contrat de bail de résidence principale",
    description: "Bail complet : loyer, charges, indexation, garantie et état des lieux.",
    category: "logement",
    type: "bail",
    content: `CONTRAT DE BAIL DE RÉSIDENCE PRINCIPALE

Entre les soussignés :

Le bailleur : [NOM DU BAILLEUR], domicilié(e) à [ADRESSE DU BAILLEUR].
Le locataire : [NOM DU LOCATAIRE], domicilié(e) à [ADRESSE ACTUELLE DU LOCATAIRE].

Il a été convenu ce qui suit :

Article 1 — Objet
Le bailleur donne en location au locataire le bien sis [ADRESSE COMPLÈTE DU BIEN], composé de [DESCRIPTION DU BIEN], destiné exclusivement à l'habitation et constituant la résidence principale du locataire.

Article 2 — Durée
Le bail prend effet le [DATE DE DÉBUT] pour une durée de [DURÉE — ex. 9 ans]. Il se renouvelle ensuite selon les règles applicables au bail de résidence principale.

Article 3 — Loyer
Le loyer mensuel est fixé à [LOYER] €. Il est payable au plus tard le [JOUR] de chaque mois sur le compte [IBAN DU BAILLEUR].

Article 4 — Charges et indexation
Les charges forfaitaires s'élèvent à [CHARGES] € par mois. Le loyer est indexé selon la formule légale applicable en Région [RÉGION].

Article 5 — Garantie locative
Une garantie locative de [MONTANT DE LA GARANTIE] € est constituée sous la forme de [COMPTE BLOQUÉ OU GARANTIE BANCAIRE].

Article 6 — Obligations des parties
Le locataire s'engage à user paisiblement du bien, à payer le loyer et les charges, à effectuer l'entretien locatif et à ne pas sous-louer sans l'accord écrit du bailleur. Le bailleur s'engage à délivrer un bien conforme et à garantir la jouissance paisible des lieux.

Article 7 — État des lieux
Un état des lieux contradictoire est établi lors de l'entrée et lors de la sortie des lieux.

Fait à [LIEU], le [DATE], en deux exemplaires.

Le bailleur : [SIGNATURE DU BAILLEUR]

Le locataire : [SIGNATURE DU LOCATAIRE]`
  },
  {
    id: "starter-resiliation-bail",
    icon: "📤",
    title: "Résiliation de bail par le locataire",
    description: "Lettre de préavis pour quitter un logement en respectant les délais.",
    category: "logement",
    type: "autre",
    content: `Madame, Monsieur,

Je soussigné(e) [NOM DU LOCATAIRE], locataire du bien sis [ADRESSE DU BIEN], vous informe par la présente de ma décision de résilier le contrat de bail de résidence principale relatif à ce bien.

Conformément au contrat et à la réglementation applicable en Région [RÉGION], je respecte un préavis de [DURÉE DU PRÉAVIS — ex. 3 mois], notifié par écrit, prenant cours le [DATE DE DÉBUT DU PRÉAVIS].

Le bail prendra donc fin le [DATE DE FIN DU BAIL].

Je vous propose de fixer la date de l'état des lieux de sortie le [DATE SOUHAITÉE] et de convenir ensemble des modalités de remise des clés.

Je vous remercie de bien vouloir me confirmer la réception de la présente.

Veuillez agréer, Madame, Monsieur, l'expression de mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  }
];

export const STARTER_TEMPLATES = [
  ...BASE_STARTER_TEMPLATES,
  ...LOGEMENT_TEMPLATES,
  ...FINANCES_TEMPLATES,
  ...EMPLOI_TEMPLATES,
  ...ADMINISTRATIF_TEMPLATES
];