import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Wand2 } from "lucide-react";
import { STARTER_TEMPLATES, STARTER_CATEGORY_LABELS } from "@/components/templates/starterTemplates";

export default function StarterTemplates({ onSelect }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const term = searchTerm.toLowerCase().trim();

  const categories = ["all", ...Object.keys(STARTER_CATEGORY_LABELS).filter((key) =>
    STARTER_TEMPLATES.some((template) => template.category === key)
  )];

  const filteredTemplates = STARTER_TEMPLATES.filter(
    (template) =>
      (activeCategory === "all" || template.category === activeCategory) &&
      (template.title.toLowerCase().includes(term) ||
        template.description.toLowerCase().includes(term))
  );

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Rechercher : mise en demeure, bail, garantie locative..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 border-gray-200"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pt-3 pb-1">
          {categories.map((key) => (
            <Button
              key={key}
              size="sm"
              variant={activeCategory === key ? "default" : "outline"}
              onClick={() => setActiveCategory(key)}
              className="shrink-0 rounded-full"
            >
              {key === "all" ? `Tous (${STARTER_TEMPLATES.length})` : STARTER_CATEGORY_LABELS[key]}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.map((template) => (
          <Card key={template.id} className="flex flex-col hover:shadow-lg transition-all duration-200">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-2xl">{template.icon}</span>
                <Badge variant="secondary">{STARTER_CATEGORY_LABELS[template.category] || template.category}</Badge>
              </div>
              <CardTitle className="text-lg">{template.title}</CardTitle>
              <CardDescription>{template.description}</CardDescription>
            </CardHeader>
            <CardContent className="mt-auto">
              <Button
                className="w-full bg-blue-600 hover:bg-blue-700"
                onClick={() => onSelect(template)}
              >
                <Wand2 className="w-4 h-4 mr-2" />
                Générer en 1 clic
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredTemplates.length === 0 && (
        <div className="text-center py-16 bg-white rounded-xl border-2 border-dashed border-gray-200">
          <p className="text-gray-500">Aucun modèle ne correspond à votre recherche.</p>
        </div>
      )}
    </div>
  );
}