export const FINANCES_TEMPLATES = [
  {
    id: "starter-plan-paiement",
    icon: "🗓️",
    title: "Demande de plan de paiement",
    description: "Proposez un échelonnement de votre dette à un créancier.",
    category: "finances",
    type: "demande_renseignements",
    content: `Madame, Monsieur,

Je fais suite à votre réclamation du [DATE DE LA RÉCLAMATION] concernant la somme de [MONTANT DÛ] € (référence [RÉFÉRENCE DU DOSSIER]).

Ma situation actuelle ne me permet pas de régler cette somme en une fois : [MOTIF DES DIFFICULTÉS].

Je vous propose un plan de paiement de [MONTANT MENSUEL] € par mois, pendant [NOMBRE DE MOIS] mois, à partir du [DATE DE DÉBUT].

Je vous remercie de me confirmer votre accord par écrit.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-contestation-facture",
    icon: "🧮",
    title: "Contestation de facture",
    description: "Contestez une facture erronée ou une prestation non fournie.",
    category: "finances",
    type: "lettre_reclamation",
    content: `Madame, Monsieur,

Je conteste la facture n° [NUMÉRO DE FACTURE] du [DATE DE LA FACTURE] d'un montant de [MONTANT] €.

Motif : [MOTIF DE LA CONTESTATION].

Je vous demande de bien vouloir la corriger ou l'annuler, et de me transmettre les justificatifs correspondants dans un délai de [DÉLAI] jours. Dans l'attente, je suspends le paiement de la somme contestée.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-demande-remboursement",
    icon: "💶",
    title: "Demande de remboursement",
    description: "Réclamez le remboursement d'un achat ou d'un trop-perçu.",
    category: "finances",
    type: "demande_remboursement",
    content: `Madame, Monsieur,

Le [DATE DE L'ACHAT], j'ai payé la somme de [MONTANT] € pour [OBJET DE L'ACHAT] (commande n° [NUMÉRO DE COMMANDE]).

Comme [MOTIF DU REMBOURSEMENT], je vous demande de me rembourser cette somme sur le compte [IBAN] dans un délai de [DÉLAI] jours.

Pièces jointes : [LISTE DES PIÈCES].

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-droit-retractation",
    icon: "↩️",
    title: "Rétractation d'un achat en ligne",
    description: "Exercez votre droit de rétractation de 14 jours.",
    category: "finances",
    type: "autre",
    content: `Madame, Monsieur,

Je vous informe par la présente que j'exerce mon droit de rétractation concernant la commande n° [NUMÉRO DE COMMANDE] passée le [DATE DE LA COMMANDE] et reçue le [DATE DE RÉCEPTION], portant sur [DESCRIPTION DU PRODUIT OU SERVICE].

Je vous demande de me rembourser la somme de [MONTANT] € sur le compte [IBAN] dans un délai de 14 jours.

Le produit sera retourné selon les modalités suivantes : [MODALITÉS DE RETOUR].

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-reclamation-banque",
    icon: "🏦",
    title: "Réclamation auprès d'une banque",
    description: "Contestez une opération, des frais ou un blocage de compte.",
    category: "finances",
    type: "lettre_reclamation",
    content: `Madame, Monsieur,

Titulaire du compte [NUMÉRO DE COMPTE IBAN], je vous adresse une réclamation concernant [OBJET DE LA RÉCLAMATION] survenu le [DATE DES FAITS], pour un montant de [MONTANT] €.

Exposé des faits : [DESCRIPTION DES FAITS].

Je vous demande de [DEMANDE — ex. rembourser, corriger, débloquer] dans un délai de [DÉLAI] jours. À défaut, je saisirai l'Ombudsfin.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-recours-impots",
    icon: "🧾",
    title: "Réclamation contre une taxation (SPF Finances)",
    description: "Contestez un avertissement-extrait de rôle dans le délai légal.",
    category: "finances",
    type: "recours",
    content: `Madame, Monsieur,

Je soussigné(e) [NOM ET PRÉNOM], numéro national [NUMÉRO NATIONAL], introduis une réclamation contre l'avertissement-extrait de rôle n° [NUMÉRO DE L'AVERTISSEMENT] daté du [DATE], relatif à l'exercice d'imposition [EXERCICE D'IMPOSITION].

Motifs de la réclamation : [MOTIFS].

Je demande que la cotisation soit ramenée à [MONTANT DEMANDÉ] € et je souhaite être entendu(e) si nécessaire.

Pièces jointes : [LISTE DES PIÈCES].

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-resiliation-abonnement",
    icon: "✂️",
    title: "Résiliation d'abonnement ou de contrat",
    description: "Téléphonie, énergie, salle de sport : mettez fin à un contrat.",
    category: "finances",
    type: "autre",
    content: `Madame, Monsieur,

Je soussigné(e) [NOM ET PRÉNOM], client(e) sous le numéro [NUMÉRO DE CLIENT], vous informe de ma décision de résilier le contrat [TYPE DE CONTRAT] souscrit le [DATE DE SOUSCRIPTION].

Cette résiliation prend effet le [DATE DE FIN SOUHAITÉE], dans le respect du préavis de [PRÉAVIS].

Merci de me confirmer la résiliation par écrit et de m'adresser la facture de clôture.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-reconnaissance-dette",
    icon: "🤝",
    title: "Reconnaissance de dette",
    description: "Document signé fixant un prêt entre particuliers et son remboursement.",
    category: "finances",
    type: "autre",
    content: `RECONNAISSANCE DE DETTE

Je soussigné(e) [NOM DU DÉBITEUR], domicilié(e) à [ADRESSE DU DÉBITEUR], reconnais devoir à [NOM DU CRÉANCIER], domicilié(e) à [ADRESSE DU CRÉANCIER], la somme de [MONTANT EN CHIFFRES] € ([MONTANT EN LETTRES]).

Cette somme a été remise le [DATE DE REMISE] et sera remboursée [MODALITÉS DE REMBOURSEMENT — échéances et dates] sur le compte [IBAN DU CRÉANCIER].

Taux d'intérêt éventuel : [TAUX D'INTÉRÊT].

Fait à [LIEU], le [DATE], en deux exemplaires.

Le débiteur : [SIGNATURE DU DÉBITEUR]
Le créancier : [SIGNATURE DU CRÉANCIER]`
  }
];