export const ADMINISTRATIF_TEMPLATES = [
  {
    id: "starter-mutuelle-remboursement",
    icon: "🏥",
    title: "Réclamation auprès de la mutuelle",
    description: "Contestez un refus ou un retard de remboursement de soins.",
    category: "sante",
    type: "lettre_reclamation",
    content: `Madame, Monsieur,

Affilié(e) sous le numéro [NUMÉRO D'AFFILIATION], je n'ai pas obtenu le remboursement de [SOINS OU PRESTATION] du [DATE DES SOINS], pour un montant de [MONTANT] €.

Motif invoqué : [MOTIF DU REFUS OU DU RETARD].

Je vous demande de réexaminer mon dossier et de procéder au remboursement dans un délai de [DÉLAI] jours. Pièces jointes : [LISTE DES PIÈCES].

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-contestation-facture-hopital",
    icon: "💊",
    title: "Contestation de facture d'hôpital",
    description: "Demandez le détail ou la rectification d'une facture médicale.",
    category: "sante",
    type: "lettre_reclamation",
    content: `Madame, Monsieur,

J'ai reçu la facture n° [NUMÉRO DE FACTURE] du [DATE DE LA FACTURE] d'un montant de [MONTANT] € relative à [SÉJOUR OU CONSULTATION].

Je conteste [ÉLÉMENT CONTESTÉ] pour la raison suivante : [MOTIF].

Merci de me transmettre le détail des prestations et suppléments facturés ainsi que la part remboursée par ma mutuelle.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-allocations-familiales",
    icon: "👨‍👩‍👧",
    title: "Demande d'informations sur les allocations familiales",
    description: "Vérifiez vos droits ou signalez un changement de situation.",
    category: "securite_sociale",
    type: "demande_renseignements",
    content: `Madame, Monsieur,

Allocataire sous le numéro [NUMÉRO D'ALLOCATAIRE], je vous écris au sujet de [OBJET DE LA DEMANDE — droits, changement de situation, retard].

Ma situation : [DESCRIPTION DE LA SITUATION FAMILIALE], avec effet au [DATE DU CHANGEMENT].

Pouvez-vous me confirmer mes droits et les démarches à suivre ? Pièces jointes : [LISTE DES PIÈCES].

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-recours-securite-sociale",
    icon: "⚖️",
    title: "Recours contre une décision de sécurité sociale",
    description: "Contestez une décision auprès de l'organisme compétent.",
    category: "securite_sociale",
    type: "recours",
    content: `Madame, Monsieur,

Je soussigné(e) [NOM ET PRÉNOM], numéro national [NUMÉRO NATIONAL], conteste la décision du [DATE DE LA DÉCISION] rendue par [ORGANISME] (dossier [RÉFÉRENCE DU DOSSIER]).

Motifs : [MOTIFS DU RECOURS].

Je demande le réexamen de mon dossier et [DEMANDE PRÉCISE]. Je me réserve la possibilité d'introduire un recours devant le tribunal du travail dans le délai légal.

Pièces jointes : [LISTE DES PIÈCES].

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-pension-demande-info",
    icon: "🧓",
    title: "Demande d'extrait de carrière (pension)",
    description: "Obtenez le relevé de votre carrière auprès du service des pensions.",
    category: "pensions",
    type: "demande_renseignements",
    content: `Madame, Monsieur,

Je soussigné(e) [NOM ET PRÉNOM], né(e) le [DATE DE NAISSANCE], numéro national [NUMÉRO NATIONAL], vous prie de bien vouloir me transmettre un relevé détaillé de ma carrière et une estimation de ma pension.

Je souhaite prendre ma retraite à partir du [DATE SOUHAITÉE DE DÉPART].

Je vous remercie d'avance de votre réponse.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-bourse-etudes",
    icon: "🎓",
    title: "Demande d'allocation d'études",
    description: "Sollicitez une aide financière pour vos études.",
    category: "etudes",
    type: "demande_renseignements",
    content: `Madame, Monsieur,

Inscrit(e) pour l'année académique [ANNÉE ACADÉMIQUE] à [ÉTABLISSEMENT] en [FILIÈRE], je sollicite une allocation d'études.

Ma situation : revenus du ménage de [REVENUS DU MÉNAGE] €, [NOMBRE DE PERSONNES À CHARGE] personne(s) à charge.

Je vous transmets les pièces justificatives suivantes : [LISTE DES PIÈCES].

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-procuration",
    icon: "🖊️",
    title: "Procuration",
    description: "Autorisez une personne à agir en votre nom pour une démarche.",
    category: "autre",
    type: "autre",
    content: `PROCURATION

Je soussigné(e) [NOM DU MANDANT], né(e) le [DATE DE NAISSANCE DU MANDANT], domicilié(e) à [ADRESSE DU MANDANT], donne procuration à [NOM DU MANDATAIRE], domicilié(e) à [ADRESSE DU MANDATAIRE], afin de [OBJET DE LA PROCURATION] auprès de [ADMINISTRATION OU ORGANISME].

Cette procuration est valable du [DATE DE DÉBUT] au [DATE DE FIN].

Fait à [LIEU], le [DATE]

Le mandant : [SIGNATURE DU MANDANT]
Le mandataire : [SIGNATURE DU MANDATAIRE]`
  },
  {
    id: "starter-plainte-administration",
    icon: "📣",
    title: "Plainte auprès d'une administration",
    description: "Signalez un dysfonctionnement ou un délai anormal.",
    category: "autre",
    type: "plainte_administrative",
    content: `Madame, Monsieur,

Je soussigné(e) [NOM ET PRÉNOM], vous adresse une plainte concernant [OBJET DE LA PLAINTE] (dossier [RÉFÉRENCE DU DOSSIER]).

Faits : [EXPOSÉ DES FAITS], depuis le [DATE DE DÉBUT DES FAITS].
Démarches déjà entreprises : [DÉMARCHES ANTÉRIEURES].

Je vous demande de traiter ma demande dans un délai de [DÉLAI] jours. À défaut, je saisirai le médiateur fédéral.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-reclamation-produit-defectueux",
    icon: "📦",
    title: "Réclamation pour produit défectueux (garantie légale)",
    description: "Exigez réparation, remplacement ou remboursement sous garantie.",
    category: "autre",
    type: "lettre_reclamation",
    content: `Madame, Monsieur,

Le [DATE D'ACHAT], j'ai acheté [PRODUIT] pour [MONTANT] € (facture n° [NUMÉRO DE FACTURE]). Le produit présente le défaut suivant : [DESCRIPTION DU DÉFAUT], apparu le [DATE D'APPARITION].

En vertu de la garantie légale de deux ans, je vous demande [SOLUTION DEMANDÉE — réparation, remplacement ou remboursement] dans un délai de [DÉLAI] jours.

À défaut, je me réserve le droit d'engager les recours nécessaires.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  }
];