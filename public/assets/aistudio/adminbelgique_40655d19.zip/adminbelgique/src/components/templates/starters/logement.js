export const LOGEMENT_TEMPLATES = [
  {
    id: "starter-bail-courte-duree",
    icon: "📅",
    title: "Contrat de bail de courte durée",
    description: "Bail de 3 ans maximum : loyer, garantie, durée et conditions de sortie.",
    category: "logement",
    type: "bail",
    content: `CONTRAT DE BAIL DE COURTE DURÉE

Entre :
Le bailleur : [NOM DU BAILLEUR], domicilié(e) à [ADRESSE DU BAILLEUR].
Le locataire : [NOM DU LOCATAIRE], domicilié(e) à [ADRESSE DU LOCATAIRE].

Article 1 — Objet
Le bailleur loue au locataire le bien sis [ADRESSE DU BIEN], destiné à l'habitation.

Article 2 — Durée
Le bail est conclu pour une durée de [DURÉE — max. 3 ans], du [DATE DE DÉBUT] au [DATE DE FIN]. Il prend fin de plein droit à l'échéance, sauf prorogation écrite.

Article 3 — Loyer et charges
Loyer mensuel : [LOYER] €. Charges : [CHARGES] € par mois. Paiement au plus tard le [JOUR] du mois sur le compte [IBAN DU BAILLEUR].

Article 4 — Garantie locative
Une garantie de [MONTANT DE LA GARANTIE] € est constituée sous la forme de [COMPTE BLOQUÉ OU GARANTIE BANCAIRE].

Article 5 — État des lieux
Un état des lieux contradictoire est établi à l'entrée et à la sortie.

Fait à [LIEU], le [DATE], en deux exemplaires.

Le bailleur : [SIGNATURE DU BAILLEUR]
Le locataire : [SIGNATURE DU LOCATAIRE]`
  },
  {
    id: "starter-bail-colocation",
    icon: "👥",
    title: "Pacte de colocation",
    description: "Répartition du loyer, des charges et des règles de vie entre colocataires.",
    category: "logement",
    type: "bail",
    content: `PACTE DE COLOCATION

Les soussignés :
[NOM DU COLOCATAIRE 1], [NOM DU COLOCATAIRE 2] et [NOM DU COLOCATAIRE 3],
colocataires du bien sis [ADRESSE DU BIEN], conviennent de ce qui suit.

Article 1 — Loyer et charges
Le loyer total de [LOYER TOTAL] € et les charges de [CHARGES TOTALES] € sont répartis comme suit : [RÉPARTITION — ex. parts égales].

Article 2 — Solidarité
Les colocataires sont tenus solidairement envers le bailleur, sauf clause contraire au bail.

Article 3 — Vie commune
Les règles suivantes sont convenues : [RÈGLES DE VIE — ménage, visites, bruit, animaux].

Article 4 — Départ d'un colocataire
Tout colocataire quittant les lieux prévient les autres [PRÉAVIS — ex. 2 mois] à l'avance et aide à trouver un remplaçant.

Article 5 — Garantie locative
La garantie de [MONTANT DE LA GARANTIE] € est restituée selon [MODALITÉS DE RESTITUTION].

Fait à [LIEU], le [DATE].

[SIGNATURES DES COLOCATAIRES]`
  },
  {
    id: "starter-etat-des-lieux",
    icon: "📋",
    title: "État des lieux d'entrée ou de sortie",
    description: "Constat pièce par pièce, à signer par le bailleur et le locataire.",
    category: "logement",
    type: "autre",
    content: `ÉTAT DES LIEUX [ENTRÉE OU SORTIE]

Bien : [ADRESSE DU BIEN]
Date : [DATE DE L'ÉTAT DES LIEUX]
Bailleur : [NOM DU BAILLEUR]
Locataire : [NOM DU LOCATAIRE]

Relevé des compteurs :
- Électricité : [INDEX ÉLECTRICITÉ]
- Gaz : [INDEX GAZ]
- Eau : [INDEX EAU]

Constat par pièce :
- Hall et couloirs : [ÉTAT HALL]
- Salon : [ÉTAT SALON]
- Cuisine : [ÉTAT CUISINE]
- Chambres : [ÉTAT CHAMBRES]
- Salle de bain et WC : [ÉTAT SALLE DE BAIN]

Clés remises : [NOMBRE DE CLÉS]
Remarques : [REMARQUES]

Fait à [LIEU], le [DATE].

Le bailleur : [SIGNATURE DU BAILLEUR]
Le locataire : [SIGNATURE DU LOCATAIRE]`
  },
  {
    id: "starter-conge-bailleur",
    icon: "📨",
    title: "Congé donné par le bailleur",
    description: "Notification de fin de bail au locataire avec motif et préavis.",
    category: "logement",
    type: "autre",
    content: `Madame, Monsieur,

En ma qualité de bailleur du bien sis [ADRESSE DU BIEN], je vous notifie par la présente le congé du bail conclu le [DATE DU BAIL].

Motif : [MOTIF DU CONGÉ — ex. occupation personnelle, travaux].

Le préavis est de [DURÉE DU PRÉAVIS] et prend cours le premier jour du mois suivant l'envoi. Le bail prendra donc fin le [DATE DE FIN DU BAIL].

Je vous invite à convenir d'une date pour l'état des lieux de sortie.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE DU BAILLEUR]`
  },
  {
    id: "starter-quittance-loyer",
    icon: "🧾",
    title: "Quittance de loyer",
    description: "Attestation de paiement du loyer et des charges pour un mois donné.",
    category: "logement",
    type: "autre",
    content: `QUITTANCE DE LOYER

Je soussigné(e) [NOM DU BAILLEUR], bailleur du bien sis [ADRESSE DU BIEN], reconnais avoir reçu de [NOM DU LOCATAIRE] la somme de [MONTANT TOTAL] € au titre du loyer ([LOYER] €) et des charges ([CHARGES] €) pour la période de [PÉRIODE].

Cette quittance annule tous les reçus établis précédemment pour la même période.

Fait à [LIEU], le [DATE]

[SIGNATURE DU BAILLEUR]`
  },
  {
    id: "starter-reclamation-charges",
    icon: "💧",
    title: "Contestation de décompte de charges",
    description: "Demandez les justificatifs d'un décompte de charges contesté.",
    category: "logement",
    type: "lettre_reclamation",
    content: `Madame, Monsieur,

J'ai bien reçu le décompte de charges du [DATE DU DÉCOMPTE] d'un montant de [MONTANT RÉCLAMÉ] € pour la période [PÉRIODE] concernant le bien sis [ADRESSE DU BIEN].

Ce décompte appelle les remarques suivantes : [MOTIF DE LA CONTESTATION].

Je vous demande de me communiquer, dans un délai de [DÉLAI] jours, les factures et justificatifs détaillés ainsi que la clé de répartition appliquée.

Dans l'attente, je conteste ce décompte et me réserve le droit de saisir le juge de paix.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-plainte-nuisances",
    icon: "🔊",
    title: "Plainte pour nuisances de voisinage",
    description: "Courrier officiel pour bruit, odeurs ou troubles répétés.",
    category: "logement",
    type: "plainte_administrative",
    content: `Madame, Monsieur,

Je soussigné(e) [NOM ET PRÉNOM], domicilié(e) à [ADRESSE], vous signale des nuisances répétées provenant de [ORIGINE DES NUISANCES — adresse ou identité du voisin].

Nature des nuisances : [DESCRIPTION — bruit, odeurs, etc.].
Dates et heures constatées : [DATES ET HEURES].
Démarches déjà entreprises : [DÉMARCHES ANTÉRIEURES].

Je vous demande d'intervenir afin de mettre fin à ces troubles dans un délai de [DÉLAI] jours, à défaut de quoi je saisirai les autorités compétentes.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-assurance-habitation-resiliation",
    icon: "🛡️",
    title: "Résiliation d'assurance habitation",
    description: "Mettez fin à votre contrat d'assurance en respectant le préavis.",
    category: "logement",
    type: "autre",
    content: `Madame, Monsieur,

Je soussigné(e) [NOM ET PRÉNOM], titulaire du contrat n° [NUMÉRO DE POLICE] relatif au bien sis [ADRESSE DU BIEN], vous informe de ma décision de résilier ce contrat à son échéance du [DATE D'ÉCHÉANCE].

Cette résiliation est notifiée dans le respect du préavis de [DURÉE DU PRÉAVIS — ex. 3 mois].

Merci de me confirmer par écrit la date de fin de couverture et le remboursement éventuel de prime.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  }
];