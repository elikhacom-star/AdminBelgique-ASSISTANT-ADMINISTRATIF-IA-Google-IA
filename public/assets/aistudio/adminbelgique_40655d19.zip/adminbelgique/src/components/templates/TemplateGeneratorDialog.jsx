import React, { useEffect, useMemo, useState } from "react";
import { Document } from "@/entities/Document";
import { Template } from "@/entities/Template";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { CheckCircle2, Copy, FileDown, Loader2, Wand2 } from "lucide-react";
import { downloadDocumentPdf } from "@/lib/pdfExport";
import { DOCUMENT_CATEGORIES } from "@/lib/templateCategories";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import TemplateVariablesForm from "@/components/templates/TemplateVariablesForm";
import { base44 } from "@/api/base44Client";

const extractPlaceholders = (content = "") => {
  const matches = content.match(/\[([^[\]]{1,60})\]/g) || [];
  return [...new Set(matches.map((match) => match.slice(1, -1)))];
};

export default function TemplateGeneratorDialog({ template, open, onOpenChange }) {
  const [values, setValues] = useState({});
  const [customTitle, setCustomTitle] = useState("");
  const [saveAsTemplate, setSaveAsTemplate] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [createdDocument, setCreatedDocument] = useState(null);
  const [copied, setCopied] = useState(false);

  const placeholders = useMemo(() => extractPlaceholders(template?.content), [template]);

  const applyValues = (text) =>
    placeholders.reduce((acc, key) => {
      const value = (values[key] || "").trim();
      return acc.split(`[${key}]`).join(value || `[${key}]`);
    }, text || "");

  const generatedContent = useMemo(() => applyValues(template?.content), [template, values, placeholders]);
  const generatedTitle = useMemo(() => applyValues(template?.title), [template, values, placeholders]);
  const documentTitle = customTitle || generatedTitle || "Document sans titre";

  useEffect(() => {
    if (open) {
      setValues({});
      setCustomTitle("");
      setSaveAsTemplate(false);
      setCreatedDocument(null);
      setCopied(false);
    }
  }, [open, template?.id]);

  const handleGenerate = async () => {
    setIsSaving(true);
    try {
      const document = await Document.create({
        title: documentTitle,
        content: generatedContent,
        type: template?.type || "autre",
        category: DOCUMENT_CATEGORIES.includes(template?.category) ? template.category : "autre",
        status: "brouillon",
      });

      base44.analytics.track({
        eventName: "document_generated",
        properties: { document_type: template?.type || "autre" },
      });

      if (saveAsTemplate) {
        await Template.create({
          title: `${template?.title || "Modèle"} — personnalisé`,
          description: `Modèle réutilisable créé depuis « ${template?.title || "un modèle prêt à l'emploi"} »`,
          content: generatedContent,
          category: template?.category || "autre",
        });
      }

      setCreatedDocument(document);
    } catch (error) {
      console.error("Erreur lors de la génération du document:", error);
      alert("Erreur lors de la génération du document");
    } finally {
      setIsSaving(false);
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(generatedContent);
    setCopied(true);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        {createdDocument ? (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-green-700">
                <CheckCircle2 className="w-5 h-5" />
                Document créé
              </DialogTitle>
              <DialogDescription>
                « {documentTitle} » a été enregistré dans vos documents
                {saveAsTemplate ? " et le modèle a été sauvegardé pour une réutilisation en 1 clic." : "."}
              </DialogDescription>
            </DialogHeader>

            <div className="bg-gray-50 rounded-lg p-4 border max-h-64 overflow-y-auto">
              <pre className="whitespace-pre-wrap text-sm text-gray-800 font-sans">{generatedContent}</pre>
            </div>

            <DialogFooter className="flex-col sm:flex-row gap-2">
              <Button variant="outline" onClick={handleCopy} className="w-full sm:w-auto">
                <Copy className="w-4 h-4 mr-2" />
                {copied ? "Copié !" : "Copier le texte"}
              </Button>
              <Button
                onClick={() => downloadDocumentPdf({ title: documentTitle, content: generatedContent })}
                className="w-full sm:w-auto bg-red-600 hover:bg-red-700"
              >
                <FileDown className="w-4 h-4 mr-2" />
                Télécharger en PDF
              </Button>
              <Button asChild variant="outline" className="w-full sm:w-auto">
                <Link to={createPageUrl("MyDocuments")}>Voir mes documents</Link>
              </Button>
            </DialogFooter>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                {template?.icon && <span className="text-xl">{template.icon}</span>}
                {template?.title || "Générer un document"}
              </DialogTitle>
              <DialogDescription>
                Complétez les informations ci-dessous : le document est rédigé automatiquement.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-5 py-2">
              <div className="grid gap-1.5">
                <Label htmlFor="document-title">Titre du document</Label>
                <Input
                  id="document-title"
                  value={documentTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  className="border-gray-200"
                />
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold text-sm text-gray-700">
                  Informations à compléter ({placeholders.length})
                </h4>
                <TemplateVariablesForm
                  placeholders={placeholders}
                  values={values}
                  onChange={(key, value) => setValues((prev) => ({ ...prev, [key]: value }))}
                />
              </div>

              <div className="space-y-2">
                <h4 className="font-semibold text-sm text-gray-700">Aperçu</h4>
                <div className="bg-gray-50 rounded-lg p-4 border max-h-64 overflow-y-auto">
                  <pre className="whitespace-pre-wrap text-xs text-gray-800 font-sans">{generatedContent}</pre>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Checkbox
                  id="save-as-template"
                  checked={saveAsTemplate}
                  onCheckedChange={setSaveAsTemplate}
                />
                <Label htmlFor="save-as-template" className="text-sm text-gray-600 font-normal cursor-pointer">
                  Enregistrer aussi comme modèle réutilisable
                </Label>
              </div>
            </div>

            <DialogFooter className="flex-col sm:flex-row gap-2">
              <Button variant="outline" onClick={() => onOpenChange(false)} className="w-full sm:w-auto">
                Annuler
              </Button>
              <Button
                onClick={handleGenerate}
                disabled={isSaving}
                className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700"
              >
                {isSaving ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Génération...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4 mr-2" />
                    Créer le document
                  </>
                )}
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}