export const EMPLOI_TEMPLATES = [
  {
    id: "starter-demission",
    icon: "🚪",
    title: "Lettre de démission",
    description: "Notifiez votre démission avec préavis à votre employeur.",
    category: "emploi",
    type: "autre",
    content: `Madame, Monsieur,

Je soussigné(e) [NOM ET PRÉNOM], occupant la fonction de [FONCTION] au sein de [NOM DE L'ENTREPRISE], vous informe par la présente de ma décision de démissionner de mon poste.

Conformément à la loi et à mon contrat, je respecterai un préavis de [DURÉE DU PRÉAVIS], prenant cours le [DATE DE DÉBUT DU PRÉAVIS] et se terminant le [DATE DE FIN DU PRÉAVIS].

Je reste disponible pour organiser la transmission de mes dossiers.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-demande-conge",
    icon: "🏖️",
    title: "Demande de congé",
    description: "Demande formelle de jours de congé à votre employeur.",
    category: "emploi",
    type: "demande_renseignements",
    content: `Madame, Monsieur,

Je souhaiterais prendre [NOMBRE DE JOURS] jours de congé du [DATE DE DÉBUT] au [DATE DE FIN] inclus.

Motif (facultatif) : [MOTIF].
Dispositions pour assurer la continuité de mon travail : [ORGANISATION PENDANT L'ABSENCE].

Je vous remercie de bien vouloir me confirmer votre accord.

Cordialement,

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-augmentation",
    icon: "📈",
    title: "Demande d'augmentation de salaire",
    description: "Argumentez une demande de revalorisation salariale.",
    category: "emploi",
    type: "demande_renseignements",
    content: `Madame, Monsieur,

Depuis mon arrivée le [DATE D'ENTRÉE] en tant que [FONCTION], j'ai notamment [RÉALISATIONS PRINCIPALES].

Mes responsabilités ont évolué avec [ÉVOLUTION DES RESPONSABILITÉS]. Je souhaite donc échanger sur une revalorisation de ma rémunération de [SALAIRE ACTUEL] € à [SALAIRE SOUHAITÉ] € brut par mois.

Je reste à votre disposition pour un entretien à la date qui vous conviendra.

Cordialement,

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-certificat-medical-employeur",
    icon: "🩺",
    title: "Avis d'incapacité de travail à l'employeur",
    description: "Prévenez votre employeur d'une absence pour maladie.",
    category: "emploi",
    type: "autre",
    content: `Madame, Monsieur,

Je vous informe que je suis en incapacité de travail depuis le [DATE DE DÉBUT] pour une durée estimée de [DURÉE ESTIMÉE], conformément au certificat médical ci-joint.

Mon adresse pendant l'incapacité : [ADRESSE PENDANT L'INCAPACITÉ].
Personne à contacter pour mes dossiers urgents : [CONTACT].

Cordialement,

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-attestation-employeur",
    icon: "📑",
    title: "Demande d'attestation d'emploi",
    description: "Obtenez une attestation de travail pour une banque ou un bailleur.",
    category: "emploi",
    type: "demande_renseignements",
    content: `Madame, Monsieur,

Je vous prie de bien vouloir me délivrer une attestation d'emploi mentionnant : ma fonction, mon type de contrat, ma date d'entrée ([DATE D'ENTRÉE]) et [AUTRES MENTIONS — ex. rémunération].

Cette attestation est destinée à [DESTINATAIRE DE L'ATTESTATION].

Je vous remercie de me la transmettre avant le [DATE SOUHAITÉE].

Cordialement,

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-reclamation-chomage-onem",
    icon: "🏛️",
    title: "Recours contre une décision de l'ONEM",
    description: "Contestez une décision de chômage devant le tribunal du travail.",
    category: "emploi",
    type: "recours",
    content: `Madame, Monsieur,

Je soussigné(e) [NOM ET PRÉNOM], numéro national [NUMÉRO NATIONAL], conteste la décision du [DATE DE LA DÉCISION] (référence [RÉFÉRENCE DU DOSSIER]) par laquelle [OBJET DE LA DÉCISION].

Mes arguments : [ARGUMENTS].

Je demande le réexamen de mon dossier et l'annulation de cette décision. Je me réserve le droit d'introduire un recours devant le tribunal du travail dans le délai légal de trois mois.

Pièces jointes : [LISTE DES PIÈCES JOINTES].

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[NOM ET SIGNATURE]`
  },
  {
    id: "starter-lettre-motivation",
    icon: "✉️",
    title: "Lettre de motivation",
    description: "Candidature structurée pour un poste précis.",
    category: "emploi",
    type: "autre",
    content: `[NOM ET PRÉNOM]
[ADRESSE]
[TÉLÉPHONE ET EMAIL]

À l'attention de [NOM DU RECRUTEUR] — [NOM DE L'ENTREPRISE]

Objet : candidature au poste de [INTITULÉ DU POSTE]

Madame, Monsieur,

Intéressé(e) par le poste de [INTITULÉ DU POSTE] publié le [DATE DE L'ANNONCE], je vous soumets ma candidature.

Mon expérience de [EXPÉRIENCE PRINCIPALE] m'a permis de développer [COMPÉTENCES CLÉS]. Je suis motivé(e) par [MOTIVATIONS POUR L'ENTREPRISE].

Je serais ravi(e) de vous rencontrer pour un entretien.

Veuillez agréer, Madame, Monsieur, mes salutations distinguées.

Fait à [LIEU], le [DATE]

[SIGNATURE]`
  }
];