import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, FileText, Star, TrendingUp, Clock, CheckCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const TEMPLATES = [
  {
    id: 1,
    title: "Demande de remboursement INAMI",
    category: "sante",
    type: "demande_remboursement",
    popular: true,
    description: "Modèle pour demander un remboursement de soins de santé auprès de l'INAMI",
    content: `Madame, Monsieur,

Par la présente, je sollicite le remboursement des frais médicaux suivants :

[DÉTAILS DES SOINS]
Date : [DATE]
Nature des soins : [TYPE]
Montant : [MONTANT]€

Vous trouverez ci-joint :
- Les attestations de soins
- La preuve de paiement
- Mon numéro INAMI : [NUMÉRO]

Dans l'attente de votre retour, je vous prie d'agréer, Madame, Monsieur, l'expression de mes salutations distinguées.

[SIGNATURE]`
  },
  {
    id: 2,
    title: "Réclamation impôts SPF Finances",
    category: "finances",
    type: "lettre_reclamation",
    popular: true,
    description: "Contester un calcul fiscal ou une décision du SPF Finances",
    content: `Madame, Monsieur,

Je me permets de vous contacter concernant [MON AVERTISSEMENT-EXTRAIT DE RÔLE / MA SITUATION FISCALE].

Référence du dossier : [NUMÉRO DOSSIER]
Exercice d'imposition : [ANNÉE]

Je souhaite contester le calcul suivant : [DÉTAILS]

Motif de ma réclamation :
[EXPLIQUER POURQUOI LE CALCUL EST INCORRECT]

Pièces justificatives jointes :
- [LISTE DES DOCUMENTS]

Je reste à votre disposition pour tout complément d'information.

Dans cette attente, je vous prie d'agréer, Madame, Monsieur, l'expression de mes salutations distinguées.

[SIGNATURE]`
  },
  {
    id: 3,
    title: "Demande d'allocations familiales",
    category: "autre",
    type: "demande_renseignements",
    description: "Demander des renseignements sur les allocations familiales",
    content: `Madame, Monsieur,

Je sollicite des informations concernant mes droits aux allocations familiales.

Ma situation :
- Nombre d'enfants : [NOMBRE]
- Âges : [ÂGES]
- Situation professionnelle : [SITUATION]

Questions :
1. [QUESTION 1]
2. [QUESTION 2]

Numéro de dossier (si applicable) : [NUMÉRO]

Je vous remercie par avance pour votre réponse.

Cordialement,
[SIGNATURE]`
  },
  {
    id: 4,
    title: "Réclamation ONEM - Allocations chômage",
    category: "emploi",
    type: "lettre_reclamation",
    description: "Contester une décision de l'ONEM concernant les allocations de chômage",
    content: `Madame, Monsieur,

Je conteste la décision de l'ONEM datée du [DATE] concernant [SUJET].

Référence du dossier : [NUMÉRO]

Motifs de ma réclamation :
[EXPLIQUER LES RAISONS]

Éléments nouveaux à prendre en compte :
- [ÉLÉMENT 1]
- [ÉLÉMENT 2]

Documents joints :
- [LISTE]

Je sollicite un réexamen de ma situation.

Cordialement,
[SIGNATURE]`
  },
  {
    id: 5,
    title: "Demande de prime régionale",
    category: "logement",
    type: "demande_renseignements",
    description: "Demander une prime à la rénovation ou à l'énergie",
    content: `Madame, Monsieur,

Je souhaite introduire une demande de prime pour [TYPE DE PRIME].

Informations sur le logement :
- Adresse : [ADRESSE]
- Type de travaux : [TRAVAUX]
- Montant estimé : [MONTANT]€

Situation du demandeur :
- Revenus : [REVENUS]
- Composition de ménage : [COMPOSITION]

Puis-je bénéficier de cette prime ? Quels sont les documents nécessaires ?

Je vous remercie pour votre aide.

Cordialement,
[SIGNATURE]`
  },
  {
    id: 6,
    title: "Demande de pension anticipée",
    category: "pensions",
    type: "demande_renseignements",
    popular: true,
    description: "Demander des informations sur la pension anticipée",
    content: `Madame, Monsieur,

Je souhaite obtenir des renseignements concernant ma pension anticipée.

Ma situation :
- Date de naissance : [DATE]
- Années de carrière : [NOMBRE]
- Situation actuelle : [EMPLOI/CHÔMAGE/AUTRE]

Questions :
1. Puis-je prendre ma pension anticipée ?
2. Quel sera le montant estimé ?
3. Quels documents fournir ?

Numéro de registre national : [NUMÉRO]

Je vous remercie par avance.

Cordialement,
[SIGNATURE]`
  }
];

export default function TemplateLibrary({ onSelectTemplate }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  const categories = [
    { id: "all", label: "Toutes", icon: FileText },
    { id: "sante", label: "Santé", icon: "🏥" },
    { id: "finances", label: "Finances", icon: "💰" },
    { id: "emploi", label: "Emploi", icon: "💼" },
    { id: "autre", label: "Autre", icon: "📝" },
    { id: "logement", label: "Logement", icon: "🏠" },
    { id: "pensions", label: "Pensions", icon: "👴" }
  ];

  const filteredTemplates = TEMPLATES.filter(template => {
    const matchesSearch = template.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const popularTemplates = TEMPLATES.filter(t => t.popular);

  const handleUseTemplate = (template) => {
    if (onSelectTemplate) {
      onSelectTemplate(template);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">📋 Bibliothèque de Templates</h2>
        <p className="text-gray-600">
          Gagnez du temps avec nos modèles pré-rédigés pour toutes vos démarches administratives
        </p>
      </div>

      {/* Templates populaires */}
      {searchTerm === "" && selectedCategory === "all" && (
        <div>
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-yellow-600" />
            <h3 className="text-lg font-semibold text-gray-900">Templates les plus utilisés</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            {popularTemplates.map(template => (
              <Card key={template.id} className="border-2 border-yellow-200 bg-yellow-50 hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setSelectedTemplate(template)}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-base">{template.title}</CardTitle>
                    <Star className="w-5 h-5 text-yellow-600 fill-current" />
                  </div>
                  <CardDescription className="text-sm">
                    {template.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full" size="sm" onClick={(e) => {
                    e.stopPropagation();
                    handleUseTemplate(template);
                  }}>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Utiliser ce modèle
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Search & Filters */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            placeholder="Rechercher un template..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="flex gap-2 flex-wrap">
          {categories.map(category => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className="gap-2"
            >
              {typeof category.icon === 'string' ? category.icon : <category.icon className="w-4 h-4" />}
              {category.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Templates grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTemplates.map(template => (
          <Dialog key={template.id}>
            <DialogTrigger asChild>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-base">{template.title}</CardTitle>
                    {template.popular && <Star className="w-4 h-4 text-yellow-500" />}
                  </div>
                  <CardDescription className="text-sm line-clamp-2">
                    {template.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2">
                    <Badge variant="secondary" className="text-xs">
                      {template.type}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {template.category}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </DialogTrigger>

            <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {template.popular && <Star className="w-5 h-5 text-yellow-500 fill-current" />}
                  {template.title}
                </DialogTitle>
                <DialogDescription>
                  {template.description}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <div className="flex gap-2">
                  <Badge>{template.type}</Badge>
                  <Badge variant="outline">{template.category}</Badge>
                </div>

                <div className="bg-gray-50 rounded-lg p-4 border">
                  <h4 className="font-semibold mb-2 text-sm text-gray-700">Aperçu du modèle :</h4>
                  <pre className="whitespace-pre-wrap text-sm text-gray-800 font-sans">
                    {template.content}
                  </pre>
                </div>

                <div className="flex justify-end gap-2">
                  <Button variant="outline">
                    <Clock className="w-4 h-4 mr-2" />
                    Enregistrer pour plus tard
                  </Button>
                  <Button onClick={() => handleUseTemplate(template)}>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Utiliser ce modèle
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        ))}
      </div>

      {filteredTemplates.length === 0 && (
        <div className="text-center py-12">
          <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">Aucun template trouvé</p>
        </div>
      )}
    </div>
  );
}