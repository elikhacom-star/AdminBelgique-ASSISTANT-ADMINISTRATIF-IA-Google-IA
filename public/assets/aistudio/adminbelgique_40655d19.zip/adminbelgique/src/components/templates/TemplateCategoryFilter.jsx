import React from "react";
import { Button } from "@/components/ui/button";
import { TEMPLATE_CATEGORIES } from "@/lib/templateCategories";

export default function TemplateCategoryFilter({ templates, active, onChange }) {
  const counts = templates.reduce((acc, template) => {
    const key = template.category || "autre";
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});

  const visible = TEMPLATE_CATEGORIES.filter(
    (category) => counts[category.value] || category.value === active
  );

  return (
    <div className="flex gap-2 overflow-x-auto pt-3 pb-1">
      <Button
        size="sm"
        variant={active === "all" ? "default" : "outline"}
        onClick={() => onChange("all")}
        className="shrink-0 rounded-full"
      >
        Tous ({templates.length})
      </Button>
      {visible.map((category) => (
        <Button
          key={category.value}
          size="sm"
          variant={active === category.value ? "default" : "outline"}
          onClick={() => onChange(category.value)}
          className="shrink-0 rounded-full"
        >
          {category.icon} {category.label} ({counts[category.value] || 0})
        </Button>
      ))}
    </div>
  );
}