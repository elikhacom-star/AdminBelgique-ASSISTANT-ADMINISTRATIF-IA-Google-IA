import React, { useState, useEffect, useCallback } from "react";
import { Document } from "@/entities/Document";
import { Analyse } from "@/entities/Analyse";
import { Question } from "@/entities/Question";
import { Template } from "@/entities/Template";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, FileText, MessageSquare, Sparkles, Loader2, X, Filter, Calendar, Tag, FileType } from "lucide-react";
import { Link } from "react-router-dom";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { createPageUrl } from "@/utils";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";

export default function GlobalSearch({ isOpen, onClose }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [results, setResults] = useState({ documents: [], analyses: [], questions: [], templates: [] });
  const [isSearching, setIsSearching] = useState(false);
  
  // Cache data to avoid refetching on every keystroke
  const [cachedData, setCachedData] = useState(null);
  const [filters, setFilters] = useState({
    date: "all", // all, week, month, year
    category: "all",
    type: "all"
  });
  const [showFilters, setShowFilters] = useState(false);

  // Load data once when dialog opens
  useEffect(() => {
    if (isOpen && !cachedData) {
      const loadData = async () => {
        setIsSearching(true);
        try {
          const [documents, analyses, questions, templates] = await Promise.all([
            Document.list("-created_date").catch(() => []),
            Analyse.list("-created_date").catch(() => []),
            Question.list("-created_date").catch(() => []),
            Template.list("-created_date").catch(() => [])
          ]);
          setCachedData({ documents, analyses, questions, templates });
        } catch (error) {
          console.error("Error loading search data:", error);
        } finally {
          setIsSearching(false);
        }
      };
      loadData();
    }
  }, [isOpen, cachedData]);

  // Advanced search algorithm
  useEffect(() => {
    if (!searchTerm || searchTerm.length < 2 || !cachedData) {
      setResults({ documents: [], analyses: [], questions: [], templates: [] });
      return;
    }

    const timer = setTimeout(() => {
      const isExactSearch = searchTerm.match(/"([^"]+)"/);
      const searchPhrase = isExactSearch ? isExactSearch[1].toLowerCase() : searchTerm.toLowerCase();
      const searchTerms = isExactSearch ? [searchPhrase] : searchPhrase.split(' ').filter(t => t.length > 1);

      const scoreItem = (item, fields) => {
        let score = 0;
        let matches = false;

        // Date filter
        if (filters.date !== "all") {
            const date = new Date(item.created_date);
            const now = new Date();
            const diffTime = Math.abs(now - date);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            
            if (filters.date === "week" && diffDays > 7) return 0;
            if (filters.date === "month" && diffDays > 30) return 0;
            if (filters.date === "year" && diffDays > 365) return 0;
        }

        // Category filter (if applicable)
        if (filters.category !== "all") {
            if (item.category !== filters.category) return 0;
        }

        // Type filter (only for Document)
        if (filters.type !== "all" && item.type) {
             if (item.type !== filters.type) return 0;
        }

        // Text scoring
        fields.forEach(({ value, weight }) => {
            if (!value) return;
            const text = value.toLowerCase();
            
            if (isExactSearch) {
                if (text.includes(searchPhrase)) {
                    score += weight * 2;
                    matches = true;
                }
            } else {
                searchTerms.forEach(term => {
                    if (text.includes(term)) {
                        score += weight;
                        matches = true;
                        // Boost for exact word match
                        if (new RegExp(`\\b${term}\\b`).test(text)) score += weight * 0.5;
                    }
                });
            }
        });

        // Recency boost (newer items get slight boost)
        if (matches && item.created_date) {
            const date = new Date(item.created_date).getTime();
            const now = new Date().getTime();
            score += (date / now) * 5; 
        }

        return matches ? score : 0;
      };

      const getFields = (type) => {
        switch(type) {
            case 'docs': return [{k: 'title', w: 20}, {k: 'content', w: 2}, {k: 'recipient', w: 5}];
            case 'analyses': return [{k: 'original_filename', w: 20}, {k: 'analysis_summary', w: 2}, {k: 'extracted_data', w: 1}];
            case 'questions': return [{k: 'question', w: 20}, {k: 'response', w: 2}];
            case 'templates': return [{k: 'title', w: 20}, {k: 'description', w: 5}, {k: 'content', w: 1}];
            default: return [];
        }
      };

      const process = (items, type) => {
         const fields = getFields(type);
         return items.map(item => {
             const fieldConfig = fields.map(f => ({ value: item[f.k], weight: f.w }));
             return { ...item, _score: scoreItem(item, fieldConfig) };
         }).filter(i => i._score > 0).sort((a,b) => b._score - a._score).slice(0, 5);
      };

      setResults({
          documents: process(cachedData.documents, 'docs'),
          analyses: process(cachedData.analyses, 'analyses'),
          questions: process(cachedData.questions, 'questions'),
          templates: process(cachedData.templates, 'templates')
      });

    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm, cachedData, filters]);

  const totalResults = results.documents.length + results.analyses.length + results.questions.length + results.templates.length;

  const handleResultClick = () => {
    onClose();
    // Keep search term and cache for next time? No, maybe reset
    // setSearchTerm(""); 
  };
  
  const resetFilters = () => setFilters({ date: "all", category: "all", type: "all" });

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            Recherche Globale
          </DialogTitle>
          <DialogDescription>
            Recherchez dans tous vos documents, analyses et questions
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              autoFocus
              placeholder="Rechercher dans vos données..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-10"
            />
            {searchTerm && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1/2 transform -translate-y-1/2 h-7 w-7"
                onClick={() => setSearchTerm("")}
              >
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>

          {/* Filtres Avancés */}
          <div className="flex flex-wrap gap-2 items-center">
            <Button 
                variant={showFilters ? "secondary" : "outline"} 
                size="sm" 
                onClick={() => setShowFilters(!showFilters)}
                className="h-8 gap-2"
            >
                <Filter className="w-3 h-3" />
                Filtres
                {(filters.date !== 'all' || filters.category !== 'all' || filters.type !== 'all') && (
                    <Badge variant="primary" className="ml-1 h-4 w-4 p-0 flex items-center justify-center rounded-full text-[10px]">!</Badge>
                )}
            </Button>
            
            {showFilters && (
                <div className="flex flex-wrap gap-2 w-full mt-2 p-3 bg-gray-50 rounded-lg border border-gray-100 animate-in fade-in slide-in-from-top-2">
                    {/* Filtre Date */}
                    <div className="w-32">
                        <Select value={filters.date} onValueChange={(v) => setFilters(prev => ({...prev, date: v}))}>
                            <SelectTrigger className="h-8 text-xs">
                                <Calendar className="w-3 h-3 mr-2" />
                                <SelectValue placeholder="Date" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">Toute date</SelectItem>
                                <SelectItem value="week">7 derniers jours</SelectItem>
                                <SelectItem value="month">Mois dernier</SelectItem>
                                <SelectItem value="year">Année dernière</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    {/* Filtre Catégorie */}
                    <div className="w-32">
                        <Select value={filters.category} onValueChange={(v) => setFilters(prev => ({...prev, category: v}))}>
                            <SelectTrigger className="h-8 text-xs">
                                <Tag className="w-3 h-3 mr-2" />
                                <SelectValue placeholder="Catégorie" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">Toute catégorie</SelectItem>
                                <SelectItem value="finances">Finances</SelectItem>
                                <SelectItem value="securite_sociale">Sécurité Sociale</SelectItem>
                                <SelectItem value="emploi">Emploi</SelectItem>
                                <SelectItem value="sante">Santé</SelectItem>
                                <SelectItem value="logement">Logement</SelectItem>
                                <SelectItem value="etudes">Études</SelectItem>
                                <SelectItem value="pensions">Pensions</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    {/* Filtre Type Document */}
                    <div className="w-32">
                        <Select value={filters.type} onValueChange={(v) => setFilters(prev => ({...prev, type: v}))}>
                            <SelectTrigger className="h-8 text-xs">
                                <FileType className="w-3 h-3 mr-2" />
                                <SelectValue placeholder="Type Doc" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">Tout type</SelectItem>
                                <SelectItem value="lettre_reclamation">Réclamation</SelectItem>
                                <SelectItem value="demande_remboursement">Remboursement</SelectItem>
                                <SelectItem value="demande_renseignements">Renseignements</SelectItem>
                                <SelectItem value="recours">Recours</SelectItem>
                                <SelectItem value="plainte_administrative">Plainte</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    
                    <Button variant="ghost" size="sm" onClick={resetFilters} className="h-8 text-xs text-gray-500 hover:text-red-500">
                        Réinitialiser
                    </Button>
                </div>
            )}
          </div>

          {isSearching && (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-yellow-500" />
            </div>
          )}

          {!isSearching && searchTerm && totalResults === 0 && (
            <div className="text-center py-12">
              <Search className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">Aucun résultat trouvé</p>
            </div>
          )}

          {!isSearching && totalResults > 0 && (
            <div className="space-y-4 overflow-y-auto max-h-[50vh]">
              {/* Templates */}
              {results.templates.length > 0 && (
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-orange-600" />
                    Modèles ({results.templates.length})
                  </h3>
                  <div className="space-y-2">
                    {results.templates.map(template => (
                      <Link
                        key={template.id}
                        to={createPageUrl("Templates")}
                        onClick={handleResultClick}
                      >
                        <Card className="hover:shadow-md transition-shadow cursor-pointer">
                          <CardContent className="p-3">
                            <h4 className="font-medium text-gray-900">{template.title}</h4>
                            <p className="text-sm text-gray-500 line-clamp-2 mt-1">
                              {template.description || "Pas de description"}
                            </p>
                            <Badge variant="outline" className="mt-1 text-xs">{template.category}</Badge>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Documents */}
              {results.documents.length > 0 && (
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-blue-600" />
                    Documents ({results.documents.length})
                  </h3>
                  <div className="space-y-2">
                    {results.documents.map(doc => (
                      <Link
                        key={doc.id}
                        to={createPageUrl("MyDocuments")}
                        onClick={handleResultClick}
                      >
                        <Card className="hover:shadow-md transition-shadow cursor-pointer">
                          <CardContent className="p-3">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h4 className="font-medium text-gray-900">{doc.title}</h4>
                                <p className="text-sm text-gray-500 line-clamp-2 mt-1">
                                  {doc.content?.substring(0, 150)}...
                                </p>
                              </div>
                              <Badge variant="secondary" className="ml-2">
                                {doc.type}
                              </Badge>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Analyses */}
              {results.analyses.length > 0 && (
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-purple-600" />
                    Analyses ({results.analyses.length})
                  </h3>
                  <div className="space-y-2">
                    {results.analyses.map(analysis => (
                      <Link
                        key={analysis.id}
                        to={createPageUrl("MyAnalyses")}
                        onClick={handleResultClick}
                      >
                        <Card className="hover:shadow-md transition-shadow cursor-pointer">
                          <CardContent className="p-3">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h4 className="font-medium text-gray-900">{analysis.original_filename}</h4>
                                <p className="text-sm text-gray-500 line-clamp-2 mt-1">
                                  {analysis.analysis_summary?.substring(0, 150)}...
                                </p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Questions */}
              {results.questions.length > 0 && (
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-green-600" />
                    Questions ({results.questions.length})
                  </h3>
                  <div className="space-y-2">
                    {results.questions.map(question => (
                      <Card key={question.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-3">
                          <h4 className="font-medium text-gray-900">{question.question}</h4>
                          <p className="text-sm text-gray-500 line-clamp-2 mt-1">
                            {question.response?.substring(0, 150)}...
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}