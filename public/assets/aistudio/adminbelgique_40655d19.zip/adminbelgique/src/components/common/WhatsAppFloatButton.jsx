import React from "react";

export default function WhatsAppFloatButton() {
  return (
    <>
      {/* BOUTON WHATSAPP FLOTTANT elikacces */}
      <a
        href="https://wa.me/32467801041?text=Bonjour%20elikacces%20IT%20Solutions%2C%20je%20viens%20de%20votre%20site%20et%20j%27ai%20une%20question%20:"
        target="_blank"
        rel="noopener noreferrer"
        id="wa-float"
        aria-label="Poser une question sur WhatsApp"
      >
        <svg viewBox="0 0 24 24" width="32" fill="white">
          <path d="M19.05 4.91A9.82 9.82 0 0 0 12.04 2C6.52 2 2.04 6.48 2.04 12c0 1.76.46 3.48 1.32 5L2 22l5.16-1.35A9.82 9.82 0 0 0 12.04 22c5.52 0 10-4.48 10-10 0-2.67-1.04-5.18-2.99-7.09zM12.04 20c-1.51 0-2.99-.4-4.28-1.16l-.31-.18-3.06.8.82-2.98-.2-.31A8.1 8.1 0 0 1 3.96 12C3.96 7.57 7.61 3.92 12.04 3.92a8.08 8.08 0 0 1 5.73 2.37 8.08 8.08 0 0 1 2.37 5.73c0 4.43-3.65 8-8.1 8zm4.42-6.07c-.24-.12-1.42-.7-1.64-.78-.22-.08-.38-.12-.54.12-.16.24-.62.78-.76.94-.14.16-.28.18-.52.06-.24-.12-1.02-.38-1.94-1.2-.72-.64-1.2-1.43-1.34-1.67-.14-.24-.02-.37.1-.49.1-.1.24-.28.36-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.54-1.3-.74-1.78-.2-.46-.4-.54-.4h-.46c-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2s.86 2.32.98 2.48c.12.16 1.69 2.58 4.1 3.62.57.25 1.02.4 1.37.51.58.18 1.1.16 1.51.1.46-.07 1.42-.58 1.62-1.14.2-.56.2-1.04.14-1.14-.06-.1-.22-.16-.46-.28z" />
        </svg>
        <div><b>Question?</b><small>Réponse en 5 min</small></div>
      </a>
      <style>{`
        #wa-float{position:fixed;bottom:25px;right:25px;background:#25D366;color:#fff;display:flex;align-items:center;gap:12px;padding:14px 22px;border-radius:50px;text-decoration:none;font-family:Inter,sans-serif;box-shadow:0 8px 24px rgba(37,211,102,.4);z-index:9999;animation:wa-bounce 2s infinite}
        #wa-float b{display:block;font-size:18px;line-height:1}#wa-float small{font-size:13px;opacity:.9}
        @keyframes wa-bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}
        #wa-float:hover{transform:scale(1.05);background:#1EBE57}
        /* Empilement au-dessus du bouton SOS Urgences */
        #wa-float{bottom:172px}
        @media (min-width:768px){#wa-float{bottom:96px;right:24px}}
      `}</style>
    </>
  );
}