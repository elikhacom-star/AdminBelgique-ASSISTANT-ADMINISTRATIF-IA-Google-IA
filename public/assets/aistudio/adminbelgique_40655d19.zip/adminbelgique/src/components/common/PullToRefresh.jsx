import React, { useEffect } from "react";

export default function PullToRefresh({ onRefresh, isRefreshing, threshold = 70, children }) {
  useEffect(() => {
    let startY = 0;
    const el = document.scrollingElement || document.documentElement;

    const onTouchStart = (e) => { startY = e.touches?.[0]?.clientY || 0; };
    const onTouchMove = (e) => {
      const dy = (e.touches?.[0]?.clientY || 0) - startY;
      if (el.scrollTop === 0 && dy > threshold && typeof onRefresh === 'function' && !isRefreshing) {
        onRefresh();
      }
    };

    window.addEventListener('touchstart', onTouchStart, { passive: true });
    window.addEventListener('touchmove', onTouchMove, { passive: true });
    return () => {
      window.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
    };
  }, [onRefresh, isRefreshing, threshold]);

  return <div>{children}</div>;
}