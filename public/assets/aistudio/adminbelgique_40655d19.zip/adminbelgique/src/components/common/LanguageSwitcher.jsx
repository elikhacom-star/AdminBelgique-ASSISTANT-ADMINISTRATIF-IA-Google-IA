import React from 'react';
import { LanguageContext } from '@/components/localization/LanguageContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Languages } from 'lucide-react';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from "@/components/ui/drawer";

const languageOptions = {
  fr: "Français (FR)",
  nl: "Nederlands (NL)",
  de: "Deutsch (DE)",
};

export default function LanguageSwitcher() {
  const { locale, changeLocale } = React.useContext(LanguageContext);
  const [open, setOpen] = React.useState(false);
  const [isMobile, setIsMobile] = React.useState(false);

  React.useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mql = window.matchMedia('(max-width: 768px)');
    const handler = (e) => setIsMobile(e.matches);
    setIsMobile(mql.matches);
    if (mql.addEventListener) mql.addEventListener('change', handler); else mql.addListener(handler);
    return () => { if (mql.removeEventListener) mql.removeEventListener('change', handler); else mql.removeListener(handler); };
  }, []);

  if (isMobile) {
    return (
      <>
        <Button variant="outline" className="flex items-center gap-2" onClick={() => setOpen(true)}>
          <Languages className="h-4 w-4" />
          <span className="hidden sm:inline">{languageOptions[locale]}</span>
          <span className="sm:hidden">{locale.toUpperCase()}</span>
        </Button>
        <Drawer open={open} onOpenChange={setOpen}>
          <DrawerContent>
            <DrawerHeader>
              <DrawerTitle>Langue</DrawerTitle>
            </DrawerHeader>
            <div className="p-2 pb-4">
              {Object.entries(languageOptions).map(([key, value]) => (
                <button
                  key={key}
                  onClick={() => { changeLocale(key); setOpen(false); }}
                  className={`w-full text-left px-3 py-2 rounded-md hover:bg-accent ${locale === key ? 'font-semibold' : ''}`}
                >
                  {value}
                </button>
              ))}
            </div>
          </DrawerContent>
        </Drawer>
      </>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2">
          <Languages className="h-4 w-4" />
          <span className="hidden sm:inline">{languageOptions[locale]}</span>
          <span className="sm:hidden">{locale.toUpperCase()}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {Object.entries(languageOptions).map(([key, value]) => (
          <DropdownMenuItem key={key} onSelect={() => changeLocale(key)}>
            {value}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}