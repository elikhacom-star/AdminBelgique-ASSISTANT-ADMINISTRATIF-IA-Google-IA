import React, { useEffect } from 'react';

const GoogleTranslate = () => {
  useEffect(() => {
    // Créer le script uniquement s'il n'existe pas déjà
    if (!document.getElementById('google-translate-script')) {
      const script = document.createElement('script');
      script.id = 'google-translate-script';
      script.src = '//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
      script.async = true;
      document.body.appendChild(script);

      // Initialiser la fonction globale
      window.googleTranslateElementInit = () => {
        if (window.google && window.google.translate) {
          new window.google.translate.TranslateElement(
            {
              pageLanguage: 'fr',
              includedLanguages: 'fr,nl,de,en',
              layout: window.google.translate.TranslateElement.InlineLayout.SIMPLE,
              autoDisplay: false,
            },
            'google_translate_element'
          );
        }
      };
    }
  }, []);

  return (
    <div className="google-translate-wrapper">
      <div id="google_translate_element" />
    </div>
  );
};

export default GoogleTranslate;