import React, { useEffect, useState } from "react";
import { FileText } from "lucide-react";
import { base44 } from "@/api/base44Client";

const REFRESH_MS = 60000;

export default function PublicDocumentCounter() {
  const [count, setCount] = useState(null);

  useEffect(() => {
    let isMounted = true;

    const loadCount = async () => {
      try {
        const response = await base44.functions.invoke("getPublicDocumentCount", {});
        const value = response?.data?.count;
        if (isMounted && typeof value === "number") setCount(value);
      } catch (error) {
        // Compteur masqué si l'information n'est pas disponible.
      }
    };

    loadCount();
    const interval = setInterval(loadCount, REFRESH_MS);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  if (count === null) return null;

  return (
    <span className="inline-flex items-center gap-1">
      <FileText className="w-4 h-4 text-yellow-600" />
      <span>
        <strong>{count}</strong> documents générés
      </span>
    </span>
  );
}