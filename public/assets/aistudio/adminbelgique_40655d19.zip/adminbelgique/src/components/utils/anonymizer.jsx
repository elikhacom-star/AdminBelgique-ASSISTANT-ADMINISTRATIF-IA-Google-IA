// Définition des expressions régulières pour détecter les données sensibles
const patterns = {
  NN: {
    regex: /\d{2}\.\d{2}\.\d{2}-\d{3}\.\d{2}/g,
    prefix: 'NN'
  },
  EMAIL: {
    regex: /[\w.-]+@[\w.-]+\.\w+/g,
    prefix: 'EMAIL'
  },
  PHONE: {
    regex: /(?:\+32|0)\s?[1-9](?:[\s.-]?\d{2}){4}/g,
    prefix: 'TEL'
  },
  IBAN: {
    regex: /BE\d{2}\s?\d{4}\s?\d{4}\s?\d{4}/g,
    prefix: 'IBAN'
  }
};

/**
 * Anonymise un texte en remplaçant les données sensibles par des pseudonymes.
 * @param {string} text Le texte à anonymiser.
 * @returns {{anonymizedText: string, mapping: {[key: string]: string}}}
 */
export const anonymizeText = (text) => {
  let anonymizedText = text;
  const mapping = {};
  let counter = 1;

  for (const key in patterns) {
    const { regex, prefix } = patterns[key];
    anonymizedText = anonymizedText.replace(regex, (match) => {
      // Vérifier si cette valeur a déjà été remplacée
      const existingPlaceholder = Object.keys(mapping).find(k => mapping[k] === match);
      if (existingPlaceholder) {
        return existingPlaceholder;
      }
      
      const placeholder = `[${prefix}_${counter++}]`;
      mapping[placeholder] = match;
      return placeholder;
    });
  }

  return { anonymizedText, mapping };
};


/**
 * Ré-identifie un texte en remplaçant les pseudonymes par les données originales.
 * @param {string} text Le texte anonymisé.
 * @param {{[key: string]: string}} mapping La table de correspondance.
 * @returns {string} Le texte ré-identifié.
 */
export const deanonymizeText = (text, mapping) => {
  if (!text) return "";
  let deanonymizedText = text;
  for (const placeholder in mapping) {
    // Utiliser une expression régulière pour remplacer toutes les occurrences du placeholder
    const regex = new RegExp(placeholder.replace(/\[/g, '\\[').replace(/\]/g, '\\]'), 'g');
    deanonymizedText = deanonymizedText.replace(regex, mapping[placeholder]);
  }
  return deanonymizedText;
};