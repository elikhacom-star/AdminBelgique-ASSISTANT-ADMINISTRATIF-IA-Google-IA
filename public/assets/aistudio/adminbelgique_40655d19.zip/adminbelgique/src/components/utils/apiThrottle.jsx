/**
 * 🚦 API Throttle Helper
 * Gère automatiquement le rate limiting des API calls
 */

class APIThrottle {
  constructor(minDelay = 1000) { // 1 seconde minimum entre chaque appel
    this.minDelay = minDelay;
    this.lastCallTime = 0;
    this.queue = [];
    this.isProcessing = false;
  }

  async throttle(apiCall) {
    return new Promise((resolve, reject) => {
      this.queue.push({ apiCall, resolve, reject });
      this.processQueue();
    });
  }

  async processQueue() {
    if (this.isProcessing || this.queue.length === 0) return;

    this.isProcessing = true;
    const { apiCall, resolve, reject } = this.queue.shift();

    const now = Date.now();
    const timeSinceLastCall = now - this.lastCallTime;
    
    if (timeSinceLastCall < this.minDelay) {
      const waitTime = this.minDelay - timeSinceLastCall;
      await new Promise(r => setTimeout(r, waitTime));
    }

    try {
      this.lastCallTime = Date.now();
      const result = await apiCall();
      resolve(result);
    } catch (error) {
      // Si erreur 429, attendre plus longtemps et réessayer
      if (error?.response?.status === 429) {
        const retryAfter = parseInt(error?.response?.headers?.['retry-after'] || '5') * 1000;
        console.warn(`⏸️ Rate limit atteint, attente de ${retryAfter}ms...`);
        
        await new Promise(r => setTimeout(r, retryAfter));
        
        // Réessayer une fois
        try {
          this.lastCallTime = Date.now();
          const result = await apiCall();
          resolve(result);
        } catch (retryError) {
          reject(retryError);
        }
      } else {
        reject(error);
      }
    }

    this.isProcessing = false;
    this.processQueue(); // Traiter l'élément suivant
  }
}

// Instance globale
export const apiThrottle = new APIThrottle(1000); // 1 seconde entre chaque appel

// Helper pour wrapper les appels API
export const throttledAPICall = (apiCall) => {
  return apiThrottle.throttle(apiCall);
};