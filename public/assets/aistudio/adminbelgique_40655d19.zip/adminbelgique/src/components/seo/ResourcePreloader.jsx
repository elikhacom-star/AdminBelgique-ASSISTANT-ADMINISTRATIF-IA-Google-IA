import { useEffect } from 'react';

/**
 * 🚀 Préchargement des ressources critiques
 * Améliore les Core Web Vitals
 */
export default function ResourcePreloader() {
  useEffect(() => {
    // 1. Preconnect aux domaines externes critiques
    const preconnectDomains = [
      'https://fonts.googleapis.com',
      'https://fonts.gstatic.com',
      'https://pagead2.googlesyndication.com',
      'https://js.stripe.com'
    ];

    preconnectDomains.forEach(domain => {
      if (!document.querySelector(`link[href="${domain}"][rel="preconnect"]`)) {
        const link = document.createElement('link');
        link.rel = 'preconnect';
        link.href = domain;
        link.crossOrigin = 'anonymous';
        document.head.appendChild(link);
      }
    });

    // 2. DNS Prefetch pour domaines non-critiques
    const dnsPrefetchDomains = [
      'https://www.googletagmanager.com',
      'https://www.google-analytics.com',
      'https://googleads.g.doubleclick.net'
    ];

    dnsPrefetchDomains.forEach(domain => {
      if (!document.querySelector(`link[href="${domain}"][rel="dns-prefetch"]`)) {
        const link = document.createElement('link');
        link.rel = 'dns-prefetch';
        link.href = domain;
        document.head.appendChild(link);
      }
    });

    // 3. Lazy loading pour images
    const images = document.querySelectorAll('img:not([loading])');
    images.forEach(img => {
      img.setAttribute('loading', 'lazy');
      img.setAttribute('decoding', 'async');
    });

  }, []);

  return null;
}