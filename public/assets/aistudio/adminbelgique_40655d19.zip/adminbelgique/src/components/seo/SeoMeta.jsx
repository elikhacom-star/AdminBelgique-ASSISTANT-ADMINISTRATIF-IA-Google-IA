import { useEffect } from "react";
import { useLocation } from "react-router-dom";

// Domaine vitrine (GitHub Pages) — la vraie home est là-bas
const SITE_VITRINE_HOME = "https://adminbelgique.com/";

// Pages publiques indexables sur app.adminbelgique.com
const PUBLIC_INDEXABLE_PATHS = [
  "/faq",
  "/services",
  "/pricing",
  "/about",
  "/contact",
  "/guidedemarchesbelgique",
  "/immoboost",
  "/belgianservices",
  "/help",
  "/fiduciaireai"
];

const isIndexable = (lowerPath) => {
  // Blog list, blog articles (/blog/:slug), et articles statiques (BlogArticle*)
  if (lowerPath.startsWith("/blog")) return true;
  return PUBLIC_INDEXABLE_PATHS.includes(lowerPath);
};

const getCurrentUrl = () => {
  if (typeof window === "undefined") return "";
  return window.location.origin + window.location.pathname;
};

const setOrCreateLink = (rel, href) => {
  let link = document.querySelector(`link[rel="${rel}"]`);
  if (!link) {
    link = document.createElement("link");
    link.setAttribute("rel", rel);
    document.head.appendChild(link);
  }
  link.setAttribute("href", href);
};

const setOrCreateMeta = (name, content) => {
  let meta = document.querySelector(`meta[name="${name}"]`);
  if (!meta) {
    meta = document.createElement("meta");
    meta.setAttribute("name", name);
    document.head.appendChild(meta);
  }
  meta.setAttribute("content", content);
};

export default function SeoMeta() {
  const location = useLocation();
  const pathname = location.pathname;
  const lowerPath = pathname.toLowerCase();

  useEffect(() => {
    let canonical;
    let robots;

    if (pathname === "/" || lowerPath === "/home") {
      // La vraie home est sur GitHub → canonical vers le vitrine, noindex ici
      canonical = SITE_VITRINE_HOME;
      robots = "noindex, follow";
    } else if (isIndexable(lowerPath)) {
      // Pages publiques (Blog, FAQ, Services, Pricing, etc.) → auto-référence, indexables
      canonical = getCurrentUrl();
      robots = "index, follow";
    } else {
      // Tout le reste = pages privées (Dashboard, Chat, Documents, etc.) → cachées de Google
      canonical = getCurrentUrl();
      robots = "noindex, nofollow";
    }

    setOrCreateLink("canonical", canonical);
    setOrCreateMeta("robots", robots);
  }, [pathname]);

  return null;
  
}
