import { useEffect } from 'react';

/**
 * ⚡ Optimisations Performance
 * - Lazy loading images
 * - Preconnect aux domaines externes
 * - Resource hints
 */
export default function PerformanceOptimizer() {
  useEffect(() => {
    // 1. Lazy loading natif pour toutes les images
    const images = document.querySelectorAll('img:not([loading])');
    images.forEach(img => {
      img.setAttribute('loading', 'lazy');
      img.setAttribute('decoding', 'async');
    });

    // 2. Preconnect aux domaines externes critiques
    const preconnectDomains = [
      'https://fonts.googleapis.com',
      'https://fonts.gstatic.com',
      'https://pagead2.googlesyndication.com',
      'https://images.unsplash.com'
    ];

    preconnectDomains.forEach(domain => {
      if (!document.querySelector(`link[href="${domain}"]`)) {
        const link = document.createElement('link');
        link.rel = 'preconnect';
        link.href = domain;
        link.crossOrigin = 'anonymous';
        document.head.appendChild(link);
      }
    });

    // 3. DNS Prefetch pour domaines non-critiques
    const dnsPrefetchDomains = [
      'https://www.googletagmanager.com',
      'https://www.google-analytics.com'
    ];

    dnsPrefetchDomains.forEach(domain => {
      if (!document.querySelector(`link[href="${domain}"][rel="dns-prefetch"]`)) {
        const link = document.createElement('link');
        link.rel = 'dns-prefetch';
        link.href = domain;
        document.head.appendChild(link);
      }
    });

    // 4. Intersection Observer pour lazy components
    if ('IntersectionObserver' in window) {
      const lazyComponents = document.querySelectorAll('[data-lazy]');
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
          }
        });
      }, {
        rootMargin: '50px'
      });

      lazyComponents.forEach(component => observer.observe(component));
    }

    // 5. Defer non-critical scripts
    const scripts = document.querySelectorAll('script[data-defer]');
    scripts.forEach(script => {
      if (!script.hasAttribute('defer')) {
        script.setAttribute('defer', '');
      }
    });

  }, []);

  return null; // Composant invisible
}