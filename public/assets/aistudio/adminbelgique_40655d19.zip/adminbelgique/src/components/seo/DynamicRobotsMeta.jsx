import { useEffect } from "react";
import { useLocation } from "react-router-dom";

// Routes publiques indexables (SEO landing pages)
const PUBLIC_ROUTES = [
  "/", "/home", "/blog", "/faq",
  "/about", "/contact", "/guidedemarchesbelgique", "/belgianservices",
  "/blogarticle5tachesautomatiser",
  "/blogarticleiatransformation",
  "/blogarticleassistantvsia",
  "/blogarticledeclarationimpots",
  "/blogarticleinamioptimise",
  "/blogarticleonemchomage",
  "/immoboost",
  "/immoboostscrap",
  "/Help"
];

const isPublicRoute = (pathname) => {
  const p = pathname.toLowerCase();
  if (PUBLIC_ROUTES.includes(p)) return true;
  // Articles de blog individuels : /blog/:slug
  if (p.startsWith("/blog/")) return true;
  return false;
};

export default function DynamicRobotsMeta() {
  const location = useLocation();

  useEffect(() => {
    let meta = document.querySelector('meta[name="robots"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.setAttribute("name", "robots");
      document.head.appendChild(meta);
    }
    const content = isPublicRoute(location.pathname)
      ? "index, follow"
      : "noindex, nofollow";
    meta.setAttribute("content", content);
  }, [location.pathname]);

  return null;
}
