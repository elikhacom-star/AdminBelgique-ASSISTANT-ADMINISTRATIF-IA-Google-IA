import { useEffect } from "react";
import { useLocation } from "react-router-dom";

// ─────────────────────────────────────────────────────────────
// Meta titles + descriptions + keywords pour toutes les pages
// Mots-clés stratégiques : Assistant Administratif IA Belgique,
// assistant virtuel entreprise bruxelles, immoboost-ia,
// administration belge, ia administration belge
// ─────────────────────────────────────────────────────────────

const PAGE_META = {
  "/": {
    title: "Assistant Administratif IA Belgique | AdminBelgique 🇧🇪",
    description: "Assistant administratif IA Belgique pour automatiser vos démarches SPF Finances, INAMI, ONEM. IA administration belge 24/7. Gagnez 6h/semaine. Essai gratuit !",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, assistant virtuel entreprise bruxelles, automatisation administrative"
  },
  "/Home": {
    title: "Assistant Administratif IA Belgique | AdminBelgique 🇧🇪",
    description: "Assistant administratif IA Belgique pour automatiser vos démarches SPF Finances, INAMI, ONEM. IA administration belge 24/7. Gagnez 6h/semaine. Essai gratuit !",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, assistant virtuel entreprise bruxelles, automatisation administrative"
  },
  "/Services": {
    title: "Services Assistant Administratif IA Belgique | AdminBelgique 🇧🇪",
    description: "IA administration belge : génération de documents, analyse administrative, assistant virtuel entreprise Bruxelles. Assistant administratif IA pour PME et indépendants.",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, assistant virtuel entreprise bruxelles, services administratifs ia"
  },
  "/Pricing": {
    title: "Tarifs Assistant Administratif IA Belgique | AdminBelgique 🇧🇪",
    description: "Plans Assistant Administratif IA Belgique dès 49€/mois. IA administration belge pour PME, indépendants et cabinets. Assistant virtuel entreprise Bruxelles. Essai gratuit !",
    keywords: "assistant administratif ia belgique, ia administration belge, assistant virtuel entreprise bruxelles, tarifs ia belgique, administration belge"
  },
  "/ImmoBoost": {
    title: "ImmoBoost IA — Agent Immobilier IA Belgique | AdminBelgique 🇧🇪",
    description: "ImmoBoost IA : agent immobilier IA Belgique. Estimation, pige de marché, annonces trilingues FR/NL/EN. Assistant administratif IA pour agences immobilières belges.",
    keywords: "immoboost-ia, assistant administratif ia belgique, ia administration belge, agent immobilier ia belgique, administration belge, assistant virtuel entreprise bruxelles"
  },
  "/Blog": {
    title: "Blog Assistant Administratif IA Belgique | AdminBelgique 🇧🇪",
    description: "Blog IA administration belge : guides administratifs, conseils SPF Finances, INAMI, ONEM. Assistant administratif IA Belgique pour PME et indépendants.",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, blog administratif belgique, assistant virtuel entreprise bruxelles"
  },
  "/FAQ": {
    title: "FAQ Assistant Administratif IA Belgique | AdminBelgique 🇧🇪",
    description: "FAQ Assistant Administratif IA Belgique : questions sur l'IA administration belge, démarches administratives, sécurité des données. Administration belge simplifiée par l'IA.",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, faq ia belgique, assistant virtuel entreprise bruxelles"
  },
  "/About": {
    title: "À propos Assistant Administratif IA Belgique | AdminBelgique 🇧🇪",
    description: "AdminBelgique : assistant administratif IA Belgique pour PME et indépendants. IA administration belge conforme RGPD. Assistant virtuel entreprise Bruxelles.",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, assistant virtuel entreprise bruxelles, adminbelgique"
  },
  "/Contact": {
    title: "Contact Assistant Administratif IA Belgique | AdminBelgique 🇧🇪",
    description: "Contactez AdminBelgique — assistant administratif IA Belgique. IA administration belge pour PME, indépendants et cabinets. Assistant virtuel entreprise Bruxelles.",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, contact ia belgique, assistant virtuel entreprise bruxelles"
  },
  "/GuideDemarchesBelgique": {
    title: "Guide des Démarches — IA Administration Belge | AdminBelgique 🇧🇪",
    description: "Guide des démarches administratives belges par l'IA. Assistant administratif IA Belgique pour SPF Finances, INAMI, ONEM. Administration belge simplifiée.",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, guide démarches belgique, assistant virtuel entreprise bruxelles"
  },
  "/BlogArticle5TachesAutomatiser": {
    title: "5 Tâches à Automatiser avec l'IA — Assistant Administratif IA Belgique",
    description: "5 tâches administratives à automatiser avec l'IA administration belge. Assistant administratif IA Belgique pour PME. Gagnez 6h/semaine. Administration belge optimisée.",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, automatisation ia belgique, assistant virtuel entreprise bruxelles"
  },
  "/BlogArticleIATransformation": {
    title: "Transformation IA des PME Belges — Assistant Administratif IA Belgique",
    description: "Comment l'IA administration belge transforme les PME. Assistant administratif IA Belgique pour automatiser vos démarches. Administration belge modernisée.",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, transformation ia pme, assistant virtuel entreprise bruxelles"
  },
  "/BlogArticleAssistantVsIA": {
    title: "Assistant vs IA — Assistant Administratif IA Belgique | AdminBelgique",
    description: "Assistant humain vs IA administration belge : comparatif complet. Assistant administratif IA Belgique pour PME et indépendants. Administration belge efficace.",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, assistant vs ia, assistant virtuel entreprise bruxelles"
  },
  "/BlogArticleDeclarationImpots": {
    title: "Déclaration d'Impôts IA — Assistant Administratif IA Belgique",
    description: "Automatisez votre déclaration d'impôts avec l'IA administration belge. Assistant administratif IA Belgique pour SPF Finances. Administration belge simplifiée.",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, déclaration impôts ia, assistant virtuel entreprise bruxelles"
  },
  "/BlogArticleINAMIOptimise": {
    title: "INAMI Optimisé par l'IA — Assistant Administratif IA Belgique",
    description: "Optimisez vos démarches INAMI avec l'IA administration belge. Assistant administratif IA Belgique pour professionnels de santé. Administration belge automatisée.",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, inami ia, assistant virtuel entreprise bruxelles"
  },
  "/BlogArticleONEMChomage": {
    title: "ONEM et Chômage IA — Assistant Administratif IA Belgique",
    description: "Gérez vos démarches ONEM et chômage avec l'IA administration belge. Assistant administratif IA Belgique pour indépendants. Administration belge simplifiée.",
    keywords: "assistant administratif ia belgique, ia administration belge, administration belge, onem ia, chômage belgique ia, assistant virtuel entreprise bruxelles"
  },
  // Pages privées (noindex) — titres simples
  "/Dashboard": { title: "AdminBelgique — Tableau de bord", description: "", keywords: "" },
  "/Chat": { title: "AdminBelgique — Assistant IA", description: "", keywords: "" },
  "/Assistant": { title: "AdminBelgique — Assistant", description: "", keywords: "" },
  "/DocumentGenerator": { title: "AdminBelgique — Générateur de documents", description: "", keywords: "" },
  "/DocumentAnalyzer": { title: "AdminBelgique — Analyseur de documents", description: "", keywords: "" },
  "/Templates": { title: "AdminBelgique — Mes modèles", description: "", keywords: "" },
  "/MyDocuments": { title: "AdminBelgique — Mes documents", description: "", keywords: "" },
  "/MyAnalyses": { title: "AdminBelgique — Mes analyses", description: "", keywords: "" },
  "/ImmoBoostScrap": { title: "AdminBelgique — ImmoScrap Pro", description: "", keywords: "" },
  "/BelgianServices": { title: "AdminBelgique — Services belges", description: "", keywords: "" },
  "/Referral": { title: "AdminBelgique — Parrainage", description: "", keywords: "" },
  "/Help": { title: "AdminBelgique — Guide d'aide", description: "", keywords: "" },
  "/urgence": { title: "AdminBelgique — Urgences", description: "", keywords: "" },
  "/BlogAdmin": { title: "AdminBelgique — Rédaction Blog", description: "", keywords: "" },
  "/AccessManagement": { title: "AdminBelgique — Gestion des accès", description: "", keywords: "" },
  "/SubscriptionManagement": { title: "AdminBelgique — Abonnements", description: "", keywords: "" },
  "/SEOValidation": { title: "AdminBelgique — Validation SEO", description: "", keywords: "" },
  "/SEODiagnostic": { title: "AdminBelgique — Diagnostic SEO", description: "", keywords: "" },
  "/MentionsLegales": { title: "AdminBelgique — Mentions légales", description: "", keywords: "" },
};

const DEFAULT_META = {
  title: "Assistant Administratif IA Belgique | AdminBelgique 🇧🇪",
  description: "Assistant administratif IA Belgique pour automatiser vos démarches SPF Finances, INAMI, ONEM. IA administration belge 24/7. Gagnez 6h/semaine. Essai gratuit !",
  keywords: "assistant administratif ia belgique, ia administration belge, administration belge, assistant virtuel entreprise bruxelles, immoboost-ia"
};

const setMetaTag = (name, content, isProperty = false) => {
  const attribute = isProperty ? "property" : "name";
  let meta = document.querySelector(`meta[${attribute}="${name}"]`);
  if (!meta) {
    meta = document.createElement("meta");
    meta.setAttribute(attribute, name);
    document.head.appendChild(meta);
  }
  meta.setAttribute("content", content);
};

export default function DynamicPageTitle() {
  const location = useLocation();

  useEffect(() => {
    const path = location.pathname;
    let meta = PAGE_META[path];

    // Blog article: /blog/:slug
    if (!meta && path.startsWith("/blog/")) {
      meta = {
        title: "AdminBelgique — Article",
        description: "Article du blog Assistant Administratif IA Belgique. IA administration belge pour PME et indépendants.",
        keywords: "assistant administratif ia belgique, ia administration belge, administration belge"
      };
    }

    // Static blog article pages fallback
    if (!meta && path.startsWith("/BlogArticle")) {
      meta = {
        title: "AdminBelgique — Blog",
        description: "Blog Assistant Administratif IA Belgique. IA administration belge pour PME et indépendants.",
        keywords: "assistant administratif ia belgique, ia administration belge, administration belge"
      };
    }

    const finalMeta = meta || DEFAULT_META;
    document.title = finalMeta.title;

    // Meta description
    if (finalMeta.description) {
      setMetaTag("description", finalMeta.description);
      setMetaTag("og:description", finalMeta.description, true);
      setMetaTag("twitter:description", finalMeta.description);
    }

    // Meta keywords
    if (finalMeta.keywords) {
      setMetaTag("keywords", finalMeta.keywords);
    }

    // OG title
    setMetaTag("og:title", finalMeta.title, true);
    setMetaTag("twitter:title", finalMeta.title);
  }, [location.pathname]);

  return null;
}