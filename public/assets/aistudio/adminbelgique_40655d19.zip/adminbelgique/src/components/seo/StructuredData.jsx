import React from 'react';
import { useLocation } from 'react-router-dom';

/**
 * 📊 Composant Schema.org pour données structurées
 * Améliore la visibilité dans les SERP Google
 */
export default function StructuredData({ pageType, data }) {
  const location = useLocation();
  const baseUrl = 'https://www.adminbelgique.com';

  const getSchema = () => {
    switch (pageType) {
      case 'organization':
        return {
          "@context": "https://schema.org",
          "@type": "Organization",
          "name": "AdminBelgique",
          "url": baseUrl,
          "logo": {
            "@type": "ImageObject",
            "url": "https://media.base44.com/images/public/68bc392a4a84d8ffe8570815/454e9018a_generated_image.png",
            "width": 512,
            "height": 512
          },
          "image": "https://media.base44.com/images/public/68bc392a4a84d8ffe8570815/93758e2a1_generated_image.png",
          "description": "Assistant administratif IA et agent administratif virtuel en Belgique. Simplification démarches administratives SPF Finances, INAMI, ONEM avec protection données maximale.",
          "address": {
            "@type": "PostalAddress",
            "addressCountry": "BE"
          },
          "contactPoint": [{
            "@type": "ContactPoint",
            "contactType": "Service client",
            "availableLanguage": ["Français", "Nederlands", "Deutsch"],
            "email": "elikaccesit@gmail.com",
            "telephone": "+32467801041"
          }],
          "sameAs": [
            "https://www.facebook.com/adminbelgique",
            "https://www.linkedin.com/company/adminbelgique"
          ],
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.8",
            "reviewCount": "156",
            "bestRating": "5"
          }
        };

      case 'service':
        return {
          "@context": "https://schema.org",
          "@type": "Service",
          "name": data?.title || "Services Assistant Administratif IA",
          "description": data?.description || "Services d'assistance administrative intelligente pour simplifier vos démarches en Belgique",
          "provider": {
            "@type": "Organization",
            "name": "AdminBelgique",
            "url": baseUrl
          },
          "areaServed": {
            "@type": "Country",
            "name": "Belgium"
          },
          "serviceType": "Assistant Administratif IA",
          "category": "Administrative Services",
          "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "EUR",
            "availability": "https://schema.org/InStock"
          }
        };

      case 'faq':
        return {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          "mainEntity": data?.questions?.map(q => ({
            "@type": "Question",
            "name": q.question,
            "acceptedAnswer": {
              "@type": "Answer",
              "text": q.answer
            }
          })) || []
        };

      case 'article':
        return {
          "@context": "https://schema.org",
          "@type": "Article",
          "headline": data?.title,
          "description": data?.description,
          "image": data?.image || "https://media.base44.com/images/public/68bc392a4a84d8ffe8570815/93758e2a1_generated_image.png",
          "author": {
            "@type": "Organization",
            "name": "AdminBelgique"
          },
          "publisher": {
            "@type": "Organization",
            "name": "AdminBelgique",
            "logo": {
              "@type": "ImageObject",
              "url": "https://media.base44.com/images/public/68bc392a4a84d8ffe8570815/454e9018a_generated_image.png"
            }
          },
          "datePublished": data?.datePublished,
          "dateModified": data?.dateModified || data?.datePublished,
          "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": `${baseUrl}${location.pathname}`
          }
        };

      case 'breadcrumb':
        return {
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          "itemListElement": data?.breadcrumbs?.map((crumb, index) => ({
            "@type": "ListItem",
            "position": index + 1,
            "name": crumb.name,
            "item": `${baseUrl}${crumb.url}`
          })) || []
        };

      case 'software':
        return {
          "@context": "https://schema.org",
          "@type": "SoftwareApplication",
          "name": "AdminBelgique Assistant IA",
          "applicationCategory": "BusinessApplication",
          "operatingSystem": "Web, iOS, Android",
          "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "EUR",
            "availability": "https://schema.org/InStock"
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.8",
            "reviewCount": "156"
          },
          "description": "Application d'assistant administratif IA pour simplifier les démarches administratives en Belgique"
        };

      case 'howto':
        return {
          "@context": "https://schema.org",
          "@type": "HowTo",
          "name": data?.title,
          "description": data?.description,
          "step": data?.steps?.map((step, index) => ({
            "@type": "HowToStep",
            "position": index + 1,
            "name": step.title,
            "text": step.description,
            "image": step.image
          })) || []
        };

      case 'localbusiness':
        return {
          "@context": "https://schema.org",
          "@type": "LocalBusiness",
          "name": "AdminBelgique",
          "image": "https://media.base44.com/images/public/68bc392a4a84d8ffe8570815/93758e2a1_generated_image.png",
          "logo": "https://media.base44.com/images/public/68bc392a4a84d8ffe8570815/454e9018a_generated_image.png",
          "@id": baseUrl,
          "url": baseUrl,
          "telephone": "+32467801041",
          "email": "elikaccesit@gmail.com",
          "address": {
            "@type": "PostalAddress",
            "addressCountry": "BE"
          },
          "geo": {
            "@type": "GeoCoordinates",
            "latitude": 50.8503,
            "longitude": 4.3517
          },
          "openingHoursSpecification": [{
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
            "opens": "09:00",
            "closes": "18:00"
          }],
          "priceRange": "€"
        };

      default:
        return null;
    }
  };

  const schema = getSchema();

  if (!schema) return null;

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026') }}
    />
  );
}