import { useEffect } from 'react';

/**
 * 🎯 Composant SEO Head pour injection meta tags
 * Utilise la manipulation directe du DOM (pas besoin de react-helmet)
 */
export default function SEOHead({ 
  title = "Assistant Administratif IA Belgique - Agent IA N°1",
  description = "Assistant administratif IA Belgique pour automatiser démarches SPF Finances, INAMI, ONEM. Agent administratif virtuel 24/7. Essai gratuit.",
  keywords = "assistant administratif ia, assistant administratif ia belgique, agent administratif ia, agent administratif belgique, automatisation administrative",
  canonical = "https://adminbelgique.com/",
  ogImage = "https://adminbelgique.com/logo.png",
  structuredData = null,
  noIndex = false
}) {
  
  useEffect(() => {
    // Update title
    document.title = title;
    
    // Helper function to set/update meta tags
    const setMetaTag = (name, content, isProperty = false) => {
      const attribute = isProperty ? 'property' : 'name';
      let meta = document.querySelector(`meta[${attribute}="${name}"]`);
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute(attribute, name);
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', content);
    };

    // Basic meta tags
    setMetaTag('description', description);
    setMetaTag('keywords', keywords);
    
    if (noIndex) {
      setMetaTag('robots', 'noindex, nofollow');
      setMetaTag('googlebot', 'noindex, nofollow');
      setMetaTag('bingbot', 'noindex, nofollow');
    } else {
      setMetaTag('robots', 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1');
      setMetaTag('googlebot', 'index, follow');
      setMetaTag('bingbot', 'index, follow');
    }
    
    // Open Graph
    setMetaTag('og:type', 'website', true);
    setMetaTag('og:url', canonical, true);
    setMetaTag('og:title', title, true);
    setMetaTag('og:description', description, true);
    setMetaTag('og:image', ogImage, true);
    setMetaTag('og:locale', 'fr_BE', true);
    setMetaTag('og:site_name', 'AdminBelgique', true);
    
    // Twitter Card
    setMetaTag('twitter:card', 'summary_large_image');
    setMetaTag('twitter:url', canonical);
    setMetaTag('twitter:title', title);
    setMetaTag('twitter:description', description);
    setMetaTag('twitter:image', ogImage);
    
    // Geo Targeting
    setMetaTag('geo.region', 'BE');
    setMetaTag('geo.placename', 'Belgique');
    setMetaTag('language', 'fr-BE');
    setMetaTag('author', 'AdminBelgique - Assistant Administratif IA');
    setMetaTag('copyright', 'AdminBelgique © 2025');
    
    // Canonical link
    let canonicalLink = document.querySelector('link[rel="canonical"]');
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.setAttribute('rel', 'canonical');
      document.head.appendChild(canonicalLink);
    }
    canonicalLink.setAttribute('href', canonical);
    
    // Structured Data
    if (structuredData) {
      const scriptId = 'structured-data-' + Math.random().toString(36).substr(2, 9);
      let script = document.querySelector(`script[id="${scriptId}"]`);
      if (!script) {
        script = document.createElement('script');
        script.type = 'application/ld+json';
        script.id = scriptId;
        document.head.appendChild(script);
      }
      script.textContent = JSON.stringify(structuredData);
      
      // Cleanup on unmount
      return () => {
        if (script && script.parentNode) {
          script.parentNode.removeChild(script);
        }
      };
    }
  }, [title, description, keywords, canonical, ogImage, structuredData]);

  return null; // Ce composant ne rend rien visuellement
}