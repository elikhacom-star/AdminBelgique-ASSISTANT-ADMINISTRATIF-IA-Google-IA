import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Download, Mail, Loader2, CheckCircle } from "lucide-react";
import { api as base44 } from "@/components/api/wrapper";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import AdvancedExport from "../export/AdvancedExport"; // NEW: Import AdvancedExport component
import { downloadDocumentPdf } from "@/lib/pdfExport";

export default function DocumentActions({ document, title, documentId, onDelete, onUpdate }) { // MODIFIED: Added onDelete, onUpdate props, kept title
  const [isExporting, setIsExporting] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const [emailData, setEmailData] = useState({
    to: "",
    subject: title || "Document AdminBelgique",
    message: "Veuillez trouver ci-joint votre document généré."
  });

  const handleExportPDF = async () => {
    setIsExporting(true);
    try {
      await downloadDocumentPdf({ title: title || 'Document', content: document });
    } catch (error) {
      console.error("Erreur export PDF:", error);
      alert("Erreur lors de l'export PDF");
    } finally {
      setIsExporting(false);
    }
  };

  const handleSendEmail = async () => {
    if (!emailData.to.trim()) {
      alert("Veuillez entrer une adresse email");
      return;
    }

    setIsSending(true);
    setEmailSent(false);

    try {
      // 🔒 Envoi exécuté côté serveur : destinataire contrôlé et contenu
      // composé à partir du document enregistré (pas depuis le navigateur).
      await base44.functions.invoke('sendDocumentEmail', {
        documentId,
        to: emailData.to,
        subject: emailData.subject,
        message: emailData.message
      });

      setEmailSent(true);
      setTimeout(() => {
        setEmailData({ to: "", subject: title || "Document AdminBelgique", message: "Veuillez trouver ci-joint votre document généré." });
        setEmailSent(false);
      }, 2000);
    } catch (error) {
      console.error("Erreur envoi email:", error);
      alert(error?.response?.data?.error || error?.message || "Erreur lors de l'envoi de l'email");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="flex gap-2 flex-wrap"> {/* MODIFIED: Changed gap-3 to gap-2 and added flex-wrap */}
      <Button
        onClick={handleExportPDF}
        disabled={isExporting}
        className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-black font-semibold"
        title="Télécharger une version PDF prête à imprimer"
      >
        {isExporting ? (
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
        ) : (
          <Download className="w-4 h-4 mr-2" />
        )}
        Télécharger en PDF
      </Button>

      {/* NOUVEAU : Export avancé */}
      <AdvancedExport document={{
        title: title || 'Document',
        type: 'autre',
        category: 'autre',
        recipient: '',
        created_date: new Date().toISOString(),
        content: document
      }} />

      <Dialog>
        <DialogTrigger asChild>
          <Button variant="outline" className="flex-1">
            <Mail className="w-4 h-4 mr-2" />
            Envoyer par Email
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Envoyer le document par email</DialogTitle>
            <DialogDescription>
              Le document sera envoyé en texte brut dans le corps de l'email
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="email-to">Destinataire *</Label>
              <Input
                id="email-to"
                type="email"
                placeholder="exemple@email.com"
                value={emailData.to}
                onChange={(e) => setEmailData({ ...emailData, to: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="email-subject">Objet</Label>
              <Input
                id="email-subject"
                value={emailData.subject}
                onChange={(e) => setEmailData({ ...emailData, subject: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="email-message">Message d'accompagnement</Label>
              <Textarea
                id="email-message"
                rows={3}
                value={emailData.message}
                onChange={(e) => setEmailData({ ...emailData, message: e.target.value })}
              />
            </div>
            <Button
              onClick={handleSendEmail}
              disabled={isSending || emailSent}
              className="w-full"
            >
              {isSending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Envoi en cours...
                </>
              ) : emailSent ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Email envoyé !
                </>
              ) : (
                <>
                  <Mail className="w-4 h-4 mr-2" />
                  Envoyer
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}