import React, { useState } from "react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, Loader2, Trash2 } from "lucide-react";
import { downloadDocumentPdf } from "@/lib/pdfExport";

export default function DocumentFullScreenPreview({
  doc,
  open,
  onClose,
  typeLabel,
  statusLabel,
  statusClass,
  onDelete
}) {
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = async () => {
    if (!doc) return;
    setIsDownloading(true);
    try {
      await downloadDocumentPdf({ title: doc.title || "Document", content: doc.content || "" });
    } catch (error) {
      console.error("Erreur export PDF:", error);
      alert("Erreur lors de l'export PDF");
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDelete = async () => {
    if (!doc) return;
    if (!window.confirm(`Supprimer définitivement « ${doc.title} » ?`)) return;
    await onDelete(doc);
  };

  return (
    <Dialog open={open} onOpenChange={(next) => !next && onClose()}>
      <DialogContent className="left-0 top-0 z-[60] flex h-[100dvh] w-full max-w-none translate-x-0 translate-y-0 flex-col gap-0 rounded-none border-0 p-0">
        <DialogTitle className="sr-only">{doc?.title || "Aperçu du document"}</DialogTitle>

        <div className="flex items-start gap-3 border-b border-gray-200 bg-white px-4 py-3 pr-12">
          <div className="min-w-0 flex-1">
            <h2 className="truncate text-base font-bold text-gray-900">
              {doc?.title || "Aperçu du document"}
            </h2>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              {typeLabel && <Badge variant="secondary" className="text-xs">{typeLabel}</Badge>}
              {statusLabel && <Badge className={`${statusClass || ""} text-xs`}>{statusLabel}</Badge>}
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto bg-gray-100">
          <div className="mx-auto my-4 w-full max-w-3xl rounded-lg border border-gray-200 bg-white p-6 md:my-6 md:p-10">
            <pre className="whitespace-pre-wrap font-sans text-[15px] leading-relaxed text-gray-800 select-text">
              {doc?.content}
            </pre>
          </div>
        </div>

        <div className="flex flex-col gap-2 border-t border-gray-200 bg-white px-4 py-3 sm:flex-row sm:justify-end">
          <Button variant="outline" onClick={onClose}>Fermer</Button>
          <Button onClick={handleDownload} disabled={isDownloading}>
            {isDownloading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Download className="mr-2 h-4 w-4" />
            )}
            Télécharger (PDF)
          </Button>
          <Button variant="destructive" onClick={handleDelete}>
            <Trash2 className="mr-2 h-4 w-4" />
            Supprimer
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}