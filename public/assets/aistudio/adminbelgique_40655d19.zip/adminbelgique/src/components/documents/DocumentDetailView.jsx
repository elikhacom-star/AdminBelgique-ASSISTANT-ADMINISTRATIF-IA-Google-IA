import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Document } from "@/entities/Document";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FileText, Download, CheckCircle, Copy, Mail, FileDown, Loader2, Tag as TagIcon, Plus, X, History, RotateCcw } from "lucide-react";
import { api as base44 } from "@/components/api/wrapper";
import { useTranslation } from "@/components/localization/useTranslation";
import { downloadDocumentPdf } from "@/lib/pdfExport";

export default function DocumentDetailView({ document, onUpdated }) {
  const { t } = useTranslation();
  const [copied, setCopied] = React.useState(false);
  const [emailRecipient, setEmailRecipient] = React.useState("");
  const [isSendingEmail, setIsSendingEmail] = React.useState(false);
  const [emailSent, setEmailSent] = React.useState(false);
  const [isExportingPdf, setIsExportingPdf] = React.useState(false);

  // Local editable state
  const [docData, setDocData] = React.useState(document || null);
  const [newTag, setNewTag] = React.useState("");
  const [updatingTags, setUpdatingTags] = React.useState(false);
  const [versionNote, setVersionNote] = React.useState("");
  const [savingVersion, setSavingVersion] = React.useState(false);
  const [restoring, setRestoring] = React.useState(false);

  React.useEffect(() => {setDocData(document || null);}, [document]);

  if (!docData) {
    return (
      <Card>
        <CardContent className="text-center py-20">
          <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">{t("mydocs.preview_placeholder")}</p>
        </CardContent>
      </Card>);

  }

  const { title, content } = docData;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadFile = (filename, contentToDownload, mimeType) => {
    const blob = new Blob([contentToDownload], { type: mimeType });
    const link = window.document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', filename);
    window.document.body.appendChild(link);
    link.click();
    window.document.body.removeChild(link);
    window.URL.revokeObjectURL(link.href);
  };

  const downloadAsTXT = () => {
    const filename = `${title.replace(/[^a-z0-9]/gi, '_')}.txt`;
    downloadFile(filename, docData.content, 'text/plain;charset=utf-8');
  };

  const downloadAsHTML = () => {
    const htmlContent = `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><title>${title}</title><style>@page{margin:2cm;size:A4}body{font-family:'Times New Roman',Times,serif;line-height:1.6;color:#333;font-size:12pt}.content{white-space:pre-wrap}</style></head><body><div class="content">${docData.content.replace(/\n/g, '<br>')}</div></body></html>`;
    const filename = `${title.replace(/[^a-z0-9]/gi, '_')}_formaté.html`;
    downloadFile(filename, htmlContent, 'text/html;charset=utf-8');
  };

  const downloadAsPDF = async () => {
    setIsExportingPdf(true);
    try {
      await downloadDocumentPdf({ title, content: docData.content });
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleSendEmail = async () => {
    if (!emailRecipient.trim()) return;
    setIsSendingEmail(true);
    try {
      // 🔒 Envoi exécuté côté serveur : destinataire contrôlé et contenu
      // composé à partir du document enregistré.
      await base44.functions.invoke('sendDocumentEmail', {
        documentId: docData.id,
        to: emailRecipient,
        subject: `Document administratif: ${title}`
      });
      setEmailSent(true);
      setTimeout(() => setEmailSent(false), 3000);
      setEmailRecipient("");
    } catch (error) {
      alert(error?.response?.data?.error || "❌ Erreur lors de l'envoi de l'email.");
    }
    setIsSendingEmail(false);
  };

  // Tag handlers
  const handleAddTag = async () => {
    const tag = newTag.trim();
    if (!tag) return;
    const current = Array.isArray(docData.tags) ? docData.tags : [];
    if (current.includes(tag)) {setNewTag("");return;}
    const updated = { ...docData, tags: [...current, tag] };
    setUpdatingTags(true);
    try {
      await Document.update(docData.id, { tags: updated.tags });
      setDocData(updated);
      onUpdated && onUpdated(updated);
      setNewTag("");
    } finally {setUpdatingTags(false);}
  };
  const handleRemoveTag = async (tag) => {
    const current = Array.isArray(docData.tags) ? docData.tags : [];
    const updated = { ...docData, tags: current.filter((t) => t !== tag) };
    setUpdatingTags(true);
    try {
      await Document.update(docData.id, { tags: updated.tags });
      setDocData(updated);
      onUpdated && onUpdated(updated);
    } finally {setUpdatingTags(false);}
  };

  // Version handlers
  const handleSaveVersion = async () => {
    setSavingVersion(true);
    try {
      const versions = Array.isArray(docData.versions) ? docData.versions : [];
      const nextVersion = (versions[versions.length - 1]?.version || 0) + 1;
      const newVersion = { version: nextVersion, title: docData.title, content: docData.content, date: new Date().toISOString(), note: versionNote || '' };
      const updated = { ...docData, versions: [...versions, newVersion] };
      await Document.update(docData.id, { versions: updated.versions });
      setDocData(updated);
      onUpdated && onUpdated(updated);
      setVersionNote("");
    } finally {setSavingVersion(false);}
  };

  const handleRestoreVersion = async (v) => {
    if (!v) return;
    setRestoring(true);
    try {
      // Auto-save current as a version before restoring
      const versions = Array.isArray(docData.versions) ? docData.versions : [];
      const currentAsVersion = { version: (versions[versions.length - 1]?.version || 0) + 1, title: docData.title, content: docData.content, date: new Date().toISOString(), note: 'Auto-save before restore' };
      const updatedContent = { title: v.title, content: v.content };
      const updated = { ...docData, ...updatedContent, versions: [...versions, currentAsVersion] };
      await Document.update(docData.id, { ...updatedContent, versions: updated.versions });
      setDocData(updated);
      onUpdated && onUpdated(updated);
    } finally {setRestoring(false);}
  };

  return (
    <Card className="mr-2 ml-5">
      <CardHeader>
        <CardTitle className="truncate">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Tags */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <TagIcon className="w-4 h-4 text-purple-600" />
            <span className="font-semibold text-gray-900">Tags</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {(docData.tags || []).map((tag, idx) =>
            <span key={idx} className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-purple-50 text-purple-700 text-xs border border-purple-200">
                #{tag}
                <button onClick={() => handleRemoveTag(tag)} className="hover:text-purple-900">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
          </div>
          <div className="flex gap-2">
            <Input
              placeholder="Ajouter un tag"
              value={newTag}
              onChange={(e) => setNewTag(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddTag()} />
            
            <Button onClick={handleAddTag} disabled={updatingTags}>
              <Plus className="w-4 h-4 mr-1" /> Ajouter
            </Button>
          </div>
        </div>

        {/* Versions */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-blue-600" />
            <span className="font-semibold text-gray-900">Historique des versions</span>
          </div>
          <div className="flex gap-2">
            <Input
              placeholder="Note (facultatif)"
              value={versionNote}
              onChange={(e) => setVersionNote(e.target.value)} />
            
            <Button onClick={handleSaveVersion} disabled={savingVersion}>
              {savingVersion ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RotateCcw className="w-4 h-4 mr-2" />}
              Enregistrer une version
            </Button>
          </div>
          {docData.versions && docData.versions.length > 0 ?
          <div className="border rounded-lg divide-y">
              {[...docData.versions].reverse().map((v, idx) =>
            <div key={idx} className="p-3 flex items-center justify-between text-sm">
                  <div className="truncate">
                    <span className="font-medium">v{v.version}</span>
                    <span className="text-gray-500 ml-2">{new Date(v.date).toLocaleString()}</span>
                    {v.note && <span className="ml-2 text-gray-700 italic">— {v.note}</span>}
                  </div>
                  <Button size="sm" variant="outline" onClick={() => handleRestoreVersion(v)} disabled={restoring}>
                    Restaurer
                  </Button>
                </div>
            )}
            </div> :

          <div className="text-xs text-gray-500">Aucune version enregistrée.</div>
          }
        </div>

        <div className="bg-gray-50 border rounded-lg p-4 max-h-80 overflow-y-auto relative group">
          <pre className="whitespace-pre-wrap text-sm font-mono leading-relaxed">{docData.content}</pre>
          <Button size="icon" variant="ghost" className="absolute top-2 right-2 h-8 w-8 opacity-0 group-hover:opacity-100" onClick={copyToClipboard} title={t("docgen.preview.copy_button")}>
            {copied ? <CheckCircle className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
          </Button>
        </div>

        <div className="space-y-2">
            <h4 className="font-semibold text-gray-900 flex items-center gap-2"><Download className="w-5 h-5 text-blue-600" />{t("mydocs.download_button")}</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                <Button onClick={downloadAsPDF} disabled={isExportingPdf} className="bg-blue-600 hover:bg-blue-700">
                  {isExportingPdf ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FileDown className="w-4 h-4 mr-2" />} PDF
                </Button>
                <Button variant="outline" onClick={downloadAsTXT}><FileText className="w-4 h-4 mr-2" /> .txt</Button>
                <Button variant="outline" onClick={downloadAsHTML}><FileDown className="w-4 h-4 mr-2" /> .html</Button>
            </div>
        </div>

        <div className="space-y-2">
            <h4 className="font-semibold text-gray-900 flex items-center gap-2"><Mail className="w-5 h-5 text-green-600" />{t("docgen.preview.send_email_title")}</h4>
            <div className="flex gap-2">
                <Input type="email" placeholder={t("docgen.preview.send_email_placeholder")} value={emailRecipient} onChange={(e) => setEmailRecipient(e.target.value)} />
                <Button onClick={handleSendEmail} disabled={isSendingEmail || !emailRecipient.trim()}>
                    {isSendingEmail ? <Loader2 className="w-4 h-4 animate-spin" /> : emailSent ? <CheckCircle className="w-4 h-4" /> : t("docgen.preview.send_button")}
                </Button>
            </div>
        </div>
      </CardContent>
    </Card>);

}