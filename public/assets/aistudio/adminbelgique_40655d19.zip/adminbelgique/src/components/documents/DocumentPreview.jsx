import React from "react";
import { CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, RotateCcw } from "lucide-react";
import DocumentActions from "./DocumentActions";

export default function DocumentPreview({ document, title, documentId, onReset }) {
  return (
    <>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-green-600" />
            Document Généré
          </CardTitle>
          <Button onClick={onReset} variant="outline" size="sm">
            <RotateCcw className="w-4 h-4 mr-2" />
            Nouveau document
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="bg-white border-2 border-gray-200 rounded-lg p-6 max-h-[500px] overflow-y-auto">
          <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed text-gray-800">
            {document}
          </pre>
        </div>

        <DocumentActions document={document} title={title} documentId={documentId} />

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-800">
          <p className="font-semibold mb-2">✅ Document sauvegardé automatiquement</p>
          <p>Vous pouvez retrouver ce document dans la section "Mes Documents"</p>
        </div>
      </CardContent>
    </>
  );
}