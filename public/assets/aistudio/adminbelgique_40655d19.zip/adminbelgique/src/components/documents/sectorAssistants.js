export const SECTORS = [
  {
    id: "logement",
    label: "Logement",
    tagline: "Bail, garantie locative, travaux, préavis",
    icon: "home",
    accent: "bg-emerald-100 text-emerald-700",
    scenarios: [
      {
        label: "Garantie locative non restituée",
        hint: "Réclamer la restitution après la fin du bail",
        title: "Demande de restitution de la garantie locative",
        type: "lettre_reclamation",
        category: "logement",
        details:
          "Je suis locataire du logement situé [adresse complète] et le bail a pris fin le [date]. L'état des lieux de sortie a été réalisé le [date] et aucune dégradation n'a été constatée. Ma garantie locative de [montant] € n'a pas été restituée dans le délai légal de deux mois. Je vous demande la restitution complète de ce montant sur le compte [IBAN] dans un délai de 15 jours."
      },
      {
        label: "Réparations non effectuées",
        hint: "Obtenir l'exécution des travaux par le bailleur",
        title: "Réclamation pour réparations non effectuées",
        type: "lettre_reclamation",
        category: "logement",
        details:
          "Je loue le logement situé [adresse complète]. Les problèmes suivants ne sont toujours pas réparés : [décrire : chauffage hors service, infiltrations, électricité non conforme]. Je les ai signalés à plusieurs reprises, notamment le [date] par [courrier / email / téléphone], sans résultat. Conformément aux articles 1719 et 1720 du Code civil, je vous demande de faire réaliser ces réparations dans un délai de 30 jours."
      },
      {
        label: "Préavis de bail contesté",
        hint: "Contester un préavis ou un délai non conforme",
        title: "Contestation du préavis reçu",
        type: "recours",
        category: "logement",
        details:
          "J'ai reçu un préavis de [nom du bailleur] le [date], prenant effet le [date]. Je conteste ce préavis pour le motif suivant : [délai de préavis trop court / forme non conforme / motif non valable]. Je demande [l'annulation du préavis / le respect du délai légal / une motivation écrite] et vous prie de me confirmer votre position par écrit."
      }
    ]
  },
  {
    id: "facturation",
    label: "Facturation",
    tagline: "Factures, prélèvements, remboursements",
    icon: "receipt",
    accent: "bg-blue-100 text-blue-700",
    scenarios: [
      {
        label: "Facture erronée ou contestée",
        hint: "Obtenir une facture rectificative",
        title: "Contestation de facture",
        type: "lettre_reclamation",
        category: "finances",
        details:
          "Je conteste la facture n° [numéro] du [date], d'un montant de [montant] €, émise par [organisme / fournisseur]. Le motif de ma contestation est le suivant : [double facturation / service non fourni / tarif erroné / index de compteur erroné]. Je demande une facture rectificative ou l'annulation des montants contestés dans un délai de 15 jours."
      },
      {
        label: "Remboursement d'un trop-payé",
        hint: "Récupérer un montant payé en trop",
        title: "Demande de remboursement d'un trop-payé",
        type: "demande_remboursement",
        category: "finances",
        details:
          "J'ai payé la somme de [montant] € le [date] à [organisme / fournisseur], pour [objet du paiement]. Ce montant ne m'était pas dû ou a été prélevé deux fois. Je demande le remboursement de [montant] € sur le compte [IBAN] dans un délai de 30 jours."
      },
      {
        label: "Échelonnement d'une facture",
        hint: "Demander un plan de paiement",
        title: "Demande d'échelonnement d'une facture",
        type: "demande_renseignements",
        category: "finances",
        details:
          "Je suis redevable de la facture n° [numéro] d'un montant de [montant] €. Ma situation actuelle ne me permet pas de régler la totalité en une fois : [expliquer brièvement : perte d'emploi, revenus réduits, frais médicaux]. Je demande l'autorisation de payer en [nombre] mensualités de [montant] € à partir du [date]."
      }
    ]
  },
  {
    id: "juridique",
    label: "Juridique",
    tagline: "Impayés, recours, plaintes",
    icon: "scale",
    accent: "bg-purple-100 text-purple-700",
    scenarios: [
      {
        label: "Impayé à réclamer",
        hint: "Mettre en demeure un débiteur",
        title: "Mise en demeure de payer",
        type: "lettre_reclamation",
        category: "autre",
        details:
          "Malgré ma demande du [date], la somme de [montant] € correspondant à [objet : facture, loyer, prestation] reste impayée. Je vous mets en demeure de me régler ce montant dans un délai de 14 jours à compter de la réception de ce courrier, à défaut de quoi je saisirai [le tribunal compétent / mon conseil]."
      },
      {
        label: "Contester une décision",
        hint: "Introduire un recours administratif",
        title: "Recours contre une décision administrative",
        type: "recours",
        category: "autre",
        details:
          "J'ai reçu la décision [référence] du [date] de [administration], me concernant : [décision contestée]. Je conteste cette décision pour les motifs suivants : [exposer les motifs de fait et de droit]. Je demande [la révision / l'annulation] de cette décision et vous prie de me notifier votre décision par écrit."
      },
      {
        label: "Plainte contre un service",
        hint: "Signaler un dysfonctionnement administratif",
        title: "Plainte administrative",
        type: "plainte_administrative",
        category: "autre",
        details:
          "Je souhaite déposer une plainte concernant le traitement de mon dossier [référence] par [service / administration]. Faits : [décrire les faits, les dates et les interlocuteurs]. Conséquences : [préjudice subi]. Je demande [la réparation / le réexamen du dossier / une réponse écrite motivée]."
      }
    ]
  }
];