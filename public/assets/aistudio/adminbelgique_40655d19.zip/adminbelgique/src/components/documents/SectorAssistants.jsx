import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { ArrowRight, ChevronDown, Home, Receipt, Scale } from "lucide-react";
import { SECTORS } from "./sectorAssistants";

const ICONS = { home: Home, receipt: Receipt, scale: Scale };

export default function SectorAssistants({ onApply }) {
  const [openSector, setOpenSector] = useState(null);

  return (
    <div className="mb-6">
      <h2 className="text-lg font-bold text-gray-900 mb-1">Assistant par secteur</h2>
      <p className="text-sm text-gray-600 mb-4">
        Choisissez votre domaine : le formulaire est pré-rempli avec le type de document, la catégorie
        et un texte de départ à compléter.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {SECTORS.map((sector) => {
          const Icon = ICONS[sector.icon];
          const isOpen = openSector === sector.id;
          return (
            <Card key={sector.id} className={isOpen ? "border-yellow-400 shadow-md" : ""}>
              <button
                type="button"
                onClick={() => setOpenSector(isOpen ? null : sector.id)}
                aria-expanded={isOpen}
                className="w-full text-left p-4 flex items-center gap-3"
              >
                <span className={`p-2 rounded-lg ${sector.accent}`}>
                  <Icon className="w-5 h-5" />
                </span>
                <span className="flex-1">
                  <span className="block font-semibold text-gray-900">{sector.label}</span>
                  <span className="block text-xs text-gray-600">{sector.tagline}</span>
                </span>
                <ChevronDown
                  className={`w-4 h-4 text-gray-400 transition-transform ${isOpen ? "rotate-180" : ""}`}
                />
              </button>

              {isOpen && (
                <div className="px-3 pb-3 space-y-2">
                  {sector.scenarios.map((scenario) => (
                    <button
                      key={scenario.label}
                      type="button"
                      onClick={() => onApply(sector, scenario)}
                      className="w-full text-left border border-gray-200 rounded-lg p-3 hover:border-yellow-400 hover:bg-yellow-50 transition-colors flex items-start gap-2"
                    >
                      <span className="flex-1">
                        <span className="block text-sm font-medium text-gray-900">{scenario.label}</span>
                        <span className="block text-xs text-gray-500 mt-1">{scenario.hint}</span>
                      </span>
                      <ArrowRight className="w-4 h-4 text-gray-400 flex-shrink-0 mt-1" />
                    </button>
                  ))}
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}