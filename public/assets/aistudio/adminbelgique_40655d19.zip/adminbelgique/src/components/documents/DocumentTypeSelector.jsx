import React from 'react';
import { Card } from "@/components/ui/card";
import { useTranslation } from "@/components/localization/useTranslation";
import { FileText, Receipt, Info, ShieldCheck, AlertTriangle } from "lucide-react";

const DocumentTypeSelector = ({ onSelect, selectedType }) => {
  const { t } = useTranslation();

  const documentTypes = [
    { id: "lettre_reclamation", title: t("docgen.type.reclamation"), description: t("docgen.type.reclamation_desc"), icon: AlertTriangle, color: "text-red-500" },
    { id: "demande_remboursement", title: t("docgen.type.remboursement"), description: t("docgen.type.remboursement_desc"), icon: Receipt, color: "text-green-500" },
    { id: "demande_renseignements", title: t("docgen.type.renseignements"), description: t("docgen.type.renseignements_desc"), icon: Info, color: "text-blue-500" },
    { id: "recours", title: t("docgen.type.recours"), description: t("docgen.type.recours_desc"), icon: ShieldCheck, color: "text-purple-500" },
    { id: "plainte_administrative", title: t("docgen.type.plainte"), description: t("docgen.type.plainte_desc"), icon: FileText, color: "text-orange-500" },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {documentTypes.map((docType) => {
        const Icon = docType.icon;
        return (
          <Card
            key={docType.id}
            onClick={() => onSelect(docType.id)}
            className={`p-6 cursor-pointer transition-all duration-200 group ${selectedType === docType.id ? 'border-yellow-400 bg-yellow-50 shadow-lg' : 'hover:shadow-md hover:border-gray-300'}`}
          >
            <div className="flex items-center gap-4">
              <div className={`p-2 rounded-lg ${selectedType === docType.id ? 'bg-yellow-100' : 'bg-gray-100 group-hover:bg-yellow-50'}`}>
                <Icon className={`w-6 h-6 ${selectedType === docType.id ? 'text-yellow-600' : `${docType.color} group-hover:text-yellow-600`}`} />
              </div>
              <div className="flex-1">
                <h3 className={`font-semibold ${selectedType === docType.id ? 'text-yellow-800' : 'text-gray-900'}`}>{docType.title}</h3>
                <p className="text-sm text-gray-600">{docType.description}</p>
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
};

export default DocumentTypeSelector;