import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";
import { User } from "@/entities/User";
import { useTranslation } from "@/components/localization/useTranslation";

const DocumentForm = ({ onGenerate, isLoading, type, category, title, recipient, details }) => {
  const { register, handleSubmit, control, setValue, formState: { errors } } = useForm();
  const { t } = useTranslation();

  const categoryLabels = {
    finances: t("category.finances"),
    securite_sociale: t("category.social_security"),
    emploi: t("category.employment"),
    sante: t("category.health"),
    logement: t("category.housing"),
    etudes: t("category.studies"),
    pensions: t("category.pensions")
  };

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const user = await User.me();
        if (user) {
          setValue("fullName", user.full_name);
          setValue("email", user.email);
        }
      } catch (error) {
        console.error("User not logged in or error fetching user", error);
      }
    };
    fetchUser();
  }, [setValue]);

  useEffect(() => {
    if (details) setValue("details", details);
  }, [details, setValue]);

  const onSubmit = (data) => {
    const lines = [];
    if (type === 'lettre_reclamation') {
      if (data.dossierNumber) lines.push(`Référence dossier: ${data.dossierNumber}`);
      if (data.decisionDate) lines.push(`Date de la décision: ${data.decisionDate}`);
      if (data.objectionDetails) lines.push(`Motifs: ${data.objectionDetails}`);
    }
    if (type === 'demande_remboursement') {
      if (data.careDate) lines.push(`Date des soins: ${data.careDate}`);
      if (data.careType) lines.push(`Nature des soins: ${data.careType}`);
      if (data.amount) lines.push(`Montant: ${data.amount}€`);
    }
    if (type === 'demande_renseignements') {
      if (data.question1) lines.push(`Question 1: ${data.question1}`);
      if (data.question2) lines.push(`Question 2: ${data.question2}`);
    }
    const specific = lines.length ? `\n\n--- Informations spécifiques ---\n${lines.join('\n')}` : '';
    const mergedDetails = `${data.details || ''}${specific}`.trim();

    const formData = {
      type,
      category,
      title,
      recipient,
      ...data,
      details: mergedDetails,
    };
    onGenerate(formData);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
      <div className="space-y-4 p-6 border rounded-lg bg-white">
        <h3 className="text-lg font-semibold">{t("docgen.details_title")}</h3>
        <div>
          <Label htmlFor="details" className="text-base">{t("docgen.details_label")}</Label>
          <p className="text-sm text-gray-500 mb-2">{t("docgen.details_help")}</p>
          <Textarea
            id="details"
            {...register("details", { required: true })}
            placeholder={t("docgen.details_placeholder")}
            className="h-40"
          />
          {errors.details && <p className="text-red-500 text-sm mt-1">Ce champ est requis.</p>}
        </div>
      </div>
      
      <div className="space-y-4 p-6 border rounded-lg bg-white">
        <h3 className="text-lg font-semibold">{t("docgen.personal_info_title")}</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="fullName">{t("docgen.fullname_label")}</Label>
            <Input id="fullName" {...register("fullName", { required: true })} placeholder={t("docgen.fullname_placeholder")} />
            {errors.fullName && <p className="text-red-500 text-sm mt-1">Ce champ est requis.</p>}
          </div>
          <div>
            <Label htmlFor="email">{t("docgen.email_label")}</Label>
            <Input id="email" type="email" {...register("email", { required: true })} placeholder={t("docgen.email_placeholder")} />
            {errors.email && <p className="text-red-500 text-sm mt-1">Ce champ est requis.</p>}
          </div>
        </div>
        <div>
          <Label htmlFor="address">{t("docgen.address_label")}</Label>
          <Input id="address" {...register("address", { required: true })} placeholder={t("docgen.address_placeholder")} />
          {errors.address && <p className="text-red-500 text-sm mt-1">Ce champ est requis.</p>}
        </div>
        <div>
          <Label htmlFor="phone">{t("docgen.phone_label")}</Label>
          <Input id="phone" {...register("phone")} placeholder={t("docgen.phone_placeholder")} />
        </div>
      </div>

      {/* Champs spécifiques selon le type de document */}
      <div className="space-y-4 p-6 border rounded-lg bg-white">
        <h3 className="text-lg font-semibold">Champs spécifiques</h3>
        {type === 'lettre_reclamation' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="dossierNumber">Référence dossier</Label>
              <Input id="dossierNumber" {...register('dossierNumber')} placeholder="Numéro de dossier" />
            </div>
            <div>
              <Label htmlFor="decisionDate">Date de la décision</Label>
              <Input id="decisionDate" type="date" {...register('decisionDate')} />
            </div>
            <div className="md:col-span-2">
              <Label htmlFor="objectionDetails">Motifs de la réclamation</Label>
              <Textarea id="objectionDetails" rows={3} {...register('objectionDetails')} placeholder="Expliquez brièvement vos motifs" />
            </div>
          </div>
        )}

        {type === 'demande_remboursement' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="careDate">Date des soins</Label>
              <Input id="careDate" type="date" {...register('careDate')} />
            </div>
            <div>
              <Label htmlFor="careType">Nature des soins</Label>
              <Input id="careType" {...register('careType')} placeholder="Consultation, kiné, etc." />
            </div>
            <div>
              <Label htmlFor="amount">Montant (€)</Label>
              <Input id="amount" type="number" step="0.01" {...register('amount')} placeholder="0.00" />
            </div>
          </div>
        )}

        {type === 'demande_renseignements' && (
          <div className="grid grid-cols-1 gap-4">
            <div>
              <Label htmlFor="question1">Question 1</Label>
              <Input id="question1" {...register('question1')} placeholder="Votre première question" />
            </div>
            <div>
              <Label htmlFor="question2">Question 2</Label>
              <Input id="question2" {...register('question2')} placeholder="Votre seconde question (optionnel)" />
            </div>
          </div>
        )}
      </div>

      <div className="flex justify-end">
        <Button type="submit" disabled={isLoading} className="w-full md:w-auto">
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {t("docgen.generating_button")}
            </>
          ) : (
            t("docgen.generate_button")
          )}
        </Button>
      </div>
    </form>
  );
};

export default DocumentForm;