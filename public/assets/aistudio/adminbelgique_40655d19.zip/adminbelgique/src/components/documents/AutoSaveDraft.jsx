import React, { useEffect, useCallback } from "react";
import { Draft } from "@/entities/Draft";
import { debounce } from "lodash";
import { Badge } from "@/components/ui/badge";
import { Save, CheckCircle } from "lucide-react";

export default function AutoSaveDraft({ type, content, title, enabled = true }) {
  const [lastSaved, setLastSaved] = React.useState(null);
  const [isSaving, setIsSaving] = React.useState(false);

  const saveDraft = useCallback(
    debounce(async (draftData) => {
      if (!enabled || !draftData.content) return;
      
      setIsSaving(true);
      try {
        const existingDrafts = await Draft.filter({ type: draftData.type });
        
        const draftToSave = {
          type: draftData.type,
          content: JSON.stringify(draftData.content),
          title: draftData.title || `Brouillon ${new Date().toLocaleString('fr-BE')}`,
          last_saved: new Date().toISOString()
        };

        if (existingDrafts.length > 0) {
          await Draft.update(existingDrafts[0].id, draftToSave);
        } else {
          await Draft.create(draftToSave);
        }
        
        setLastSaved(new Date());
      } catch (error) {
        console.error("Erreur sauvegarde brouillon:", error);
      } finally {
        setIsSaving(false);
      }
    }, 2000),
    [enabled]
  );

  useEffect(() => {
    if (content && Object.keys(content).length > 0) {
      saveDraft({ type, content, title });
    }
  }, [content, type, title, saveDraft]);

  if (!enabled) return null;

  return (
    <div className="flex items-center gap-2">
      {isSaving ? (
        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
          <Save className="w-3 h-3 mr-1 animate-pulse" />
          Sauvegarde...
        </Badge>
      ) : lastSaved ? (
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
          <CheckCircle className="w-3 h-3 mr-1" />
          Sauvegardé {lastSaved.toLocaleTimeString('fr-BE', { hour: '2-digit', minute: '2-digit' })}
        </Badge>
      ) : null}
    </div>
  );
}