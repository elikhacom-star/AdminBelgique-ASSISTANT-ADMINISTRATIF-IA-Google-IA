import React, { useState, useEffect } from "react";
import { Document } from "@/entities/Document";
import { Question } from "@/entities/Question";
import { Analyse } from "@/entities/Analyse";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, FileText, MessageSquare, TrendingUp, DollarSign, BarChart3 } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function UsageAnalytics() {
  const [stats, setStats] = useState({
    documents: 0,
    questions: 0,
    analyses: 0,
    timeSaved: 0,
    moneySaved: 0,
    activityData: []
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      const [documents, questions, analyses] = await Promise.all([
        Document.list("-created_date").catch(() => []),
        Question.list("-created_date").catch(() => []),
        Analyse.list("-created_date").catch(() => [])
      ]);

      // Calculs d'économies
      const documentsCount = documents.length;
      const questionsCount = questions.length;
      const analysesCount = analyses.length;

      // Temps moyen économisé par action
      const timeSavedPerDoc = 45; // minutes
      const timeSavedPerQuestion = 15; // minutes
      const timeSavedPerAnalysis = 30; // minutes

      const totalTimeSaved = 
        (documentsCount * timeSavedPerDoc) +
        (questionsCount * timeSavedPerQuestion) +
        (analysesCount * timeSavedPerAnalysis);

      // Argent économisé (basé sur tarif horaire moyen avocat/comptable: 150€/h)
      const hourlyRate = 150;
      const moneySaved = Math.round((totalTimeSaved / 60) * hourlyRate);

      // Données d'activité (30 derniers jours)
      const activityData = generateActivityData(documents, questions, analyses);

      setStats({
        documents: documentsCount,
        questions: questionsCount,
        analyses: analysesCount,
        timeSaved: totalTimeSaved,
        moneySaved: moneySaved,
        activityData: activityData
      });

    } catch (error) {
      console.error("Error loading analytics:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const generateActivityData = (documents, questions, analyses) => {
    const last30Days = [];
    const today = new Date();

    for (let i = 29; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];

      const docsCount = documents.filter(d => 
        d.created_date && d.created_date.startsWith(dateStr)
      ).length;

      const questionsCount = questions.filter(q => 
        q.created_date && q.created_date.startsWith(dateStr)
      ).length;

      const analysesCount = analyses.filter(a => 
        a.created_date && a.created_date.startsWith(dateStr)
      ).length;

      last30Days.push({
        date: date.toLocaleDateString('fr-BE', { day: '2-digit', month: 'short' }),
        documents: docsCount,
        questions: questionsCount,
        analyses: analysesCount,
        total: docsCount + questionsCount + analysesCount
      });
    }

    return last30Days;
  };

  const formatTime = (minutes) => {
    if (minutes < 60) return `${minutes}min`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h${mins > 0 ? mins + 'min' : ''}`;
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-500 mx-auto" />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-2 border-blue-200 bg-blue-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-600 font-medium">Documents créés</p>
                <p className="text-3xl font-bold text-blue-900">{stats.documents}</p>
              </div>
              <FileText className="w-10 h-10 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-green-200 bg-green-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-600 font-medium">Questions posées</p>
                <p className="text-3xl font-bold text-green-900">{stats.questions}</p>
              </div>
              <MessageSquare className="w-10 h-10 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-purple-200 bg-purple-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-600 font-medium">Temps économisé</p>
                <p className="text-3xl font-bold text-purple-900">{formatTime(stats.timeSaved)}</p>
              </div>
              <Clock className="w-10 h-10 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-yellow-200 bg-yellow-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-yellow-600 font-medium">Argent économisé</p>
                <p className="text-3xl font-bold text-yellow-900">{stats.moneySaved}€</p>
              </div>
              <DollarSign className="w-10 h-10 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Graphique d'activité */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Activité des 30 derniers jours
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={stats.activityData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Area type="monotone" dataKey="total" stroke="#FBBF24" fill="#FEF3C7" name="Total" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Détails économies */}
      <Card className="bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
        <CardContent className="p-6">
          <h3 className="text-lg font-bold text-emerald-900 mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            💰 Calcul des économies
          </h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between items-center">
              <span className="text-emerald-700">Documents générés ({stats.documents} × 45min)</span>
              <Badge className="bg-emerald-600">≈ {stats.documents * 45}min</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-emerald-700">Questions répondues ({stats.questions} × 15min)</span>
              <Badge className="bg-emerald-600">≈ {stats.questions * 15}min</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-emerald-700">Analyses effectuées ({stats.analyses} × 30min)</span>
              <Badge className="bg-emerald-600">≈ {stats.analyses * 30}min</Badge>
            </div>
            <div className="border-t-2 border-emerald-300 pt-3 mt-3">
              <div className="flex justify-between items-center font-bold">
                <span className="text-emerald-900">Total temps économisé</span>
                <Badge className="bg-emerald-700 text-white">{formatTime(stats.timeSaved)}</Badge>
              </div>
              <p className="text-xs text-emerald-600 mt-2">
                ≈ {stats.moneySaved}€ économisés vs. tarif horaire avocat/comptable (150€/h)
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}