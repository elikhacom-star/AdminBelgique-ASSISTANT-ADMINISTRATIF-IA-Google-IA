import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@/index.css'

// Force HTTPS — redirige toute requête http:// vers https:// (équivalent client-side d'un 301).
// Ignoré en dev local (vite) et dans l'aperçu base44.
if (
  typeof window !== 'undefined' &&
  window.location.protocol === 'http:' &&
  !['localhost', '127.0.0.1'].includes(window.location.hostname) &&
  !window.location.hostname.endsWith('.base44.app') &&
  !window.location.port
) {
  window.location.replace(
    'https://' + window.location.hostname + window.location.pathname + window.location.search + window.location.hash
  );
}

// Clickjacking protection — empêche l'intégration de l'app dans un iframe non autorisé.
// Désactivé dans le builder Base44 (hostname *.base44.app) pour ne pas casser l'aperçu.
if (
  typeof window !== 'undefined' &&
  window.self !== window.top &&
  !window.location.hostname.endsWith('.base44.app')
) {
  window.top.location = window.self.location;
}

ReactDOM.createRoot(document.getElementById('root')).render(
  // <React.StrictMode>
  <App />
  // </React.StrictMode>,
)

if (import.meta.hot) {
  import.meta.hot.on('vite:beforeUpdate', () => {
    window.parent?.postMessage({ type: 'sandbox:beforeUpdate' }, '*');
  });
  import.meta.hot.on('vite:afterUpdate', () => {
    window.parent?.postMessage({ type: 'sandbox:afterUpdate' }, '*');
  });
}