import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, AlertTriangle, ExternalLink, Code, Server, Globe } from "lucide-react";

export default function ConfigurationGuide() {
  // Ajouter meta noindex et gérer le titre de la page
  React.useEffect(() => {
    // Set document title
    document.title = "🚫 Bloquer pages techniques/admin - NOINDEX + robots.txt";

    // Create and append meta robots tag
    const metaRobots = document.createElement('meta');
    metaRobots.name = 'robots';
    metaRobots.content = 'noindex, nofollow';
    document.head.appendChild(metaRobots);

    // Cleanup function to remove meta tag and reset title when component unmounts
    return () => {
      document.head.removeChild(metaRobots);
      // Optionally reset title to a default or previous value if needed
      // For this specific use case, it's often not necessary as pages are usually single-mounted.
      // document.title = "Default Title";
    };
  }, []);

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8">
          <Badge className="mb-4 bg-blue-100 text-blue-800 border-blue-300">
            <Server className="w-4 h-4 mr-2" />
            Configuration Serveur
          </Badge>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            🔧 Guide : Configuration robots.txt
          </h1>
          <p className="text-xl text-gray-600">
            Instructions pour optimiser le référencement
          </p>
        </div>

        {/* ALERTE : Robots.txt détecté mais incomplet */}
        <Alert className="mb-8 bg-orange-50 border-2 border-orange-300">
          <AlertTriangle className="h-5 w-5 text-orange-600" />
          <AlertTitle className="text-orange-900 font-bold">
            ⚠️ Votre robots.txt actuel est INCOMPLET
          </AlertTitle>
          <AlertDescription className="text-orange-800">
            <p className="mb-2">
              Nous avons détecté un fichier robots.txt basique sur votre domaine, mais il <strong>manque les autorisations critiques</strong> pour Stripe.
            </p>
            <p className="font-semibold">
              Vous devez le remplacer par la version optimisée ci-dessous.
            </p>
          </AlertDescription>
        </Alert>

        {/* Étape 1 : Contacter Support */}
        <Card className="mb-8 border-2 border-orange-300">
          <CardHeader className="bg-orange-50">
            <CardTitle className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-500 text-white rounded-full flex items-center justify-center font-bold">
                1
              </div>
              <div>
                <span className="text-orange-900">Option 1 : Contacter le Support Technique</span>
                <p className="text-sm text-orange-700 font-normal mt-1">
                  🔥 La plus simple - recommandée
                </p>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <Alert className="bg-blue-50 border-blue-200">
              <CheckCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                Votre hébergeur peut configurer robots.txt directement à la racine de votre domaine
              </AlertDescription>
            </Alert>

            <div>
              <h4 className="font-bold text-gray-900 mb-2">📧 Demandez au support technique :</h4>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-700 mb-3">
                  <strong>Objet :</strong> Configuration robots.txt pour AdminBelgique.com
                </p>
                <p className="text-sm text-gray-700 leading-relaxed">
                  Bonjour,<br/><br/>
                  Pourriez-vous créer un fichier <code className="bg-gray-200 px-1">robots.txt</code> à la racine de mon domaine 
                  <strong> adminbelgique.com</strong> avec le contenu suivant ?<br/><br/>
                  <em>(Copiez le contenu de l&apos;Étape 3 ci-dessous)</em><br/><br/>
                  Cela permettra aux moteurs de recherche d&apos;indexer correctement mon site.<br/><br/>
                  Merci !
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Étape 2 : Accès FTP/SFTP */}
        <Card className="mb-8 border-2 border-blue-300">
          <CardHeader className="bg-blue-50">
            <CardTitle className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold">
                2
              </div>
              <div>
                <span className="text-blue-900">Option 2 : Upload Manuel via FTP/SFTP</span>
                <p className="text-sm text-blue-700 font-normal mt-1">
                  Si vous avez accès FTP à votre serveur
                </p>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <ol className="list-decimal list-inside space-y-3 text-sm text-gray-700">
              <li>
                <strong>Connectez-vous à votre serveur via FTP</strong> (FileZilla, WinSCP, Cyberduck...)
              </li>
              <li>
                <strong>Naviguez vers le dossier racine</strong> de votre site (souvent <code className="bg-gray-100 px-1">public_html/</code> ou <code className="bg-gray-100 px-1">www/</code>)
              </li>
              <li>
                <strong>Créez un nouveau fichier texte</strong> nommé exactement <code className="bg-gray-100 px-1">robots.txt</code>
              </li>
              <li>
                <strong>Copiez-collez le contenu</strong> de l&apos;Étape 3 ci-dessous
              </li>
              <li>
                <strong>Sauvegardez et uploadez</strong> le fichier
              </li>
              <li>
                <strong>Vérifiez</strong> en visitant <code className="text-blue-600">https://www.adminbelgique.com/robots.txt</code>
              </li>
            </ol>
          </CardContent>
        </Card>

        {/* Étape 3 : Contenu du fichier */}
        <Card className="mb-8 bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-300">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-500 text-white rounded-full flex items-center justify-center font-bold">
                3
              </div>
              <div>
                <span className="text-green-900">Contenu Exact du Fichier robots.txt</span>
                <p className="text-sm text-green-700 font-normal mt-1">
                  📋 À copier-coller intégralement
                </p>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <Alert className="mb-4">
              <Code className="h-4 w-4" />
              <AlertTitle>Copiez exactement ce qui suit :</AlertTitle>
            </Alert>
            
            <pre className="bg-gray-900 text-green-400 p-4 rounded-lg overflow-x-auto text-xs leading-relaxed">
{`# robots.txt optimisé pour AdminBelgique.com
# Dernière mise à jour : 2025-01-14

User-agent: *
Allow: /

# ✅ AUTORISER Stripe (paiements)
Allow: /v3

# Bloquer admin/dashboard si nécessaire
Disallow: /admin/
Disallow: /dashboard/api/

# Bloquer fichiers système
Disallow: /api/internal/
Disallow: /*.json$

# ✅ Sitemap
Sitemap: https://www.adminbelgique.com/sitemap.xml

# ✅ Google Search Console
User-agent: Googlebot
Allow: /
Allow: /*.js
Allow: /*.css

# Bing
User-agent: Bingbot
Allow: /
Allow: /*.js
Allow: /*.css

# Autres bots légitimes
User-agent: Slurp
Allow: /

User-agent: DuckDuckBot
Allow: /

# Bloquer bots scraping agressifs
User-agent: AhrefsBot
Crawl-delay: 10

User-agent: SemrushBot
Crawl-delay: 10

User-agent: MJ12bot
Disallow: /

User-agent: dotbot
Disallow: /`}
            </pre>

            <div className="mt-4 flex gap-3">
              <button
                onClick={() => {
                  const content = document.querySelector('pre').textContent;
                  navigator.clipboard.writeText(content);
                  alert('✅ Contenu copié dans le presse-papiers !');
                }}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
              >
                📋 Copier le Contenu
              </button>
              <a
                href="data:text/plain;charset=utf-8,# robots.txt optimisé pour AdminBelgique.com%0A# Dernière mise à jour : 2025-01-14%0A%0AUser-agent: *%0AAllow: /%0A%0A# ✅ AUTORISER Stripe (paiements)%0AAllow: /v3%0A%0A# Bloquer admin/dashboard si nécessaire%0ADisallow: /admin/%0ADisallow: /dashboard/api/%0A%0A# Bloquer fichiers système%0ADisallow: /api/internal/%0ADisallow: /*.json$%0A%0A# ✅ Sitemap%0ASitemap: https://www.adminbelgique.com/sitemap.xml%0A%0A# ✅ Google Search Console%0AUser-agent: Googlebot%0AAllow: /%0AAllow: /*.js%0AAllow: /*.css%0A%0A# Bing%0AUser-agent: Bingbot%0AAllow: /%0AAllow: /*.js%0AAllow: /*.css%0A%0A# Autres bots légitimes%0AUser-agent: Slurp%0AAllow: /%0A%0AUser-agent: DuckDuckBot%0AAllow: /%0A%0A# Bloquer bots scraping agressifs%0AUser-agent: AhrefsBot%0ACrawl-delay: 10%0A%0AUser-agent: SemrushBot%0ACrawl-delay: 10%0A%0AUser-agent: MJ12bot%0ADisallow: /%0A%0AUser-agent: dotbot%0ADisallow: /"
                download="robots.txt"
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
              >
                💾 Télécharger robots.txt
              </a>
            </div>
          </CardContent>
        </Card>

        {/* Vérification */}
        <Card className="mb-8 bg-purple-50 border-2 border-purple-300">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-purple-900">
              <Globe className="w-5 h-5" />
              Vérifier que ça fonctionne
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <ol className="list-decimal list-inside space-y-3 text-sm text-gray-700">
              <li>
                <strong>Visitez directement :</strong>{' '}
                <a 
                  href="https://www.adminbelgique.com/robots.txt" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline"
                >
                  https://www.adminbelgique.com/robots.txt
                  <ExternalLink className="w-3 h-3 inline ml-1" />
                </a>
                <br/>
                <span className="text-gray-600">Vous devriez voir le contenu du fichier</span>
              </li>
              <li>
                <strong>Testez avec Google :</strong>{' '}
                <a 
                  href="https://www.google.com/webmasters/tools/robots-testing-tool" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline"
                >
                  Google Robots Testing Tool
                  <ExternalLink className="w-3 h-3 inline ml-1" />
                </a>
              </li>
              <li>
                <strong>Google Search Console :</strong>{' '}
                Allez dans Exploration → Testeur de robots.txt
              </li>
            </ol>
          </CardContent>
        </Card>

        {/* Résumé des bénéfices */}
        <div className="bg-gradient-to-r from-yellow-100 to-orange-100 rounded-lg p-6 border-2 border-yellow-300">
          <h3 className="text-xl font-bold text-gray-900 mb-4">
            ✅ Bénéfices après configuration :
          </h3>
          <ul className="space-y-2">

            <li className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700">Stripe JS sera accessible pour les paiements</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700">Googlebot pourra indexer tous vos contenus JS/CSS</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700">Sitemap déclaré pour meilleure indexation</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700">Protection contre les bots scraping agressifs</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}