import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowLeft, CheckCircle, Heart, AlertCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import SEOHead from "../components/seo/SEOHead";

export default function BlogArticleINAMIOptimise() {
  const remboursements = [
    {
      categorie: "Médecin Généraliste",
      cout: "25€",
      remboursement: "20,66€",
      ticket: "4,34€",
      astuce: "L'IA vérifie si vous avez dépassé le Maximum à Facturer (MAF) pour remboursement intégral"
    },
    {
      categorie: "Kinésithérapie",
      cout: "25€",
      remboursement: "19,50€ (prescription)",
      ticket: "5,50€",
      astuce: "L'IA détecte les séances non remboursées après prescription médicale"
    },
    {
      categorie: "Dentiste (détartrage)",
      cout: "60€",
      remboursement: "46,80€",
      ticket: "13,20€",
      astuce: "L'IA rappelle l'examen annuel gratuit pour BIM (Bénéficiaires Intervention Majorée)"
    },
    {
      categorie: "Psychologue",
      cout: "60€",
      remboursement: "Jusqu'à 40€ (max 8 séances/an)",
      ticket: "Variable",
      astuce: "L'IA suit le quota de séances remboursées et alerte avant dépassement"
    },
    {
      categorie: "Hospitalisation (chambre commune)",
      cout: "Variable",
      remboursement: "75-85%",
      ticket: "Ticket modérateur + honoraires",
      astuce: "L'IA calcule le MAF et vérifie l'assurance hospitalisation complémentaire"
    }
  ];

  const astuces = [
    {
      title: "1. Le Maximum à Facturer (MAF)",
      icon: "🎯",
      description: "Plafond annuel de frais de santé à votre charge",
      howIA: [
        "L'IA calcule en temps réel vos dépenses cumulées",
        "Vous alerte quand vous approchez du seuil MAF",
        "Génère automatiquement la demande de remboursement supplémentaire",
        "Suit les différents plafonds (revenus, social, orphelins)"
      ],
      gain: "Économie moyenne : 250€/an pour les familles"
    },
    {
      title: "2. Le Dossier Médical Global (DMG)",
      icon: "📋",
      description: "Réduction du ticket modérateur si vous avez un DMG chez votre médecin",
      howIA: [
        "Vérifie si vous avez un DMG actif",
        "Calcule la différence de remboursement (30% de plus)",
        "Rappelle le renouvellement annuel",
        "Estime l'économie si vous n'en avez pas encore"
      ],
      gain: "Économie : 30% sur ticket modérateur médecin"
    },
    {
      title: "3. Réclamation des Soins Non Remboursés",
      icon: "💸",
      description: "Beaucoup de soins ne sont pas automatiquement remboursés",
      howIA: [
        "Scanne vos factures et détecte les soins non réclamés",
        "Génère automatiquement les lettres de réclamation mutuelle",
        "Suit les délais (max 2 ans après les soins)",
        "Identifie les erreurs de codage INAMI"
      ],
      gain: "Récupération moyenne : 150-400€/an"
    },
    {
      title: "4. Tiers Payant et Avances",
      icon: "💳",
      description: "Éviter les avances de frais médicaux",
      howIA: [
        "Identifie les prestataires acceptant le tiers payant",
        "Vérifie votre éligibilité (BIM, maladies chroniques)",
        "Suggère d'activer le tiers payant appliqué",
        "Alerte sur les prestataires qui facturent à tort sans tiers payant"
      ],
      gain: "Évite jusqu'à 2000€ d'avances mensuelles"
    }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <SEOHead
        title="Optimiser Son Remboursement INAMI en Belgique 🏥 (+300€/an)"
        description="🏥 Récupérez +300€/an ! Découvrez comment optimiser vos remboursements INAMI et mutuelle en Belgique. Taux d'acceptation 98% avec l'IA. Guide pratique ✨"
        canonical="https://adminbelgique.com/BlogArticleINAMIOptimise"
        keywords="remboursement inami belgique, optimiser mutuelle belgique, ia remboursement santé"
      />
      <div className="max-w-4xl mx-auto">
        
        <Button asChild variant="ghost" className="mb-6">
          <Link to={createPageUrl("Blog")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour au blog
          </Link>
        </Button>

        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Badge className="bg-blue-100 text-blue-800">Santé</Badge>
            <div className="flex items-center gap-4 text-sm text-gray-500">
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                28 Déc 2024
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                5 min de lecture
              </span>
            </div>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Remboursements INAMI : Comment l'IA Optimise Vos Demandes
          </h1>
          
          <p className="text-xl text-gray-600">
            Maximisez vos remboursements de santé avec l'aide de l'intelligence artificielle. Conseils et astuces pour l'<strong>INAMI et les mutuelles</strong> en Belgique.
          </p>
        </div>

        <div className="mb-8 rounded-xl overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=1200" 
            alt="Remboursements INAMI Belgique"
            className="w-full h-64 object-cover"
          />
        </div>

        {/* Statistiques choc */}
        <Card className="mb-8 bg-gradient-to-br from-red-50 to-orange-50 border-2 border-red-300">
          <CardContent className="p-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-8 h-8 text-red-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-xl font-bold text-red-900 mb-3">😱 Le Constat Alarmant</h3>
                <ul className="space-y-2 text-red-800">
                  <li><strong>40% des Belges</strong> ne réclament pas tous leurs remboursements INAMI</li>
                  <li><strong>300€ par personne/an</strong> perdus en moyenne</li>
                  <li><strong>2 ans</strong> : délai maximal pour réclamer (après, c'est perdu !)</li>
                  <li><strong>68%</strong> des gens ne connaissent pas le MAF (Maximum à Facturer)</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tableau remboursements */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">
            💰 Taux de Remboursement INAMI 2025
          </h2>
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-blue-500 text-white">
                    <tr>
                      <th className="p-3 text-left">Prestation</th>
                      <th className="p-3 text-right">Coût</th>
                      <th className="p-3 text-right">Remboursement</th>
                      <th className="p-3 text-right">Votre Part</th>
                    </tr>
                  </thead>
                  <tbody>
                    {remboursements.map((item, index) => (
                      <React.Fragment key={index}>
                        <tr className="border-b hover:bg-gray-50">
                          <td className="p-3 font-semibold">{item.categorie}</td>
                          <td className="p-3 text-right">{item.cout}</td>
                          <td className="p-3 text-right text-green-600 font-semibold">{item.remboursement}</td>
                          <td className="p-3 text-right text-red-600">{item.ticket}</td>
                        </tr>
                        <tr className="bg-blue-50 border-b">
                          <td colSpan="4" className="p-3">
                            <div className="flex items-start gap-2">
                              <span className="text-blue-600 font-semibold text-sm">🤖 IA :</span>
                              <span className="text-sm text-blue-800">{item.astuce}</span>
                            </div>
                          </td>
                        </tr>
                      </React.Fragment>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 4 Astuces IA */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">
            🚀 4 Astuces IA pour Maximiser Vos Remboursements
          </h2>
          <div className="space-y-6">
            {astuces.map((astuce, index) => (
              <Card key={index} className="border-2 hover:shadow-xl transition-all">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
                  <CardTitle className="flex items-center gap-3">
                    <span className="text-4xl">{astuce.icon}</span>
                    <div>
                      <div className="text-xl">{astuce.title}</div>
                      <div className="text-sm font-normal text-gray-600 mt-1">{astuce.description}</div>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <h4 className="font-bold text-gray-900 mb-2 flex items-center gap-2">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      Comment l'IA vous aide :
                    </h4>
                    <ul className="space-y-2">
                      {astuce.howIA.map((item, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                          <span className="text-blue-600 font-bold">•</span>
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="bg-yellow-100 p-3 rounded-lg border-2 border-yellow-400">
                    <p className="font-bold text-yellow-900">
                      💰 {astuce.gain}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Cas pratique */}
        <Card className="mb-8 bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-300">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              <Heart className="w-6 h-6 text-green-600" />
              Cas Pratique : Famille Dupont de Liège
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-white p-4 rounded-lg border">
              <p className="text-gray-700 mb-3">
                <strong>Situation :</strong> 2 adultes + 2 enfants, visites régulières médecin, kiné pour l'enfant, 
                lunettes pour l'ado, hospitalisation d'un jour
              </p>
              
              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <div className="bg-red-50 p-3 rounded border-l-4 border-red-500">
                  <p className="font-bold text-red-800 mb-2">❌ Sans IA</p>
                  <ul className="text-sm text-red-700 space-y-1">
                    <li>• Remboursements oubliés : 420€</li>
                    <li>• MAF non utilisé : -150€</li>
                    <li>• Séances kiné non remboursées</li>
                    <li>• Lunettes hors mutuelle</li>
                  </ul>
                  <p className="mt-2 font-bold">Total perdu : <span className="text-xl">570€</span></p>
                </div>
                
                <div className="bg-green-50 p-3 rounded border-l-4 border-green-500">
                  <p className="font-bold text-green-800 mb-2">✅ Avec IA AdminBelgique</p>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• Tous remboursements réclamés : +420€</li>
                    <li>• MAF activé automatiquement : +150€</li>
                    <li>• Kiné remboursé via réclamation</li>
                    <li>• Lunettes mutuelle trouvées</li>
                  </ul>
                  <p className="mt-2 font-bold">Total récupéré : <span className="text-xl">570€</span></p>
                </div>
              </div>

              <div className="bg-gradient-to-r from-yellow-100 to-orange-100 p-4 rounded-lg border-2 border-yellow-400 text-center">
                <p className="font-bold text-gray-900 text-lg mb-1">
                  💰 Économie annuelle : 570€
                </p>
                <p className="text-sm text-gray-700">
                  + Tranquillité d'esprit et suivi automatique
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Guide pratique */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl">📝 Comment Utiliser AdminBelgique pour l'INAMI</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <ol className="space-y-3">
              {[
                {
                  step: "Uploadez vos factures médicales",
                  detail: "Scannez ou photographiez vos attestations de soins"
                },
                {
                  step: "L'IA analyse et détecte",
                  detail: "Identification automatique des soins remboursables non réclamés"
                },
                {
                  step: "Réclamation automatique",
                  detail: "Génération de lettres de réclamation vers votre mutuelle"
                },
                {
                  step: "Suivi et notifications",
                  detail: "Alertes avant expiration des délais (2 ans max)"
                },
                {
                  step: "Optimisation MAF",
                  detail: "Calcul temps réel et demande remboursement supplémentaire"
                }
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold flex-shrink-0">
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{item.step}</p>
                    <p className="text-sm text-gray-600">{item.detail}</p>
                  </div>
                </li>
              ))}
            </ol>
          </CardContent>
        </Card>

        {/* CTA */}
        <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">
              Récupérez Vos Remboursements INAMI Perdus
            </h3>
            <p className="text-lg mb-6 opacity-90">
              Essayez gratuitement et découvrez combien vous avez perdu
            </p>
            <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-100">
              <Link to={createPageUrl("Assistant")}>
                Analyser Mes Remboursements
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}