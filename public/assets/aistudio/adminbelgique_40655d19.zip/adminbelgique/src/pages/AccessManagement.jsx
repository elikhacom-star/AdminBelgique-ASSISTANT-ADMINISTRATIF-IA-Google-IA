import React, { useState, useEffect, useCallback } from "react";
import { UserAccess } from "@/entities/UserAccess";
import { User } from "@/entities/User";
import { useForm, Controller } from "react-hook-form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Edit, X, User as UserIcon, Shield, Loader2, AlertTriangle, RefreshCw, CheckCircle, Lock, Power, PowerOff } from "lucide-react";
import { useTranslation } from "@/components/localization/useTranslation";

const roleIcons = {
  admin: <Shield className="w-4 h-4 text-red-500" />,
  user: <UserIcon className="w-4 h-4 text-gray-500" />,
};

const roleColors = {
  admin: "bg-red-100 text-red-800 border-red-200",
  user: "bg-blue-100 text-blue-800 border-blue-200",
};

export default function AccessManagement() {
  const { t } = useTranslation();
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [isAdmin, setIsAdmin] = useState(false);

  const { register, handleSubmit, control, reset, setValue, formState: { errors } } = useForm();

  // Ajouter meta noindex
  React.useEffect(() => {
    const metaRobots = document.createElement('meta');
    metaRobots.name = 'robots';
    metaRobots.content = 'noindex, nofollow';
    document.head.appendChild(metaRobots);

    return () => {
      document.head.removeChild(metaRobots);
    };
  }, []);

  // SÉCURITÉ : Charger l'utilisateur actuel et vérifier s'il est admin
  useEffect(() => {
    const checkAdminStatus = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
        
        // ✅ Vérification côté client pour l'UX uniquement.
        // La sécurité est strictement appliquée côté serveur par les règles RLS
        // de l'entité UserAccess (admin-only pour create/read/update/delete).
        const isUserAdmin = user?.role === 'admin';
        setIsAdmin(isUserAdmin);
        
        console.log('[AccessManagement] User:', user?.email, 'Role:', user?.role, 'IsAdmin:', isUserAdmin);
      } catch (error) {
        setCurrentUser(null);
        setIsAdmin(false);
      }
    };
    checkAdminStatus();
  }, []);

  const loadUsers = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await UserAccess.list("-created_date");
      setUsers(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error("Erreur de chargement:", e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadUsers();
  }, [loadUsers, refreshKey]);

  const onSubmit = async (data) => {
    if (!isAdmin) {
      alert("Vous n'avez pas les permissions nécessaires pour effectuer cette action.");
      return;
    }

    try {
      const userData = {
        ...data,
        active: editingUser ? editingUser.active : true // Preserve active status on edit, default true on create
      };

      if (editingUser) {
        await UserAccess.update(editingUser.id, userData);
      } else {
        await UserAccess.create(userData);
      }
      
      setShowForm(false);
      setEditingUser(null);
      reset();
      await loadUsers();
    } catch (error) {
      alert(`Erreur lors de la sauvegarde: ${error.message}`);
    }
  };

  const handleDelete = async (user) => {
    if (!isAdmin) {
      alert("Vous n'avez pas les permissions nécessaires pour supprimer des utilisateurs.");
      return;
    }

    if (user.email === currentUser?.email) {
      alert("Vous ne pouvez pas supprimer votre propre accès !");
      return;
    }

    if (window.confirm(`Êtes-vous sûr de vouloir supprimer l'accès de ${user.email} ?`)) {
      try {
        await UserAccess.delete(user.id);
        await loadUsers();
      } catch (error) {
        alert(`Erreur lors de la suppression: ${error.message}`);
      }
    }
  };

  const handleToggleActive = async (user) => {
    if (!isAdmin) return;
    if (user.email === currentUser?.email) {
        alert("Vous ne pouvez pas désactiver votre propre compte.");
        return;
    }

    try {
        await UserAccess.update(user.id, { active: !user.active });
        await loadUsers();
    } catch (error) {
        alert(`Erreur lors de la modification du statut: ${error.message}`);
    }
  };

  const handleEdit = (user) => {
    if (!isAdmin) {
      alert("Vous n'avez pas les permissions nécessaires pour modifier des utilisateurs.");
      return;
    }

    setEditingUser(user);
    setValue("email", user.email);
    setValue("role", user.role);
    setValue("notes", user.notes || "");
    setShowForm(true);
  };

  const handleAddNew = () => {
    if (!isAdmin) {
      alert("Vous n'avez pas les permissions nécessaires pour ajouter des utilisateurs.");
      return;
    }

    setEditingUser(null);
    reset();
    setShowForm(true);
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingUser(null);
    reset();
  };
  
  const handleRefresh = () => {
    setRefreshKey(prevKey => prevKey + 1);
  };

  // Si l'utilisateur n'est pas admin, afficher un message d'accès refusé
  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-yellow-500" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="p-4 md:p-8">
        <div className="max-w-2xl mx-auto mt-12">
          <Alert variant="destructive" className="bg-red-50 border-red-200">
            <Lock className="h-5 w-5 text-red-600" />
            <AlertTitle className="text-red-800 font-bold text-lg">Accès Refusé</AlertTitle>
            <AlertDescription className="text-red-700">
              <p className="mb-2">Vous n'avez pas les permissions nécessaires pour accéder à cette page.</p>
              <p className="text-sm">Seuls les <strong>administrateurs</strong> peuvent gérer les accès utilisateurs.</p>
              <p className="text-sm mt-2">Si vous pensez qu'il s'agit d'une erreur, contactez votre administrateur système.</p>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8" key={refreshKey}>
      <div className="max-w-5xl mx-auto">
        
        {/* En-tête */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-red-100 rounded-full px-4 py-2 mb-4">
            <Shield className="w-5 h-5 text-red-600" />
            <span className="text-red-800 font-medium">Zone Administrateur</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Gestion des Accès</h1>
          <p className="text-gray-600">Contrôlez qui peut accéder à votre application</p>
        </div>

        {/* Alerte importante */}
        <Alert className="mb-6 bg-yellow-50 border-yellow-200">
          <AlertTriangle className="h-4 w-4 text-yellow-600" />
          <AlertTitle className="text-yellow-800">Important :</AlertTitle>
          <AlertDescription className="text-yellow-700">
            Seuls les utilisateurs listés ci-dessous pourront se connecter à l'application. 
            Soyez prudent lors de la suppression d'accès.
          </AlertDescription>
        </Alert>

        {/* Actions principales */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-xl font-semibold">Utilisateurs Autorisés</h2>
            <p className="text-gray-500">
              {users.length} utilisateur{users.length > 1 ? 's' : ''} autorisé{users.length > 1 ? 's' : ''}
            </p>
          </div>
          <div className="flex gap-3">
            <Button onClick={handleRefresh} variant="outline" size="icon" title="Actualiser">
              <RefreshCw className="w-4 h-4" />
            </Button>
            <Button onClick={handleAddNew} className="bg-green-600 hover:bg-green-700">
              <Plus className="w-4 h-4 mr-2" />
              Ajouter un utilisateur
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Liste des utilisateurs */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserIcon className="w-5 h-5" />
                  Liste des accès
                </CardTitle>
              </CardHeader>
              <CardContent>
                {users.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <UserIcon className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>Aucun utilisateur autorisé</p>
                    <Button onClick={handleAddNew} className="mt-4">
                      Ajouter le premier utilisateur
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {users.map((user) => (
                      <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                            {roleIcons[user.role]}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{user.email}</span>
                              {user.email === currentUser?.email && (
                                <Badge variant="outline" className="text-xs">
                                  <CheckCircle className="w-3 h-3 mr-1" />
                                  Vous
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge className={`${roleColors[user.role]} text-xs`}>
                                {user.role === 'admin' ? 'Administrateur' : 'Utilisateur'}
                              </Badge>
                              {!user.active && (
                                <Badge variant="destructive" className="text-xs">
                                  Désactivé
                                </Badge>
                              )}
                              {user.notes && (
                                <span className="text-xs text-gray-500">{user.notes}</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            onClick={() => handleToggleActive(user)}
                            size="sm"
                            variant="outline"
                            className={user.active ? "text-orange-600 hover:bg-orange-50" : "text-green-600 hover:bg-green-50"}
                            title={user.active ? "Désactiver" : "Activer"}
                            disabled={user.email === currentUser?.email}
                          >
                            {user.active ? <PowerOff className="w-4 h-4" /> : <Power className="w-4 h-4" />}
                          </Button>
                          <Button
                            onClick={() => handleEdit(user)}
                            size="sm"
                            variant="outline"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            onClick={() => handleDelete(user)}
                            size="sm"
                            variant="outline"
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            disabled={user.email === currentUser?.email}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Formulaire */}
          <div className="lg:col-span-1">
            {showForm && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    {editingUser ? 'Modifier l\'utilisateur' : 'Nouvel utilisateur'}
                    <Button onClick={handleCancel} size="sm" variant="ghost">
                      <X className="w-4 h-4" />
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div>
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        {...register("email", { required: "L'email est requis" })}
                        placeholder="utilisateur@example.com"
                      />
                      {errors.email && (
                        <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="role">Rôle *</Label>
                      <Controller
                        name="role"
                        control={control}
                        rules={{ required: "Le rôle est requis" }}
                        render={({ field }) => (
                          <Select onValueChange={field.onChange} value={field.value}>
                            <SelectTrigger>
                              <SelectValue placeholder="Choisir un rôle" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="user">Utilisateur</SelectItem>
                              <SelectItem value="admin">Administrateur</SelectItem>
                            </SelectContent>
                          </Select>
                        )}
                      />
                      {errors.role && (
                        <p className="text-red-500 text-sm mt-1">{errors.role.message}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="notes">Notes (optionnel)</Label>
                      <Textarea
                        id="notes"
                        {...register("notes")}
                        placeholder="Notes sur cet utilisateur..."
                        rows={3}
                      />
                    </div>

                    <div className="flex gap-2">
                      <Button type="submit" className="flex-1">
                        {editingUser ? 'Modifier' : 'Ajouter'}
                      </Button>
                      <Button type="button" onClick={handleCancel} variant="outline">
                        Annuler
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}