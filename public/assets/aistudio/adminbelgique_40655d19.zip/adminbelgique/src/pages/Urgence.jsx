import React from 'react';
import { useNavigate } from 'react-router-dom';
import EmergencyDisplay, { DEFAULT_EMERGENCY_OPTIONS } from '@/components/emergency/EmergencyDisplay';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, ShieldAlert } from 'lucide-react';

export default function Urgence() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50 via-white to-white px-4 py-8 md:px-8">
      <div className="mx-auto max-w-6xl space-y-8">
        <div className="rounded-3xl border border-red-200 bg-white p-6 shadow-sm md:p-8">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-red-100 px-4 py-2 text-sm font-semibold text-red-700">
            <ShieldAlert className="w-4 h-4" />
            Urgence administration Belgique
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900 md:text-5xl">Les actions urgentes les plus demandées, en accès direct.</h1>
          <p className="mt-4 max-w-3xl text-base text-slate-600 md:text-lg">
            Pas besoin d’attendre dans un chat. Choisissez votre situation et lancez immédiatement la bonne action.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {DEFAULT_EMERGENCY_OPTIONS.map((option) => (
            <Card key={option.id} className="border-red-200 shadow-sm">
              <CardContent className="flex h-full flex-col gap-4 p-5">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">{option.title}</h2>
                  <p className="mt-1 text-sm text-slate-600">{option.subtitle}</p>
                </div>
                <Button
                  onClick={() => navigate('/Chat', { state: { emergencyPrompt: option.prompt } })}
                  className="mt-auto w-full justify-between bg-red-600 hover:bg-red-700"
                >
                  Ouvrir cette urgence
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {DEFAULT_EMERGENCY_OPTIONS.slice(0, 2).map((option) => (
            <EmergencyDisplay key={option.id} data={option.data} fullScreen />
          ))}
        </div>
      </div>
    </div>
  );
}