import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowLeft, CheckCircle, AlertTriangle, FileText, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import SEOHead from "../components/seo/SEOHead";

export default function BlogArticleONEMChomage() {
  const situations = [
    {
      title: "Chômage Complet",
      icon: "📋",
      conditions: [
        "Avoir perdu involontairement son emploi",
        "Être inscrit comme demandeur d'emploi",
        "Totaliser au moins 312 jours de travail (1 an) dans les 21 mois",
        "Être disponible sur le marché du travail"
      ],
      iaHelp: [
        "Calcul automatique de vos jours de travail prestés",
        "Vérification de l'éligibilité avant demande",
        "Génération dossier complet C1, C4, carte de contrôle",
        "Calendrier des contrôles et convocations"
      ]
    },
    {
      title: "Chômage Temporaire",
      icon: "⏰",
      conditions: [
        "Force majeure (ex: crise COVID)",
        "Raisons économiques",
        "Intempéries (secteur construction)",
        "Accident technique"
      ],
      iaHelp: [
        "Suivi automatique des jours de chômage temporaire",
        "Vérification que l'employeur a bien introduit la demande",
        "Calcul des allocations attendues",
        "Alerte si retard de paiement"
      ]
    },
    {
      title: "Crédit-Temps et Interruption de Carrière",
      icon: "🕐",
      conditions: [
        "Réduction de prestations à 4/5 ou mi-temps",
        "Interruption complète",
        "Congé parental, soins palliatifs, soins médicaux"
      ],
      iaHelp: [
        "Simulation du montant d'allocations selon le régime",
        "Guide pas à pas pour l'introduction de la demande",
        "Suivi des conditions (ancienneté, accord employeur)",
        "Rappels renouvellement périodique"
      ]
    }
  ];

  const etapes = [
    {
      numero: "1",
      titre: "Inscription ONEM & FOREM/VDAB/ACTIRIS",
      delai: "Dans les 4 jours ouvrables",
      documents: ["Carte d'identité", "C4 (attestation employeur)", "Diplômes et CV"],
      pieges: [
        "Ne PAS attendre la fin du préavis pour s'inscrire",
        "S'inscrire IMMÉDIATEMENT après la perte d'emploi",
        "Vérifier que l'employeur a bien envoyé le C4 électroniquement"
      ],
      iaAide: "L'IA vérifie que vous avez tous les documents et génère les formulaires pré-remplis"
    },
    {
      numero: "2",
      titre: "Demande d'allocations (Formulaire C109)",
      delai: "Dans les 2 mois",
      documents: ["C1 (déclaration de chômage)", "C4", "Carte de contrôle C3.2A"],
      pieges: [
        "Ne pas oublier de signer électroniquement",
        "Bien compléter TOUTES les rubriques du C1",
        "Joindre justificatifs de formations/études si demandé"
      ],
      iaAide: "L'IA remplit automatiquement le C109 et C1 avec vos données, détecte les champs manquants"
    },
    {
      numero: "3",
      titre: "Contrôle de Disponibilité",
      delai: "Variable (6-12 mois après inscription)",
      documents: ["Preuves de recherche d'emploi", "Candidatures envoyées", "Réponses employeurs"],
      pieges: [
        "CONSERVER toutes les preuves de candidatures (emails, réponses)",
        "Minimum 2-3 candidatures par semaine selon région",
        "Accepter les offres d'emploi convenable (même si salaire inférieur)"
      ],
      iaAide: "L'IA enregistre automatiquement vos candidatures, génère un dossier de preuves, prépare votre défense"
    },
    {
      numero: "4",
      titre: "Pointage Mensuel (Carte de Contrôle)",
      delai: "Avant le 4 du mois suivant",
      documents: ["Carte C3.2A", "Preuves de recherche active"],
      pieges: [
        "NE JAMAIS oublier de pointer (=suspension immédiate)",
        "Bien indiquer les jours travaillés, malades, formations",
        "Déclarer tout revenu complémentaire"
      ],
      iaAide: "L'IA vous rappelle les dates de pointage 3 jours avant, pré-remplit la carte selon votre agenda"
    }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <SEOHead
        title="ONEM & Chômage en Belgique : Guide Complet 2025 📋"
        description="📋 Découvrez le guide complet ONEM 2025 ! Chômage, allocations, contrôles : préparez votre dossier en 1h avec l'IA. Réduisez vos erreurs de 80%. Guide gratuit ✨"
        canonical="https://adminbelgique.com/BlogArticleONEMChomage"
        keywords="onem chômage belgique, allocation chômage belgique, guide onem 2025"
      />
      <div className="max-w-4xl mx-auto">
        
        <Button asChild variant="ghost" className="mb-6">
          <Link to={createPageUrl("Blog")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour au blog
          </Link>
        </Button>

        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Badge className="bg-purple-100 text-purple-800">Emploi</Badge>
            <div className="flex items-center gap-4 text-sm text-gray-500">
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                20 Déc 2024
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                8 min de lecture
              </span>
            </div>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            ONEM et Chômage : L'IA Comme Assistant Personnel
          </h1>
          
          <p className="text-xl text-gray-600">
            Comment l'intelligence artificielle peut vous aider dans vos démarches <strong>ONEM</strong>, de l'inscription aux allocations en passant par la recherche d'emploi.
          </p>
        </div>

        <div className="mb-8 rounded-xl overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=1200" 
            alt="ONEM Chômage Belgique"
            className="w-full h-64 object-cover"
          />
        </div>

        {/* Alert Important */}
        <Card className="mb-8 bg-orange-50 border-2 border-orange-300">
          <CardContent className="p-6">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-orange-900 mb-2">⚠️ Les Erreurs Qui Coûtent Cher</h3>
                <ul className="space-y-1 text-orange-800">
                  <li>• <strong>62%</strong> des dossiers ONEM incomplets au premier dépôt</li>
                  <li>• <strong>3-6 mois</strong> de retard pour obtenir les allocations</li>
                  <li>• <strong>45%</strong> sanctionnés lors du contrôle de disponibilité faute de preuves</li>
                  <li>• <strong>1200€/mois</strong> perdus en moyenne pendant l'attente du dossier</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 3 Situations */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">
            💼 Les 3 Situations ONEM les Plus Fréquentes
          </h2>
          <div className="space-y-6">
            {situations.map((situation, index) => (
              <Card key={index} className="border-2 hover:shadow-lg transition-all">
                <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
                  <CardTitle className="flex items-center gap-3">
                    <span className="text-4xl">{situation.icon}</span>
                    {situation.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-bold text-gray-900 mb-2">📋 Conditions :</h4>
                      <ul className="space-y-1">
                        {situation.conditions.map((cond, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                            <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                            {cond}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                      <h4 className="font-bold text-blue-900 mb-2 flex items-center gap-2">
                        🤖 Aide IA AdminBelgique :
                      </h4>
                      <ul className="space-y-1">
                        {situation.iaHelp.map((help, i) => (
                          <li key={i} className="text-sm text-blue-800">• {help}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* 4 Étapes */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">
            🚀 Les 4 Étapes Clés (Avec Pièges à Éviter)
          </h2>
          <div className="space-y-6">
            {etapes.map((etape, index) => (
              <Card key={index} className="border-2 border-gray-200 hover:shadow-xl transition-all">
                <CardHeader className="bg-gradient-to-r from-gray-50 to-white">
                  <div className="flex items-start justify-between">
                    <CardTitle className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-purple-500 text-white rounded-full flex items-center justify-center text-xl font-bold">
                        {etape.numero}
                      </div>
                      <div>
                        <div className="text-xl">{etape.titre}</div>
                        <Badge className="mt-1 bg-red-100 text-red-800">
                          ⏰ Délai : {etape.delai}
                        </Badge>
                      </div>
                    </CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <h4 className="font-bold text-gray-900 mb-2 flex items-center gap-2">
                      <FileText className="w-5 h-5 text-blue-600" />
                      Documents nécessaires :
                    </h4>
                    <ul className="grid grid-cols-1 md:grid-cols-3 gap-2">
                      {etape.documents.map((doc, i) => (
                        <li key={i} className="bg-gray-50 p-2 rounded text-sm text-gray-700 border">
                          {doc}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-red-50 p-4 rounded-lg border-l-4 border-red-500">
                    <h4 className="font-bold text-red-900 mb-2">❌ Pièges à éviter :</h4>
                    <ul className="space-y-1">
                      {etape.pieges.map((piege, i) => (
                        <li key={i} className="text-sm text-red-800">• {piege}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-500">
                    <h4 className="font-bold text-green-900 mb-2">✅ Aide IA :</h4>
                    <p className="text-sm text-green-800">{etape.iaAide}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Montants */}
        <Card className="mb-8 bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="text-2xl">💰 Montants des Allocations ONEM 2025</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-lg border text-center">
                <div className="text-3xl font-bold text-blue-600 mb-1">65%</div>
                <div className="text-sm text-gray-600 mb-2">Du salaire (3 premiers mois)</div>
                <div className="text-xs text-gray-500">Cohabitant avec charge de famille</div>
              </div>
              <div className="bg-white p-4 rounded-lg border text-center">
                <div className="text-3xl font-bold text-purple-600 mb-1">60%</div>
                <div className="text-sm text-gray-600 mb-2">Du salaire</div>
                <div className="text-xs text-gray-500">Isolé</div>
              </div>
              <div className="bg-white p-4 rounded-lg border text-center">
                <div className="text-3xl font-bold text-pink-600 mb-1">55-40%</div>
                <div className="text-sm text-gray-600 mb-2">Du salaire (dégressif)</div>
                <div className="text-xs text-gray-500">Cohabitant</div>
              </div>
            </div>
            <div className="bg-yellow-100 p-4 rounded-lg border-2 border-yellow-400">
              <p className="text-sm text-gray-800">
                <strong>🤖 Aide IA :</strong> L'IA calcule automatiquement votre allocation selon votre situation familiale, 
                votre dernière rémunération et la durée de chômage. Elle simule aussi la dégressivité pour vous aider à planifier.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Contrôle Disponibilité */}
        <Card className="mb-8 bg-orange-50 border-2 border-orange-300">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              <Users className="w-6 h-6 text-orange-600" />
              Le Contrôle de Disponibilité : Réussir l'Épreuve
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-700">
              C'est <strong>l'étape la plus stressante</strong> : un contrôleur ONEM évalue si vous cherchez activement du travail.
            </p>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-red-100 p-4 rounded-lg border-l-4 border-red-500">
                <h4 className="font-bold text-red-900 mb-2">❌ Ce qui NE marche PAS :</h4>
                <ul className="text-sm text-red-800 space-y-1">
                  <li>• "J'ai cherché sur internet"</li>
                  <li>• Pas de preuves écrites</li>
                  <li>• Refuser des offres convenables</li>
                  <li>• Être trop sélectif sur le poste</li>
                  <li>• Pas assez de candidatures (min 2-3/semaine)</li>
                </ul>
              </div>
              
              <div className="bg-green-100 p-4 rounded-lg border-l-4 border-green-500">
                <h4 className="font-bold text-green-900 mb-2">✅ Ce qui marche :</h4>
                <ul className="text-sm text-green-800 space-y-1">
                  <li>• Dossier complet de candidatures (emails + réponses)</li>
                  <li>• Inscriptions agences intérim</li>
                  <li>• Participation aux séances info FOREM/VDAB</li>
                  <li>• Formations professionnelles</li>
                  <li>• Acceptation d'emploi "convenable"</li>
                </ul>
              </div>
            </div>

            <div className="bg-blue-100 p-4 rounded-lg border-2 border-blue-400">
              <h4 className="font-bold text-blue-900 mb-2">🤖 AdminBelgique vous prépare :</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>✅ Enregistrement automatique de toutes vos candidatures</li>
                <li>✅ Génération d'un dossier PDF de preuves prêt à présenter</li>
                <li>✅ Suggestions de réponses aux questions pièges du contrôleur</li>
                <li>✅ Simulation d'entretien de contrôle avec l'IA</li>
                <li>✅ Lettre de défense si sanction injuste</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* CTA */}
        <Card className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">
              Simplifiez Vos Démarches ONEM avec l'IA
            </h3>
            <p className="text-lg mb-6 opacity-90">
              Dossier complet en 30 minutes au lieu de 3 semaines
            </p>
            <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-100">
              <Link to={createPageUrl("Assistant")}>
                Préparer Mon Dossier ONEM
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}