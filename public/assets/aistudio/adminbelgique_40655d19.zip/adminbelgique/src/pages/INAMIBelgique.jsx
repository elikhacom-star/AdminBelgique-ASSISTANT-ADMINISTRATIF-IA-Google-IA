import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, FileText, MessageSquare, ArrowRight, CheckCircle } from "lucide-react";

export default function INAMIBelgique() {
  return (
    <div className="min-h-screen">
      <div className="bg-gradient-to-br from-green-50 to-teal-100 py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <Badge className="mb-4 bg-green-100 text-green-800">
            <Heart className="w-4 h-4 mr-2" />
            Santé & INAMI
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Remboursements INAMI & Mutuelle Belgique
          </h1>
          <p className="text-xl text-gray-700 mb-8">
            Assistant administratif IA pour vos démarches INAMI, soins de santé, mutuelles belges
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-green-600 hover:bg-green-700">
              <Link to={createPageUrl("Assistant")}>
                <MessageSquare className="w-5 h-5 mr-2" />
                Questions INAMI
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to={createPageUrl("DocumentGenerator")}>
                <FileText className="w-5 h-5 mr-2" />
                Demande de Remboursement
              </Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto py-12 px-4">
        {/* Services Grid */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            Services INAMI & Mutuelles
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {
                title: "Remboursements INAMI",
                description: "Soins médicaux, consultations, analyses, hospitalisations",
                icon: Heart
              },
              {
                title: "Mutuelles Belges",
                description: "Mutualités Chrétiennes, Socialistes, Libres, Neutres",
                icon: CheckCircle
              },
              {
                title: "Attestations Soins",
                description: "Médecin, dentiste, kiné, pharmacie, soins infirmiers",
                icon: FileText
              },
              {
                title: "Réclamations",
                description: "Contester un refus, demander révision remboursement",
                icon: MessageSquare
              }
            ].map((service, idx) => {
              const Icon = service.icon;
              return (
                <Card key={idx} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Icon className="w-5 h-5 text-green-600" />
                      {service.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">{service.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        <section className="prose max-w-none mb-12">
          <h2>Agent Administratif INAMI Belgique</h2>
          <p>
            AdminBelgique est votre <strong>assistant administratif virtuel</strong> spécialisé en démarches de santé. 
            Notre <strong>agent administratif IA</strong> vous aide avec l'INAMI, les mutuelles, les remboursements de soins.
          </p>

          <h3>Services Assistant Administratif Santé</h3>
          <ul>
            <li><strong>Remboursements INAMI</strong> : agent administratif pour réclamations</li>
            <li><strong>Mutuelles belges</strong> : Mutualités Chrétiennes, Socialistes, Libres</li>
            <li><strong>Soins de santé</strong> : médecin, dentiste, kiné, pharmacie</li>
            <li><strong>Attestations</strong> : assistant administratif pour documents</li>
          </ul>

          <h3>Avantages Agent Administratif IA INAMI</h3>
          <p>
            Notre <strong>assistant administratif</strong> connaît toutes les procédures INAMI, peut générer 
            automatiquement vos demandes de remboursement, et vous guide dans vos démarches avec les mutuelles belges.
          </p>

          <h3>Mutuelles Belges Couvertes</h3>
          <p>
            Notre agent administratif IA vous accompagne pour toutes les mutuelles : Mutualité Chrétienne, 
            Mutualité Socialiste, Mutualité Libérale, Mutualité Neutre, Mutualité Libre, Partena, Solidaris.
          </p>
        </section>

        <Card className="bg-gradient-to-r from-green-500 to-teal-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">
              Simplifiez vos démarches INAMI
            </h3>
            <p className="text-green-100 mb-6">
              Agent administratif IA disponible 24/7 pour vos questions santé
            </p>
            <Button asChild size="lg" variant="secondary">
              <Link to={createPageUrl("Assistant")}>
                Essayer Gratuitement
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}