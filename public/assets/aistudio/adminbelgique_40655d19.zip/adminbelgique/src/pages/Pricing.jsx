import React, { useState } from "react";
import { User } from "@/entities/User";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { CheckCircle, Crown, Building2, Rocket, Sparkles } from "lucide-react";
import { createPageUrl } from "@/utils";

const pricingPlans = [
  {
    name: "Gratuit",
    icon: Sparkles,
    color: "border-gray-300",
    buttonColor: "bg-gray-600 hover:bg-gray-700",
    monthlyPrice: 0,
    yearlyPrice: 0,
    features: [
      "3 questions administratives/mois",
      "2 analyses de documents/mois",
      "5 documents générés/mois",
      "20 messages IA/mois",
      "Protection des données",
      "Support par email"
    ],
    limitations: [
      "Limites mensuelles strictes",
      "Pas d'accès prioritaire"
    ]
  },
  {
    name: "Pro",
    planId: "pro",
    icon: Crown,
    color: "border-yellow-400 shadow-xl",
    buttonColor: "bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600",
    popular: true,
    monthlyPrice: 29,
    yearlyPrice: 279,
    features: [
      "Questions illimitées",
      "Analyses illimitées",
      "Documents illimités",
      "Messages IA illimités",
      "Protection données avancée",
      "Support prioritaire 24/7",
      "Historique complet",
      "Export des documents",
      "IMMO BOOST inclus"
    ]
  },
  {
    name: "Cabinet",
    planId: "cabinet",
    icon: Building2,
    color: "border-blue-400",
    buttonColor: "bg-blue-600 hover:bg-blue-700",
    monthlyPrice: 99,
    yearlyPrice: 950,
    features: [
      "Tout du plan Pro",
      "5 utilisateurs inclus",
      "Gestion d'équipe",
      "Tableaux de bord avancés",
      "API personnalisée",
      "Formation sur mesure",
      "Gestionnaire de compte dédié",
      "SLA garanti 99.9%"
    ]
  },
  {
    name: "Enterprise",
    planId: "enterprise",
    icon: Rocket,
    color: "border-purple-400",
    buttonColor: "bg-purple-600 hover:bg-purple-700",
    monthlyPrice: null,
    yearlyPrice: null,
    features: [
      "Tout du plan Cabinet",
      "Utilisateurs illimités",
      "Infrastructure dédiée",
      "Intégrations personnalisées",
      "Conformité RGPD avancée",
      "Hébergement on-premise",
      "Support 24/7/365",
      "Contrat sur mesure"
    ]
  }
];

export default function Pricing() {
  const [isYearly, setIsYearly] = useState(false);
  const [user, setUser] = useState(null);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (error) {
        setUser(null);
      }
    };
    loadUser();
  }, []);

  const handleSubscribe = async (planId) => {
    // Plan gratuit : juste se connecter et commencer
    if (!planId) {
      if (!user) {
        await User.login();
      }
      window.location.href = createPageUrl("Assistant");
      return;
    }

    // Plans payants : rediriger vers Contact
    window.location.href = createPageUrl("Contact");
  };

  const getSavings = (monthly, yearly) => {
    if (!monthly || !yearly) return 0;
    const monthlyCost = monthly * 12;
    return Math.round(((monthlyCost - yearly) / monthlyCost) * 100);
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-yellow-100 text-yellow-800 border-yellow-300">
            <Crown className="w-4 h-4 mr-2" />
            Tarification Transparente
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Choisissez le plan qui vous convient
          </h1>
          <p className="text-xl text-gray-600 mb-6">
            Essayez gratuitement, passez à Pro quand vous êtes prêt
          </p>

          {/* Yearly Toggle */}
          <div className="flex items-center justify-center gap-4 mb-8">
            <Label htmlFor="billing-toggle" className={!isYearly ? 'font-semibold' : ''}>
              Mensuel
            </Label>
            <Switch
              id="billing-toggle"
              checked={isYearly}
              onCheckedChange={setIsYearly}
            />
            <Label htmlFor="billing-toggle" className={isYearly ? 'font-semibold' : ''}>
              Annuel
              <Badge className="ml-2 bg-green-100 text-green-800">-20%</Badge>
            </Label>
          </div>
        </div>

        {/* Plans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {pricingPlans.map((plan, index) => {
            const Icon = plan.icon;
            const price = isYearly ? plan.yearlyPrice : plan.monthlyPrice;
            const savings = getSavings(plan.monthlyPrice, plan.yearlyPrice);

            return (
              <Card key={index} className={`relative ${plan.color} ${plan.popular ? 'scale-105' : ''} hover:shadow-2xl transition-all duration-300`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-4 py-1 shadow-lg">
                      ⭐ Plus Populaire
                    </Badge>
                  </div>
                )}
                
                <CardHeader className="text-center pb-6 pt-8">
                  <div className="w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-8 h-8 text-gray-700" />
                  </div>
                  <CardTitle className="text-2xl mb-2">{plan.name}</CardTitle>
                  <div className="mb-2">
                    {price === null ? (
                      <span className="text-2xl font-bold text-gray-900">Sur devis</span>
                    ) : price === 0 ? (
                      <span className="text-4xl font-bold text-gray-900">0€</span>
                    ) : (
                      <>
                        <span className="text-4xl font-bold text-gray-900">{price}€</span>
                        <span className="text-gray-600">/{isYearly ? 'an' : 'mois'}</span>
                      </>
                    )}
                  </div>
                  {isYearly && savings > 0 && (
                    <Badge className="bg-green-100 text-green-800">
                      Économisez {savings}%
                    </Badge>
                  )}
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    {plan.features.map((feature, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-gray-700">{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  {plan.limitations && (
                    <div className="pt-3 border-t space-y-2">
                      {plan.limitations.map((limitation, i) => (
                        <div key={i} className="flex items-start gap-2 text-gray-500">
                          <span className="text-xs">⚠️</span>
                          <span className="text-xs">{limitation}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  <Button 
                    onClick={() => handleSubscribe(plan.planId)}
                    className={`w-full mt-6 ${plan.buttonColor} text-white`}
                    size="lg"
                  >
                    {plan.name === "Gratuit" ? "Commencer Gratuitement" : 
                     plan.name === "Enterprise" ? "Nous Contacter" : 
                     "Choisir ce Plan"}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Footer Info */}
        <div className="text-center mt-12">
          <p className="text-gray-600 mb-4">
            🔒 Paiements sécurisés • ✅ Sans engagement • 🔄 Annulation à tout moment
          </p>
          
          {/* Moyens de paiement acceptés */}
          <div className="bg-white rounded-lg p-6 border-2 border-gray-200 max-w-3xl mx-auto">
            <h3 className="font-bold text-gray-900 mb-4">💳 Moyens de paiement acceptés</h3>
            <div className="flex flex-wrap gap-4 justify-center items-center">
              <div className="flex items-center gap-2 px-4 py-2 bg-blue-50 rounded-lg border border-blue-200">
                <span className="text-2xl">💳</span>
                <span className="text-sm font-medium">Visa / Mastercard</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-red-50 rounded-lg border border-red-200">
                <span className="text-2xl">🇧🇪</span>
                <span className="text-sm font-medium">Bancontact</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-purple-50 rounded-lg border border-purple-200">
                <span className="text-2xl">🏦</span>
                <span className="text-sm font-medium">SEPA</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-orange-50 rounded-lg border border-orange-200">
                <span className="text-2xl">🔒</span>
                <span className="text-sm font-medium">Paiement Sécurisé</span>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-4">
              Pour passer au plan Pro, Cabinet ou Enterprise, contactez-nous
            </p>
          </div>
          
          <p className="text-sm text-gray-500 mt-4">
            TVA belge non incluse • Facturation mensuelle ou annuelle (-20%)
          </p>
        </div>
      </div>
    </div>
  );
}