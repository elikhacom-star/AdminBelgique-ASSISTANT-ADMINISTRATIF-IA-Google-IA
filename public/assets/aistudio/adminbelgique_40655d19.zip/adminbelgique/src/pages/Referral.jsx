import React, { useState, useEffect } from "react";
import { User } from "@/entities/User";
import { Referral } from "@/entities/Referral";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Gift, Copy, Users, Euro, TrendingUp, Share2, CheckCircle, Mail } from "lucide-react";
import { toast } from "sonner";

export default function ReferralPage() {
  const [user, setUser] = useState(null);
  const [referralData, setReferralData] = useState(null);
  const [referrals, setReferrals] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadReferralData();
  }, []);

  const loadReferralData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      // Chercher ou créer le code de parrainage
      const existingReferrals = await Referral.filter({ referrer_email: currentUser.email });
      
      let myReferral;
      if (existingReferrals.length === 0) {
        // Créer un nouveau code
        const referralCode = generateReferralCode(currentUser.email);
        myReferral = await Referral.create({
          referrer_email: currentUser.email,
          referral_code: referralCode,
          status: 'pending'
        });
      } else {
        myReferral = existingReferrals[0];
      }

      setReferralData(myReferral);

      // Charger tous les parrainages
      const allReferrals = await Referral.filter({ referrer_email: currentUser.email });
      setReferrals(allReferrals);

    } catch (error) {
      console.error("Erreur chargement parrainage:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const generateReferralCode = (email) => {
    const hash = email.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return `ADMIN${hash.toString(36).toUpperCase()}`;
  };

  const getReferralUrl = () => {
    return `${window.location.origin}?ref=${referralData?.referral_code}`;
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success("Copié dans le presse-papier !");
  };

  const shareViaEmail = () => {
    const subject = "🎁 Découvrez AdminBelgique - Assistant Administratif IA";
    const body = `Bonjour,

Je te recommande AdminBelgique, un assistant administratif IA qui simplifie toutes les démarches en Belgique (impôts, INAMI, ONEM, etc.).

🎁 Avec mon code de parrainage, tu obtiens 1 mois gratuit au plan Pro !

👉 Inscris-toi ici : ${getReferralUrl()}

C'est gratuit pour essayer, et vraiment efficace !

Bonne découverte,
${user?.full_name || 'Un ami'}`;

    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const shareViaWhatsApp = () => {
    const message = `🎁 Découvre AdminBelgique, l'assistant administratif IA pour la Belgique !\n\nAvec mon code parrain, tu obtiens 1 MOIS GRATUIT au plan Pro 🚀\n\n👉 ${getReferralUrl()}\n\nC'est gratuit pour essayer !`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
  };

  const stats = {
    total: referrals.length,
    completed: referrals.filter(r => r.status === 'completed').length,
    rewarded: referrals.filter(r => r.status === 'rewarded').length,
    pending: referrals.filter(r => r.status === 'pending').length,
    totalEarnings: referrals.filter(r => r.status === 'rewarded').reduce((acc, r) => acc + (r.reward_value || 0), 0)
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Gift className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-3">
            Programme de Parrainage
          </h1>
          <p className="text-xl text-gray-600">
            Invitez vos amis et gagnez des récompenses ensemble ! 🎉
          </p>
        </div>

        {/* Comment ça marche */}
        <Card className="mb-8 border-2 border-yellow-300 bg-gradient-to-br from-yellow-50 to-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl">
              <TrendingUp className="w-6 h-6 text-yellow-600" />
              Comment ça marche ?
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-500 text-white rounded-full flex items-center justify-center mx-auto mb-3 text-2xl font-bold">
                  1
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Partagez votre lien</h3>
                <p className="text-sm text-gray-600">
                  Envoyez votre lien personnalisé à vos amis, famille ou collègues
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-orange-500 text-white rounded-full flex items-center justify-center mx-auto mb-3 text-2xl font-bold">
                  2
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Ils s'inscrivent</h3>
                <p className="text-sm text-gray-600">
                  Votre filleul crée son compte et obtient 1 mois gratuit au plan Pro
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-red-500 text-white rounded-full flex items-center justify-center mx-auto mb-3 text-2xl font-bold">
                  3
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Vous gagnez tous les deux</h3>
                <p className="text-sm text-gray-600">
                  Vous recevez 1 mois gratuit + 20€ de crédit pour chaque filleul qui s'abonne
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-6 text-center">
              <Users className="w-8 h-8 text-blue-500 mx-auto mb-2" />
              <div className="text-3xl font-bold text-gray-900">{stats.total}</div>
              <div className="text-sm text-gray-600">Invitations</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <div className="text-3xl font-bold text-gray-900">{stats.completed}</div>
              <div className="text-sm text-gray-600">Inscrits</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <Gift className="w-8 h-8 text-purple-500 mx-auto mb-2" />
              <div className="text-3xl font-bold text-gray-900">{stats.rewarded}</div>
              <div className="text-sm text-gray-600">Récompensés</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <Euro className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
              <div className="text-3xl font-bold text-gray-900">{stats.totalEarnings}€</div>
              <div className="text-sm text-gray-600">Gagnés</div>
            </CardContent>
          </Card>
        </div>

        {/* Votre lien de parrainage */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Share2 className="w-5 h-5" />
              Votre Lien de Parrainage
            </CardTitle>
            <CardDescription>
              Partagez ce lien pour inviter vos amis
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Input 
                value={getReferralUrl()} 
                readOnly 
                className="flex-1 font-mono text-sm"
              />
              <Button onClick={() => copyToClipboard(getReferralUrl())}>
                <Copy className="w-4 h-4 mr-2" />
                Copier
              </Button>
            </div>

            <div className="flex gap-2">
              <Button onClick={shareViaEmail} variant="outline" className="flex-1">
                <Mail className="w-4 h-4 mr-2" />
                Partager par Email
              </Button>
              <Button onClick={shareViaWhatsApp} variant="outline" className="flex-1 bg-green-50 hover:bg-green-100">
                <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
                WhatsApp
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Récompenses */}
        <Card className="mb-8 border-2 border-green-300 bg-gradient-to-br from-green-50 to-emerald-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl">
              <Gift className="w-6 h-6 text-green-600" />
              Vos Récompenses
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Alert className="bg-white border-green-200">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <AlertTitle className="text-green-900 font-bold">
                  Pour votre filleul :
                </AlertTitle>
                <AlertDescription className="text-green-800">
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>🎁 <strong>1 mois gratuit</strong> au plan Pro (valeur 29€)</li>
                    <li>✅ Accès immédiat à toutes les fonctionnalités</li>
                    <li>🚀 Sans engagement</li>
                  </ul>
                </AlertDescription>
              </Alert>

              <Alert className="bg-white border-yellow-200">
                <Gift className="h-5 w-5 text-yellow-600" />
                <AlertTitle className="text-yellow-900 font-bold">
                  Pour vous (parrain) :
                </AlertTitle>
                <AlertDescription className="text-yellow-800">
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>🎁 <strong>1 mois gratuit</strong> dès que votre filleul s'inscrit</li>
                    <li>💰 <strong>20€ de crédit</strong> si votre filleul s'abonne au plan Pro</li>
                    <li>🔄 Récompenses illimitées - parrainez autant que vous voulez !</li>
                  </ul>
                </AlertDescription>
              </Alert>
            </div>
          </CardContent>
        </Card>

        {/* Historique des parrainages */}
        {referrals.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Historique des Parrainages</CardTitle>
              <CardDescription>
                Suivez vos invitations et récompenses
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {referrals.map((ref, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        ref.status === 'rewarded' ? 'bg-green-100' :
                        ref.status === 'completed' ? 'bg-blue-100' :
                        'bg-gray-100'
                      }`}>
                        {ref.status === 'rewarded' ? <CheckCircle className="w-5 h-5 text-green-600" /> :
                         ref.status === 'completed' ? <Users className="w-5 h-5 text-blue-600" /> :
                         <Gift className="w-5 h-5 text-gray-600" />}
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">
                          {ref.referred_email || 'En attente d\'inscription'}
                        </div>
                        <div className="text-sm text-gray-500">
                          {ref.conversion_date ? 
                            `Inscrit le ${new Date(ref.conversion_date).toLocaleDateString('fr-BE')}` :
                            'Lien partagé'
                          }
                        </div>
                      </div>
                    </div>
                    <Badge className={
                      ref.status === 'rewarded' ? 'bg-green-600' :
                      ref.status === 'completed' ? 'bg-blue-600' :
                      'bg-gray-400'
                    }>
                      {ref.status === 'rewarded' ? '✅ Récompensé' :
                       ref.status === 'completed' ? '🎉 Inscrit' :
                       '⏳ En attente'}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}