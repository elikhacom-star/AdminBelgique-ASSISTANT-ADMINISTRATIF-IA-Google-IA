import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calculator, FileText, MessageSquare, ArrowRight, CheckCircle } from "lucide-react";

export default function ImpotsBelgique() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-blue-50 to-indigo-100 py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <Badge className="mb-4 bg-blue-100 text-blue-800">
            <Calculator className="w-4 h-4 mr-2" />
            Service Fiscal Belge
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Déclaration d'Impôts en Belgique Simplifiée
          </h1>
          <p className="text-xl text-gray-700 mb-8">
            Votre assistant administratif IA pour gérer vos impôts, déclarations fiscales et remboursements SPF Finances
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
              <Link to={createPageUrl("Assistant")}>
                <MessageSquare className="w-5 h-5 mr-2" />
                Poser une question sur les impôts
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to={createPageUrl("DocumentGenerator")}>
                <FileText className="w-5 h-5 mr-2" />
                Générer un document fiscal
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto py-12 px-4">
        
        {/* Services */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            Services Impôts Belgique
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {
                title: "Déclaration Impôts Belgique",
                description: "Aide à la déclaration d'impôts sur le revenu, Tax-on-web, MyMinfin",
                icon: FileText
              },
              {
                title: "Remboursement Impôts",
                description: "Suivi remboursement fiscal, réclamations SPF Finances",
                icon: Calculator
              },
              {
                title: "Précompte Professionnel",
                description: "Calcul, attestations, questions précompte professionnel",
                icon: CheckCircle
              },
              {
                title: "Fiscalité Immobilière",
                description: "Précompte immobilier, revenu cadastral, déductions",
                icon: Calculator
              }
            ].map((service, idx) => {
              const Icon = service.icon;
              return (
                <Card key={idx} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Icon className="w-5 h-5 text-blue-600" />
                      {service.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">{service.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        {/* SEO Content */}
        <section className="prose max-w-none mb-12">
          <h2>Assistant Administratif IA pour Impôts Belgique</h2>
          <p>
            AdminBelgique est votre <strong>agent administratif virtuel spécialisé en fiscalité belge</strong>. 
            Notre assistant administratif IA vous aide avec toutes vos questions sur les impôts en Belgique : 
            déclaration d'impôts, SPF Finances, Tax-on-web, MyMinfin, remboursements fiscaux.
          </p>

          <h3>Déclaration d'Impôts Simplifiée</h3>
          <p>
            Notre <strong>assistant administratif</strong> vous guide étape par étape pour votre déclaration fiscale belge. 
            Posez vos questions sur les déductions fiscales, crédits d'impôt, revenus immobiliers, précompte professionnel.
          </p>

          <h3>Services SPF Finances</h3>
          <ul>
            <li><strong>Tax-on-web</strong> : aide à la déclaration en ligne</li>
            <li><strong>MyMinfin</strong> : gestion de votre dossier fiscal</li>
            <li><strong>Réclamations fiscales</strong> : agent administratif pour contester</li>
            <li><strong>Remboursements</strong> : suivi de vos remboursements d'impôts</li>
          </ul>

          <h3>Pourquoi Utiliser un Agent Administratif IA ?</h3>
          <p>
            Notre <strong>assistant administratif virtuel</strong> est disponible 24/7 pour répondre à vos questions fiscales. 
            L'agent administratif IA connaît la législation belge, les formulaires SPF Finances, et peut générer 
            automatiquement des documents fiscaux professionnels.
          </p>
        </section>

        {/* CTA */}
        <Card className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">
              Prêt à simplifier vos impôts en Belgique ?
            </h3>
            <p className="text-blue-100 mb-6">
              Essayez gratuitement notre assistant administratif IA spécialisé fiscalité
            </p>
            <Button asChild size="lg" variant="secondary">
              <Link to={createPageUrl("Assistant")}>
                Commencer Gratuitement
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}