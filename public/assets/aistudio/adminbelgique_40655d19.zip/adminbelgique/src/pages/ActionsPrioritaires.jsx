import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  AlertTriangle, 
  CheckCircle, 
  Copy, 
  Download, 
  ExternalLink, 
  FileText,
  Mail,
  Zap
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function ActionsPrioritaires() {
  const { toast } = useToast();
  const [checkedItems, setCheckedItems] = useState({});

  const robotsTxtContent = `# robots.txt optimisé pour AdminBelgique.com
# Dernière mise à jour : 2025-01-14

User-agent: *
Allow: /

# ✅ AUTORISER Google AdSense (CRUCIAL)
Allow: /pagead/
Allow: /*.js
Allow: /*.css

# ✅ AUTORISER Stripe (paiements)
Allow: /v3

# ❌ BLOQUER pages techniques/admin
Disallow: /admin/
Disallow: /dashboard/
Disallow: /ConfigurationGuide
Disallow: /SEODiagnostic
Disallow: /SEOValidation
Disallow: /Redirections301Guide
Disallow: /SearchConsoleGuide
Disallow: /WhatsAppSetup
Disallow: /AccessManagement
Disallow: /ActionsPrioritaires

# Bloquer fichiers système
Disallow: /api/internal/
Disallow: /*.json$

# ✅ Sitemap
Sitemap: https://adminbelgique.com/sitemap.xml

# ✅ Google Search Console
User-agent: Googlebot
Allow: /
Allow: /pagead/
Allow: /*.js
Allow: /*.css
Disallow: /admin/
Disallow: /dashboard/
Disallow: /ConfigurationGuide
Disallow: /SEODiagnostic
Disallow: /SEOValidation

# Bing
User-agent: Bingbot
Allow: /
Allow: /*.js
Allow: /*.css
Disallow: /admin/
Disallow: /dashboard/

# Autres bots légitimes
User-agent: Slurp
Allow: /
Disallow: /admin/

User-agent: DuckDuckBot
Allow: /
Disallow: /admin/

# Bloquer bots scraping agressifs
User-agent: AhrefsBot
Crawl-delay: 10

User-agent: SemrushBot
Crawl-delay: 10

User-agent: MJ12bot
Disallow: /

User-agent: dotbot
Disallow: /`;

  const emailTemplate = `Objet : [URGENT] Configuration robots.txt pour AdminBelgique.com

Bonjour,

Je gère le site web adminbelgique.com et j'ai besoin de mettre à jour le fichier robots.txt à la racine de mon domaine.

Le fichier robots.txt actuel est trop basique et bloque potentiellement l'indexation par Google AdSense et les moteurs de recherche.

Pourriez-vous remplacer le contenu actuel du fichier robots.txt (ou le créer s'il n'existe pas) par le contenu ci-dessous ?

--- DÉBUT DU FICHIER robots.txt ---
${robotsTxtContent}
--- FIN DU FICHIER robots.txt ---

Emplacement du fichier : https://adminbelgique.com/robots.txt

Cette mise à jour permettra :
✅ À Google AdSense de charger ses scripts correctement
✅ À Googlebot d'indexer tous les contenus publics (JS/CSS)
✅ De bloquer les pages administratives privées
✅ De protéger contre les bots de scraping agressifs

Merci de votre aide rapide sur ce sujet critique pour le référencement.

Cordialement,
Elik Khadjavi
AdminBelgique.com
elikaccesit@gmail.com
+32 467 80 10 41`;

  const copyRobotsTxt = () => {
    navigator.clipboard.writeText(robotsTxtContent);
    toast({
      title: "✅ Contenu copié !",
      description: "Collez-le dans votre email ou fichier FTP",
    });
  };

  const copyEmail = () => {
    navigator.clipboard.writeText(emailTemplate);
    toast({
      title: "✅ Email copié !",
      description: "Collez-le dans votre client email",
    });
  };

  const downloadRobotsTxt = () => {
    const blob = new Blob([robotsTxtContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'robots.txt';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
    
    toast({
      title: "✅ Fichier téléchargé !",
      description: "Uploadez-le via FTP à la racine de votre site",
    });
  };

  const toggleCheck = (id) => {
    setCheckedItems(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const allChecked = Object.keys(checkedItems).length >= 5 && Object.values(checkedItems).every(v => v);

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8">
          <Badge className="mb-4 bg-red-100 text-red-800 border-red-300">
            <AlertTriangle className="w-4 h-4 mr-2" />
            Actions Urgentes
          </Badge>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            🚨 Plan d'Action SEO Urgent
          </h1>
          <p className="text-xl text-gray-600">
            3 actions critiques pour récupérer votre position #1 sur "assistant administratif IA"
          </p>
        </div>

        {/* Progression */}
        {allChecked && (
          <Alert className="mb-8 bg-green-50 border-2 border-green-300">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <AlertTitle className="text-green-900 font-bold">
              ✅ Toutes les actions ont été complétées !
            </AlertTitle>
            <AlertDescription className="text-green-800">
              Attendez 24-48h que Google réindexe votre site. Vérifiez ensuite votre position dans les résultats de recherche.
            </AlertDescription>
          </Alert>
        )}

        {/* ACTION 1 : robots.txt */}
        <Card className="mb-6 border-2 border-red-300">
          <CardHeader className="bg-red-50">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-3">
                <div className="w-10 h-10 bg-red-500 text-white rounded-full flex items-center justify-center font-bold">
                  1
                </div>
                <div>
                  <span className="text-red-900">🔴 URGENT - Remplacer robots.txt</span>
                  <p className="text-sm text-red-700 font-normal mt-1">
                    Priorité absolue - Bloque actuellement l'indexation
                  </p>
                </div>
              </CardTitle>
              <Checkbox 
                checked={checkedItems['robots']}
                onCheckedChange={() => toggleCheck('robots')}
              />
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            
            {/* Diagnostic */}
            <Alert variant="destructive" className="bg-red-50 border-red-200">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="text-red-800">
                <strong>Problème détecté :</strong> Le robots.txt actuel est trop basique et peut bloquer :
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>Les scripts Google AdSense (/pagead/)</li>
                  <li>Les fichiers JS/CSS nécessaires à Googlebot</li>
                  <li>L'indexation correcte de vos pages</li>
                </ul>
              </AlertDescription>
            </Alert>

            {/* Solutions */}
            <div className="grid md:grid-cols-2 gap-4">
              
              {/* Option 1 : Email support */}
              <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Mail className="w-5 h-5 text-blue-600" />
                    Option 1 : Email Support
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-gray-700">
                    Envoyez cet email pré-rédigé à votre hébergeur :
                  </p>
                  <div className="bg-white p-3 rounded border border-blue-200 max-h-40 overflow-y-auto">
                    <pre className="text-xs text-gray-700 whitespace-pre-wrap">
                      {emailTemplate.substring(0, 200)}...
                    </pre>
                  </div>
                  <Button onClick={copyEmail} className="w-full bg-blue-600 hover:bg-blue-700">
                    <Copy className="w-4 h-4 mr-2" />
                    Copier l'Email Complet
                  </Button>
                </CardContent>
              </Card>

              {/* Option 2 : FTP */}
              <Card className="bg-purple-50 border-purple-200">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <FileText className="w-5 h-5 text-purple-600" />
                    Option 2 : Upload FTP
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-gray-700">
                    Si vous avez accès FTP, téléchargez et uploadez le fichier :
                  </p>
                  <ol className="text-xs text-gray-600 space-y-1 list-decimal list-inside">
                    <li>Téléchargez robots.txt</li>
                    <li>Connectez-vous via FTP</li>
                    <li>Uploadez à la racine (public_html/)</li>
                    <li>Remplacez l'ancien fichier</li>
                  </ol>
                  <div className="flex gap-2">
                    <Button onClick={downloadRobotsTxt} variant="outline" className="flex-1">
                      <Download className="w-4 h-4 mr-2" />
                      Télécharger
                    </Button>
                    <Button onClick={copyRobotsTxt} variant="outline" className="flex-1">
                      <Copy className="w-4 h-4 mr-2" />
                      Copier
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Contenu robots.txt */}
            <details className="bg-gray-50 rounded-lg p-4 border border-gray-200">
              <summary className="cursor-pointer font-semibold text-gray-900 mb-2">
                📄 Voir le contenu complet du robots.txt optimisé
              </summary>
              <pre className="bg-gray-900 text-green-400 p-4 rounded text-xs overflow-x-auto mt-3">
                {robotsTxtContent}
              </pre>
            </details>

            {/* Vérification */}
            <Alert className="bg-yellow-50 border-yellow-200">
              <Zap className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800">
                <strong>Vérification :</strong> Après mise en place, testez 
                <a 
                  href="https://adminbelgique.com/robots.txt" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline ml-1"
                >
                  adminbelgique.com/robots.txt
                  <ExternalLink className="w-3 h-3 inline ml-1" />
                </a>
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* ACTION 2 : Google Search Console */}
        <Card className="mb-6 border-2 border-orange-300">
          <CardHeader className="bg-orange-50">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-500 text-white rounded-full flex items-center justify-center font-bold">
                  2
                </div>
                <div>
                  <span className="text-orange-900">Soumettre à Google Search Console</span>
                  <p className="text-sm text-orange-700 font-normal mt-1">
                    Demander réindexation immédiate
                  </p>
                </div>
              </CardTitle>
              <Checkbox 
                checked={checkedItems['gsc']}
                onCheckedChange={() => toggleCheck('gsc')}
              />
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <ol className="space-y-3 list-decimal list-inside text-gray-700">
              <li>
                <strong>Ouvrez Google Search Console</strong>
                <Button asChild size="sm" variant="outline" className="ml-3 mb-1">
                  <a href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer">
                    Ouvrir GSC
                    <ExternalLink className="w-3 h-3 ml-2" />
                  </a>
                </Button>
              </li>
              <li>
                <strong>Cliquez sur "Inspection de l'URL"</strong> (en haut)
              </li>
              <li>
                <strong>Entrez :</strong> <code className="bg-gray-100 px-2 py-1 rounded">https://adminbelgique.com</code>
              </li>
              <li>
                <strong>Cliquez sur "Demander une indexation"</strong>
              </li>
              <li>
                <strong>Attendez la confirmation</strong> (1-2 minutes)
              </li>
            </ol>

            <Alert className="bg-blue-50 border-blue-200">
              <AlertDescription className="text-blue-800">
                💡 <strong>Conseil :</strong> Faites la même chose pour vos 5 pages les plus importantes 
                (Services, FAQ, Blog, etc.)
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* ACTION 3 : Vérifier AdSense */}
        <Card className="mb-6 border-2 border-yellow-300">
          <CardHeader className="bg-yellow-50">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-3">
                <div className="w-10 h-10 bg-yellow-500 text-white rounded-full flex items-center justify-center font-bold">
                  3
                </div>
                <div>
                  <span className="text-yellow-900">Vérifier Code AdSense</span>
                  <p className="text-sm text-yellow-700 font-normal mt-1">
                    S'assurer que le code est visible dans le HTML
                  </p>
                </div>
              </CardTitle>
              <Checkbox 
                checked={checkedItems['adsense']}
                onCheckedChange={() => toggleCheck('adsense')}
              />
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <ol className="space-y-3 list-decimal list-inside text-gray-700">
              <li>
                <strong>Ouvrez :</strong> <code className="bg-gray-100 px-2 py-1 rounded">adminbelgique.com</code>
              </li>
              <li>
                <strong>Faites CTRL+U</strong> (afficher le code source)
              </li>
              <li>
                <strong>CTRL+F</strong> → Cherchez : <code className="bg-gray-100 px-2 py-1 rounded">adsbygoogle.js</code>
              </li>
              <li>
                <strong>Vérifiez que vous voyez :</strong>
                <pre className="bg-gray-900 text-green-400 p-3 rounded text-xs mt-2 overflow-x-auto">
{`<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3910073181226892"
     crossorigin="anonymous"></script>`}
                </pre>
              </li>
              <li>
                <strong>IMPORTANT :</strong> Vérifiez que <code className="bg-gray-100 px-2 py-1 rounded">src=""</code> n'est PAS VIDE
              </li>
            </ol>

            <Alert variant="destructive" className="bg-red-50 border-red-200">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="text-red-800">
                <strong>Si src="" est vide :</strong> Le code AdSense n'est pas correctement injecté dans Base44. 
                Contactez le support Base44 immédiatement.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* Timeline */}
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-300">
          <CardHeader>
            <CardTitle>⏱️ Timeline de Récupération</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="w-16 h-16 bg-purple-500 text-white rounded-full flex items-center justify-center font-bold flex-shrink-0">
                  J+0
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">Aujourd'hui</h4>
                  <p className="text-sm text-gray-600">Appliquer les 3 actions ci-dessus</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-16 h-16 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold flex-shrink-0">
                  J+1
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">24h après</h4>
                  <p className="text-sm text-gray-600">Google commence la réindexation</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-16 h-16 bg-green-500 text-white rounded-full flex items-center justify-center font-bold flex-shrink-0">
                  J+3-7
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">3-7 jours après</h4>
                  <p className="text-sm text-gray-600">Remontée visible dans les résultats de recherche</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Ressources */}
        <Card>
          <CardHeader>
            <CardTitle>📚 Ressources Utiles</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <a 
                href="https://www.google.com/webmasters/tools/robots-testing-tool"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg hover:border-blue-400 transition-colors"
              >
                <FileText className="w-5 h-5 text-gray-600" />
                <div>
                  <div className="font-semibold">Testeur robots.txt</div>
                  <div className="text-xs text-gray-500">Google Search Console</div>
                </div>
                <ExternalLink className="w-4 h-4 ml-auto text-gray-400" />
              </a>

              <a 
                href="https://search.google.com/search-console"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg hover:border-blue-400 transition-colors"
              >
                <Zap className="w-5 h-5 text-gray-600" />
                <div>
                  <div className="font-semibold">Search Console</div>
                  <div className="text-xs text-gray-500">Indexation & Performance</div>
                </div>
                <ExternalLink className="w-4 h-4 ml-auto text-gray-400" />
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}