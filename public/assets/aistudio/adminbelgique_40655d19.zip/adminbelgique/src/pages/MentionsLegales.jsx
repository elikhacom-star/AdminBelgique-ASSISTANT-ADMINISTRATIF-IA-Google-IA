
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Building2, Mail, Phone, Globe, AlertTriangle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function MentionsLegales() {
  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-blue-100 rounded-full px-4 py-2 mb-4">
            <Shield className="w-5 h-5 text-blue-600" />
            <span className="text-blue-800 font-medium">Mentions Légales</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Mentions Légales et Informations sur l'Entreprise
          </h1>
          <p className="text-gray-600">
            Informations légales concernant AdminBelgique, service privé d'assistance administrative
          </p>
        </div>

        {/* DISCLAIMER PROMINANT */}
        <Alert className="mb-8 bg-red-50 border-2 border-red-300">
          <AlertTriangle className="h-6 w-6 text-red-600" />
          <AlertTitle className="text-red-900 font-bold text-lg">
            ⚠️ SERVICE PRIVÉ INDÉPENDANT
          </AlertTitle>
          <AlertDescription className="text-red-800">
            <p className="font-semibold mb-2">
              AdminBelgique.com est un <strong>service privé d'assistance administrative</strong> propulsé par l'intelligence artificielle.
            </p>
            <p>
              Nous ne sommes <strong>en aucun cas affiliés, soutenus ou mandatés</strong> par une entité gouvernementale ou administrative belge telle que :
            </p>
            <ul className="list-disc list-inside mt-2 space-y-1">
              <li>SPF Finances (Service Public Fédéral Finances)</li>
              <li>INAMI (Institut National d'Assurance Maladie-Invalidité)</li>
              <li>ONEM (Office National de l'Emploi)</li>
              <li>Aucune autre institution publique belge</li>
            </ul>
            <p className="mt-3 font-semibold">
              AdminBelgique est une <strong>initiative privée indépendante</strong> visant à faciliter les démarches administratives des citoyens et entreprises belges.
            </p>
          </AlertDescription>
        </Alert>

        {/* Informations Éditeur */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="w-5 h-5" />
              Éditeur du Site (Société Privée)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Raison Sociale</h3>
                <p className="text-gray-700">ElikAcces IT Services</p>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Statut Juridique</h3>
                <p className="text-gray-700">Entreprise Privée Indépendante</p>
              </div>

              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Siège Social</h3>
                <p className="text-gray-700">Belgique</p>
              </div>

              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Nom Commercial</h3>
                <p className="text-gray-700">AdminBelgique</p>
              </div>
            </div>

            <div className="pt-4 border-t">
              <h3 className="font-semibold text-gray-900 mb-3">Coordonnées de Contact</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-gray-500" />
                  <div>
                    <p className="font-medium text-gray-900">Email</p>
                    <a href="mailto:elikaccesit@gmail.com" className="text-blue-600 hover:underline">
                     contact@adminbelgique.com
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-gray-500" />
                  <div>
                    <p className="font-medium text-gray-900">Téléphone</p>
                    <a href="tel:+32467801041" className="text-blue-600 hover:underline">
                      +32 467 80 10 41
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Globe className="w-5 h-5 text-gray-500" />
                  <div>
                    <p className="font-medium text-gray-900">Site Web Entreprise</p>
                    <a href="https://adminbelgique.com/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                      www.adminbelgique.com
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Directeur de Publication */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Directeur de Publication</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700">
              Le directeur de la publication est le représentant légal d'ElikAcces IT Services.
            </p>
            <p className="text-sm text-gray-600 mt-2">
              Contact : contact@adminbelgique.com
            </p>
          </CardContent>
        </Card>

        {/* Hébergement */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Hébergement du Site</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 mb-3">
              Le site AdminBelgique.com est hébergé par un fournisseur professionnel garantissant :
            </p>
            <div className="bg-gray-50 rounded-lg p-4">
              <ul className="space-y-2 text-sm text-gray-700">
                <li>✅ Infrastructure sécurisée et redondante</li>
                <li>✅ Conformité RGPD européenne</li>
                <li>✅ Chiffrement SSL/TLS (HTTPS)</li>
                <li>✅ Sauvegardes automatiques quotidiennes</li>
                <li>✅ Protection contre les attaques DDoS</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Propriété Intellectuelle */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Propriété Intellectuelle</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-gray-700">
              L'ensemble du contenu de ce site (textes, images, logos, graphismes, code source, etc.) est la propriété exclusive d'ElikAcces IT Services, sauf mention contraire.
            </p>
            <p className="text-gray-700">
              Toute reproduction, représentation, modification, publication ou adaptation de tout ou partie des éléments du site, quel que soit le moyen ou le procédé utilisé, est interdite sans autorisation écrite préalable.
            </p>
            <p className="text-sm text-gray-600">
              <strong>Marques :</strong> AdminBelgique, IMMO BOOST et tous logos associés sont des marques commerciales d'ElikAcces IT Services.
            </p>
          </CardContent>
        </Card>

        {/* Limitation de Responsabilité */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Limitation de Responsabilité</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-gray-700">
              AdminBelgique est un <strong>service privé d'assistance administrative</strong> utilisant l'intelligence artificielle pour faciliter les démarches administratives.
            </p>
            <p className="text-gray-700 font-semibold text-red-700">
              ⚠️ Les informations et conseils fournis par notre plateforme sont à titre informatif uniquement et ne constituent pas un avis juridique officiel.
            </p>
            <p className="text-gray-700">
              Nous recommandons vivement de consulter les sites officiels des administrations belges concernées ou de faire appel à un professionnel qualifié (avocat, comptable) pour toute situation complexe ou nécessitant une expertise juridique.
            </p>
            <p className="text-sm text-gray-600 mt-4">
              ElikAcces IT Services ne peut être tenu responsable des décisions prises par les utilisateurs sur la base des informations fournies par AdminBelgique.
            </p>
          </CardContent>
        </Card>

        {/* Protection des Données */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Protection des Données Personnelles</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 mb-3">
              AdminBelgique respecte strictement le Règlement Général sur la Protection des Données (RGPD) et la législation belge en matière de vie privée.
            </p>
            <p className="text-gray-700">
              Pour plus d'informations sur la collecte, le traitement et la protection de vos données personnelles, consultez notre <a href="#" className="text-blue-600 hover:underline font-semibold">Politique de Confidentialité</a>.
            </p>
          </CardContent>
        </Card>

        {/* Date de Dernière Mise à Jour */}
        <div className="text-center text-sm text-gray-500 mt-8">
          <p>Mentions légales mises à jour le {new Date().toLocaleDateString('fr-BE', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>
      </div>
    </div>
  );
}
