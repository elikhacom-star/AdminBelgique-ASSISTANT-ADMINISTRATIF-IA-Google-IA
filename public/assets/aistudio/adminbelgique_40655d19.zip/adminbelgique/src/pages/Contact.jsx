import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, Phone, Globe, Clock, User } from "lucide-react";

export default function Contact() {
  return (
    <div className="p-2 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-blue-100 rounded-full px-4 py-2 mb-4">
            <User className="w-5 h-5 text-blue-600" />
            <span className="text-blue-800 font-medium">Informations de Contact</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">Contactez-nous</h1>
          <p className="text-gray-600">
            Nous sommes là pour vous accompagner dans toutes vos démarches administratives
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Informations de contact */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Phone className="w-5 h-5 text-blue-600" />
                Coordonnées Principales
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
                <Mail className="w-6 h-6 text-blue-600" />
                <div>
                  <p className="font-semibold text-gray-900">Email</p>
                  <a 
                    href="mailto:elikaccesit@gmail.com" 
                    className="text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    elikaccesit@gmail.com
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-green-50 rounded-lg">
                <Phone className="w-6 h-6 text-green-600" />
                <div>
                  <p className="font-semibold text-gray-900">Téléphone</p>
                  <a 
                    href="tel:+32467801041" 
                    className="text-green-600 hover:text-green-800 transition-colors font-mono"
                  >
                    +32 467 80 10 41
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-purple-50 rounded-lg">
                <Globe className="w-6 h-6 text-purple-600" />
                <div>
                  <p className="font-semibold text-gray-900">Site Internet</p>
                  <a 
                    href="https://www.elikacces.ovh" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-purple-600 hover:text-purple-800 transition-colors"
                  >
                    www.elikacces.ovh
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Informations sur le service */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Clock className="w-5 h-5 text-gray-600" />
                À Propos du Service
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-yellow-50 rounded-lg">
                <h3 className="font-semibold text-yellow-800 mb-2">🇧🇪 AdminBelgique Premium</h3>
                <p className="text-yellow-700 text-sm">
                  Votre assistant IA spécialisé dans l'administration belge avec technologie 
                  d'anonymisation brevetée pour une sécurité maximale de vos données.
                </p>
              </div>

              <div className="p-4 bg-emerald-50 rounded-lg">
                <h3 className="font-semibold text-emerald-800 mb-2">🏠 IMMO BOOST</h3>
                <p className="text-emerald-700 text-sm">
                  Module immobilier révolutionnaire avec recherche automatique 
                  et analyse IA des portails belges (Immoweb, Logic-Immo, Zimmo).
                </p>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold text-gray-800 mb-2">🔒 Sécurité Garantie</h3>
                <p className="text-gray-700 text-sm">
                  Protection maximale avec chiffrement multicouche et anonymisation 
                  intelligente. Vos données personnelles ne quittent jamais 
                  votre appareil en clair.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Section action */}
        <Card className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardContent className="text-center py-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Besoin d'aide ou d'informations ?
            </h2>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Notre équipe est disponible pour vous accompagner dans l'utilisation 
              de la plateforme et répondre à toutes vos questions techniques ou administratives.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild className="bg-blue-600 hover:bg-blue-700">
                <a href="mailto:elikaccesit@gmail.com">
                  <Mail className="w-4 h-4 mr-2" />
                  Envoyer un Email
                </a>
              </Button>
              <Button asChild variant="outline">
                <a href="tel:+32467801041">
                  <Phone className="w-4 h-4 mr-2" />
                  Appeler Maintenant
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}