import React, { useState, useEffect, useRef } from "react";
import { LISTING_PREFILL_KEY } from "@/lib/listingToClientFile";
import { appendClientActivities } from "@/lib/clientActivity";
import { db } from "@/components/api/wrapper";
import { Document } from "@/entities/Document";
import { InvokeLLM } from "@/integrations/Core";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, FileText } from "lucide-react"; // Added FileText
import { useForm, Controller } from "react-hook-form";
import DocumentTypeSelector from "../components/documents/DocumentTypeSelector";
import DocumentForm from "../components/documents/DocumentForm";
import DocumentPreview from "../components/documents/DocumentPreview";
import SectorAssistants from "../components/documents/SectorAssistants";
import { useTranslation } from "@/components/localization/useTranslation";
import { anonymizeText, deanonymizeText } from "../components/utils/anonymizer";
import LimitChecker from "../components/freemium/LimitChecker";
import { Badge } from "@/components/ui/badge";
import AutoSaveDraft from "../components/documents/AutoSaveDraft";
import TemplateLibrary from "../components/templates/TemplateLibrary"; // New import
import { useToast } from "@/components/ui/use-toast"; // New import
import { base44 } from "@/api/base44Client";

const DocumentGenerator = () => {
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [generatedDocument, setGeneratedDocument] = useState("");
  const [documentDetails, setDocumentDetails] = useState({});
  const [showTemplates, setShowTemplates] = useState(false); // New state
  const { t, locale } = useTranslation();
  const { toast } = useToast(); // Initialize toast

  const { control, handleSubmit, watch, setValue, formState: { errors } } = useForm({ // Added setValue
    defaultValues: {
      type: "",
      category: "",
      title: "",
      recipient: "",
      details: "" // Ensure 'details' is part of defaultValues for template loading
    }
  });
  const prefillClientId = useRef(null);

  // Pré-remplissage depuis une annonce vérifiée (ImmoBoost)
  useEffect(() => {
    const raw = sessionStorage.getItem(LISTING_PREFILL_KEY);
    if (!raw) return;
    sessionStorage.removeItem(LISTING_PREFILL_KEY);
    try {
      const prefill = JSON.parse(raw);
      prefillClientId.current = prefill.client_id || null;
      ["type", "category", "title", "recipient", "details"].forEach((k) => setValue(k, prefill[k] || ""));
      toast({
        title: "Document pré-rempli",
        description: "Les informations de l'annonce vérifiée ont été reprises. Vérifiez puis continuez."
      });
    } catch (_) {}
  }, [setValue, toast]);

  const selectedType = watch("type");
  const allFormData = watch();

  const categoryLabels = {
    finances: t("category.finances"),
    securite_sociale: t("category.social_security"),
    emploi: t("category.employment"),
    sante: t("category.health"),
    logement: t("category.housing"),
    etudes: t("category.studies"),
    pensions: t("category.pensions"),
    general: t("category.general"),
    autre: t("category.other"),
  };

  const handleGenerate = async (formData) => {
    setIsLoading(true);
    setDocumentDetails(formData);

    const fullTextToAnonymize = `
      ${formData.fullName || ''}
      ${formData.address || ''}
      ${formData.email || ''}
      ${formData.phone || ''}
      ${formData.recipient || ''}
      ${formData.details || ''}
    `;

    const { mapping } = anonymizeText(fullTextToAnonymize);

    const anonymizedFormData = {
      fullName: formData.fullName ? deanonymizeText(anonymizeText(formData.fullName).anonymizedText, mapping) : '',
      address: formData.address ? deanonymizeText(anonymizeText(formData.address).anonymizedText, mapping) : '',
      email: formData.email ? deanonymizeText(anonymizeText(formData.email).anonymizedText, mapping) : '',
      phone: formData.phone ? deanonymizeText(anonymizeText(formData.phone).anonymizedText, mapping) : 'Non spécifié',
      recipient: formData.recipient ? deanonymizeText(anonymizeText(formData.recipient).anonymizedText, mapping) : '',
      details: formData.details ? deanonymizeText(anonymizeText(formData.details).anonymizedText, mapping) : ''
    };

    const documentType = t(`docgen.type.${formData.type}`);

    const prompt = `
      Langue de réponse: ${locale}.
      Génère une lettre administrative formelle pour la Belgique, en format texte brut.

      Type de document: ${documentType}
      Catégorie: ${categoryLabels[formData.category] || 'Autre'}
      Destinataire: ${anonymizedFormData.recipient}
      Objet: ${formData.title || ''}

      Informations de l'expéditeur (anonymisées):
      - Nom complet: ${anonymizedFormData.fullName}
      - Adresse: ${anonymizedFormData.address}
      - Email: ${anonymizedFormData.email}
      - Téléphone: ${anonymizedFormData.phone}

      Description détaillée de la situation et de la demande (anonymisée):
      ${anonymizedFormData.details}

      Instructions:
      1. Rédige une lettre formelle et complète en utilisant les informations anonymisées ci-dessus.
      2. Utilise les pseudonymes (ex: [PERSON_1], [EMAIL_1]) dans le corps du texte lorsque tu fais référence aux données.
      3. La lettre doit être prête à être envoyée. Ne mets pas de placeholders comme "[Votre Nom]".
    `;

    try {
      const anonymizedResponse = await InvokeLLM({ prompt });
      const finalDocument = deanonymizeText(anonymizedResponse, mapping);

      setGeneratedDocument(finalDocument);

      await Document.create({
        title: formData.title || 'Document sans titre',
        content: finalDocument,
        type: formData.type || 'lettre_reclamation',
        category: formData.category || 'autre',
        recipient: formData.recipient || '',
        status: "brouillon",
      });

      if (prefillClientId.current) {
        const linkedClient = await db.Client.get(prefillClientId.current);
        await appendClientActivities(linkedClient, {
          type: "document",
          channel: "partage",
          title: formData.title || "Document sans titre",
          details: "Document généré",
          date: new Date().toISOString()
        });
      }

      base44.analytics.track({
        eventName: "document_generated",
        properties: { document_type: formData.type || "autre" },
      });

      setStep(3);
    } catch (error) {
      console.error("Erreur lors de la génération du document:", error);
      alert("Une erreur est survenue. Veuillez réessayer.");
    } finally {
      setIsLoading(false);
    }
  };

  const onFirstSubmit = (data) => {
    setDocumentDetails(data);
    setStep(2);
  };

  const resetGenerator = () => {
    setStep(1);
    setGeneratedDocument("");
    setDocumentDetails({});
    // Reset form fields
    setValue("type", "");
    setValue("category", "");
    setValue("title", "");
    setValue("recipient", "");
    setValue("details", "");
  };

  // New function to handle template selection
  const handleSelectTemplate = (template) => {
    setValue("type", template.type);
    setValue("category", template.category);
    setValue("title", template.title);
    setValue("details", template.content); // Assuming template.content maps to form 'details'
    setShowTemplates(false);
    toast({
      title: "Modèle chargé",
      description: `Le modèle "${template.title}" a été appliqué au formulaire.`,
      variant: "success", // Assuming you have a "success" variant for toast
    });
  };

  const handleApplySector = (sector, scenario) => {
    setValue("type", scenario.type);
    setValue("category", scenario.category);
    setValue("title", scenario.title);
    setValue("details", scenario.details);
    toast({
      title: `Assistant ${sector.label}`,
      description: `Formulaire pré-rempli : ${scenario.title}. Complétez les passages entre crochets.`,
    });
  };

  return (
    <LimitChecker feature="document_count">
      {({ onActionStart, remainingActions, currentPlan }) => {
        const renderStep = () => {
          switch (step) {
            case 1:
              return (
                <form onSubmit={handleSubmit(onFirstSubmit)}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl">{t("docgen.step1_title")}</CardTitle>
                        <p className="text-gray-500">{t("docgen.step1_subtitle")}</p>
                      </div>
                      <AutoSaveDraft 
                        type="document" 
                        content={allFormData} 
                        title={allFormData.title || "Brouillon document"}
                        enabled={Object.keys(allFormData).some(k => allFormData[k])}
                      />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <Label className="font-semibold">{t("docgen.type_label")}</Label>
                      <Controller
                        name="type"
                        control={control}
                        rules={{ required: true }}
                        render={({ field }) => (
                          <DocumentTypeSelector onSelect={field.onChange} selectedType={field.value} />
                        )}
                      />
                       {errors.type && <p className="text-red-500 text-sm mt-1">{t("docgen.error.type")}</p>}
                    </div>

                    <div>
                      <Label htmlFor="category" className="font-semibold">{t("docgen.category_label")}</Label>
                      <Controller
                        name="category"
                        control={control}
                        rules={{ required: true }}
                        render={({ field }) => (
                          <Select onValueChange={field.onChange} value={field.value}>
                            <SelectTrigger><SelectValue placeholder={t("docgen.category_placeholder")} /></SelectTrigger>
                            <SelectContent>
                              {Object.entries(categoryLabels).map(([key, label]) => (
                                <SelectItem key={key} value={key}>{label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        )}
                      />
                       {errors.category && <p className="text-red-500 text-sm mt-1">{t("docgen.error.category")}</p>}
                    </div>

                    <div>
                      <Label htmlFor="title" className="font-semibold">{t("docgen.title_label")}</Label>
                      <Controller
                        name="title"
                        control={control}
                        rules={{ required: true }}
                        render={({ field }) => <Input {...field} placeholder={t("docgen.title_placeholder")} />}
                      />
                      {errors.title && <p className="text-red-500 text-sm mt-1">{t("docgen.error.required")}</p>}
                    </div>

                    <div>
                      <Label htmlFor="recipient" className="font-semibold">{t("docgen.recipient_label")}</Label>
                       <Controller
                        name="recipient"
                        control={control}
                        rules={{ required: true }}
                        render={({ field }) => <Input {...field} placeholder={t("docgen.recipient_placeholder")} />}
                      />
                      {errors.recipient && <p className="text-red-500 text-sm mt-1">{t("docgen.error.required")}</p>}
                    </div>
                    <Button type="submit" className="w-full">{t("docgen.continue_button")}</Button>
                  </CardContent>
                </form>
              );
            case 2:
              return (
                <>
                  <CardHeader>
                    <Button variant="ghost" onClick={() => setStep(1)} className="absolute top-4 left-4">
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      {t("docgen.back_button")}
                    </Button>
                    <div className="flex items-center justify-between pt-12">
                      <div className="text-center flex-1">
                        <CardTitle className="text-xl">{t("docgen.step2_title")}</CardTitle>
                        <p className="text-gray-500">{t("docgen.step2_subtitle")}</p>
                      </div>
                      <AutoSaveDraft 
                        type="document" 
                        content={{...documentDetails, ...allFormData}} 
                        title={documentDetails.title || "Brouillon document"}
                        enabled={true}
                      />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <DocumentForm
                      onGenerate={async (formData) => {
                        const canProceed = await onActionStart();
                        if (canProceed) {
                          const combinedData = { ...documentDetails, ...formData };
                          handleGenerate(combinedData);
                        }
                      }}
                      isLoading={isLoading}
                      type={documentDetails.type}
                      category={documentDetails.category}
                      title={documentDetails.title}
                      recipient={documentDetails.recipient}
                      details={documentDetails.details}
                      // Pass setValue to DocumentForm if it needs to update form fields directly,
                      // or ensure DocumentForm updates its internal state which will be merged with documentDetails.
                      // For now, it seems DocumentForm's onSubmit handles this via onGenerate.
                    />
                  </CardContent>
                </>
              );
            case 3:
              return (
                 <DocumentPreview
                    document={generatedDocument}
                    title={documentDetails.title || 'Document'}
                    onReset={resetGenerator}
                  />
              );
            default:
              return null;
          }
        };

        return (
          <div className="min-h-screen p-2 md:p-8"> {/* Changed className */}
            <div className="max-w-4xl mx-auto"> {/* Changed max-w */}
              <div className="text-center mb-8">
                <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">{t("docgen.title")}</h1>
                <p className="text-gray-600">{t("docgen.subtitle_long")}</p>
                {currentPlan === 'free' && (
                  <Badge className="mt-2 bg-yellow-100 text-yellow-800">
                    {remainingActions} {t("docgen.remaining_docs")}
                  </Badge>
                )}
              </div>

              {/* NOUVEAU : Bouton Templates */}
              <div className="flex justify-end mb-4">
                <Button 
                  variant="outline" 
                  onClick={() => setShowTemplates(!showTemplates)}
                  className="gap-2"
                >
                  <FileText className="w-4 h-4" />
                  {showTemplates ? t("docgen.templates.hide") : t("docgen.templates.use")}
                </Button>
              </div>

              {/* Bibliothèque de templates */}
              {showTemplates && (
                <div className="mb-8">
                  <TemplateLibrary onSelectTemplate={handleSelectTemplate} />
                </div>
              )}

              {step === 1 && <SectorAssistants onApply={handleApplySector} />}

              <Card className="relative">
                {renderStep()}
              </Card>
            </div>
          </div>
        );
      }}
    </LimitChecker>
  );
};

export default DocumentGenerator;