import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import ReactMarkdown from 'react-markdown';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, ArrowLeft, ArrowRight, Loader2 } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function ArticleView() {
  const { slug } = useParams();
  const [article, setArticle] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const results = await base44.entities.Article.filter({ slug });
      setArticle(results[0] || null);
      setLoading(false);
    };
    load();
  }, [slug]);

  useEffect(() => {
    if (!article) return;
    document.title = article.meta_title || article.title;
    const desc = document.querySelector('meta[name="description"]');
    if (desc && article.meta_description) desc.setAttribute('content', article.meta_description);
  }, [article]);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-yellow-500" />
      </div>
    );
  }

  if (!article) {
    return (
      <div className="mx-auto max-w-2xl p-8 text-center">
        <h1 className="mb-3 text-2xl font-bold text-gray-900">Article introuvable</h1>
        <p className="mb-6 text-gray-600">Cet article n'existe pas ou n'est pas encore publié.</p>
        <Button asChild>
          <Link to={createPageUrl('Blog')}>
            <ArrowLeft className="h-4 w-4" />
            Retour au blog
          </Link>
        </Button>
      </div>
    );
  }

  const faqSchema = article.faq?.length
    ? {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: article.faq.map((item) => ({
          '@type': 'Question',
          name: item.question,
          acceptedAnswer: { '@type': 'Answer', text: item.answer }
        }))
      }
    : null;

  return (
    <div className="min-h-screen p-4 md:p-8">
      {faqSchema && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026') }} />
      )}

      <article className="mx-auto max-w-3xl">
        <Button asChild variant="ghost" size="sm" className="mb-4">
          <Link to={createPageUrl('Blog')}>
            <ArrowLeft className="h-4 w-4" />
            Retour au blog
          </Link>
        </Button>

        {article.image_url && (
          <img
            src={article.image_url}
            alt={article.image_alt || article.title}
            loading="lazy"
            className="mb-6 h-64 w-full rounded-xl object-cover"
          />
        )}

        <div className="mb-4 flex flex-wrap items-center gap-3">
          {article.category && <Badge className="bg-yellow-100 text-yellow-800">{article.category}</Badge>}
          {article.published_date && (
            <span className="flex items-center gap-1 text-xs text-gray-500">
              <Calendar className="h-3 w-3" />
              {article.published_date}
            </span>
          )}
          {article.read_time && (
            <span className="flex items-center gap-1 text-xs text-gray-500">
              <Clock className="h-3 w-3" />
              {article.read_time}
            </span>
          )}
        </div>

        <h1 className="mb-6 text-3xl font-bold leading-tight text-gray-900 md:text-4xl">{article.title}</h1>

        <div className="prose prose-slate max-w-none prose-headings:font-bold prose-a:text-yellow-700">
          <ReactMarkdown>{article.content}</ReactMarkdown>
        </div>

        {article.faq?.length > 0 && (
          <div className="mt-10">
            <h2 className="mb-4 text-2xl font-bold text-gray-900">Questions fréquentes</h2>
            <div className="space-y-3">
              {article.faq.map((item, index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <p className="mb-2 font-semibold text-gray-900">{item.question}</p>
                    <p className="text-sm text-gray-700">{item.answer}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        <Card className="mt-10 bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="mb-3 text-2xl font-bold">Simplifiez vos démarches dès maintenant</h2>
            <p className="mb-6 opacity-90">
              AdminBelgique génère vos documents administratifs conformes au droit belge en quelques minutes.
            </p>
            <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-100">
              <Link to={createPageUrl('DocumentGenerator')}>
                Essayer gratuitement
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>
      </article>
    </div>
  );
}