import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  MessageCircle, 
  Server, 
  Bot, 
  Smartphone, 
  ArrowRight, 
  CheckCircle,
  Zap,
  Shield,
  Clock,
  Database
} from "lucide-react";

export default function WhatsAppFlow() {
  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8">
          <Badge className="mb-4 bg-green-100 text-green-800 border-green-300">
            <MessageCircle className="w-4 h-4 mr-2" />
            Fonctionnement du Bot WhatsApp
          </Badge>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            🤖 Comment fonctionne le Bot WhatsApp AdminBelgique ?
          </h1>
          <p className="text-xl text-gray-600">
            Découvrez le parcours d'un message depuis WhatsApp jusqu'à la réponse IA
          </p>
        </div>

        {/* Vue d'ensemble */}
        <Card className="mb-8 border-2 border-blue-300 bg-gradient-to-br from-blue-50 to-cyan-50">
          <CardHeader>
            <CardTitle className="text-blue-900">⚡ Vue d'ensemble (en 5 secondes)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-2">
                  <Smartphone className="w-8 h-8 text-green-600" />
                </div>
                <p className="text-sm font-semibold">1. Utilisateur</p>
                <p className="text-xs text-gray-600">Envoie message</p>
              </div>
              
              <ArrowRight className="w-6 h-6 text-gray-400 rotate-90 md:rotate-0" />
              
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-2">
                  <Server className="w-8 h-8 text-blue-600" />
                </div>
                <p className="text-sm font-semibold">2. Webhook</p>
                <p className="text-xs text-gray-600">Reçoit & traite</p>
              </div>
              
              <ArrowRight className="w-6 h-6 text-gray-400 rotate-90 md:rotate-0" />
              
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-2">
                  <Bot className="w-8 h-8 text-purple-600" />
                </div>
                <p className="text-sm font-semibold">3. Agent IA</p>
                <p className="text-xs text-gray-600">Génère réponse</p>
              </div>
              
              <ArrowRight className="w-6 h-6 text-gray-400 rotate-90 md:rotate-0" />
              
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-2">
                  <MessageCircle className="w-8 h-8 text-green-600" />
                </div>
                <p className="text-sm font-semibold">4. WhatsApp</p>
                <p className="text-xs text-gray-600">Envoie réponse</p>
              </div>
            </div>
            
            <div className="mt-6 text-center">
              <Badge className="bg-green-600 text-white">
                <Clock className="w-4 h-4 mr-2" />
                Temps total : 2-5 secondes ⚡
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Flux détaillé */}
        <div className="space-y-6">
          
          {/* ÉTAPE 1 */}
          <Card className="border-2 border-green-300">
            <CardHeader className="bg-green-50">
              <CardTitle className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-500 text-white rounded-full flex items-center justify-center font-bold">
                  1
                </div>
                <div>
                  <span className="text-green-900">Utilisateur envoie un message WhatsApp</span>
                  <p className="text-sm text-green-700 font-normal mt-1">
                    📱 L'utilisateur ouvre WhatsApp et envoie un message
                  </p>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <Alert className="bg-white border-green-200">
                <MessageCircle className="h-5 w-5 text-green-600" />
                <AlertTitle className="text-green-900 font-bold">
                  Exemple de message utilisateur :
                </AlertTitle>
                <AlertDescription className="text-green-800">
                  <div className="bg-green-50 rounded-lg p-4 mt-2 border border-green-200">
                    <p className="font-mono text-sm">
                      "Comment faire ma déclaration d'impôts en Belgique ?"
                    </p>
                  </div>
                  <div className="mt-3 space-y-1 text-sm">
                    <p>• <strong>Depuis</strong> : +32 474 12 34 56 (numéro utilisateur)</p>
                    <p>• <strong>Vers</strong> : +32 467 80 10 41 (bot AdminBelgique)</p>
                    <p>• <strong>Plateforme</strong> : WhatsApp Business API</p>
                  </div>
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* ÉTAPE 2 */}
          <Card className="border-2 border-blue-300">
            <CardHeader className="bg-blue-50">
              <CardTitle className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold">
                  2
                </div>
                <div>
                  <span className="text-blue-900">WhatsApp → Webhook AdminBelgique</span>
                  <p className="text-sm text-blue-700 font-normal mt-1">
                    🌐 Meta envoie le message à votre serveur
                  </p>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div className="bg-gray-900 rounded-lg p-4 text-white font-mono text-xs overflow-x-auto">
                <p className="text-green-400">// 📡 Meta envoie cette requête HTTP POST :</p>
                <p className="mt-2">POST https://adminbelgique.com/api/functions/whatsappWebhook</p>
                <p className="mt-2 text-gray-400">{'{'}</p>
                <p className="ml-4">"entry": [{'{'}</p>
                <p className="ml-8">"changes": [{'{'}</p>
                <p className="ml-12">"value": {'{'}</p>
                <p className="ml-16">"messages": [{'{'}</p>
                <p className="ml-20">"from": "32474123456",</p>
                <p className="ml-20">"text": {'{'} "body": "Comment faire ma déclaration..." {'}'},</p>
                <p className="ml-20">"timestamp": "1704124800"</p>
                <p className="ml-16">{'}'}]</p>
                <p className="ml-12">{'}'}</p>
                <p className="ml-8">{'}'}]</p>
                <p className="ml-4">{'}'}]</p>
                <p className="text-gray-400">{'}'}</p>
              </div>

              <Alert className="bg-white border-blue-200">
                <Server className="h-5 w-5 text-blue-600" />
                <AlertTitle className="text-blue-900 font-bold">
                  Que fait le webhook ?
                </AlertTitle>
                <AlertDescription className="text-blue-800 space-y-2 mt-2">
                  <div className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Vérifie l'authenticité du message (signature Meta)</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Extrait le numéro de téléphone de l'utilisateur</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Extrait le contenu du message</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Prépare l'envoi à l'agent IA</span>
                  </div>
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* ÉTAPE 3 */}
          <Card className="border-2 border-purple-300">
            <CardHeader className="bg-purple-50">
              <CardTitle className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-500 text-white rounded-full flex items-center justify-center font-bold">
                  3
                </div>
                <div>
                  <span className="text-purple-900">Agent IA "admin_belge" traite la question</span>
                  <p className="text-sm text-purple-700 font-normal mt-1">
                    🤖 Le MÊME agent que le Chat Web AdminBelgique
                  </p>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <Alert className="bg-purple-50 border-purple-200">
                <Bot className="h-5 w-5 text-purple-600" />
                <AlertTitle className="text-purple-900 font-bold">
                  🔥 IMPORTANT : C'est le MÊME agent que votre Chat !
                </AlertTitle>
                <AlertDescription className="text-purple-800">
                  <p className="mb-3">
                    Le webhook utilise <code className="bg-white px-2 py-1 rounded font-mono text-sm">admin_belge</code>, 
                    le même agent configuré dans <code className="bg-white px-2 py-1 rounded font-mono text-sm">agents/admin_belge.json</code>
                  </p>
                  <div className="bg-white rounded p-3 border border-purple-300">
                    <p className="text-sm font-semibold mb-2">✨ Capacités de l'agent :</p>
                    <ul className="space-y-1 text-sm">
                      <li>• Expert administration belge (SPF, INAMI, ONEM)</li>
                      <li>• Recherche web en temps réel</li>
                      <li>• Accès aux entités (Documents, Analyses)</li>
                      <li>• Multilangue (FR/NL/DE)</li>
                      <li>• Mémoire conversationnelle</li>
                    </ul>
                  </div>
                </AlertDescription>
              </Alert>

              <div className="bg-gray-900 rounded-lg p-4 text-white font-mono text-xs overflow-x-auto">
                <p className="text-green-400">// 🤖 Code du webhook (simplifié) :</p>
                <p className="mt-2 text-blue-400">const</p> AGENT_NAME = <span className="text-yellow-300">"admin_belge"</span>;
                
                <p className="mt-3 text-gray-400">// Créer/récupérer conversation</p>
                <p><span className="text-blue-400">const</span> conversation = <span className="text-blue-400">await</span> base44.asServiceRole.agents</p>
                <p className="ml-4">.createConversation({'{'} agent_name: AGENT_NAME {'}'})</p>
                
                <p className="mt-3 text-gray-400">// Ajouter message utilisateur</p>
                <p><span className="text-blue-400">await</span> base44.asServiceRole.agents.addMessage(</p>
                <p className="ml-4">conversation, {'{'} role: <span className="text-yellow-300">"user"</span>, content: messageText {'}'}</p>
                <p>)</p>
                
                <p className="mt-3 text-gray-400">// L'IA génère AUTOMATIQUEMENT la réponse !</p>
                <p className="text-green-400">// ✨ Magie de base44 : pas besoin d'appeler InvokeLLM</p>
              </div>

              <Alert className="bg-white border-yellow-200">
                <Zap className="h-5 w-5 text-yellow-600" />
                <AlertTitle className="text-yellow-900 font-bold">
                  ⚡ Génération automatique de la réponse
                </AlertTitle>
                <AlertDescription className="text-yellow-800">
                  <p className="mb-2">
                    Quand vous ajoutez un message utilisateur avec <code className="bg-gray-100 px-2 py-1 rounded">addMessage()</code>, 
                    l'agent IA génère <strong>automatiquement</strong> une réponse intelligente.
                  </p>
                  <p className="text-sm">
                    Pas besoin d'appeler manuellement l'IA - base44 s'en charge ! 🎉
                  </p>
                </AlertDescription>
              </Alert>

              <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4">
                <h4 className="font-bold text-blue-900 mb-3">🧠 Exemple de réponse générée :</h4>
                <div className="bg-white rounded p-3 border border-blue-300 text-sm">
                  <p className="font-semibold text-gray-900 mb-2">
                    Question : "Comment faire ma déclaration d'impôts ?"
                  </p>
                  <p className="text-gray-700 mb-2">
                    Réponse IA (extrait) :
                  </p>
                  <div className="bg-gray-50 p-3 rounded border">
                    <p className="text-xs text-gray-800">
                      "Pour faire votre déclaration d'impôts en Belgique, voici les étapes :<br/><br/>
                      
                      1️⃣ <strong>Via MyMinfin (en ligne)</strong> :<br/>
                      • Rendez-vous sur myminfin.belgium.be<br/>
                      • Connectez-vous avec votre eID ou itsme<br/>
                      • Accédez à "Ma déclaration"<br/><br/>
                      
                      2️⃣ <strong>Délais</strong> :<br/>
                      • Déclaration papier : 30 juin<br/>
                      • Déclaration en ligne : 15 juillet<br/><br/>
                      
                      3️⃣ <strong>Documents à préparer</strong> :<br/>
                      • Fiches de paie (281.10)<br/>
                      • Preuves de frais déductibles<br/>
                      • Attestations diverses<br/><br/>
                      
                      Besoin d'aide spécifique ? Dites-moi ! 🇧🇪"
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* ÉTAPE 4 */}
          <Card className="border-2 border-green-300">
            <CardHeader className="bg-green-50">
              <CardTitle className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-500 text-white rounded-full flex items-center justify-center font-bold">
                  4
                </div>
                <div>
                  <span className="text-green-900">Envoi de la réponse sur WhatsApp</span>
                  <p className="text-sm text-green-700 font-normal mt-1">
                    📤 Le webhook renvoie la réponse à l'utilisateur
                  </p>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div className="bg-gray-900 rounded-lg p-4 text-white font-mono text-xs overflow-x-auto">
                <p className="text-green-400">// 📤 Envoi via WhatsApp Business API :</p>
                <p className="mt-2">POST https://graph.facebook.com/v18.0/{'{'}phoneNumberId{'}'}/messages</p>
                <p className="mt-2 text-gray-400">{'{'}</p>
                <p className="ml-4">"messaging_product": <span className="text-yellow-300">"whatsapp"</span>,</p>
                <p className="ml-4">"to": <span className="text-yellow-300">"32474123456"</span>,</p>
                <p className="ml-4">"type": <span className="text-yellow-300">"text"</span>,</p>
                <p className="ml-4">"text": {'{'}</p>
                <p className="ml-8">"body": <span className="text-yellow-300">"Pour faire votre déclaration..."</span></p>
                <p className="ml-4">{'}'}</p>
                <p className="text-gray-400">{'}'}</p>
              </div>

              <Alert className="bg-white border-green-200">
                <MessageCircle className="h-5 w-5 text-green-600" />
                <AlertTitle className="text-green-900 font-bold">
                  ✅ L'utilisateur reçoit la réponse sur WhatsApp !
                </AlertTitle>
                <AlertDescription className="text-green-800">
                  <p className="mb-3">
                    La réponse apparaît instantanément dans la conversation WhatsApp de l'utilisateur.
                  </p>
                  <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                    <p className="text-sm font-semibold mb-2">📱 L'utilisateur voit :</p>
                    <div className="bg-white rounded p-3 space-y-2">
                      <div className="flex items-start gap-2">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <Bot className="w-4 h-4 text-blue-600" />
                        </div>
                        <div className="bg-gray-100 rounded-lg p-3 max-w-[80%]">
                          <p className="text-xs text-gray-800">
                            Pour faire votre déclaration d'impôts en Belgique, voici les étapes...
                          </p>
                          <p className="text-[10px] text-gray-500 mt-1">Envoyé à 14:32</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          {/* Stockage */}
          <Card className="border-2 border-indigo-300">
            <CardHeader className="bg-indigo-50">
              <CardTitle className="flex items-center gap-3">
                <Database className="w-8 h-8 text-indigo-600" />
                <span className="text-indigo-900">Stockage & Historique</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <Alert className="bg-white border-indigo-200">
                <Shield className="h-5 w-5 text-indigo-600" />
                <AlertTitle className="text-indigo-900 font-bold">
                  💾 Toutes les conversations sont sauvegardées
                </AlertTitle>
                <AlertDescription className="text-indigo-800">
                  <div className="space-y-3 mt-3">
                    <div className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-semibold">Chaque conversation WhatsApp est stockée dans base44</p>
                        <p className="text-xs text-gray-600">Permet à l'IA de se souvenir du contexte</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-semibold">Métadonnées incluses</p>
                        <p className="text-xs text-gray-600">Numéro WhatsApp, nom utilisateur, timestamp</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-semibold">Accessible via Dashboard</p>
                        <p className="text-xs text-gray-600">Vous pouvez consulter l'historique des conversations</p>
                      </div>
                    </div>
                  </div>
                </AlertDescription>
              </Alert>

              <div className="bg-indigo-50 rounded-lg p-4 border-2 border-indigo-200">
                <h4 className="font-bold text-indigo-900 mb-3">🔍 Structure d'une conversation :</h4>
                <div className="bg-white rounded p-3 border border-indigo-300 font-mono text-xs">
                  <p className="text-gray-500">// Base de données base44</p>
                  <p className="mt-2">{'{'}</p>
                  <p className="ml-4">"id": "conv_123456",</p>
                  <p className="ml-4">"agent_name": "admin_belge",</p>
                  <p className="ml-4">"metadata": {'{'}</p>
                  <p className="ml-8">"whatsapp_number": "32474123456",</p>
                  <p className="ml-8">"platform": "whatsapp",</p>
                  <p className="ml-8">"user_name": "Jean Dupont"</p>
                  <p className="ml-4">{'}'},</p>
                  <p className="ml-4">"messages": [</p>
                  <p className="ml-8">{'{'} "role": "user", "content": "Comment..." {'}'},</p>
                  <p className="ml-8">{'{'} "role": "assistant", "content": "Pour faire..." {'}'}</p>
                  <p className="ml-4">]</p>
                  <p>{'}'}</p>
                </div>
              </div>
            </CardContent>
          </Card>

        </div>

        {/* Récapitulatif */}
        <Card className="mt-8 border-2 border-yellow-300 bg-gradient-to-br from-yellow-50 to-orange-50">
          <CardHeader className="bg-yellow-100">
            <CardTitle className="text-yellow-900">🎯 Récapitulatif</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold text-gray-900 mb-3">✅ Avantages</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span>Réponses instantanées (2-5 secondes)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span>Même qualité que le Chat Web</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span>Disponible 24/7</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span>Chiffrement E2E WhatsApp</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span>Mémoire conversationnelle</span>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-bold text-gray-900 mb-3">🔧 Configuration requise</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Shield className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                    <span>Compte Meta Business vérifié</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Shield className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                    <span>WhatsApp Business API activée</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Shield className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                    <span>Webhook configuré et vérifié</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Shield className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                    <span>Variables d'environnement définies</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Shield className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                    <span>Agent IA "admin_belge" actif</span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}