
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, ExternalLink, Trash2, AlertCircle } from "lucide-react";

export default function SearchConsoleGuide() {
  // Ajouter meta noindex et gérer le titre
  React.useEffect(() => {
    // Set document title
    const originalTitle = document.title;
    document.title = '🚫 Bloquer pages techniques/admin - NOINDEX + robots.txt';

    // Add meta robots tag
    const metaRobots = document.createElement('meta');
    metaRobots.name = 'robots';
    metaRobots.content = 'noindex, nofollow';
    document.head.appendChild(metaRobots);

    return () => {
      // Clean up: remove meta tag and restore original title
      document.head.removeChild(metaRobots);
      document.title = originalTitle; // Restore original title on unmount
    };
  }, []); // Empty dependency array means this runs once on mount and cleans up on unmount

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8">
          <Badge className="mb-4 bg-green-100 text-green-800 border-green-300">
            <CheckCircle className="w-4 h-4 mr-2" />
            Propriété Déjà Ajoutée ✅
          </Badge>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            🧹 Nettoyage Google Search Console
          </h1>
          <p className="text-xl text-gray-600">
            Étapes pour supprimer les anciennes versions de votre site
          </p>
        </div>

        {/* Ce qui est fait */}
        <Alert className="mb-8 bg-green-50 border-green-200">
          <CheckCircle className="h-5 w-5 text-green-600" />
          <AlertTitle className="text-green-800 font-bold">✅ Déjà Fait</AlertTitle>
          <AlertDescription className="text-green-700">
            <ul className="list-disc list-inside space-y-1 mt-2">
              <li>Propriété <code>https://www.adminbelgique.com</code> ajoutée à Search Console</li>
              <li>Redirections Cloudflare actives</li>
              <li>Meta tags canonical configurés</li>
            </ul>
          </AlertDescription>
        </Alert>

        {/* Étape 1 : Soumettre le Sitemap */}
        <Card className="mb-6 border-2 border-blue-300">
          <CardHeader className="bg-blue-50">
            <CardTitle className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold">
                1
              </div>
              <span className="text-blue-900">Soumettre votre Sitemap</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <Alert className="bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                Le sitemap aide Google à comprendre la structure de votre site
              </AlertDescription>
            </Alert>

            <div className="space-y-3">
              <h4 className="font-bold text-gray-900">📝 Marche à suivre :</h4>
              <ol className="space-y-3">
                <li className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-sm font-bold text-blue-700">
                    1
                  </span>
                  <div>
                    <p className="font-semibold text-gray-900">Allez dans Search Console</p>
                    <p className="text-sm text-gray-600">Sélectionnez la propriété <code>https://www.adminbelgique.com</code></p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-sm font-bold text-blue-700">
                    2
                  </span>
                  <div>
                    <p className="font-semibold text-gray-900">Menu : "Sitemaps" (à gauche)</p>
                    <p className="text-sm text-gray-600">Cliquez sur "Sitemaps" dans le menu de gauche</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-sm font-bold text-blue-700">
                    3
                  </span>
                  <div>
                    <p className="font-semibold text-gray-900">Ajouter le sitemap</p>
                    <p className="text-sm text-gray-600 mb-2">Dans "Ajouter un sitemap", entrez :</p>
                    <code className="bg-gray-900 text-green-400 px-3 py-1 rounded text-sm block">
                      sitemap.xml
                    </code>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-sm font-bold text-blue-700">
                    4
                  </span>
                  <div>
                    <p className="font-semibold text-gray-900">Valider</p>
                    <p className="text-sm text-gray-600">Cliquez sur "Envoyer"</p>
                  </div>
                </li>
              </ol>
            </div>

            <Button asChild className="w-full">
              <a href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer">
                Ouvrir Search Console
                <ExternalLink className="w-4 h-4 ml-2" />
              </a>
            </Button>
          </CardContent>
        </Card>

        {/* Étape 2 : Supprimer les anciennes URLs */}
        <Card className="mb-6 border-2 border-red-300">
          <CardHeader className="bg-red-50">
            <CardTitle className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-500 text-white rounded-full flex items-center justify-center font-bold">
                2
              </div>
              <span className="text-red-900">Supprimer les Anciennes URLs</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <Alert className="bg-yellow-50 border-yellow-200">
              <Trash2 className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800">
                <strong>Important :</strong> Supprimez les versions non-www pour éviter le contenu dupliqué
              </AlertDescription>
            </Alert>

            <div className="space-y-3">
              <h4 className="font-bold text-gray-900">🗑️ URLs à supprimer :</h4>
              <div className="bg-gray-100 p-4 rounded-lg space-y-2">
                <div className="flex items-center justify-between">
                  <code className="text-sm">http://adminbelgique.com</code>
                  <Badge variant="destructive">À supprimer</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <code className="text-sm">https://adminbelgique.com</code>
                  <Badge variant="destructive">À supprimer</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <code className="text-sm">http://www.adminbelgique.com</code>
                  <Badge variant="destructive">À supprimer</Badge>
                </div>
              </div>
            </div>

            <div className="space-y-3 mt-6">
              <h4 className="font-bold text-gray-900">📝 Marche à suivre :</h4>
              <ol className="space-y-3">
                <li className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-red-100 rounded-full flex items-center justify-center text-sm font-bold text-red-700">
                    1
                  </span>
                  <div>
                    <p className="font-semibold text-gray-900">Menu : "Suppressions"</p>
                    <p className="text-sm text-gray-600">Dans Search Console, cliquez sur "Suppressions" dans le menu de gauche</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-red-100 rounded-full flex items-center justify-center text-sm font-bold text-red-700">
                    2
                  </span>
                  <div>
                    <p className="font-semibold text-gray-900">Nouvelle demande</p>
                    <p className="text-sm text-gray-600">Cliquez sur "Nouvelle demande"</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-red-100 rounded-full flex items-center justify-center text-sm font-bold text-red-700">
                    3
                  </span>
                  <div>
                    <p className="font-semibold text-gray-900">Entrer les URLs à supprimer</p>
                    <p className="text-sm text-gray-600 mb-2">Pour chaque URL ci-dessus :</p>
                    <ul className="text-sm text-gray-600 list-disc list-inside ml-4">
                      <li>Collez l'URL complète</li>
                      <li>Choisissez "Supprimer temporairement l'URL"</li>
                      <li>Cliquez sur "Suivant" puis "Envoyer"</li>
                    </ul>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-red-100 rounded-full flex items-center justify-center text-sm font-bold text-red-700">
                    4
                  </span>
                  <div>
                    <p className="font-semibold text-gray-900">Répétez pour chaque URL</p>
                    <p className="text-sm text-gray-600">Faites une demande séparée pour chacune des 3 URLs</p>
                  </div>
                </li>
              </ol>
            </div>

            <Alert className="bg-blue-50 border-blue-200 mt-4">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                <strong>⏱️ Délai :</strong> Google prend 24-48h pour traiter ces demandes de suppression
              </AlertDescription>
            </Alert>

            <Button asChild className="w-full" variant="destructive">
              <a href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer">
                <Trash2 className="w-4 h-4 mr-2" />
                Aller aux Suppressions
                <ExternalLink className="w-4 h-4 ml-2" />
              </a>
            </Button>
          </CardContent>
        </Card>

        {/* Étape 3 : Vérification */}
        <Card className="border-2 border-green-300">
          <CardHeader className="bg-green-50">
            <CardTitle className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-500 text-white rounded-full flex items-center justify-center font-bold">
                3
              </div>
              <span className="text-green-900">Vérifier que ça fonctionne</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="space-y-3">
              <h4 className="font-bold text-gray-900">✅ Tests à effectuer (après 48h) :</h4>
              <ol className="space-y-3">
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900">Test Google</p>
                    <p className="text-sm text-gray-600">Tapez <code>site:adminbelgique.com</code> dans Google - ne devrait montrer que les versions www</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900">Test Redirect</p>
                    <p className="text-sm text-gray-600">Visitez <code>http://adminbelgique.com</code> - doit rediriger vers <code>https://www.adminbelgique.com</code></p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900">Vérifier Search Console</p>
                    <p className="text-sm text-gray-600">Surveillez les rapports de couverture - aucune erreur de duplicate content</p>
                  </div>
                </li>
              </ol>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-6">
              <Button asChild variant="outline">
                <a href="https://www.google.com/search?q=site:adminbelgique.com" target="_blank" rel="noopener noreferrer">
                  Test site: Google
                  <ExternalLink className="w-4 h-4 ml-2" />
                </a>
              </Button>
              <Button asChild variant="outline">
                <a href="https://httpstatus.io/" target="_blank" rel="noopener noreferrer">
                  Test Redirections
                  <ExternalLink className="w-4 h-4 ml-2" />
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Timeline */}
        <Alert className="mt-8 bg-purple-50 border-purple-200">
          <AlertCircle className="h-5 w-5 text-purple-600" />
          <AlertTitle className="text-purple-900 font-bold">⏱️ Timeline Complète</AlertTitle>
          <AlertDescription className="text-purple-800">
            <ul className="list-disc list-inside space-y-1 mt-2">
              <li><strong>Maintenant :</strong> Soumettre sitemap + demander suppressions</li>
              <li><strong>24h :</strong> Cloudflare propage les redirections</li>
              <li><strong>48h :</strong> Google traite les demandes de suppression</li>
              <li><strong>1 semaine :</strong> Ré-indexation complète avec www</li>
              <li><strong>2-4 semaines :</strong> SEO stabilisé, amélioration visible</li>
            </ul>
          </AlertDescription>
        </Alert>

        {/* CTA */}
        <div className="mt-8 text-center p-6 bg-gradient-to-r from-blue-100 to-purple-100 rounded-lg border-2 border-blue-300">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            🚀 Action Immédiate
          </h3>
          <p className="text-lg text-gray-700 mb-4">
            Faites ces 2 actions maintenant dans Search Console
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Badge className="bg-blue-500 text-white py-2 px-4 text-base">
              1️⃣ Soumettre sitemap.xml
            </Badge>
            <Badge className="bg-red-500 text-white py-2 px-4 text-base">
              2️⃣ Supprimer 3 anciennes URLs
            </Badge>
          </div>
        </div>
      </div>
    </div>
  );
}
