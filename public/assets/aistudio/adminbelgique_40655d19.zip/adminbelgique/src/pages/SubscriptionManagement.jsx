import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Label } from "@/components/ui/label";
import { 
  Crown, 
  Users, 
  DollarSign, 
  TrendingUp, 
  Search, 
  Calendar,
  Mail,
  Loader2,
  XCircle,
  Shield,
  Edit,
  CheckCircle
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function SubscriptionManagement() {
  const [usageLimits, setUsageLimits] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterPlan, setFilterPlan] = useState("all");
  const [currentUser, setCurrentUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [newPlan, setNewPlan] = useState("");
  const [newEndDate, setNewEndDate] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  // Ajouter meta noindex
  React.useEffect(() => {
    const metaRobots = document.createElement('meta');
    metaRobots.name = 'robots';
    metaRobots.content = 'noindex, nofollow';
    document.head.appendChild(metaRobots);

    return () => {
      document.head.removeChild(metaRobots);
    };
  }, []);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const user = await base44.auth.me();
      setCurrentUser(user);
      
      const isUserAdmin = user?.role === 'admin';
      setIsAdmin(isUserAdmin);

      if (isUserAdmin) {
        const limits = await base44.entities.UsageLimit.list('-created_date');
        setUsageLimits(Array.isArray(limits) ? limits : []);
      }
    } catch (error) {
      console.error("Erreur chargement:", error);
      setIsAdmin(false);
    } finally {
      setIsLoading(false);
    }
  };

  const openEditDialog = (limit) => {
    setEditingUser(limit);
    setNewPlan(limit.plan);
    setNewEndDate(limit.subscription_end ? new Date(limit.subscription_end).toISOString().split('T')[0] : '');
    setShowEditDialog(true);
  };

  const handleSaveSubscription = async () => {
    if (!editingUser || !newPlan) return;
    
    setIsSaving(true);
    try {
      const updateData = {
        plan: newPlan,
        subscription_start: editingUser.subscription_start || new Date().toISOString(),
      };

      // Si un plan payant, définir une date de fin (12 mois par défaut)
      if (newPlan !== 'free') {
        if (newEndDate) {
          updateData.subscription_end = new Date(newEndDate).toISOString();
        } else {
          // Par défaut : 1 an
          const endDate = new Date();
          endDate.setFullYear(endDate.getFullYear() + 1);
          updateData.subscription_end = endDate.toISOString();
        }
      } else {
        updateData.subscription_end = null;
      }

      await base44.entities.UsageLimit.update(editingUser.id, updateData);
      
      setShowEditDialog(false);
      setEditingUser(null);
      await loadData(); // Recharger les données
      
      alert(`✅ Abonnement mis à jour pour ${editingUser.user_email}`);
    } catch (error) {
      console.error("Erreur mise à jour:", error);
      alert("❌ Erreur lors de la mise à jour de l'abonnement");
    } finally {
      setIsSaving(false);
    }
  };

  const planColors = {
    free: "bg-gray-100 text-gray-800 border-gray-300",
    pro: "bg-yellow-100 text-yellow-800 border-yellow-300",
    cabinet: "bg-blue-100 text-blue-800 border-blue-300",
    enterprise: "bg-purple-100 text-purple-800 border-purple-300"
  };

  const planIcons = {
    free: Users,
    pro: Crown,
    cabinet: Users,
    enterprise: TrendingUp
  };

  const planLabels = {
    free: "Gratuit",
    pro: "Pro",
    cabinet: "Cabinet",
    enterprise: "Enterprise"
  };

  const filteredUsers = usageLimits.filter(limit => {
    const matchesSearch = limit.user_email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPlan = filterPlan === "all" || limit.plan === filterPlan;
    return matchesSearch && matchesPlan;
  });

  const stats = {
    total: usageLimits.length,
    free: usageLimits.filter(u => u.plan === 'free').length,
    pro: usageLimits.filter(u => u.plan === 'pro').length,
    cabinet: usageLimits.filter(u => u.plan === 'cabinet').length,
    enterprise: usageLimits.filter(u => u.plan === 'enterprise').length,
    revenue: (
      usageLimits.filter(u => u.plan === 'pro').length * 29 +
      usageLimits.filter(u => u.plan === 'cabinet').length * 99
    )
  };

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-yellow-500" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="p-4 md:p-8">
        <div className="max-w-2xl mx-auto mt-12">
          <Alert variant="destructive" className="bg-red-50 border-red-200">
            <Shield className="h-5 w-5 text-red-600" />
            <AlertTitle className="text-red-800 font-bold text-lg">Accès Refusé</AlertTitle>
            <AlertDescription className="text-red-700">
              <p className="mb-2">Vous n'avez pas les permissions nécessaires pour accéder à cette page.</p>
              <p className="text-sm">Seuls les <strong>administrateurs</strong> peuvent gérer les abonnements.</p>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-purple-100 rounded-full px-4 py-2 mb-4">
            <Crown className="w-5 h-5 text-purple-600" />
            <span className="text-purple-800 font-medium">Gestion Abonnements</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Gestion des Abonnements</h1>
          <p className="text-gray-600">Gérez manuellement les plans de vos utilisateurs</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Utilisateurs</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
                </div>
                <Users className="w-10 h-10 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Abonnés Pro</p>
                  <p className="text-3xl font-bold text-yellow-600">{stats.pro}</p>
                </div>
                <Crown className="w-10 h-10 text-yellow-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Cabinets</p>
                  <p className="text-3xl font-bold text-blue-600">{stats.cabinet}</p>
                </div>
                <Users className="w-10 h-10 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Revenu Mensuel</p>
                  <p className="text-3xl font-bold text-green-600">{stats.revenue}€</p>
                </div>
                <DollarSign className="w-10 h-10 text-green-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Rechercher par email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterPlan} onValueChange={setFilterPlan}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Filtrer par plan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous les plans</SelectItem>
                  <SelectItem value="free">Gratuit</SelectItem>
                  <SelectItem value="pro">Pro</SelectItem>
                  <SelectItem value="cabinet">Cabinet</SelectItem>
                  <SelectItem value="enterprise">Enterprise</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Users List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Liste des Utilisateurs ({filteredUsers.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredUsers.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <Users className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p>Aucun utilisateur trouvé</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredUsers.map((limit) => {
                  const PlanIcon = planIcons[limit.plan];
                  const isExpired = limit.subscription_end && new Date(limit.subscription_end) < new Date();
                  
                  return (
                    <div key={limit.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center gap-4 flex-1">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full flex items-center justify-center">
                          <PlanIcon className="w-6 h-6 text-gray-700" />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <Mail className="w-4 h-4 text-gray-400" />
                            <span className="font-medium text-gray-900">{limit.user_email}</span>
                          </div>
                          
                          <div className="flex items-center gap-3 text-sm text-gray-600">
                            <Badge className={planColors[limit.plan]}>
                              {planLabels[limit.plan]}
                            </Badge>
                            
                            {limit.subscription_start && (
                              <div className="flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                <span>Depuis: {new Date(limit.subscription_start).toLocaleDateString('fr-BE')}</span>
                              </div>
                            )}
                            
                            {isExpired && (
                              <Badge className="bg-red-100 text-red-800">
                                <XCircle className="w-3 h-3 mr-1" />
                                Expiré
                              </Badge>
                            )}
                            
                            {limit.subscription_end && !isExpired && (
                              <div className="flex items-center gap-1 text-xs">
                                <CheckCircle className="w-3 h-3 text-green-600" />
                                <span>Jusqu'au {new Date(limit.subscription_end).toLocaleDateString('fr-BE')}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="text-right text-sm">
                          {limit.plan !== 'free' && (
                            <p className="font-semibold text-gray-900">
                              {limit.plan === 'pro' ? '29€/mois' : limit.plan === 'cabinet' ? '99€/mois' : 'Sur devis'}
                            </p>
                          )}
                          <div className="flex gap-2 text-xs text-gray-500 mt-1">
                            <span>{limit.research_count || 0} Q</span>
                            <span>{limit.document_count || 0} D</span>
                            <span>{limit.analysis_count || 0} A</span>
                          </div>
                        </div>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openEditDialog(limit)}
                        >
                          <Edit className="w-4 h-4 mr-2" />
                          Modifier
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Dialog Edit Subscription */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Modifier l'abonnement</DialogTitle>
            <DialogDescription>
              Utilisateur: <strong>{editingUser?.user_email}</strong>
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="plan">Plan</Label>
              <Select value={newPlan} onValueChange={setNewPlan}>
                <SelectTrigger id="plan">
                  <SelectValue placeholder="Choisir un plan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="free">Gratuit</SelectItem>
                  <SelectItem value="pro">Pro (29€/mois)</SelectItem>
                  <SelectItem value="cabinet">Cabinet (99€/mois)</SelectItem>
                  <SelectItem value="enterprise">Enterprise (Sur devis)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {newPlan !== 'free' && (
              <div>
                <Label htmlFor="endDate">Date de fin (optionnel)</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={newEndDate}
                  onChange={(e) => setNewEndDate(e.target.value)}
                  placeholder="Laisser vide = 1 an"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Si vide, l'abonnement sera valable 1 an à partir d'aujourd'hui
                </p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowEditDialog(false)}
              disabled={isSaving}
            >
              Annuler
            </Button>
            <Button
              onClick={handleSaveSubscription}
              disabled={isSaving || !newPlan}
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Enregistrement...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Enregistrer
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}