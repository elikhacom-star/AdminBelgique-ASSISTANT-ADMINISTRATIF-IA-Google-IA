import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Plus, Receipt, CalendarClock, Info, Repeat } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import RecurringInvoiceForm from "@/components/invoices/RecurringInvoiceForm";
import RecurringInvoiceCard from "@/components/invoices/RecurringInvoiceCard";
import GeneratedInvoicesList from "@/components/invoices/GeneratedInvoicesList";
import { downloadDocumentPdf } from "@/lib/pdfExport";
import { todayBrussels, formatDateFr } from "@/lib/recurringInvoices";

export default function RecurringInvoices() {
  const { toast } = useToast();
  const [plans, setPlans] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [activePlansCount, setActivePlansCount] = useState(0);
  const [monthCount, setMonthCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [generatingId, setGeneratingId] = useState(null);
  const [senderDefaults, setSenderDefaults] = useState({ sender_name: "", sender_details: "" });

  const loadData = async () => {
    setIsLoading(true);
    try {
      const monthStart = `${todayBrussels().slice(0, 7)}-01`;
      const [planPage, invoicePage, activeCount, generatedThisMonth] = await Promise.all([
        base44.entities.RecurringInvoice.filter({}, { sort: "next_issue_date", limit: 100 }),
        base44.entities.Invoice.filter({}, { sort: "-issue_date", limit: 50 }),
        base44.entities.RecurringInvoice.count({ active: true }),
        base44.entities.Invoice.count({ issue_date: { $gte: monthStart } }),
      ]);

      const loadedPlans = planPage.items || [];
      setPlans(loadedPlans);
      setInvoices(invoicePage.items || []);
      setActivePlansCount(activeCount || 0);
      setMonthCount(generatedThisMonth || 0);

      const reference = loadedPlans[0];
      setSenderDefaults({
        sender_name: reference?.sender_name || "",
        sender_details: reference?.sender_details || "",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const openCreate = () => {
    setEditingPlan(null);
    setShowForm(true);
  };

  const openEdit = (plan) => {
    setEditingPlan(plan);
    setShowForm(true);
  };

  const handleSave = async (values) => {
    setIsSaving(true);
    try {
      if (editingPlan) {
        await base44.entities.RecurringInvoice.update(editingPlan.id, values);
      } else {
        const me = await base44.auth.me();
        await base44.entities.RecurringInvoice.create({ ...values, owner_email: me?.email || "" });
      }
      setShowForm(false);
      setEditingPlan(null);
      toast({
        title: editingPlan ? "Échéancier mis à jour" : "Échéancier créé",
        description: "La facture sera émise automatiquement à chaque échéance.",
      });
      await loadData();
    } finally {
      setIsSaving(false);
    }
  };

  const handleToggleActive = async (plan) => {
    await base44.entities.RecurringInvoice.update(plan.id, { active: !plan.active });
    toast({
      title: plan.active ? "Échéancier en pause" : "Échéancier réactivé",
      description: plan.active
        ? `Aucune nouvelle facture ne sera émise pour ${plan.client_name}.`
        : `La facturation reprendra à la prochaine échéance.`,
    });
    await loadData();
  };

  const handleDeletePlan = async (plan) => {
    const confirmed = window.confirm(
      `Supprimer l'échéancier de ${plan.client_name} ? Les factures déjà émises sont conservées.`
    );
    if (!confirmed) return;
    await base44.entities.RecurringInvoice.delete(plan.id);
    toast({ title: "Échéancier supprimé" });
    await loadData();
  };

  const handleGenerateNow = async (plan) => {
    setGeneratingId(plan.id);
    try {
      const response = await base44.functions.invoke("generateRecurringInvoices", { planId: plan.id });
      const data = response?.data || {};
      if (data.error) {
        toast({ title: "Émission impossible", description: data.error, variant: "destructive" });
        return;
      }
      toast({
        title: "Facture émise",
        description: `Facture ${(data.invoices || [])[0] || ""} créée dans l'onglet « Factures émises ».`,
      });
      await loadData();
    } finally {
      setGeneratingId(null);
    }
  };

  const handleDownloadPdf = (invoice) => {
    downloadDocumentPdf({ title: `Facture ${invoice.invoice_number}`, content: invoice.content });
  };

  const handleMarkPaid = async (invoice) => {
    await base44.entities.Invoice.update(invoice.id, { status: "payee" });
    toast({ title: "Facture marquée comme payée" });
    await loadData();
  };

  const handleDeleteInvoice = async (invoice) => {
    const confirmed = window.confirm(`Supprimer la facture ${invoice.invoice_number} ?`);
    if (!confirmed) return;
    await base44.entities.Invoice.delete(invoice.id);
    toast({ title: "Facture supprimée" });
    await loadData();
  };

  const nextIssue = plans.find((plan) => plan.active)?.next_issue_date;

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 flex items-center gap-2">
              <Receipt className="w-7 h-7 text-yellow-600" />
              Factures récurrentes
            </h1>
            <p className="text-gray-600">Facturez automatiquement vos clients réguliers, à la bonne date.</p>
          </div>
          <Button onClick={openCreate} className="gap-2 bg-yellow-500 hover:bg-yellow-600 text-black">
            <Plus className="w-4 h-4" />
            Nouvelle facture récurrente
          </Button>
        </div>

        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="p-4 flex items-start gap-3">
            <Info className="w-5 h-5 text-yellow-700 mt-0.5 shrink-0" />
            <p className="text-sm text-yellow-900">
              Une vérification automatique a lieu chaque matin à 7h (heure belge) : chaque échéance arrivée à
              terme produit sa facture, puis passe à la période suivante. Vous pouvez aussi émettre une facture
              immédiatement ou mettre un échéancier en pause.
            </p>
          </CardContent>
        </Card>

        <div className="grid gap-4 sm:grid-cols-3">
          <Card>
            <CardContent className="p-5">
              <p className="text-sm text-gray-500">Échéanciers actifs</p>
              <p className="text-2xl font-bold text-gray-900">{activePlansCount}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5">
              <p className="text-sm text-gray-500">Factures émises ce mois-ci</p>
              <p className="text-2xl font-bold text-gray-900">{monthCount}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5">
              <p className="text-sm text-gray-500">Prochaine échéance</p>
              <p className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <CalendarClock className="w-5 h-5 text-gray-400" />
                {nextIssue ? formatDateFr(nextIssue) : "—"}
              </p>
            </CardContent>
          </Card>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
          </div>
        ) : (
          <Tabs defaultValue="plans">
            <TabsList>
              <TabsTrigger value="plans">Échéanciers ({plans.length})</TabsTrigger>
              <TabsTrigger value="invoices">Factures émises ({invoices.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="plans" className="mt-4 space-y-3">
              {plans.length === 0 ? (
                <Card>
                  <CardContent className="p-10 text-center text-gray-500">
                    <Repeat className="w-10 h-10 mx-auto mb-3 text-gray-300" />
                    Aucun échéancier pour l'instant. Créez-en un pour votre premier client régulier.
                  </CardContent>
                </Card>
              ) : (
                plans.map((plan) => (
                  <RecurringInvoiceCard
                    key={plan.id}
                    plan={plan}
                    onEdit={openEdit}
                    onToggleActive={handleToggleActive}
                    onDelete={handleDeletePlan}
                    onGenerateNow={handleGenerateNow}
                    isGenerating={generatingId === plan.id}
                  />
                ))
              )}
            </TabsContent>

            <TabsContent value="invoices" className="mt-4">
              {invoices.length === 0 ? (
                <Card>
                  <CardContent className="p-10 text-center text-gray-500">
                    <Receipt className="w-10 h-10 mx-auto mb-3 text-gray-300" />
                    Aucune facture émise pour le moment. Les factures apparaîtront ici automatiquement.
                  </CardContent>
                </Card>
              ) : (
                <GeneratedInvoicesList
                  invoices={invoices}
                  onDownloadPdf={handleDownloadPdf}
                  onMarkPaid={handleMarkPaid}
                  onDelete={handleDeleteInvoice}
                />
              )}
            </TabsContent>
          </Tabs>
        )}
      </div>

      <RecurringInvoiceForm
        open={showForm}
        onOpenChange={setShowForm}
        plan={editingPlan}
        defaults={senderDefaults}
        onSubmit={handleSave}
        isSaving={isSaving}
      />
    </div>
  );
}