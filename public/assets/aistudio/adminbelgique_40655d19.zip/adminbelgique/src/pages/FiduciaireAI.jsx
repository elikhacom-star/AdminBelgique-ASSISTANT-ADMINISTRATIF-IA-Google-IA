import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Calculator, Brain, PenTool, Shield, Globe, Zap, Check, Lock, LogIn, Loader2, Calendar, FileText, Settings, Building2, CreditCard } from "lucide-react";
import FiduciaireStudioTool from "@/components/fiduciaire/FiduciaireStudioTool";

export default function FiduciaireAI() {
  const { isAuthenticated, isLoadingAuth } = useAuth();

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#f4f7fb" }}>

      {/* ═══ HERO ═══ */}
      <section className="relative overflow-hidden text-white py-20 px-6" style={{ background: "linear-gradient(160deg, #0f1f3d 0%, #1a2e52 60%, #003d1a 100%)" }}>
        <div className="max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 border border-emerald-400/40 rounded-full px-4 py-1.5 mb-8 text-sm text-emerald-300 font-medium">
            <Zap className="w-4 h-4" />
            2e verticale — Infrastructure IA appliquée à la comptabilité belge
          </div>

          <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-6">
            L'assistant IA fiscal{" "}
            <span className="underline decoration-emerald-400 underline-offset-4">et réglementaire</span>{" "}
            pour les{" "}
            <span className="text-emerald-400">fiduciaires belges</span>
          </h1>

          <p className="text-lg text-slate-300 mb-10 max-w-2xl leading-relaxed">
            La même architecture multi-agents validée sur l'immobilier avec ImmoBoost AI, appliquée au suivi fiscal : échéances TVA/IPP/ISOC calculées automatiquement, communication client rédigée en un clic.
          </p>

          <div className="flex flex-wrap gap-3 mb-14">
            <a href="#fiduciaires">
              <Button className="bg-emerald-500 hover:bg-emerald-600 text-white font-semibold px-6 py-2.5 rounded-lg">
                Découvrir Fiduciaires AI
              </Button>
            </a>
            <Button asChild variant="outline" className="border-white/30 text-white bg-white/10 hover:bg-white/20 font-semibold px-6 py-2.5 rounded-lg">
              <Link to={isAuthenticated ? "/Dashboard" : "/login"}>
                Accéder à la plateforme
              </Link>
            </Button>
          </div>

          <hr className="border-white/10 mb-10" />

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
            { icon: Calendar, value: "Instantané", label: "Calcul des échéances TVA/IPP/ISOC" },
            { icon: Globe, value: "FR / NL", label: "Communication bilingue" },
            { icon: Shield, value: "SPF Finances", label: "Alertes de vérification officielle" },
            { icon: FileText, value: "Multi-agents", label: "Architecture réutilisée d'ImmoBoost" }].
            map((s, i) =>
            <div key={i} className="flex flex-col items-center text-center gap-2">
                <s.icon className="w-6 h-6 text-emerald-400" />
                <div className="text-2xl font-bold text-white">{s.value}</div>
                <div className="text-xs text-slate-400">{s.label}</div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ═══ PRÉSENTATION DES AGENTS ═══ */}
      <section className="py-16 px-6" style={{ backgroundColor: "#f4f7fb" }}>
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-xs font-bold tracking-widest text-emerald-500 uppercase mb-3">2e Verticale — En développement</p>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Fiduciaires AI</h2>
            <p className="text-slate-600 leading-relaxed">
              Après avoir validé notre infrastructure sur l'immobilier, nous l'appliquons au secteur comptable et fiscal belge — la même mécanique de collaboration entre un agent d'analyse et un agent de communication.
            </p>
          </div>

          <div className="space-y-4 mb-10">
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "linear-gradient(135deg, #3b82f6, #06b6d4)" }}>
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="font-bold text-slate-900 text-base">Le Cerveau Fiscal &amp; Réglementaire</div>
                  <div className="text-xs text-blue-500 font-mono mb-2">fiduciaire_assistant</div>
                  <p className="text-sm text-slate-600">Calcule les échéances TVA, IPP et ISOC selon le profil du client, structure les éléments de bilan et repère les pièces manquantes avant clôture.</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "linear-gradient(135deg, #22c55e, #16a34a)" }}>
                  <PenTool className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="font-bold text-slate-900 text-base">La Plume Client</div>
                  <div className="text-xs text-green-500 font-mono mb-2">fiduciaire_communication_assistant</div>
                  <p className="text-sm text-slate-600">Traduit l'analyse technique en messages clairs pour le client : rappels d'échéances, synthèses de situation, demandes de pièces justificatives.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-5">
            {[
            {
              num: "1", color: "#3b82f6",
              title: "Le Calcul des Échéances",
              agent: "fiduciaire_assistant",
              desc: "Selon le type d'entité et le régime TVA du client, l'assistant calcule les prochaines échéances de dépôt et signale les points nécessitant une vérification officielle."
            },
            {
              num: "2", color: "#f97316",
              title: "Le Dossier Structuré — Transfert Interne",
              agent: "Transfert automatique",
              desc: "Le profil client, les échéances calculées et les points d'attention sont transmis en un clic à l'assistant communication. Zéro ressaisie."
            },
            {
              num: "3", color: "#22c55e",
              title: "La Communication Client",
              agent: "fiduciaire_communication_assistant",
              desc: "L'assistant rédige un message clair et rassurant, prêt à être envoyé par email au client, sans jargon inutile."
            }].
            map((step) =>
            <div key={step.num} className="flex gap-4">
                <div className="flex-shrink-0 flex flex-col items-center">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-base" style={{ backgroundColor: step.color }}>
                    {step.num}
                  </div>
                </div>
                <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex-1">
                  <div className="font-bold text-slate-900 mb-1">{step.title}</div>
                  <div className="text-xs font-mono text-slate-400 mb-2">{step.agent}</div>
                  <p className="text-sm text-slate-600">{step.desc}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ═══ INFRASTRUCTURE ═══ */}
      <section className="py-16 px-6" style={{ backgroundColor: "#f4f7fb" }}>
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-xs font-bold tracking-widest text-emerald-500 uppercase mb-3">Infrastructure</p>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Une infrastructure adaptée, pas réinventée</h2>
            <p className="text-slate-600">Le même socle technique qu'ImmoBoost, appliqué au cadre réglementaire belge de la comptabilité.</p>
          </div>

          <div className="space-y-4">
            {[
            {
              iconBg: "linear-gradient(135deg, #3b82f6, #06b6d4)",
              icon: Calendar,
              title: "Calcul d'Échéances Fiscales",
              desc: "Détermination automatique des dates limites TVA, IPP et ISOC selon le régime exact du client, avec signalement explicite des points à confirmer officiellement.",
              tags: ["TVA mensuel/trimestriel", "IPP / ISOC", "Alerte \"à vérifier\""]
            },
            {
              iconBg: "linear-gradient(135deg, #f97316, #ea580c)",
              icon: Globe,
              title: "Adaptation FR / NL",
              desc: "Communication client disponible en français et en néerlandais, adaptée au contexte réglementaire belge.",
              tags: ["FR / NL natif", "Ton adapté au contexte"]
            },
            {
              iconBg: "linear-gradient(135deg, #22c55e, #16a34a)",
              icon: Shield,
              title: "Rigueur Réglementaire",
              desc: "L'assistant ne cite jamais un taux ou une date de mémoire : toute échéance passe par un calcul vérifiable, avec recommandation de confirmation sur MyMinfin.",
              tags: ["SPF Finances", "MyMinfin", "Zéro affirmation non vérifiée"]
            },
            {
              iconBg: "linear-gradient(135deg, #a855f7, #7c3aed)",
              icon: Settings,
              title: "Architecture Multi-Agents Réutilisée",
              desc: "Le même code source qui fait collaborer les 2 agents d'ImmoBoost, redéployé ici : séparation nette entre l'analyse réglementaire et la rédaction client.",
              tags: ["Flux structurés", "Séparation des rôles", "Infrastructure duplicable"]
            }].
            map((f, i) =>
            <div key={i} className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4" style={{ background: f.iconBg }}>
                  <f.icon className="w-6 h-6 text-white" />
                </div>
                <div className="font-bold text-slate-900 mb-2">{f.title}</div>
                <p className="text-sm text-slate-600 mb-3">{f.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {f.tags.map((tag, j) =>
                <span key={j} className="text-xs border border-emerald-300 text-emerald-600 rounded-full px-3 py-0.5">{tag}</span>
                )}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ═══ ROADMAP ═══ */}
      <section className="py-16 px-6" style={{ backgroundColor: "#f4f7fb" }}>
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-xs font-bold tracking-widest text-emerald-500 uppercase mb-3">Une Roadmap Infinie</p>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">D'un vertical à une infrastructure</h2>
            <p className="text-slate-600">La technologie validée sur l'immobilier et les fiduciaires est immédiatement duplicable aux autres secteurs administratifs belges.</p>
          </div>

          <div className="space-y-4">
            {[
            { icon: Building2, iconBg: "#3b82f6", title: "Immobilier", badge: "Validé — Disponible", badgeColor: "text-green-600 border-green-300 bg-green-50", desc: "ImmoBoost AI opérationnel. Proof-of-Concept majeur déployé et testé." },
            { icon: Calculator, iconBg: "#6366f1", title: "Fiduciaires (Comptabilité)", badge: "En développement", badgeColor: "text-orange-500 border-orange-300 bg-orange-50", desc: "Fiduciaires AI en construction. Échéances fiscales et communication client automatisées." },
            { icon: Shield, iconBg: "#f97316", title: "Assurances", badge: "Prochainement", badgeColor: "text-orange-500 border-orange-300 bg-orange-50", desc: "Gestion de devis, conformité FSMA, comparaison de polices multilingue." },
            { icon: CreditCard, iconBg: "#0ea5e9", title: "Courtage de Crédit", badge: "Prochainement", badgeColor: "text-orange-500 border-orange-300 bg-orange-50", desc: "Simulation de prêts hypothécaires, comparaison taux, conformité CKP." }].
            map((item, i) =>
            <div key={i} className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: item.iconBg }}>
                  <item.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="font-bold text-slate-900">{item.title}</span>
                    <span className={`text-xs border rounded-full px-2.5 py-0.5 font-medium ${item.badgeColor}`}>{item.badge}</span>
                  </div>
                  <p className="text-sm text-slate-600">{item.desc}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ═══ FINAL CTA ═══ */}
      <section className="py-16 px-6 text-center" style={{ background: "linear-gradient(135deg, #16a34a 0%, #22c55e 100%)" }}>
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">L'infrastructure IA B2B de référence en Belgique</h2>
          <p className="text-emerald-100 mb-8">La plateforme est prête, testée et verticalisée. Fiduciaires AI est notre 2e démonstration de sa capacité à s'adapter à n'importe quel secteur.</p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Button asChild className="bg-white/20 border border-white/40 text-white hover:bg-white/30 font-semibold px-6 rounded-lg">
              <Link to="/register">Démarrer maintenant →</Link>
            </Button>
            <Button asChild variant="outline" className="border-white/40 text-white bg-white/10 hover:bg-white/20 font-semibold px-6 rounded-lg">
              <Link to="/login">Se connecter</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ═══ STUDIO TOOL ═══ */}
      <section id="fiduciaires" className="scroll-mt-20 pt-16 pr-4 pl-4 pb-64" style={{ backgroundColor: "#f4f7fb" }}>
        <div className="max-w-7xl mx-auto">
          {isLoadingAuth ?
          <div className="flex items-center justify-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
            </div> :
          isAuthenticated ?
          <FiduciaireStudioTool /> :

          <div className="max-w-xl mx-auto text-center bg-white rounded-2xl shadow-sm border border-slate-100 p-10">
              <div className="w-16 h-16 rounded-2xl bg-emerald-100 flex items-center justify-center mx-auto mb-4">
                <Lock className="w-8 h-8 text-emerald-500" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-3">Accédez au Studio IA</h3>
              <p className="text-slate-600 mb-6">
                Connectez-vous pour accéder à Fiduciaires AI Studio — calculez les échéances fiscales de vos clients et générez leur communication en un clic.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button asChild className="bg-emerald-500 hover:bg-emerald-600 text-white font-semibold rounded-xl">
                  <Link to="/register">Démarrer maintenant</Link>
                </Button>
                <Button asChild variant="outline" className="border-emerald-300 text-emerald-600 hover:bg-emerald-50 font-semibold rounded-xl">
                  <Link to="/login">
                    <LogIn className="w-4 h-4 mr-2" />Se connecter
                  </Link>
                </Button>
              </div>
            </div>
          }
        </div>
      </section>
    </div>);

}
