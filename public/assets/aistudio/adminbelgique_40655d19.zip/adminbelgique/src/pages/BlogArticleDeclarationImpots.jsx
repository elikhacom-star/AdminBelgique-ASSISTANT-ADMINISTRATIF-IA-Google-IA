import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowLeft, CheckCircle, AlertTriangle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import SEOHead from "../components/seo/SEOHead";

export default function BlogArticleDeclarationImpots() {
  const steps = [
    {
      title: "1. Rassembler vos documents fiscaux",
      icon: "📄",
      description: "Upload de tous vos documents : fiches de paie, attestations 281.10, factures professionnelles, attestations de dons",
      iaHelp: "L'IA scanne et classe automatiquement vos documents par catégorie fiscale"
    },
    {
      title: "2. Analyse des revenus et dépenses",
      icon: "💰",
      description: "Identification de tous vos revenus imposables et frais déductibles",
      iaHelp: "L'IA détecte les déductions oubliées : frais de déplacement, frais professionnels, dons, épargne-pension"
    },
    {
      title: "3. Optimisation fiscale automatique",
      icon: "🎯",
      description: "Calcul des scénarios pour minimiser votre impôt légalement",
      iaHelp: "L'IA suggère les meilleures options : quotient conjugal, rente alimentaire, avantages fiscaux méconnus"
    },
    {
      title: "4. Pré-remplissage de la déclaration",
      icon: "✍️",
      description: "Génération automatique du formulaire avec toutes les cases remplies",
      iaHelp: "L'IA remplit automatiquement les codes correcte du SPF Finances (codes 1250, 1251, etc.)"
    },
    {
      title: "5. Vérification et envoi",
      icon: "✅",
      description: "Contrôle final et soumission à Tax-on-Web",
      iaHelp: "L'IA détecte les erreurs potentielles avant envoi et calcule votre remboursement estimé"
    }
  ];

  const deductions = [
    {
      title: "Frais Professionnels",
      icon: "💼",
      examples: ["Vêtements de travail", "Déplacements domicile-travail", "Matériel informatique", "Formation continue"],
      economie: "Moyenne 800€/an"
    },
    {
      title: "Logement",
      icon: "🏠",
      examples: ["Crédit hypothécaire", "Chèques habitat", "Travaux d'économie d'énergie", "Assurance habitation"],
      economie: "Moyenne 1200€/an"
    },
    {
      title: "Épargne et Pension",
      icon: "🏦",
      examples: ["Épargne-pension", "Assurance-vie", "PLCI pour indépendants"],
      economie: "Moyenne 600€/an"
    },
    {
      title: "Famille",
      icon: "👨‍👩‍👧",
      examples: ["Frais de garde d'enfants", "Pensions alimentaires", "Titres-services"],
      economie: "Moyenne 400€/an"
    }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <SEOHead
        title="Déclarer Ses Impôts en Belgique avec l'IA 💰 (Guide 2025)"
        description="💰 Gagnez 5-8h sur votre déclaration d'impôts ! Découvrez le guide complet pour déclarer vos impôts belges avec l'IA. Optimisez vos déductions à 100%. Étape par étape ✨"
        canonical="https://adminbelgique.com/BlogArticleDeclarationImpots"
        keywords="déclaration impôts belgique ia, impôts spf finances belgique, optimisation fiscale ia"
      />
      <div className="max-w-4xl mx-auto">
        
        <Button asChild variant="ghost" className="mb-6">
          <Link to={createPageUrl("Blog")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour au blog
          </Link>
        </Button>

        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Badge className="bg-green-100 text-green-800">Guide Complet</Badge>
            <div className="flex items-center gap-4 text-sm text-gray-500">
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                1 Jan 2025
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                10 min de lecture
              </span>
            </div>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Guide Complet : Déclarer Ses Impôts en Belgique avec l'IA
          </h1>
          
          <p className="text-xl text-gray-600">
            Comment utiliser l'intelligence artificielle pour préparer et optimiser votre déclaration d'impôts belge auprès du <strong>SPF Finances</strong>.
          </p>
        </div>

        <div className="mb-8 rounded-xl overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=1200" 
            alt="Déclaration impôts Belgique IA"
            className="w-full h-64 object-cover"
          />
        </div>

        {/* Alert Important */}
        <Card className="mb-8 bg-red-50 border-2 border-red-300">
          <CardContent className="p-6">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-red-900 mb-2">⚠️ Dates Limites 2025</h3>
                <ul className="space-y-1 text-red-800">
                  <li><strong>30 juin 2025</strong> : Déclaration papier</li>
                  <li><strong>15 juillet 2025</strong> : Déclaration Tax-on-Web</li>
                  <li><strong>25 octobre 2025</strong> : Via comptable agréé</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Introduction */}
        <Card className="mb-8 bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200">
          <CardContent className="p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-3">📊 Pourquoi l'IA Change Tout</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              La déclaration d'impôts belge est <strong>complexe</strong> : 400+ codes fiscaux, règles changeantes, déductions méconnues. 
              <strong>90% des Belges</strong> ne profitent pas de toutes leurs déductions possibles, perdant en moyenne <strong>500€ par an</strong> !
            </p>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white p-3 rounded-lg text-center border">
                <div className="text-2xl font-bold text-blue-600">8h → 30min</div>
                <div className="text-xs text-gray-600">Temps réduit</div>
              </div>
              <div className="bg-white p-3 rounded-lg text-center border">
                <div className="text-2xl font-bold text-green-600">+500€</div>
                <div className="text-xs text-gray-600">Économie moyenne</div>
              </div>
              <div className="bg-white p-3 rounded-lg text-center border">
                <div className="text-2xl font-bold text-purple-600">100%</div>
                <div className="text-xs text-gray-600">Déductions trouvées</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Les 5 étapes */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">
            🚀 Les 5 Étapes avec l'IA
          </h2>
          <div className="space-y-6">
            {steps.map((step, index) => (
              <Card key={index} className="border-2 hover:shadow-lg transition-all">
                <CardHeader className="bg-gradient-to-r from-gray-50 to-white">
                  <CardTitle className="flex items-center gap-3">
                    <span className="text-4xl">{step.icon}</span>
                    <span>{step.title}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-3">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-gray-700">{step.description}</p>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
                    <p className="text-sm">
                      <strong className="text-blue-900">🤖 Aide IA :</strong>
                      <span className="text-blue-800 ml-2">{step.iaHelp}</span>
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Déductions méconnues */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">
            💰 Déductions Que Vous Oubliez (Détectées par l'IA)
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {deductions.map((deduction, index) => (
              <Card key={index} className="border-2 border-green-200">
                <CardHeader className="bg-green-50">
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <span className="text-2xl">{deduction.icon}</span>
                      {deduction.title}
                    </span>
                    <Badge className="bg-green-600 text-white">{deduction.economie}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <ul className="space-y-2">
                    {deduction.examples.map((example, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                        <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                        {example}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Erreurs à éviter */}
        <Card className="mb-8 bg-orange-50 border-2 border-orange-300">
          <CardHeader>
            <CardTitle className="text-2xl text-orange-900">⚠️ 5 Erreurs Fréquentes (Que l'IA Évite)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              {
                error: "Oublier les frais de déplacement domicile-travail",
                solution: "L'IA calcule automatiquement selon la distance (0,15€/km jusqu'à 75km, 0,10€/km au-delà)"
              },
              {
                error: "Ne pas déclarer les revenus complémentaires",
                solution: "L'IA détecte tous les revenus même mineurs (Airbnb, freelance, crypto)"
              },
              {
                error: "Mal choisir entre quotient conjugal et imposition séparée",
                solution: "L'IA compare les 2 scénarios et choisit le plus avantageux"
              },
              {
                error: "Oublier les dons déductibles",
                solution: "L'IA identifie automatiquement les dons déductibles (min 40€) jusqu'à 10% des revenus nets"
              },
              {
                error: "Ne pas profiter du bonus épargne-pension",
                solution: "L'IA suggère le montant optimal pour maximiser la réduction d'impôt (30% ou 25%)"
              }
            ].map((item, index) => (
              <div key={index} className="bg-white p-4 rounded-lg border border-orange-200">
                <div className="flex items-start gap-3">
                  <span className="text-xl">❌</span>
                  <div className="flex-1">
                    <p className="font-semibold text-orange-900 mb-1">{item.error}</p>
                    <p className="text-sm text-gray-700">
                      <span className="text-green-700 font-semibold">✅ Solution IA :</span> {item.solution}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Exemple concret */}
        <Card className="mb-8 bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200">
          <CardHeader>
            <CardTitle className="text-2xl">💡 Exemple Concret : Marie de Bruxelles</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-white p-4 rounded-lg border">
              <p className="text-gray-700 mb-3">
                <strong>Situation :</strong> Employée, 45 000€ brut/an, 2 enfants, crédit hypothécaire, 
                15km domicile-travail, cotise épargne-pension
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-red-50 p-3 rounded border-l-4 border-red-500">
                  <p className="font-bold text-red-800 mb-2">❌ Sans IA</p>
                  <ul className="text-sm text-red-700 space-y-1">
                    <li>• Temps : 8 heures</li>
                    <li>• Déductions oubliées : 1200€</li>
                    <li>• Impôt payé : 9 500€</li>
                    <li>• Stress : Maximum</li>
                  </ul>
                </div>
                <div className="bg-green-50 p-3 rounded border-l-4 border-green-500">
                  <p className="font-bold text-green-800 mb-2">✅ Avec IA AdminBelgique</p>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• Temps : 30 minutes</li>
                    <li>• Toutes déductions : 3200€</li>
                    <li>• Impôt payé : 8 900€</li>
                    <li>• Stress : Zéro</li>
                  </ul>
                </div>
              </div>
              <div className="mt-4 bg-yellow-100 p-3 rounded-lg border-2 border-yellow-400 text-center">
                <p className="font-bold text-yellow-900 text-lg">
                  💰 Économie totale : 600€ + 7,5 heures gagnées
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA */}
        <Card className="bg-gradient-to-r from-green-600 to-emerald-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">
              Préparez Votre Déclaration d'Impôts avec l'IA
            </h3>
            <p className="text-lg mb-6 opacity-90">
              Essayez gratuitement et découvrez combien vous pouvez économiser
            </p>
            <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-100">
              <Link to={createPageUrl("Assistant")}>
                Commencer Ma Déclaration
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}