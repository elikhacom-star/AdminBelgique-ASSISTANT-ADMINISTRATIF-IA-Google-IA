import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  Building2, 
  Inbox, 
  Wallet, 
  Heart, 
  TrendingUp,
  Info,
  AlertTriangle,
  CheckCircle,
  Loader2,
  ExternalLink
} from "lucide-react";

export default function BelgianServices() {
  const [isLoading, setIsLoading] = useState(false);
  const [activeService, setActiveService] = useState(null);
  const [serviceData, setServiceData] = useState(null);
  const [error, setError] = useState(null);

  const callBelgianService = async (service, action, data = {}) => {
    setIsLoading(true);
    setError(null);
    setActiveService(`${service}-${action}`);

    try {
      const response = await base44.functions.invoke('belgianServicesIntegration', {
        service,
        action,
        data
      });

      setServiceData(response.data);
    } catch (err) {
      console.error("Erreur service belge:", err);
      setError(err.message || "Une erreur est survenue");
    } finally {
      setIsLoading(false);
    }
  };

  const services = [
    {
      id: 'myminfin',
      name: 'MyMinfin',
      icon: Wallet,
      color: 'blue',
      description: 'SPF Finances - Impôts et fiscalité',
      officialUrl: 'https://eservices.minfin.fgov.be/myminfin-web/',
      actions: [
        { 
          id: 'get_tax_data', 
          label: 'Mes données fiscales',
          description: 'Revenus, déductions, impôt estimé'
        },
        { 
          id: 'get_payment_status', 
          label: 'État des paiements',
          description: 'Paiements en attente et effectués'
        }
      ]
    },
    {
      id: 'ebox',
      name: 'eBox',
      icon: Inbox,
      color: 'purple',
      description: 'Courriers officiels électroniques',
      officialUrl: 'https://www.ebox.be/',
      actions: [
        { 
          id: 'list_messages', 
          label: 'Mes messages',
          description: 'Courriers des administrations'
        },
        { 
          id: 'get_message', 
          label: 'Lire un message',
          description: 'Détails d\'un courrier spécifique'
        }
      ]
    },
    {
      id: 'mypension',
      name: 'MyPension',
      icon: TrendingUp,
      color: 'green',
      description: 'Calcul et estimation de pension',
      officialUrl: 'https://www.mypension.be/',
      actions: [
        { 
          id: 'estimate_pension', 
          label: 'Estimer ma pension',
          description: 'Montant mensuel, âge légal, recommandations'
        }
      ]
    },
    {
      id: 'mycarenet',
      name: 'MyCareNet',
      icon: Heart,
      color: 'red',
      description: 'Données de santé et remboursements',
      officialUrl: 'https://www.mycarenet.be/',
      actions: [
        { 
          id: 'get_health_data', 
          label: 'Mes données santé',
          description: 'Remboursements, mutuelle, consultations'
        }
      ]
    }
  ];

  const colorClasses = {
    blue: { bg: 'bg-blue-100', text: 'text-blue-800', border: 'border-blue-300', button: 'bg-blue-600 hover:bg-blue-700' },
    purple: { bg: 'bg-purple-100', text: 'text-purple-800', border: 'border-purple-300', button: 'bg-purple-600 hover:bg-purple-700' },
    green: { bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-300', button: 'bg-green-600 hover:bg-green-700' },
    red: { bg: 'bg-red-100', text: 'text-red-800', border: 'border-red-300', button: 'bg-red-600 hover:bg-red-700' },
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-blue-100 rounded-full px-4 py-2 mb-4">
            <Building2 className="w-5 h-5 text-blue-600" />
            <span className="text-blue-800 font-medium">Services Officiels Belges</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Intégrations Services Publics Belges
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Accédez à vos données administratives depuis MyMinfin, eBox, MyPension et MyCareNet
          </p>
        </div>

        {/* Avertissement Mode Simulation */}
        <Alert className="mb-8 bg-yellow-50 border-yellow-300">
          <AlertTriangle className="h-5 w-5 text-yellow-600" />
          <AlertTitle className="text-yellow-900 font-bold">
            ⚙️ Mode Simulation Activé
          </AlertTitle>
          <AlertDescription className="text-yellow-800">
            <p className="mb-2">
              Les données affichées sont <strong>simulées</strong> pour démonstration. 
              Pour accéder à vos vraies données, une authentification OAuth avec chaque service est nécessaire.
            </p>
            <p className="text-sm font-semibold">
              📧 Contactez-nous pour activer l'authentification réelle : 
              <a href="mailto:elikaccesit@gmail.com" className="underline ml-1">elikaccesit@gmail.com</a>
            </p>
          </AlertDescription>
        </Alert>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {services.map((service) => {
            const Icon = service.icon;
            const colors = colorClasses[service.color];

            return (
              <Card key={service.id} className={`border-2 ${colors.border}`}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 ${colors.bg} rounded-lg flex items-center justify-center`}>
                        <Icon className={`w-6 h-6 ${colors.text}`} />
                      </div>
                      <div>
                        <CardTitle className="text-xl">{service.name}</CardTitle>
                        <CardDescription>{service.description}</CardDescription>
                      </div>
                    </div>
                    <a 
                      href={service.officialUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <ExternalLink className="w-5 h-5" />
                    </a>
                  </div>
                </CardHeader>

                <CardContent className="space-y-3">
                  {service.actions.map((action) => (
                    <div key={action.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex-1">
                        <p className="font-semibold text-gray-900">{action.label}</p>
                        <p className="text-sm text-gray-600">{action.description}</p>
                      </div>
                      <Button
                        onClick={() => callBelgianService(service.id, action.id, {})}
                        disabled={isLoading}
                        className={colors.button}
                        size="sm"
                      >
                        {isLoading && activeService === `${service.id}-${action.id}` ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          'Tester'
                        )}
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Résultats */}
        {serviceData && (
          <Card className="border-2 border-green-300 bg-green-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-900">
                <CheckCircle className="w-5 h-5" />
                Résultats (Simulation)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {serviceData.note && (
                <Alert className="mb-4 bg-blue-50 border-blue-300">
                  <Info className="h-4 w-4" />
                  <AlertDescription className="text-blue-800">
                    {serviceData.note}
                  </AlertDescription>
                </Alert>
              )}
              
              <pre className="bg-white p-4 rounded-lg border border-green-300 overflow-auto max-h-96 text-sm">
                {JSON.stringify(serviceData, null, 2)}
              </pre>
            </CardContent>
          </Card>
        )}

        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Erreur</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Guide d'utilisation */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>📖 Comment ça fonctionne ?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-800 font-bold">1</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Mode Simulation (Actuel)</h4>
                  <p className="text-sm text-gray-600">
                    Les données affichées sont des exemples fictifs pour montrer comment ça fonctionne. 
                    Aucune connexion réelle aux services n'est établie.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-purple-800 font-bold">2</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Activation Authentification OAuth</h4>
                  <p className="text-sm text-gray-600">
                    Pour accéder à vos vraies données, il faut configurer l'authentification OAuth 
                    avec chaque service (MyMinfin, eBox, etc.). Ceci nécessite :
                  </p>
                  <ul className="text-sm text-gray-600 mt-2 space-y-1 ml-4">
                    <li>• Inscription aux API des services publics belges</li>
                    <li>• Configuration des clés OAuth (client_id, client_secret)</li>
                    <li>• Flux d'autorisation pour chaque utilisateur</li>
                    <li>• Gestion sécurisée des tokens d'accès</li>
                  </ul>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-green-800 font-bold">3</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Mode Production (Futur)</h4>
                  <p className="text-sm text-gray-600">
                    Une fois configuré, vous pourrez :
                  </p>
                  <ul className="text-sm text-gray-600 mt-2 space-y-1 ml-4">
                    <li>• Voir vos vraies données fiscales de MyMinfin</li>
                    <li>• Lire vos courriers eBox en temps réel</li>
                    <li>• Calculer précisément votre pension future</li>
                    <li>• Consulter vos remboursements de soins de santé</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4 mt-6">
              <h4 className="font-bold text-blue-900 mb-2">🔐 Sécurité et Confidentialité</h4>
              <p className="text-sm text-blue-800">
                Toutes les connexions utilisent le protocole OAuth2 standard. 
                Vos identifiants ne transitent JAMAIS par notre serveur. 
                Seuls des tokens temporaires d'accès sont stockés, chiffrés dans votre session.
              </p>
            </div>

            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>Besoin d'activation ?</AlertTitle>
              <AlertDescription>
                Contactez-nous à <strong>elikaccesit@gmail.com</strong> pour activer 
                l'authentification réelle avec les services belges.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}