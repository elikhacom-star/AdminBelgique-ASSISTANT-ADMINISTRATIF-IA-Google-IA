import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MessageSquare, Bot, FileText, Sparkles, Users, Shield, BookOpen, HelpCircle, ExternalLink, LayoutDashboard, LogIn, LogOut, User as UserIcon } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Help() {
  const features = [
    {
      title: "🏠 Tableau de Bord Assistant Administratif",
      icon: LayoutDashboard,
      description: "Votre cockpit agent administratif IA personnel",
      details: [
        "Vue d'overview de toutes vos démarches avec assistant administratif",
        "Statistiques en temps réel par agent administratif IA (en cours, à faire, terminées)",
        "Centre de notifications avec alertes importantes",
        "Création et suivi de démarches personnalisées avec assistant administratif",
        "Rappels automatiques des échéances par agent administratif"
      ],
      color: "bg-indigo-500",
      url: createPageUrl("Dashboard")
    },
    {
      title: "🤖 Assistant Administratif IA Simple",
      icon: MessageSquare,
      description: "Agent administratif pour questions rapides et ponctuelles",
      details: [
        "Posez une question et obtenez une réponse immédiate de l'assistant administratif IA",
        "Idéal pour des informations spécifiques avec agent administratif",
        "Questions suggérées pour vous guider par assistant administratif",
        "Interface simple et rapide agent administratif IA",
        "Système d'évaluation des réponses de l'assistant administratif"
      ],
      color: "bg-yellow-500",
      url: createPageUrl("Assistant")
    },
    {
      title: "🧠 Agent Administratif IA - Chat Avancé",
      icon: Bot,
      description: "Assistant administratif conversationnel avec mémoire persistante",
      details: [
        "Se souvient de toutes vos conversations précédentes - agent administratif avec mémoire",
        "Peut gérer des dossiers complexes - assistant administratif expert",
        "Accès à votre historique de documents et questions",
        "Capable de faire des recherches immobilières intelligentes",
        "Interface de chat avancée avec outils intégrés agent administratif IA"
      ],
      color: "bg-blue-500",
      url: createPageUrl("Chat")
    },
    {
      title: "📄 Générateur Agent Administratif Documents",
      icon: FileText,
      description: "Création automatique de courriers par assistant administratif IA",
      details: [
        "Lettres de réclamation, demandes de remboursement par agent administratif",
        "Recours administratifs, demandes de renseignements avec assistant administratif IA",
        "Format professionnel et personnalisé par agent administratif",
        "Téléchargement en plusieurs formats",
        "Sauvegarde automatique de vos documents assistant administratif"
      ],
      color: "bg-red-500",
      url: createPageUrl("DocumentGenerator")
    },
    {
      title: "🔍 Analyseur Agent Administratif Documents",
      icon: Sparkles,
      description: "Analyse IA de vos documents par assistant administratif",
      details: [
        "Upload de PDF, images, fichiers CSV pour agent administratif",
        "Extraction automatique des informations clés par assistant administratif IA",
        "Conseils et actions recommandées par agent administratif",
        "Sauvegarde de vos analyses assistant administratif",
        "Intégration avec le Chat Agent administratif pour questions de suivi"
      ],
      color: "bg-purple-500",
      url: createPageUrl("DocumentAnalyzer")
    },
    {
      title: "🏘️ ImmoScrap Pro - Agent Administratif Immobilier",
      icon: Users,
      description: "Assistant administratif IA immobilier avec recherche automatique",
      details: [
        "Fiches clients avec critères de recherche détaillés par agent administratif",
        "IA agent administratif qui analyse les portails immobiliers belges en temps réel",
        "Recherche automatique sur Immoweb, Logic-Immo, Zimmo par assistant administratif",
        "Analyse intelligente des correspondances avec les critères",
        "Liens directs vers les annonces pertinentes par agent administratif IA",
        "Suivi du portefeuille client complet avec assistant administratif"
      ],
      color: "bg-emerald-500",
      url: createPageUrl("ImmoBoostScrap")
    },
    {
      title: "📚 Mes Documents Assistant Administratif",
      icon: BookOpen,
      description: "Bibliothèque de tous vos documents générés par agent administratif",
      details: [
        "Accès rapide à tous vos courriers créés par assistant administratif",
        "Filtrage par catégorie et statut agent administratif",
        "Historique complet avec dates assistant administratif IA",
        "Aperçu et téléchargement agent administratif",
        "Organisation par projets assistant administratif"
      ],
      color: "bg-orange-500",
      url: createPageUrl("MyDocuments")
    },
    {
      title: "📋 Mes Analyses Agent Administratif",
      icon: FileText,
      description: "Historique de toutes vos analyses de documents par assistant administratif IA",
      details: [
        "Toutes vos analyses sauvegardées par agent administratif",
        "Recherche dans le contenu assistant administratif",
        "Réutilisation pour de nouvelles questions agent administratif IA",
        "Export des données extraites par assistant administratif",
        "Liens vers le Chat Agent administratif"
      ],
      color: "bg-teal-500",
      url: createPageUrl("MyAnalyses")
    }
  ];

  const connectionGuide = [
    {
      icon: LogIn,
      title: "Se Connecter",
      description: "Cliquez sur le bouton BLEU 'Se connecter' en haut à droite",
      details: "Authentification sécurisée avec Google. Vos données restent privées grâce à notre technologie d'anonymisation."
    },
    {
      icon: UserIcon,
      title: "Utilisateur Connecté",
      description: "Votre nom apparaît dans un badge vert en haut à droite",
      details: "Vous voyez 'Connecté en tant que [Votre Nom]' pour confirmer votre session active."
    },
    {
      icon: LogOut,
      title: "Se Déconnecter", 
      description: "Cliquez sur le bouton gris 'Se déconnecter' pour changer d'utilisateur",
      details: "Important pour la sécurité, surtout sur des appareils partagés."
    }
  ];

  const belgianServices = [
    {
      name: "SPF Finances",
      description: "Service Public Fédéral Finances",
      url: "https://finances.belgium.be",
      features: ["Déclarations d'impôts", "Remboursements", "Questions fiscales"]
    },
    {
      name: "ONSS",
      description: "Office National de Sécurité Sociale",
      url: "https://www.onss.be",
      features: ["Cotisations sociales", "Attestations", "Déclarations trimestrielles"]
    },
    {
      name: "ONEM",
      description: "Office National de l'Emploi",
      url: "https://www.onem.be",
      features: ["Allocations de chômage", "Recherche d'emploi", "Formations"]
    },
    {
      name: "My e-Box",
      description: "Boîte mail électronique sécurisée",
      url: "https://www.myebox.belgium.be",
      features: ["Documents officiels", "Courrier administratif", "Notifications"]
    }
  ];

  const workflowSteps = [
    {
      step: "1",
      title: "Connexion Sécurisée",
      description: "Connectez-vous avec votre compte Google",
      icon: LogIn,
      color: "bg-blue-100 text-blue-600"
    },
    {
      step: "2", 
      title: "Découvrez le Tableau de Bord",
      description: "Consultez vos démarches et notifications",
      icon: LayoutDashboard,
      color: "bg-indigo-100 text-indigo-600"
    },
    {
      step: "3",
      title: "Posez vos Questions",
      description: "Utilisez l'Assistant IA ou le Chat Agent selon vos besoins",
      icon: MessageSquare,
      color: "bg-yellow-100 text-yellow-600"
    },
    {
      step: "4",
      title: "Analysez vos Documents",
      description: "Uploadez et analysez vos documents administratifs",
      icon: Sparkles,
      color: "bg-purple-100 text-purple-600"
    },
    {
      step: "5",
      title: "Générez vos Courriers",
      description: "Créez des lettres administratives professionnelles",
      icon: FileText,
      color: "bg-red-100 text-red-600"
    }
  ];

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-blue-100 rounded-full px-4 py-2 mb-4">
            <HelpCircle className="w-5 h-5 text-blue-600" />
            <span className="text-blue-800 font-medium">Guide Complet Assistant Administratif et Agent Administratif IA</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            AdminBelgique Premium - Guide Assistant Administratif IA et Agent Administratif Belgique
          </h1>
          <p className="text-gray-600">
            Découvrez votre assistant administratif virtuel et agent administratif IA - Maîtrisez toutes les fonctionnalités
          </p>
        </div>

        {/* Workflow de démarrage */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">🚀 Comment Commencer ?</h2>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {workflowSteps.map((step, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-4">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 ${step.color}`}>
                    <step.icon className="w-6 h-6" />
                  </div>
                  <div className="text-2xl font-bold text-gray-800 mb-2">{step.step}</div>
                  <h3 className="font-semibold text-sm mb-2">{step.title}</h3>
                  <p className="text-xs text-gray-600">{step.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Guide de connexion */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">🔐 Gestion de Votre Connexion</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {connectionGuide.map((item, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <div className="p-2 bg-gray-100 rounded-lg">
                      <item.icon className="w-5 h-5 text-gray-700" />
                    </div>
                    {item.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="font-medium mb-2">{item.description}</p>
                  <p className="text-sm text-gray-600">{item.details}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* NOUVEAU: Section spéciale IMMO BOOST */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">🏠 IMMO BOOST - Votre Assistant Immobilier IA</h2>
          <Card className="bg-gradient-to-r from-emerald-50 to-blue-50 border-emerald-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-emerald-800">
                <Users className="w-6 h-6" />
                🚀 Innovation Majeure : Recherche Immobilière Intelligente
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-emerald-700">
                <strong>IMMO BOOST</strong> transforme la recherche immobilière grâce à l'IA. Plus besoin de parcourir
                manuellement des centaines d'annonces sur différents sites !
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <h4 className="font-bold text-gray-900 mb-2">🎯 Ce que fait l'IA pour vous :</h4>
                  <ul className="text-sm text-gray-700 space-y-1">
                    <li>• Analyse automatiquement Immoweb, Logic-Immo, Zimmo</li>
                    <li>• Trouve les annonces qui correspondent EXACTEMENT aux critères</li>
                    <li>• Compare chaque bien avec les exigences du client</li>
                    <li>• Fournit une analyse détaillée de chaque correspondance</li>
                    <li>• Génère des liens directs vers les bonnes annonces</li>
                  </ul>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <h4 className="font-bold text-gray-900 mb-2">⚡ Workflow ultra-efficace :</h4>
                  <ol className="text-sm text-gray-700 space-y-1">
                    <li>1. Créez une fiche client avec ses critères</li>
                    <li>2. Cliquez sur "Rechercher" 🔍</li>
                    <li>3. L'IA analyse le marché en temps réel</li>
                    <li>4. Recevez une liste d'annonces pertinentes</li>
                    <li>5. Cliquez pour voir directement l'annonce sur le site</li>
                  </ol>
                </div>
              </div>
              
              <div className="bg-emerald-100 p-4 rounded-lg">
                <p className="text-emerald-800 font-medium">
                  💡 <strong>Résultat :</strong> Au lieu de passer des heures à chercher manuellement,
                  vous obtenez en quelques secondes une sélection qualifiée d'annonces qui correspondent
                  réellement aux besoins de vos clients !
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Fonctionnalités principales */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">✨ Toutes Nos Fonctionnalités</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-all">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${feature.color} bg-opacity-20`}>
                      <feature.icon className={`w-5 h-5 ${feature.color.replace('bg-', 'text-')}`} />
                    </div>
                    {feature.title}
                  </CardTitle>
                  <p className="text-gray-600">{feature.description}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2">
                    {feature.details.map((detail, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm">
                        <div className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 flex-shrink-0"></div>
                        {detail}
                      </li>
                    ))}
                  </ul>
                  <Link to={feature.url}>
                    <button className={`w-full py-2 px-4 rounded-lg text-white ${feature.color} hover:opacity-90 transition-opacity`}>
                      Utiliser ce service
                    </button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Différences Assistant vs Chat Agent */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">🤔 Assistant Simple vs Chat Agent : Quelle différence ?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="border-yellow-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-yellow-700">
                  <MessageSquare className="w-5 h-5" />
                  Assistant IA Simple
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Badge className="bg-yellow-100 text-yellow-800">Recommandé pour : Questions ponctuelles</Badge>
                <div className="space-y-2 text-sm">
                  <p className="font-semibold text-green-600">✅ Avantages :</p>
                  <ul className="space-y-1 text-gray-600">
                    <li>• Interface simple et rapide</li>
                    <li>• Réponses immédiates</li>
                    <li>• Questions suggérées</li>
                    <li>• Parfait pour débuter</li>
                  </ul>
                  <p className="font-semibold text-orange-600 mt-3">⚠️ Limitations :</p>
                  <ul className="space-y-1 text-gray-600">
                    <li>• Pas de mémoire entre sessions</li>
                    <li>• Une question à la fois</li>
                    <li>• Pas d'accès aux dossiers</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="border-blue-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-700">
                  <Bot className="w-5 h-5" />
                  Chat Agent IA
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Badge className="bg-blue-100 text-blue-800">Recommandé pour : Dossiers complexes</Badge>
                <div className="space-y-2 text-sm">
                  <p className="font-semibold text-green-600">✅ Avantages :</p>
                  <ul className="space-y-1 text-gray-600">
                    <li>• Mémoire persistante complète</li>
                    <li>• Conversations approfondies</li>
                    <li>• Accès à tous vos documents</li>
                    <li>• Recherches immobilières</li>
                    <li>• Suivi de dossiers complexes</li>
                  </ul>
                  <p className="font-semibold text-orange-600 mt-3">⚠️ Note :</p>
                  <ul className="space-y-1 text-gray-600">
                    <li>• Plus puissant mais plus complexe</li>
                    <li>• Temps de réponse légèrement plus long</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Services administratifs belges */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">🇧🇪 Services Administratifs Belges Intégrés</h2>
          <p className="text-gray-600 mb-6">
            Notre plateforme peut vous guider vers les services officiels belges et, dans certains cas, 
            faciliter vos démarches grâce à des intégrations directes.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {belgianServices.map((service, index) => (
              <Card key={index} className="hover:shadow-lg transition-all">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{service.name}</span>
                    <a href={service.url} target="_blank" rel="noopener noreferrer" 
                       className="text-blue-600 hover:text-blue-800">
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </CardTitle>
                  <p className="text-gray-600 text-sm">{service.description}</p>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {service.features.map((feature, idx) => (
                      <Badge key={idx} variant="secondary" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Section Protection des données */}
        <Card className="bg-green-50 border-green-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-800">
              <Shield className="w-5 h-5" />
              🔒 Votre Assistant Administratif et Agent Administratif IA - Sécurité Maximale
            </CardTitle>
          </CardHeader>
          <CardContent className="text-green-700 space-y-3">
            <p>
              <strong>Technologie d'anonymisation intelligente brevetée pour agent administratif IA:</strong> L'assistant administratif ne voit jamais vos informations 
              personnelles réelles - elles sont automatiquement chiffrées et remplacées par des codes avant traitement par l'agent administratif.
            </p>
            <p>
              <strong>Protection multicouche pour assistant administratif:</strong> Chiffrement HTTPS, anonymisation intelligente, chiffrement au repos, 
              contrôle d'accès strict pour votre agent administratif IA.
            </p>
            <p>
              <strong>Résultat assistant administratif et agent administratif:</strong> Vous bénéficiez de conseils personnalisés tout en gardant 
              vos données privées en sécurité totale. Conformité RGPD garantie pour votre assistant administratif virtuel.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
