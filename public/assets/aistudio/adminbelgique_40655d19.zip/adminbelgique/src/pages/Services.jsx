import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MessageSquare, Bot, FileText, Sparkles, Users, LayoutDashboard, ArrowRight, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useTranslation } from "../components/localization/useTranslation";

export default function Services() {
  const { t } = useTranslation();

  const services = [
    {
      id: "assistant",
      icon: MessageSquare,
      color: "bg-yellow-500",
      title: t("service.assistant.title"),
      subtitle: "Questions/Réponses rapides",
      description: t("service.assistant.desc"),
      features: [
        "Réponses en moins de 30 secondes",
        "Spécialisé SPF Finances, INAMI, ONEM",
        "Interface simple et intuitive",
        "Questions suggérées intelligentes",
        "Système d'évaluation des réponses"
      ],
      useCases: [
        "Comment faire ma déclaration d'impôts ?",
        "Quels documents pour une demande de chômage ONEM ?",
        "Procédure remboursement INAMI"
      ],
      cta: "Poser une question",
      url: createPageUrl("Assistant")
    },
    {
      id: "chat",
      icon: Bot,
      color: "bg-blue-500",
      title: t("service.chat.title"),
      subtitle: "Conversations avec mémoire",
      description: t("service.chat.desc"),
      features: [
        "Mémoire persistante complète",
        "Gestion de dossiers complexes",
        "Accès à votre historique de documents",
        "Recherches immobilières intelligentes (IMMO BOOST)",
        "Conversations naturelles approfondies"
      ],
      useCases: [
        "Suivi d'un recours administratif",
        "Dossier de pension complexe",
        "Recherche immobilière personnalisée"
      ],
      cta: "Démarrer une conversation",
      url: createPageUrl("Chat")
    },
    {
      id: "generator",
      icon: FileText,
      color: "bg-red-500",
      title: t("service.generator.title"),
      subtitle: "Création automatique de courriers",
      description: t("service.generator.desc"),
      features: [
        "Lettres de réclamation optimisées",
        "Demandes de remboursement INAMI",
        "Recours administratifs structurés",
        "Format professionnel garanti",
        "Téléchargement PDF/DOCX"
      ],
      useCases: [
        "Lettre de réclamation SPF Finances",
        "Demande de remboursement mutuelle",
        "Recours amende routière"
      ],
      cta: "Générer un document",
      url: createPageUrl("DocumentGenerator")
    },
    {
      id: "analyzer",
      icon: Sparkles,
      color: "bg-purple-500",
      title: "Analyseur de Documents",
      subtitle: "Extraction intelligente de données",
      description: "Uploadez n'importe quel document administratif (PDF, image) et notre IA en extrait automatiquement les informations clés.",
      features: [
        "Analyse PDF, images, CSV",
        "Extraction automatique de données",
        "Conseils personnalisés",
        "Détection des erreurs",
        "Historique complet des analyses"
      ],
      useCases: [
        "Analyser un avertissement-extrait de rôle",
        "Comprendre une décision ONEM",
        "Vérifier un contrat de bail"
      ],
      cta: "Analyser un document",
      url: createPageUrl("DocumentAnalyzer")
    },
    {
      id: "immo",
      icon: Users,
      color: "bg-emerald-500",
      title: t("service.immo.title"),
      subtitle: "Recherche automatique pour agents",
      description: t("service.immo.desc"),
      features: [
        "Scan automatique Immoweb, Logic-Immo, Zimmo",
        "Matching IA avec critères clients",
        "Analyse de correspondance détaillée",
        "Liens directs vers annonces",
        "Gestion complète portefeuille clients"
      ],
      useCases: [
        "Recherche automatique pour client",
        "Analyse marché immobilier Bruxelles",
        "Suivi opportunités en temps réel"
      ],
      cta: "Découvrir ImmoScrap Pro",
      url: createPageUrl("ImmoBoostScrap")
    },
    {
      id: "dashboard",
      icon: LayoutDashboard,
      color: "bg-indigo-500",
      title: t("service.dashboard.title"),
      subtitle: "Vue d'ensemble de vos démarches",
      description: t("service.dashboard.desc"),
      features: [
        "Vue d'ensemble complète",
        "Notifications intelligentes",
        "Rappels d'échéances automatiques",
        "Statistiques de temps économisé",
        "Organisation par catégories"
      ],
      useCases: [
        "Suivi déclaration d'impôts",
        "Rappel renouvellement mutuelle",
        "Échéances ONEM"
      ],
      cta: "Voir mon tableau de bord",
      url: createPageUrl("Dashboard")
    }
  ];

  return (
    <div className="min-h-screen">
      <div className="p-2 md:p-8">
      <div className="max-w-6xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-blue-100 text-blue-800 border-blue-300">
            <Sparkles className="w-4 h-4 mr-2" />
            {t("services.badge")}
          </Badge>
          <h1 className="text-2xl md:text-5xl font-bold text-gray-900 mb-4">
            {t("services.title")}
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {t("services.subtitle")}
          </p>
        </div>

        {/* Services détaillés */}
        <div className="space-y-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card key={service.id} className="border-2 hover:shadow-2xl transition-all">
                <CardHeader className={`${service.color} text-white p-4 md:p-6`}>
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                      <Icon className="w-8 h-8" />
                    </div>
                    <div>
                      <CardTitle className="text-2xl">{service.title}</CardTitle>
                      <p className="text-sm opacity-90 mt-1">{service.subtitle}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-4 md:p-6">
                  <p className="text-gray-700 text-lg mb-6">{service.description}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    {/* Fonctionnalités */}
                    <div>
                      <h4 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-green-600" />
                        {t("services.features_title")}
                      </h4>
                      <ul className="space-y-2">
                        {service.features.map((feature, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-gray-600">
                            <span className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 flex-shrink-0"></span>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    {/* Cas d'usage */}
                    <div>
                      <h4 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-yellow-600" />
                        {t("services.usecases_title")}
                      </h4>
                      <ul className="space-y-2">
                        {service.useCases.map((useCase, i) => (
                          <li key={i} className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg border border-gray-200">
                            💡 {useCase}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <Button asChild className={`w-full ${service.color} hover:opacity-90 text-white`} size="lg">
                    <Link to={service.url}>
                      {service.cta}
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* CTA Final */}
        <Card className="mt-12 bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="text-3xl font-bold mb-4">
              {t("services.cta.ready")}
            </h2>
            <p className="text-lg mb-6 opacity-90">
              {t("services.cta.try")}
            </p>
            <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-100">
              <Link to={createPageUrl("Assistant")}>
                {t("services.cta.btn")}
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
      </div>
    </div>
  );
}