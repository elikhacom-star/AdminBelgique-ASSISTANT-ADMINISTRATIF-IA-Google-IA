import React, { useState, useEffect } from "react";
import { db } from "@/components/api/wrapper";
const Client = db.Client;
const PropertyMatch = db.PropertyMatch;
import { useForm, Controller } from "react-hook-form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, Trash2, Edit, X, User, Loader2, Home, Euro, BedDouble, MapPin, 
  Search, Sparkles, ExternalLink, Tag, AlertTriangle, Download, 
  FileSpreadsheet, ChevronDown, 
  Map as MapIcon, List, MessageCircle, Mail, TrendingUp, Share2, ShieldCheck 
} from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"; 
import WandRefineButton from "@/components/immo/WandRefineButton"; 
import { exportClientsCsv, exportPropertiesCsv } from "@/lib/csvExport";
import { useTranslation } from "@/components/localization/useTranslation";
import { api as base44 } from "@/components/api/wrapper";
import ManualSearchAssistant from "@/components/immo/ManualSearchAssistant";
import QuickLookPopover from "@/components/immo/QuickLookPopover";
import VerificationBadges from "@/components/immo/VerificationBadges";
import StrictEmptyState from "@/components/immo/StrictEmptyState";
import PrecisionFilters from "@/components/immo/PrecisionFilters";
import ClientActivityHistory from "@/components/immo/ClientActivityHistory";
import ListingToClientFileButton from "@/components/immo/ListingToClientFileButton";
import { appendClientActivities } from "@/lib/clientActivity";
import { useViewedProperties } from "@/hooks/useViewedProperties";
import { normalizeProperty, detectPropertyType, detectTransaction, parseLocation, deduplicateProperties, geolocatePostalCode } from "@/lib/propertyUtils";
import { DEFAULT_PRECISION_FILTERS, getPropertySources, getBudgetCeiling, filterPropertiesByPrecision } from "@/lib/propertyFilters";
import { refineSearchCriteria } from "@/functions/refineSearchCriteria";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import LimitChecker from "@/components/freemium/LimitChecker"; 

// Importation des composants pour la carte interactive
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Correction pour les icônes Leaflet par défaut dans React
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// 🔒 Les appels IA passent par les fonctions backend (intégration et quotas côté serveur).

export default function MyClients() {
  const { t } = useTranslation();
  const [clients, setClients] = useState([]);
  const [propertyMatches, setPropertyMatches] = useState([]); 
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingClient, setEditingClient] = useState(null);

  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState(null);
  const [searchingForClient, setSearchingForClient] = useState(null);
  const [integrationLimitHit, setIntegrationLimitHit] = useState(false);
  const [cacheInfo, setCacheInfo] = useState(null);
  const [searchMeta, setSearchMeta] = useState(null);
  const [precisionFilters, setPrecisionFilters] = useState(DEFAULT_PRECISION_FILTERS);

  const [isRefining, setIsRefining] = useState(false);
  const [refinedInfo, setRefinedInfo] = useState(null);
  const [gpsCoords, setGpsCoords] = useState(null);

  // État pour la vue carte/liste et la sélection de biens pour le partage
  const [viewMode, setViewMode] = useState('list'); 
  const [selectedProperties, setSelectedProperties] = useState({});

  const { isViewed, markAsViewed, viewedPortals } = useViewedProperties();

  const { register, handleSubmit, control, reset, setValue, formState: { errors } } = useForm();

  const loadClients = async () => {
    setIsLoading(true);
    try {
      const [clientsData, matchesData] = await Promise.all([
        Client.list("-created_date"),
        PropertyMatch.list("-created_date")
      ]);
      setClients(Array.isArray(clientsData) ? clientsData : []);
      setPropertyMatches(Array.isArray(matchesData) ? matchesData : []); 
    } catch (e) {
      console.error("Erreur de chargement:", e); 
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadClients();
  }, []);

  const onSubmit = async (data) => {
    try {
      const clientData = {
        name: data.name,
        email: data.email,
        phone: data.phone,
        notes: data.notes,
        search_criteria: {
          transaction_type: data.transaction_type,
          property_type: data.property_type,
          location: data.location,
          min_bedrooms: Number(data.min_bedrooms),
          max_budget: Number(data.max_budget)
        }
      };

      if (editingClient) {
        await Client.update(editingClient.id, clientData);
      } else {
        await Client.create(clientData);
      }
      
      setShowForm(false);
      setEditingClient(null);
      reset();
      await loadClients();
    } catch (error) {
      alert(`Erreur lors de la sauvegarde: ${error.message}`);
    }
  };

  const handleDelete = async (client) => {
    if (window.confirm(`Êtes-vous sûr de vouloir supprimer le client ${client.name} ?`)) {
      try {
        await Client.delete(client.id);
        await loadClients();
      } catch (error) {
        alert(`Erreur lors de la suppression: ${error.message}`);
      }
    }
  };

  const handleEdit = (client) => {
    setEditingClient(client);
    setValue("name", client.name);
    setValue("email", client.email);
    setValue("phone", client.phone);
    setValue("notes", client.notes);
    setValue("transaction_type", client.search_criteria?.transaction_type);
    setValue("property_type", client.search_criteria?.property_type);
    setValue("location", client.search_criteria?.location);
    setValue("min_bedrooms", client.search_criteria?.min_bedrooms);
    setValue("max_budget", client.search_criteria?.max_budget);
    setShowForm(true);
  };
  
  const createSpecificGoogleSearchUrl = (property) => {
    const { transaction } = detectTransaction(property);
    const propertyType = detectPropertyType(property);
    const { postalCode, cityName } = parseLocation(property.location);
    const norm = normalizeProperty(property);

    let url = `https://www.immoweb.be/fr/recherche/${propertyType}/${transaction}?countries=BE`;

    if (postalCode) {
      url += `&postalCodes=${postalCode}`;
    } else if (cityName) {
      url += `&query=${encodeURIComponent(cityName)}`;
    }

    // CORRECTION : Filtrage strict sur le prix minimum ET maximum pour isoler l'annonce unique
    if (norm._priceNum > 0) {
      url += `&minPrice=${norm._priceNum}&maxPrice=${norm._priceNum}`;
    }

    if (property.bedrooms) {
      const bedroomCount = String(property.bedrooms).match(/\d+/);
      if (bedroomCount) {
        url += `&minBedroomCount=${bedroomCount[0]}`;
      }
    }

    if (gpsCoords && postalCode) {
      url += `&latitude=${gpsCoords.lat.toFixed(4)}&longitude=${gpsCoords.lon.toFixed(4)}&radius=5`;
    }

    return url;
  };

  const createPortalUrl = (property, portal) => {
    const { transactionShort } = detectTransaction(property);
    const propertyType = detectPropertyType(property);
    const { postalCode, cityName } = parseLocation(property.location);
    const location = encodeURIComponent(postalCode ? `${postalCode} ${cityName}` : (property.location || 'Belgique'));
    
    switch(portal) {
      case 'immoweb':
        return `https://www.immoweb.be/fr/recherche/${propertyType}/a-${transactionShort}?countries=BE&query=${location}`;
      case 'logic-immo':
        return `https://www.logic-immo.be/fr/recherche/${propertyType}-${transactionShort}.html?query=${location}`;
      case 'zimmo':
        return `https://www.zimmo.be/fr/search/?q=${location}&type=${propertyType}&transaction=${transactionShort}`;
      case 'tweedehands':
        return `https://www.tweedehands.be/q/${propertyType}/${transactionShort}/${location}/`;
      case 'vlan':
        return `https://www.vlan.be/fr/recherche/${propertyType}-${transactionShort}?q=${location}`;
      case 'heylen':
        return `https://www.heylen.be/fr/recherche?type=${propertyType}&purpose=${transactionShort}&location=${location}`;
      default:
        return `https://www.immoweb.be/fr/recherche/${propertyType}/a-${transactionShort}?countries=BE&query=${location}`;
    }
  };

  const createBroadSearchUrl = (property, portal = 'immoweb') => {
    const { transactionShort } = detectTransaction(property);
    const propertyType = detectPropertyType(property);
    const { postalCode, cityName } = parseLocation(property.location);
    const location = encodeURIComponent(postalCode ? `${postalCode}` : (cityName || 'Belgique'));
    
    switch(portal) {
      case 'immoweb':
        return `https://www.immoweb.be/fr/recherche/${propertyType}/a-${transactionShort}?countries=BE&query=${location}`;
      case 'logic-immo':
        return `https://www.logic-immo.be/fr/recherche/${propertyType}-${transactionShort}.html?query=${location}`;
      default:
        return `https://www.immoweb.be/fr/recherche/${propertyType}/a-${transactionShort}?countries=BE&query=${location}`;
    }
  };

  const createGoogleSearchUrl = (criteria) => {
    const searchTerms = [];
    if (criteria.property_type) searchTerms.push(criteria.property_type);
    if (criteria.transaction_type === 'location') searchTerms.push('à louer');
    else searchTerms.push('à vendre');
    if (criteria.location) searchTerms.push(criteria.location);
    else searchTerms.push('Belgique');
    if (criteria.max_budget) searchTerms.push(`max ${criteria.max_budget}€`);
    if (criteria.min_bedrooms) searchTerms.push(`${criteria.min_bedrooms} chambres`);
    searchTerms.push('site:immoweb.be OR site:logic-immo.be OR site:zimmo.be');
    
    return `https://www.google.com/search?q=${encodeURIComponent(searchTerms.join(' '))}`;
  };

  // Gestion du basculement de sélection d'un bien pour le partage
  const togglePropertySelection = (index) => {
    setSelectedProperties(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  const handleClientUpdated = (updatedClient) => {
    if (!updatedClient?.id) return;
    setClients((prev) => prev.map((c) => (c.id === updatedClient.id ? updatedClient : c)));
    if (searchingForClient?.id === updatedClient.id) {
      setSearchingForClient(updatedClient);
    }
  };

  // Partage WhatsApp et Email (uniquement les biens sélectionnés)
  const handleShare = async (platform) => {
    if (!searchResults || searchResults.length === 0) return;
    
    const itemsToShare = searchResults.filter((_, index) => selectedProperties[index]);
    if (itemsToShare.length === 0) {
      alert("Veuillez sélectionner au moins un bien à partager en cochant la case correspondante.");
      return;
    }

    let text = `Bonjour, voici une sélection de biens correspondant à vos critères (${searchingForClient?.name || 'Recherche'}) :\n\n`;
    itemsToShare.forEach((prop, index) => {
      text += `*${index + 1}. ${prop.title}*\n`;
      text += `💰 Prix: ${prop.price}\n`;
      text += `📍 Lieu: ${prop.location}\n`;
      text += `🔗 Lien: ${prop.url}\n\n`;
    });
    text += `N'hésitez pas à me dire ceux qui vous intéressent !`;

    if (platform === 'whatsapp') {
      const cleanPhone = String(searchingForClient?.phone || '').replace(/[^\d+]/g, '').replace(/^\+/, '');
      const waUrl = cleanPhone
        ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`
        : `https://wa.me/?text=${encodeURIComponent(text)}`;
      window.open(waUrl, '_blank');
    } else if (platform === 'email') {
      const subject = encodeURIComponent(`Sélection immobilière - ${searchingForClient?.name || ''}`);
      const recipient = searchingForClient?.email || '';
      window.open(`mailto:${recipient}?subject=${subject}&body=${encodeURIComponent(text)}`, '_blank');
    }

    if (searchingForClient?.id) {
      const now = new Date().toISOString();
      const entries = itemsToShare.map((prop) => {
        const isDirectLink = prop.url && prop.url.startsWith('http') && !prop.url.includes('google.com/search');
        return {
          type: 'annonce',
          channel: platform,
          title: prop.title || 'Annonce immobilière',
          details: [prop.price, prop.location].filter(Boolean).join(' • '),
          url: isDirectLink ? prop.url : createSpecificGoogleSearchUrl(prop),
          date: now
        };
      });
      const updated = await appendClientActivities(searchingForClient, entries);
      handleClientUpdated(updated);
    }
  };

  // Calcul de rentabilité
  const calculateYield = (priceNum, estimatedRent) => {
    if (!priceNum || !estimatedRent || priceNum <= 0) return null;
    const totalCost = priceNum * 1.125; 
    const annualRent = estimatedRent * 12;
    const grossYield = (annualRent / totalCost) * 100;
    return grossYield.toFixed(2);
  };

  const handleSearch = async (client, onActionStart, force = false) => {
    if (force) {
      setIntegrationLimitHit(false);
      setCacheInfo(null);
      setSearchResults(null);
    }
    const canProceed = await onActionStart();
    if (!canProceed) return;

    setSearchingForClient(client);
    setIsSearching(true);
    setSearchResults(null);
    setViewMode('list');
    // Chaque nouvelle recherche repart avec les filtres ouverts et le budget du client
    setPrecisionFilters({
      ...DEFAULT_PRECISION_FILTERS,
      maxBudget: Number(client.search_criteria?.max_budget) || null
    });

    const criteria = client.search_criteria;

    // 🔒 La recherche est exécutée côté serveur : l'intégration IA et le quota
    // freemium ne sont plus accessibles depuis le navigateur.
    try {
      const aiResponse = await base44.functions.invoke('searchPropertyMatches', { criteria });
      const payload = aiResponse?.data || aiResponse || {};
      const rawProperties = Array.isArray(payload.properties) ? payload.properties : [];

      setIntegrationLimitHit(false);
      setCacheInfo(null);
      setSearchMeta({
        strictMatches: rawProperties.length,
        discardedCount: payload.discarded_count || 0,
        noResultsReason: payload.no_results_reason || null,
        fromCache: false
      });

      const deduped = deduplicateProperties(rawProperties);
      setSearchResults(deduped);

      if (deduped.length > 0) {
        
        // Sélectionner par défaut tous les biens trouvés
        const initialSel = {};
        deduped.forEach((_, i) => { initialSel[i] = true; });
        setSelectedProperties(initialSel);
        
        for (const prop of rawProperties) {
          try {
            const isDirectLink = prop.url && prop.url.startsWith('http') && !prop.url.includes('google.com/search');
            await PropertyMatch.create({
              client_id: client.id,
              property_title: prop.title,
              property_price: prop.price,
              property_location: prop.location,
              property_url: isDirectLink ? prop.url : createSpecificGoogleSearchUrl(prop),
              property_details: JSON.stringify(prop),
              correspondence_score: prop.correspondence_score || 'N/A',
              status: 'nouveau',
              notified: false
            });
          } catch (err) {
            console.error("Erreur sauvegarde match:", err);
          }
        }
        await loadClients();
      }
    } catch (error) {
      console.error("Erreur recherche:", error); 
      const genericSearchUrl = createGoogleSearchUrl(criteria);

      const isLimit = error?.status === 402 || /limit of integrations/i.test(error?.message || '') || error?.data?.extra_data?.reason === 'integration_credits_limit_reached';
      if (isLimit) {
        setIntegrationLimitHit(true);
        const cached = getClientMatches(client.id).sort((a,b) => new Date(b.created_date) - new Date(a.created_date));
        if (cached.length > 0) {
          const normalized = cached.slice(0, 6).map((m) => {
            let details = {};
            try { details = JSON.parse(m.property_details || '{}'); } catch (_) {}
            return {
              title: m.property_title || details.title || 'Annonce immobilière',
              price: m.property_price || details.price || 'N/A',
              price_num: details.price_num || 0,
              location: m.property_location || details.location || (criteria.location || 'Belgique'),
              lat: details.lat, lng: details.lng,
              estimated_rent_num: details.estimated_rent_num,
              summary: details.summary || 'Résultat précédent (cache) sauvegardé',
              bedrooms: details.bedrooms || 'N/A',
              surface: details.surface || 'N/A',
              features: details.features || undefined,
              correspondence_score: m.correspondence_score || details.correspondence_score || 'N/A',
              match_analysis: details.match_analysis || 'Affichage du cache (crédits épuisés)',
              url: m.property_url || genericSearchUrl
            };
          });
          setSearchResults(normalized);
          const initialSel = {};
          normalized.forEach((_, i) => { initialSel[i] = true; });
          setSelectedProperties(initialSel);
          setCacheInfo({ count: cached.length, lastDate: cached[0].created_date });
          setSearchMeta({
            strictMatches: normalized.length,
            discardedCount: 0,
            noResultsReason: null,
            fromCache: true
          });
        }
      }
    } finally {
      setIsSearching(false);
    }
  };

  const handleRefineCriteria = async (client) => {
    if (!client) return;
    setIsRefining(true);
    try {
      const response = await refineSearchCriteria({ criteria: client.search_criteria || {} });
      const refined = response?.data?.refined || response?.refined;
      if (!refined) throw new Error("Aucun critère affiné retourné");

      setRefinedInfo({ clientId: client.id, clientName: client.name, ...refined });

      if (refined.postalCode) {
        const coords = await geolocatePostalCode(refined.postalCode);
        setGpsCoords(coords);
      }
    } catch (error) {
      console.error("Erreur lors de l'affinage des critères:", error);
      setRefinedInfo({
        clientId: client.id,
        clientName: client.name,
        error: "L'affinage automatique a échoué. Merci de réessayer dans un instant."
      });
    } finally {
      setIsRefining(false);
    }
  };

  const handleAddNew = () => {
    setEditingClient(null);
    reset();
    setShowForm(true);
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingClient(null);
    reset();
  };

  const getClientMatches = (clientId) => {
    return propertyMatches.filter(m => m.client_id === clientId);
  };

  const getNewMatchesCount = (clientId) => {
    return propertyMatches.filter(m => m.client_id === clientId && m.status === 'nouveau').length;
  };

  const clientBudget = Number(searchingForClient?.search_criteria?.max_budget) || 0;
  const budgetCeiling = getBudgetCeiling(searchResults, clientBudget);

  const resetPrecisionFilters = () => applyPrecisionFilters({
    ...DEFAULT_PRECISION_FILTERS,
    maxBudget: clientBudget || null
  });

  // Appliquer un filtre retire de la sélection les biens qu'il masque
  const applyPrecisionFilters = (nextFilters) => {
    setPrecisionFilters(nextFilters);
    if (!Array.isArray(searchResults)) return;

    const stillVisible = {};
    filterPropertiesByPrecision(searchResults, nextFilters, budgetCeiling).forEach(({ index }) => {
      stillVisible[index] = selectedProperties[index] !== false;
    });
    setSelectedProperties(stillVisible);
  };

  const precisionSources = getPropertySources(searchResults);
  const visibleResults = filterPropertiesByPrecision(searchResults, precisionFilters, budgetCeiling);

  const defaultCenter = [50.8503, 4.3517];

  return (
    <LimitChecker feature="immo_search_count">
      {({ onActionStart, remainingActions, currentPlan }) => (
        <div className="p-4 md:p-8">
          <div className="max-w-6xl mx-auto">
            
            <div className="text-center mb-6 md:mb-8 px-1">
              <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900 leading-tight">IMMO BOOST - Mes Recherches</h1>
              {currentPlan === 'free' && (
                <div className="mt-2 flex justify-center">
                  <Badge className={remainingActions === 0 ? "bg-red-100 text-red-800" : "bg-yellow-100 text-yellow-800"}>
                    {remainingActions === 0 ? "⚠️ Limite atteinte" : `${remainingActions} recherche${remainingActions > 1 ? 's' : ''} restante${remainingActions > 1 ? 's' : ''}`}
                  </Badge>
                </div>
              )}
              <p className="text-sm md:text-base text-gray-600 mt-2">Matching automatique et suivi intelligent des opportunités immobilières</p>
            </div>

        <div className="flex flex-col sm:flex-row sm:flex-wrap sm:justify-end gap-2 mb-6">
          <Button variant="outline" onClick={() => exportClientsCsv(clients)} disabled={clients.length === 0} className="w-full sm:w-auto justify-center sm:justify-start">
            <Download className="w-4 h-4 mr-2" />
            <span className="text-sm">Exporter clients (CSV)</span>
          </Button>
          <Button variant="outline" onClick={() => exportPropertiesCsv(propertyMatches, clients)} disabled={propertyMatches.length === 0} className="w-full sm:w-auto justify-center sm:justify-start">
            <FileSpreadsheet className="w-4 h-4 mr-2" />
            <span className="text-sm">Exporter biens (CSV)</span>
          </Button>
          <Button onClick={handleAddNew} className="w-full sm:w-auto justify-center sm:justify-start">
            <Plus className="w-4 h-4 mr-2" />
            <span className="text-sm">Ajouter une recherche</span>
          </Button>
        </div>

        {(isSearching || searchResults) && (
          <Card className="mb-8 bg-blue-50 border-blue-200">
            <CardHeader>
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <CardTitle className="flex items-center gap-2 text-blue-800 text-sm sm:text-base">
                    <Sparkles className="w-5 h-5 shrink-0" />
                    <span className="break-words">Résultats pour {searchingForClient?.name}</span>
                  </CardTitle>
                  <p className="text-sm text-blue-700 mt-1">
                    Cochez les biens à inclure puis partagez votre sélection.
                  </p>
                </div>
                
                <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                  {!isSearching && searchResults?.length > 0 && (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="sm" className="bg-white">
                          <Share2 className="w-4 h-4 mr-2" />
                          Partager la sélection ({Object.values(selectedProperties).filter(Boolean).length})
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleShare('whatsapp')} className="cursor-pointer text-green-600">
                          <MessageCircle className="w-4 h-4 mr-2" /> Envoyer par WhatsApp
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleShare('email')} className="cursor-pointer text-blue-600">
                          <Mail className="w-4 h-4 mr-2" /> Envoyer par Email
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  )}
                  
                  {!isSearching && searchResults?.length > 0 && (
                    <div className="flex bg-white rounded-md border p-0.5">
                      <Button variant={viewMode === 'list' ? 'secondary' : 'ghost'} size="sm" onClick={() => setViewMode('list')} className="h-7 px-2">
                        <List className="w-4 h-4 mr-1" /> Liste
                      </Button>
                      <Button variant={viewMode === 'map' ? 'secondary' : 'ghost'} size="sm" onClick={() => setViewMode('map')} className="h-7 px-2">
                        <MapIcon className="w-4 h-4 mr-1" /> Carte
                      </Button>
                    </div>
                  )}

                  {cacheInfo && (
                    <Button variant="outline" size="sm" onClick={() => handleSearch(searchingForClient, onActionStart, true)}>
                      Forcer nouvelle recherche
                    </Button>
                  )}
                  <Button variant="ghost" size="icon" onClick={() => setSearchResults(null)} className="shrink-0">
                    <X className="w-5 h-5" />
                  </Button>
                </div>
              </div>

              {integrationLimitHit && (
                <div className="mt-3">
                  <Alert variant="destructive">
                    <AlertTitle className="flex items-center gap-2"><AlertTriangle className="w-4 h-4" /> Crédits épuisés</AlertTitle>
                    <AlertDescription>
                      Recherches IA indisponibles. Continuez en recherche manuelle ou <Link to={createPageUrl('Pricing')} className="underline font-medium">mettez à niveau</Link>.
                    </AlertDescription>
                  </Alert>
                </div>
              )}
            </CardHeader>

            <CardContent>
              {!isSearching && searchMeta && (
                <div className="mb-4 rounded-lg border border-blue-200 bg-white p-3 text-xs text-blue-900 space-y-1">
                  <p className="font-semibold flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                    Recherche stricte : les critères ne sont pas élargis automatiquement.
                  </p>
                  <p>
                    {searchMeta.strictMatches} annonce{searchMeta.strictMatches > 1 ? 's' : ''} vérifiable{searchMeta.strictMatches > 1 ? 's' : ''}
                    {searchMeta.discardedCount > 0 && ` • ${searchMeta.discardedCount} écartée${searchMeta.discardedCount > 1 ? 's' : ''} (lien ou informations non vérifiables)`}
                    {searchMeta.fromCache && ' • résultats enregistrés, à reconfirmer'}
                  </p>
                </div>
              )}

              {!isSearching && searchResults?.length > 0 && (
                <PrecisionFilters
                  sources={precisionSources}
                  value={precisionFilters}
                  onChange={applyPrecisionFilters}
                  onReset={resetPrecisionFilters}
                  budgetCeiling={budgetCeiling}
                  clientBudget={clientBudget}
                  shownCount={visibleResults.length}
                  totalCount={searchResults.length}
                />
              )}

              {isSearching ? (
                <div className="text-center py-8">
                  <Loader2 className="w-8 h-8 animate-spin mx-auto text-blue-600 mb-4" />
                  <p className="text-blue-700">Analyse et calculs de rentabilité en cours...</p>
                </div>
              ) : searchResults && searchResults.length > 0 && visibleResults.length === 0 ? (
                <div className="text-center py-8 space-y-3">
                  <p className="text-sm text-gray-600">
                    Aucune annonce ne correspond à ces filtres de précision. Vos critères de recherche restent inchangés.
                  </p>
                  <Button variant="outline" size="sm" onClick={resetPrecisionFilters}>
                    Réinitialiser les filtres
                  </Button>
                </div>
              ) : searchResults && searchResults.length > 0 ? (
                
                viewMode === 'map' ? (
                  <div className="h-[500px] w-full rounded-lg overflow-hidden border border-blue-200 relative z-0">
                    <MapContainer 
                      center={searchResults[0]?.lat && searchResults[0]?.lng ? [searchResults[0].lat, searchResults[0].lng] : defaultCenter} 
                      zoom={11} 
                      style={{ height: '100%', width: '100%' }}
                    >
                      <TileLayer
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      />
                      {visibleResults.map(({ property: prop, index: idx }) => {
                        let lat = prop.lat;
                        let lng = prop.lng;
                        
                        // CORRECTION : Utilisation intelligente de geolocatePostalCode
                        if (!lat || !lng) {
                          const { postalCode } = parseLocation(prop.location);
                          const geo = geolocatePostalCode(postalCode);
                          
                          if (geo && (geo.lat || geo.latitude) && (geo.lng || geo.lon || geo.longitude)) {
                            // On injecte un micro-décalage de 0.005 pour éviter que les biens 
                            // d'un même code postal ne soient empilés exactement au même endroit
                            lat = (geo.lat || geo.latitude) + (Math.random() - 0.5) * 0.005;
                            lng = (geo.lng || geo.lon || geo.longitude) + (Math.random() - 0.5) * 0.005;
                          } else {
                            // Fallback par défaut vers Bruxelles si la fonction échoue
                            lat = defaultCenter[0] + (Math.random() - 0.5) * 0.1;
                            lng = defaultCenter[1] + (Math.random() - 0.5) * 0.1;
                          }
                        }

                        const isDirectLink = prop.url && prop.url.startsWith('http') && !prop.url.includes('google.com/search');
                        const yieldRate = calculateYield(prop.price_num, prop.estimated_rent_num);

                        return (
                          <Marker key={idx} position={[lat, lng]}>
                            <Popup className="w-64">
                              <div className="flex flex-col gap-2">
                                <span className="font-bold text-sm leading-tight">{prop.title}</span>
                                <span className="text-blue-600 font-bold">{prop.price || 'Prix non communiqué'}</span>
                                <span className="text-xs text-gray-500">
                                  {prop.source ? `Source : ${prop.source}` : ''}{prop.verified ? ' • annonce vérifiée' : ''}
                                </span>
                                {yieldRate && (
                                  <Badge className="bg-purple-100 text-purple-800 w-fit">
                                    <TrendingUp className="w-3 h-3 mr-1" /> Rendement {yieldRate}%
                                  </Badge>
                                )}
                                <div className="flex items-center gap-2 mt-1">
                                  <input 
                                    type="checkbox" 
                                    checked={!!selectedProperties[idx]} 
                                    onChange={() => togglePropertySelection(idx)}
                                    className="w-4 h-4 text-blue-600 rounded cursor-pointer"
                                  />
                                  <span className="text-xs text-gray-600">Sélectionner pour partage</span>
                                </div>
                                <Button asChild size="sm" className="w-full mt-2">
                                  <a href={isDirectLink ? prop.url : createSpecificGoogleSearchUrl(prop)} target="_blank" rel="noopener noreferrer">
                                    Voir l'annonce
                                  </a>
                                </Button>
                              </div>
                            </Popup>
                          </Marker>
                        )
                      })}
                    </MapContainer>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {visibleResults.map(({ property: prop, index }) => {
                      const isDirectLink = prop.url && prop.url.startsWith('http') && !prop.url.includes('google.com/search');
                      const yieldRate = calculateYield(prop.price_num, prop.estimated_rent_num);
                      
                      return (
                      <Card key={index} className={`hover:shadow-md transition-shadow relative overflow-hidden border-2 ${selectedProperties[index] ? 'border-blue-500 bg-white' : 'border-transparent bg-gray-50/50'}`}>
                        
                        {yieldRate && (
                          <div className="absolute top-0 right-0 bg-purple-600 text-white text-xs font-bold px-3 py-1 rounded-bl-lg flex items-center shadow-sm z-10">
                            <TrendingUp className="w-3 h-3 mr-1" /> Rendement Brut ~{yieldRate}%
                          </div>
                        )}

                        <CardHeader className={yieldRate ? "pt-8" : ""}>
                          {/* Case à cocher pour sélection de partage */}
                          <div className="flex items-center justify-between bg-blue-50/80 p-2 rounded-md mb-2 border border-blue-100">
                            <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-blue-900">
                              <input 
                                type="checkbox" 
                                checked={!!selectedProperties[index]} 
                                onChange={() => togglePropertySelection(index)}
                                className="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500 cursor-pointer"
                              />
                              {selectedProperties[index] ? '✅ Sélectionné pour le partage' : '⬜ Cliquer pour inclure au partage'}
                            </label>
                          </div>

                          <div className="flex justify-between items-start gap-2 mb-2">
                            <CardTitle className="text-base leading-tight break-words">{prop.title}</CardTitle>
                          </div>
                          <div className="flex justify-between items-center gap-2">
                            <p className="text-base sm:text-lg font-bold text-blue-600">
                              {prop.price && String(prop.price).trim() ? prop.price : 'Prix non communiqué'}
                            </p>
                          </div>
                          <div className="mt-2">
                            <VerificationBadges property={prop} />
                          </div>
                          <p className="text-sm text-gray-500 flex items-center">
                            <MapPin className="w-4 h-4 mr-1" />
                            {prop.location}
                          </p>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {(prop.bedrooms || prop.surface) && (
                              <div className="flex gap-4 text-sm text-gray-600">
                                {prop.bedrooms && (
                                  <span className="flex items-center">
                                    <BedDouble className="w-4 h-4 mr-1" />
                                    {prop.bedrooms} ch.
                                  </span>
                                )}
                                {prop.surface && (
                                  <span className="flex items-center">
                                    <Home className="w-4 h-4 mr-1" />
                                    {prop.surface}
                                  </span>
                                )}
                              </div>
                            )}

                            {yieldRate && prop.estimated_rent_num > 0 && (
                              <div className="bg-purple-50 text-purple-800 text-xs p-2 rounded border border-purple-100 flex items-center gap-2">
                                <Euro className="w-3.5 h-3.5" /> 
                                Loyer estimé: <strong>{prop.estimated_rent_num}€/mois</strong>. 
                                Calculé avec ~12.5% de frais d'achat.
                              </div>
                            )}
                            
                            {prop.features && (
                              <p className="text-sm text-green-700 font-medium">✨ {prop.features}</p>
                            )}
                            <p className="text-sm text-gray-700">{prop.summary}</p>
                            
                            {prop.match_analysis && (
                              <div className="bg-blue-50 p-3 rounded-lg border border-blue-200 mt-2">
                                <p className="text-xs text-blue-700">{prop.match_analysis}</p>
                              </div>
                            )}
                          </div>
                          
                          <QuickLookPopover url={isDirectLink ? prop.url : createSpecificGoogleSearchUrl(prop)} property={prop} />

                          <div className="flex flex-col gap-2 mt-4">
                            {isDirectLink && (
                              <Button asChild size="sm" className="w-full bg-green-600 hover:bg-green-700 text-white">
                                <a href={prop.url} target="_blank" rel="noopener noreferrer" onClick={() => markAsViewed(prop, 'direct')}>
                                  <ExternalLink className="w-4 h-4 mr-2" />
                                  Consulter l'annonce originale
                                </a>
                              </Button>
                            )}

                            {isDirectLink && prop.verified && searchingForClient && (
                              <ListingToClientFileButton
                                property={prop}
                                client={searchingForClient}
                                onClientUpdated={handleClientUpdated}
                              />
                            )}

                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button size="sm" variant={isDirectLink ? "outline" : "default"} className="w-full">
                                  Chercher sur les portails <ChevronDown className="w-4 h-4 ml-2" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent className="w-64">
                                <DropdownMenuItem asChild>
                                  <a href={createSpecificGoogleSearchUrl(prop)} target="_blank" rel="noopener noreferrer" onClick={() => markAsViewed(prop, 'immoweb-exact')}>
                                    <span>🎯 Immoweb (Critères précis)</span>
                                  </a>
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem asChild>
                                  <a href={createBroadSearchUrl(prop, 'immoweb')} target="_blank" rel="noopener noreferrer" className="text-blue-700" onClick={() => markAsViewed(prop, 'immoweb-broad')}>
                                    <span>🏠 Immoweb (Élargir la zone)</span>
                                  </a>
                                </DropdownMenuItem>
                                <DropdownMenuItem asChild>
                                  <a href={createPortalUrl(prop, 'zimmo')} target="_blank" rel="noopener noreferrer" onClick={() => markAsViewed(prop, 'zimmo')}>
                                    <span>🌐 Zimmo</span>
                                  </a>
                                </DropdownMenuItem>
                                <DropdownMenuItem asChild>
                                  <a href={createPortalUrl(prop, 'vlan')} target="_blank" rel="noopener noreferrer" onClick={() => markAsViewed(prop, 'vlan')}>
                                    <span>🏘️ Vlan</span>
                                  </a>
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </CardContent>
                      </Card>
                    )})}
                  </div>
                )
              ) : (
                <StrictEmptyState
                  criteria={searchingForClient?.search_criteria || {}}
                  reason={searchMeta?.noResultsReason}
                  discardedCount={searchMeta?.discardedCount || 0}
                />
              )}
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className={`lg:col-span-2 ${showForm ? '' : 'lg:col-span-3'}`}>
            <Card>
              <CardHeader><CardTitle>Mes Recherches</CardTitle></CardHeader>
              <CardContent>
                {integrationLimitHit && <ManualSearchAssistant criteria={searchingForClient?.search_criteria || {}} />}
                {isLoading ? (
                  <div className="text-center py-8"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></div>
                ) : clients.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <User className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>Aucune recherche pour le moment.</p>
                    <Button onClick={handleAddNew} className="mt-4">Ajouter votre première recherche</Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                    {clients.map((client) => {
                      const matchesCount = getNewMatchesCount(client.id); 
                      return (
                        <Card key={client.id} className="relative"> 
                          {matchesCount > 0 && ( 
                            <div className="absolute -top-2 -right-2 z-10">
                              <Badge className="bg-red-500 text-white animate-pulse">{matchesCount} nouveau{matchesCount > 1 ? 'x' : ''}</Badge>
                            </div>
                          )}
                          <CardHeader>
                            <div className="flex flex-col gap-2">
                              <div className="flex justify-between items-start gap-2">
                                <CardTitle className="text-base sm:text-lg leading-tight break-words">{client.name}</CardTitle>
                                <div className="flex items-center gap-1.5 shrink-0">
                                  <WandRefineButton onConfirm={() => handleRefineCriteria(client)} disabled={isRefining} />
                                  <Button onClick={() => handleSearch(client, onActionStart)} size="icon" variant="outline" className="bg-blue-50 text-blue-700 h-9 w-9"><Search className="w-4 h-4" /></Button>
                                  <Button onClick={() => handleEdit(client)} size="icon" variant="outline" className="h-9 w-9"><Edit className="w-4 h-4" /></Button>
                                  <Button onClick={() => handleDelete(client)} size="icon" variant="outline" className="text-red-500 hover:bg-red-50 h-9 w-9"><Trash2 className="w-4 h-4" /></Button>
                                </div>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <h4 className="font-semibold mb-2">Critères de recherche :</h4>
                            <div className="space-y-2 text-sm text-gray-700">
                              <div className="flex items-center gap-2"><Tag className="w-4 h-4 text-gray-500" /><Badge variant="secondary">{client.search_criteria?.transaction_type === 'location' ? 'À louer' : 'À vendre'}</Badge></div>
                              <div className="flex items-center gap-2"><Home className="w-4 h-4 text-gray-500" /><Badge variant="secondary">{client.search_criteria?.property_type || 'N/A'}</Badge></div>
                              <div className="flex items-center gap-2"><MapPin className="w-4 h-4 text-gray-500" /><span>{client.search_criteria?.location || 'N/A'}</span></div>
                              <div className="flex items-center gap-2"><Euro className="w-4 h-4 text-gray-500" /><span>Budget max: {client.search_criteria?.max_budget || 'N/A'} €</span></div>
                            </div>

                            {refinedInfo?.clientId === client.id && (
                              <div className="mt-4 rounded-lg border border-purple-200 bg-purple-50 p-3 text-sm">
                                {refinedInfo.error ? (
                                  <p className="text-purple-900">{refinedInfo.error}</p>
                                ) : (
                                  <>
                                    <div className="flex items-center gap-1.5 font-semibold text-purple-800 mb-2">
                                      <Sparkles className="w-4 h-4" />
                                      Critères affinés par l'IA
                                    </div>
                                    <div className="space-y-1 text-purple-900">
                                      <p>Budget max : {refinedInfo.maxPrice ? `${refinedInfo.maxPrice} €` : 'N/A'}</p>
                                      <p>Chambres min : {refinedInfo.minBedrooms || 'N/A'}</p>
                                      <p>
                                        Zone : {[refinedInfo.postalCode, refinedInfo.cityName].filter(Boolean).join(' ') || 'Belgique'}
                                        {refinedInfo.radiusKm ? ` (+${refinedInfo.radiusKm} km)` : ''}
                                      </p>
                                      <p>Confiance : {refinedInfo.confidence ?? 'N/A'}%</p>
                                      {refinedInfo.reasoning && (
                                        <p className="text-xs italic text-purple-700 mt-1">{refinedInfo.reasoning}</p>
                                      )}
                                    </div>
                                  </>
                                )}
                              </div>
                            )}

                            <ClientActivityHistory
                              client={client}
                              matches={getClientMatches(client.id)}
                              onClientUpdated={handleClientUpdated}
                            />
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {showForm && (
            <div className="lg:col-span-1">
              <Card className="sticky top-4">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    {editingClient ? 'Modifier' : 'Nouvelle recherche'}
                    <Button onClick={handleCancel} size="sm" variant="ghost"><X className="w-4 h-4" /></Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div><Label>Nom *</Label><Input {...register("name", { required: true })} /></div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div><Label>Email</Label><Input type="email" {...register("email")} /></div>
                      <div><Label>Téléphone</Label><Input {...register("phone")} /></div>
                    </div>
                    <h4 className="font-semibold pt-4 border-t">Critères</h4>
                    <div>
                      <Label>Transaction *</Label>
                      <Controller name="transaction_type" control={control} rules={{ required: true }} render={({ field }) => (
                        <Select onValueChange={field.onChange} value={field.value}>
                          <SelectTrigger><SelectValue placeholder="À vendre ou louer ?" /></SelectTrigger>
                          <SelectContent><SelectItem value="vente">À vendre</SelectItem><SelectItem value="location">À louer</SelectItem></SelectContent>
                        </Select>
                      )} />
                    </div>
                    <div>
                      <Label>Type *</Label>
                      <Controller name="property_type" control={control} rules={{ required: true }} render={({ field }) => (
                        <Select onValueChange={field.onChange} value={field.value}>
                          <SelectTrigger><SelectValue placeholder="Type" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="maison">Maison</SelectItem>
                            <SelectItem value="appartement">Appartement</SelectItem>
                            <SelectItem value="terrain">Terrain</SelectItem>
                            <SelectItem value="commerce">Commerce</SelectItem>
                          </SelectContent>
                        </Select>
                      )} />
                    </div>
                    <div><Label>Localisation *</Label><Input {...register("location", { required: true })} /></div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div><Label>Chambres min.</Label><Input type="number" {...register("min_bedrooms")} /></div>
                      <div><Label>Budget max (€)</Label><Input type="number" {...register("max_budget")} /></div>
                    </div>
                    <Button type="submit" className="w-full">{editingClient ? 'Sauvegarder' : 'Ajouter'}</Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          )}
          </div>
        </div>
        </div>
      )}
    </LimitChecker>
  );
}