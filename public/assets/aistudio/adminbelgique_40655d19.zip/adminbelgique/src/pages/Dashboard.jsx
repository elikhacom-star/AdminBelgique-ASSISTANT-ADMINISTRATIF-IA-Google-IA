import React, { useState, useEffect, useMemo, useCallback } from "react";
import { User } from "@/entities/User";
import { Demarche } from "@/entities/Demarche";
import { Notification } from "@/entities/Notification";
import { Button } from "@/components/ui/button";
import { Loader2, PlusCircle, LayoutGrid, Bell, RefreshCw, Settings } from "lucide-react";
import SummaryStats from "../components/dashboard/SummaryStats";
import DemarcheCard from "../components/dashboard/DemarcheCard";
import NotificationItem from "../components/dashboard/NotificationItem";
import DemarcheForm from "../components/dashboard/DemarcheForm";
import { AnimatePresence } from "framer-motion";
import UsageStats from "../components/freemium/UsageStats";
import UsageAnalytics from "../components/analytics/UsageAnalytics";
import WhatsAppConnect from "../components/whatsapp/WhatsAppConnect";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { base44 } from "@/api/base44Client";
import PullToRefresh from "@/components/common/PullToRefresh";
import { useTranslation } from "../components/localization/useTranslation";

export default function Dashboard() {
  const { t } = useTranslation();
  const [user, setUser] = useState(null);
  const [demarches, setDemarches] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingDemarche, setEditingDemarche] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const loadDashboardData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [currentUser, demarchesData, notificationsData] = await Promise.all([
        User.me().catch(() => null), // Gérer le cas où l'utilisateur n'est pas connecté
        Demarche.list("-due_date"),
        Notification.list("-created_date"),
      ]);
      
      setUser(currentUser);
      setDemarches(Array.isArray(demarchesData) ? demarchesData : []);
      setNotifications(Array.isArray(notificationsData) ? notificationsData.filter(n => !n.is_read) : []);

    } catch (error) {
      console.error("Erreur lors du chargement du tableau de bord:", error);
    } finally {
      setIsLoading(false);
    }
  }, []); // Empty dependency array means this function is created once

  useEffect(() => {
    loadDashboardData();
  }, [loadDashboardData]);

  const stats = useMemo(() => {
    return {
      inProgress: demarches.filter(d => d.status === 'en_cours').length,
      toDo: demarches.filter(d => d.status === 'a_faire').length,
      completed: demarches.filter(d => d.status === 'termine').length,
    };
  }, [demarches]);

  const handleDismissNotification = async (id) => {
    // Optimistic UI update
    setNotifications(prev => prev.filter(n => n.id !== id));
    try {
      await Notification.update(id, { is_read: true });
    } catch (error) {
      console.error("Erreur lors de la mise à jour de la notification:", error);
      // Rollback not implemented for simplicity, but could be added here
    }
  };
  
  const handleEditDemarche = (demarche) => {
    setEditingDemarche(demarche);
    setShowForm(true);
  };
  
  const handleAddNewDemarche = () => {
    setEditingDemarche(null);
    setShowForm(true);
  };
  
  const handleSubmitDemarche = async (formData) => {
    try {
      if (editingDemarche) {
        await Demarche.update(editingDemarche.id, formData);
      } else {
        await Demarche.create(formData);
      }
    } catch (error) {
      console.error("Erreur lors de la sauvegarde de la démarche:", error);
      alert("Une erreur est survenue.");
    } finally {
      setShowForm(false);
      setEditingDemarche(null);
      await loadDashboardData(); // Reload data to reflect changes
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return t("dashboard.greeting.morning");
    if (hour < 18) return t("dashboard.greeting.afternoon");
    return t("dashboard.greeting.evening");
  };

  const pullToRefresh = async () => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    await loadDashboardData();
    setTimeout(() => setIsRefreshing(false), 600);
  };

  useEffect(() => {}, [isRefreshing, loadDashboardData]);

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-yellow-500" />
      </div>
    );
  }

  return (
    <PullToRefresh isRefreshing={isRefreshing} onRefresh={pullToRefresh}>
      <div className="p-2 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl md:text-3xl font-bold text-gray-900">
              {getGreeting()}, {user?.full_name?.split(' ')[0] || 'Utilisateur'} !
            </h1>
            <p className="text-gray-600">
              {t("dashboard.welcome")}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={pullToRefresh} className="min-h-[44px]">
              <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              Rafraîchir
            </Button>
            <Button variant="outline" size="sm" onClick={() => setShowSettings(true)} className="min-h-[44px]">
              <Settings className="w-4 h-4 mr-2" />
              Réglages
            </Button>
          </div>
        </div>

        {/* Pull to Refresh indicator */}
        {isRefreshing && (
          <div className="mt-3 flex items-center gap-2 text-sm text-blue-700">
            <Loader2 className="w-4 h-4 animate-spin" /> Rafraîchissement...
          </div>
        )}
        
        {/* Formulaire (conditionnel) */}
        <AnimatePresence>
          {showForm && (
              <DemarcheForm
                demarche={editingDemarche}
                onSubmit={handleSubmitDemarche}
                onCancel={() => {
                  setShowForm(false);
                  setEditingDemarche(null); // Clear editing state on cancel
                }}
              />
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
          
          {/* Colonne principale */}
          <div className="lg:col-span-2 space-y-6">
            {/* Stats */}
            <SummaryStats stats={stats} />
            
            {/* Démarches */}
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold flex items-center gap-2">
                <LayoutGrid className="w-6 h-6 text-gray-700"/>
                {t("dashboard.active_demarches")}
              </h2>
              <Button onClick={handleAddNewDemarche}>
                <PlusCircle className="w-4 h-4 mr-2" />
                {t("dashboard.new_demarche")}
              </Button>
            </div>
            
            {demarches.filter(d => d.status !== 'termine').length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {demarches.filter(d => d.status !== 'termine').map(demarche => (
                  <DemarcheCard key={demarche.id} demarche={demarche} onEdit={handleEditDemarche} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 border-2 border-dashed rounded-lg">
                <p className="text-gray-500">{t("dashboard.no_demarches")}</p>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* NOUVEAU : WhatsApp */}
            <WhatsAppConnect />

            {/* Compteur d'utilisation */}
            <UsageStats />

            {/* Notifications */}
            <h2 className="text-2xl font-semibold flex items-center gap-2">
              <Bell className="w-6 h-6 text-gray-700"/>
              {t("dashboard.notifications")}
            </h2>
            {notifications.length > 0 ? (
              <div className="space-y-3">
                {notifications.map(notification => (
                  <NotificationItem 
                    key={notification.id} 
                    notification={notification} 
                    onDismiss={handleDismissNotification}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 border-2 border-dashed rounded-lg">
                <p className="text-gray-500">{t("dashboard.no_notifications")}</p>
              </div>
            )}
          </div>
        </div>

        {/* NOUVEAU : Analytics complètes */}
        <div className="mt-8">
          <h2 className="text-2xl font-semibold mb-6">📊 {t("dashboard.stats_title")}</h2>
          <UsageAnalytics />
        </div>
        {/* Settings dialog */}
        <Dialog open={showSettings} onOpenChange={setShowSettings}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Paramètres</DialogTitle>
              <DialogDescription>Gérer votre compte et vos données.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {isRefreshing && (
                <div className="mt-2 flex items-center gap-2 text-sm text-blue-700">
                  <span className="inline-block h-3 w-3 rounded-full bg-blue-500 animate-pulse" /> Mise à jour...
                </div>
              )}
              <button
                className="inline-flex items-center justify-center bg-red-600 hover:bg-red-700 text-white font-medium px-4 py-2 rounded-md w-full"
                onClick={async () => {
                  if (window.confirm('Confirmer la suppression définitive du compte ?')) {
                    await base44.auth.deleteAccount();
                    alert('Votre compte a été supprimé.');
                    window.location.href = '/';
                  }
                }}
              >
                Supprimer mon compte
              </button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      </div>
    </PullToRefresh>
  );
}