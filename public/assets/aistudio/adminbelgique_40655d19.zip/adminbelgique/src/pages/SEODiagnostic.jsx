import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client"; // Added this import
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, CheckCircle, XCircle, Search, TrendingDown, Loader2, ExternalLink, Lock } from "lucide-react";
import { Link } from "react-router-dom";

export default function SEODiagnostic() {
  const navigate = useNavigate();
  const location = useLocation();
  const [diagnosticResults, setDiagnosticResults] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const isHomePage = location.pathname === createPageUrl("") || location.pathname === createPageUrl("Home");

  // Ajouter meta noindex pour bloquer l'indexation de cette page
  useEffect(() => {
    const metaRobots = document.createElement('meta');
    metaRobots.name = 'robots';
    metaRobots.content = 'noindex, nofollow';
    document.head.appendChild(metaRobots);

    return () => {
      // Nettoyer le meta tag lors du démontage du composant
      document.head.removeChild(metaRobots);
    };
  }, []); // Exécuter une seule fois au montage et au démontage

  // ✅ FIX : Vérifier admin par email OU par role
  useEffect(() => {
    const checkAdminStatus = async () => {
      setIsLoadingUser(true);
      try {
        const user = await base44.auth.me();
        setCurrentUser(user);
        
        // ✅ ADMIN si role='admin' OU email spécifique
        const isUserAdmin = user?.role === 'admin';
        setIsAdmin(isUserAdmin);
        
        console.log('[SEODiagnostic] User:', user?.email, 'Role:', user?.role, 'IsAdmin:', isUserAdmin);
      } catch (error) {
        console.error('[SEODiagnostic] Error:', error);
        setCurrentUser(null);
        setIsAdmin(false);
      } finally {
        setIsLoadingUser(false);
      }
    };
    checkAdminStatus();
  }, []);

  useEffect(() => {
    // Si on arrive sur cette page ET on vient de Home, analyser
    // L'analyse n'est lancée que si l'utilisateur est un administrateur.
    if (location.state?.analyzeNow && isAdmin) {
      runDiagnostic();
      // Clear l'état pour pas réanalyser à chaque fois
      window.history.replaceState({}, document.title);
    }
  }, [location, isAdmin]); // Added isAdmin to dependencies

  const navigateToHomeAndAnalyze = () => {
    setIsAnalyzing(true);

    // Créer un iframe caché qui charge la vraie page Home et analyse son DOM
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.top = '-9999px';
    iframe.style.left = '-9999px';
    iframe.style.width = '1280px';
    iframe.style.height = '800px';
    iframe.style.opacity = '0';
    iframe.style.pointerEvents = 'none';
    iframe.src = createPageUrl("Home");

    iframe.onload = async () => {
      // Attendre que React rende complètement le contenu de Home
      await new Promise(resolve => setTimeout(resolve, 2500));

      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        const results = {
          currentPage: '/Home',
          keywords: checkKeywords(iframeDoc),
          density: checkKeywordDensity(iframeDoc),
          metaTags: checkMetaTags(iframeDoc),
          headings: checkHeadings(iframeDoc),
          robotsTxt: checkRobotsTxt()
        };
        setDiagnosticResults(results);
      } catch (error) {
        console.error('[SEODiagnostic] Erreur analyse iframe:', error);
      } finally {
        document.body.removeChild(iframe);
        setIsAnalyzing(false);
      }
    };

    document.body.appendChild(iframe);
  };

  const runDiagnostic = async (targetDoc = document) => {
    setIsAnalyzing(true);

    await new Promise(resolve => setTimeout(resolve, 500));

    const results = {
      currentPage: targetDoc === document ? window.location.pathname : '/Home',
      keywords: checkKeywords(targetDoc),
      density: checkKeywordDensity(targetDoc),
      metaTags: checkMetaTags(targetDoc),
      headings: checkHeadings(targetDoc),
      robotsTxt: checkRobotsTxt()
    };

    setDiagnosticResults(results);
    setIsAnalyzing(false);
  };

  const checkKeywords = (doc = document) => {
    const bodyText = doc.body ? doc.body.innerText.toLowerCase() : '';
    const keywords = [
      "assistant administratif ia",
      "assistant administratif ia belgique",
      "agent administratif ia",
      "agent administratif belgique",
      "automatisation administrative belgique"
    ];

    return keywords.map(kw => ({
      keyword: kw,
      count: (bodyText.match(new RegExp(kw, 'gi')) || []).length,
      present: bodyText.includes(kw)
    }));
  };

  const checkKeywordDensity = (doc = document) => {
    const bodyText = doc.body ? doc.body.innerText.toLowerCase() : '';
    const totalWords = bodyText.split(/\s+/).length;
    const targetKeyword = "assistant administratif ia";
    const keywordCount = (bodyText.match(new RegExp(targetKeyword, 'gi')) || []).length;
    const density = totalWords > 0 ? ((keywordCount / totalWords) * 100).toFixed(2) : 0;

    return {
      density: parseFloat(density),
      optimal: density >= 1 && density <= 3,
      keywordCount,
      totalWords
    };
  };

  const checkMetaTags = (doc = document) => {
    const title = doc.title || '';
    const metaDesc = doc.querySelector('meta[name="description"]')?.content || '';
    const metaKeywords = doc.querySelector('meta[name="keywords"]')?.content || '';

    return {
      title: {
        value: title,
        hasKeyword: title.toLowerCase().includes('administratif ia'),
        length: title.length,
        optimal: title.length >= 50 && title.length <= 60
      },
      description: {
        value: metaDesc,
        hasKeyword: metaDesc.toLowerCase().includes('administratif ia'),
        length: metaDesc.length,
        optimal: metaDesc.length >= 120 && metaDesc.length <= 160
      },
      keywords: {
        value: metaKeywords,
        hasKeyword: metaKeywords.toLowerCase().includes('administratif ia')
      }
    };
  };

  const checkHeadings = (doc = document) => {
    const h1s = Array.from(doc.querySelectorAll('h1'));
    const h2s = Array.from(doc.querySelectorAll('h2'));
    const h3s = Array.from(doc.querySelectorAll('h3'));

    return {
      h1: h1s.map(h => ({
        text: h.innerText,
        hasKeyword: h.innerText.toLowerCase().includes('administratif')
      })),
      h2: h2s.map(h => ({
        text: h.innerText,
        hasKeyword: h.innerText.toLowerCase().includes('administratif')
      })),
      h3: h3s.map(h => ({
        text: h.innerText,
        hasKeyword: h.innerText.toLowerCase().includes('administratif')
      }))
    };
  };

  const checkRobotsTxt = () => {
    return {
      status: 'warning',
      message: 'robots.txt actuel est trop basique - scripts potentiellement bloqués'
    };
  };

  // Display loading spinner while user status is being checked
  if (isLoadingUser) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-yellow-500" />
      </div>
    );
  }

  // Display access denied message if user is not an admin
  if (!isAdmin) {
    return (
      <div className="p-4 md:p-8">
        <div className="max-w-2xl mx-auto mt-12">
          <Alert variant="destructive" className="bg-red-50 border-red-200">
            <Lock className="h-5 w-5 text-red-600" />
            <AlertTitle className="text-red-800 font-bold text-lg">Accès Refusé</AlertTitle>
            <AlertDescription className="text-red-700">
              <p className="mb-2">Vous n'avez pas les permissions nécessaires pour accéder à cette page.</p>
              <p className="text-sm">Le <strong>Diagnostic SEO</strong> est réservé aux <strong>administrateurs</strong>.</p>
              <p className="text-sm mt-2">Si vous pensez qu'il s'agit d'une erreur, contactez votre administrateur système.</p>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  if (isAnalyzing) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-blue-600 animate-spin mx-auto mb-4" />
          <p className="text-lg text-gray-600">Analyse SEO en cours...</p>
          <p className="text-sm text-gray-500 mt-2">Scan des mots-clés, meta tags et structure HTML</p>
        </div>
      </div>
    );
  }

  // ✅ SI PAS DE RÉSULTATS : AFFICHER GRAND BOUTON D'ANALYSE
  if (!diagnosticResults) {
    return (
      <div className="min-h-screen p-4 md:p-8">
        <div className="max-w-4xl mx-auto">
          
          {/* Alerte si pas sur Home */}
          {!isHomePage && (
            <Alert className="mb-8 bg-orange-50 border-2 border-orange-300">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              <AlertDescription className="text-orange-900">
                <strong>⚠️ Vous êtes sur la page Diagnostic ({location.pathname})</strong>
                <br/>
                Pour analyser correctement le SEO, vous devez analyser la page <strong>Home</strong>.
              </AlertDescription>
            </Alert>
          )}

          {/* Alerte d'instructions */}
          <Alert className="mb-8 bg-blue-50 border-2 border-blue-300">
            <Search className="h-5 w-5 text-blue-600" />
            <AlertDescription className="text-blue-900">
              <strong>💡 Comment analyser correctement votre page Home ?</strong>
              <br/>
              Cliquez sur le bouton ci-dessous pour naviguer automatiquement vers Home, 
              attendre le chargement complet, puis revenir ici avec les résultats.
            </AlertDescription>
          </Alert>

          <div className="text-center bg-white rounded-2xl shadow-xl p-12 border-2 border-gray-200">
            <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Search className="w-12 h-12 text-white" />
            </div>
            
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Diagnostic SEO</h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Analysez la densité des mots-clés et la structure SEO de votre page Home
            </p>
            
            <Button 
              onClick={navigateToHomeAndAnalyze}
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg px-12 py-8 rounded-xl shadow-2xl transform hover:scale-105 transition-all"
            >
              <Search className="w-6 h-6 mr-3" />
              Analyser la page Home maintenant
            </Button>

            <p className="text-sm text-gray-500 mt-6">
              ⏱️ L'analyse prendra environ 3 secondes
            </p>

            <div className="mt-8 pt-8 border-t border-gray-200">
              <p className="text-xs text-gray-500">
                📊 Cette analyse vérifie : densité mots-clés, structure HTML (H1/H2/H3), meta tags, présence des mots-clés stratégiques
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        
        {/* Navigation Alert si pas sur Home */}
        {!isHomePage && (
          <Alert className="mb-8 bg-orange-50 border-2 border-orange-300">
            <AlertTriangle className="h-5 w-5 text-orange-600" />
            <AlertDescription className="text-orange-900">
              <strong>⚠️ Attention :</strong> Ce diagnostic analyse la page actuelle ({diagnosticResults?.currentPage}).
              <br/>
              <Button 
                onClick={navigateToHomeAndAnalyze}
                variant="outline"
                className="mt-3"
              >
                Analyser Home à la place
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Badge si analyse Home réussie */}
        {isHomePage && diagnosticResults && (
          <Alert className="mb-8 bg-green-50 border-2 border-green-300">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <AlertDescription className="text-green-900">
              <strong>✅ Analyse de la page Home effectuée !</strong> Résultats ci-dessous.
            </AlertDescription>
          </Alert>
        )}

        {/* Header Alert */}
        <Alert className="mb-8 bg-red-50 border-2 border-red-300">
          <AlertTriangle className="h-5 w-5 text-red-600" />
          <AlertDescription className="text-red-900">
            <strong>🚨 PROBLÈME DÉTECTÉ :</strong> Votre site a perdu sa position #1 pour "assistant administratif IA".
            <br/>Diagnostic complet ci-dessous avec actions correctives.
          </AlertDescription>
        </Alert>

        <div className="text-center mb-8">
          <Badge className="mb-4 bg-red-100 text-red-800">
            <TrendingDown className="w-4 h-4 mr-2" />
            Perte de Positionnement Détectée
          </Badge>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Diagnostic SEO Urgent
          </h1>
          <p className="text-sm text-gray-600">
            Page analysée : <code className="bg-gray-200 px-2 py-1 rounded">{diagnosticResults.currentPage}</code>
          </p>
        </div>

        {/* Densité Mots-Clés */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>📊 Densité du Mot-Clé Principal</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-semibold">Mot-clé : "assistant administratif IA"</span>
                <Badge variant={diagnosticResults.density.optimal ? "default" : "destructive"}>
                  Densité : {diagnosticResults.density.density}%
                </Badge>
              </div>
              <div className="bg-gray-100 rounded-lg p-4">
                <p className="text-sm">
                  <strong>Occurrences :</strong> {diagnosticResults.density.keywordCount} fois sur {diagnosticResults.density.totalWords} mots totaux
                </p>
                <p className="text-sm mt-2">
                  <strong>Optimal :</strong> 1-3% (soit {Math.floor(diagnosticResults.density.totalWords * 0.01)} à {Math.floor(diagnosticResults.density.totalWords * 0.03)} occurrences)
                </p>
              </div>
              {!diagnosticResults.density.optimal && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    ⚠️ Densité {diagnosticResults.density.density < 1 ? 'TROP FAIBLE' : 'TROP ÉLEVÉE'} ! 
                    {diagnosticResults.density.density === 0 ? ' Aucun mot-clé détecté sur cette page.' : ' Ajustement nécessaire.'}
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Présence Mots-Clés */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>🔍 Présence des Mots-Clés Stratégiques</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {diagnosticResults.keywords.map((kw, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <span className="font-medium">{kw.keyword}</span>
                    <span className="text-sm text-gray-600 ml-3">({kw.count} occurrences)</span>
                  </div>
                  {kw.present ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <XCircle className="w-5 h-5 text-red-600" />
                  )}
                </div>
              ))}
            </div>
            {diagnosticResults.keywords.every(k => k.count === 0) && (
              <Alert className="mt-4 bg-yellow-50 border-yellow-300">
                <AlertTriangle className="h-4 w-4 text-yellow-600" />
                <AlertDescription className="text-yellow-900">
                  <strong>Aucun mot-clé détecté !</strong> Assurez-vous d'être sur la bonne page.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Meta Tags */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>📝 Meta Tags</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <strong>Title Tag</strong>
                <Badge variant={diagnosticResults.metaTags.title.hasKeyword ? "default" : "destructive"}>
                  {diagnosticResults.metaTags.title.hasKeyword ? '✅ Mot-clé présent' : '❌ Mot-clé absent'}
                </Badge>
              </div>
              <p className="text-sm bg-gray-100 p-3 rounded">{diagnosticResults.metaTags.title.value}</p>
              <p className="text-xs text-gray-600 mt-1">
                Longueur : {diagnosticResults.metaTags.title.length} caractères 
                {diagnosticResults.metaTags.title.optimal ? ' ✅' : ' ⚠️ Non optimal (idéal: 50-60 car.)'}
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <strong>Meta Description</strong>
                <Badge variant={diagnosticResults.metaTags.description.hasKeyword ? "default" : "destructive"}>
                  {diagnosticResults.metaTags.description.hasKeyword ? '✅ Mot-clé présent' : '❌ Mot-clé absent'}
                </Badge>
              </div>
              <p className="text-sm bg-gray-100 p-3 rounded">{diagnosticResults.metaTags.description.value || 'Aucune description'}</p>
              <p className="text-xs text-gray-600 mt-1">
                Longueur : {diagnosticResults.metaTags.description.length} caractères
                {diagnosticResults.metaTags.description.optimal ? ' ✅' : ' ⚠️ Non optimal (idéal: 120-160 car.)'}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Headings */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>📌 Structure des Titres (H1, H2, H3)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <strong className="block mb-2">H1 (Titre Principal) - {diagnosticResults.headings.h1.length} trouvé(s)</strong>
                {diagnosticResults.headings.h1.length === 0 && (
                  <Alert variant="destructive" className="mb-2">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>❌ Aucun H1 trouvé ! Critique pour le SEO</AlertDescription>
                  </Alert>
                )}
                {diagnosticResults.headings.h1.map((h, idx) => (
                  <div key={idx} className="flex items-start gap-2 p-2 bg-gray-50 rounded mb-2">
                    {h.hasKeyword ? (
                      <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    )}
                    <span className="text-sm">{h.text}</span>
                  </div>
                ))}
              </div>

              <div>
                <strong className="block mb-2">
                  H2 (Sous-titres) - {diagnosticResults.headings.h2.filter(h => h.hasKeyword).length}/{diagnosticResults.headings.h2.length} avec mot-clé
                </strong>
                {diagnosticResults.headings.h2.length === 0 && (
                  <p className="text-sm text-gray-500 italic">Aucun H2 trouvé sur cette page</p>
                )}
                <p className="text-xs text-gray-600 mb-2">Affichage limité aux 5 premiers</p>
                {diagnosticResults.headings.h2.slice(0, 5).map((h, idx) => (
                  <div key={idx} className="flex items-start gap-2 p-2 bg-gray-50 rounded mb-1">
                    {h.hasKeyword ? (
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                    )}
                    <span className="text-xs">{h.text}</span>
                  </div>
                ))}
              </div>

              <div>
                <strong className="block mb-2">
                  H3 - {diagnosticResults.headings.h3.filter(h => h.hasKeyword).length}/{diagnosticResults.headings.h3.length} avec mot-clé
                </strong>
                {diagnosticResults.headings.h3.length === 0 && (
                  <p className="text-sm text-gray-500 italic">Aucun H3 trouvé sur cette page</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Robots.txt Warning */}
        <Alert className="mb-6 bg-orange-50 border-orange-300">
          <AlertTriangle className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-900">
            <strong>⚠️ robots.txt actuel :</strong> Trop basique et peut bloquer des scripts essentiels (AdSense, Googlebot).
            <br/>Cela peut empêcher Google d'indexer correctement votre site.
          </AlertDescription>
        </Alert>

        {/* Actions Correctives */}
        <Card className="bg-blue-50 border-2 border-blue-300 mb-6">
          <CardHeader>
            <CardTitle className="text-blue-900">🎯 Actions Correctives Immédiates</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="bg-white p-4 rounded-lg">
              <strong className="text-red-600">1. URGENT - Remplacer robots.txt</strong>
              <p className="text-sm mt-2">Le robots.txt actuel bloque potentiellement l'indexation.</p>
              <Button asChild className="mt-2" size="sm">
                <Link to={createPageUrl("ActionsPrioritaires")}>
                  Voir l'email pré-rédigé
                </Link>
              </Button>
            </div>

            {!isHomePage && (
              <div className="bg-white p-4 rounded-lg">
                <strong className="text-orange-600">2. Analyser la page Home</strong>
                <p className="text-sm mt-2">Ce diagnostic analyse {diagnosticResults.currentPage}. Analysez Home pour voir les mots-clés.</p>
                <Button onClick={navigateToHomeAndAnalyze} className="mt-2" size="sm" variant="outline">
                  Analyser Home
                </Button>
              </div>
            )}

            <div className="bg-white p-4 rounded-lg">
              <strong className="text-yellow-600">3. Soumettre à Google Search Console</strong>
              <p className="text-sm mt-2">Demander une réindexation immédiate de la page d'accueil.</p>
              <Button asChild className="mt-2" size="sm" variant="outline">
                <a href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer">
                  Ouvrir Search Console
                  <ExternalLink className="w-3 h-3 ml-1" />
                </a>
              </Button>
            </div>

            <Button className="w-full mt-4 bg-blue-600 hover:bg-blue-700" onClick={runDiagnostic}>
              <Search className="w-4 h-4 mr-2" />
              Relancer le Diagnostic
            </Button>
          </CardContent>
        </Card>

        {/* Plan d'action complet */}
        <Card className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">
              Plan d'Action Complet
            </h2>
            <p className="mb-6 opacity-90">
              Consultez le plan d'action détaillé avec checklist pour récupérer votre position #1
            </p>
            <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-100">
              <Link to={createPageUrl("ActionsPrioritaires")}>
                <AlertTriangle className="w-5 h-5 mr-2" />
                Voir le Plan d'Action Urgent
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}