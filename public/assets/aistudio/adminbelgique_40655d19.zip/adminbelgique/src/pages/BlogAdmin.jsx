import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ShieldAlert, Loader2, PenSquare } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import ArticleGeneratorForm from '@/components/blog/ArticleGeneratorForm';
import ArticleEditor from '@/components/blog/ArticleEditor';
import ArticleAdminList from '@/components/blog/ArticleAdminList';


export default function BlogAdmin() {
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [articles, setArticles] = useState([]);
  const [draft, setDraft] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const loadArticles = async () => {
    const list = await base44.entities.Article.list('-created_date', 100);
    const sorted = [...list].sort((a, b) => (a.display_order ?? 0) - (b.display_order ?? 0));
    setArticles(sorted);
  };

  const handleMove = async (index, direction) => {
    const target = index + direction;
    if (target < 0 || target >= articles.length) return;
    const next = [...articles];
    [next[index], next[target]] = [next[target], next[index]];
    setArticles(next);
    await base44.entities.Article.bulkUpdate(
      next.map((a, i) => ({ id: a.id, display_order: i }))
    );
    await loadArticles();
  };

  useEffect(() => {
    const init = async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        if (me?.role === 'admin') await loadArticles();
      } catch (_) {
        setUser(null);
      }
      setLoading(false);
    };
    init();
  }, []);

  const handleGenerate = async (keyword, brief) => {
    setIsGenerating(true);
    try {
      // 🔒 Génération exécutée côté serveur (fonction réservée aux administrateurs).
      const articleCall = await base44.functions.invoke('generateBlogArticle', { keyword, brief });
      const result = articleCall?.data?.article || articleCall?.article;

      // Sauvegarde immédiate en brouillon pour ne pas perdre l'article
      const payload = {
        ...result,
        main_keyword: keyword,
        keywords: result.keywords || [],
        faq: result.faq || [],
        published: false
      };
      const saved = await base44.entities.Article.create(payload);
      await loadArticles();
      setDraft({ ...saved, main_keyword: keyword });
      toast({ title: 'Article généré', description: 'Brouillon enregistré. Relisez-le puis publiez-le.' });
    } catch (error) {
      toast({
        title: 'Génération impossible',
        description: "L'IA n'a pas pu produire l'article. Réessayez.",
        variant: 'destructive'
      });
    }
    setIsGenerating(false);
  };

  const handleSave = async (form, publish) => {
    setIsSaving(true);
    try {
      const payload = {
        ...form,
        main_keyword: draft.main_keyword || '',
        keywords: draft.keywords || [],
        faq: draft.faq || [],
        published: publish,
        published_date: publish
          ? draft.published_date || new Date().toISOString().slice(0, 10)
          : draft.published_date
      };

      if (draft.id) {
        await base44.entities.Article.update(draft.id, payload);
      } else {
        await base44.entities.Article.create(payload);
      }

      await loadArticles();
      setDraft(null);
      toast({ title: publish ? 'Article publié' : 'Brouillon enregistré' });
    } catch (error) {
      toast({ title: 'Enregistrement impossible', variant: 'destructive' });
    }
    setIsSaving(false);
  };

  const handleTogglePublish = async (article) => {
    await base44.entities.Article.update(article.id, {
      published: !article.published,
      published_date: article.published_date || new Date().toISOString().slice(0, 10)
    });
    await loadArticles();
  };

  const handleDelete = async (article) => {
    if (!window.confirm(`Supprimer définitivement « ${article.title} » ?`)) return;
    await base44.entities.Article.delete(article.id);
    await loadArticles();
  };

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-yellow-500" />
      </div>
    );
  }

  if (user?.role !== 'admin') {
    return (
      <div className="mx-auto max-w-xl p-8">
        <Alert variant="destructive">
          <ShieldAlert className="h-4 w-4" />
          <AlertDescription>
            Cette page est réservée aux administrateurs d'AdminBelgique.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="mx-auto max-w-5xl space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="flex items-center gap-2 text-2xl font-bold text-gray-900 md:text-3xl">
              <PenSquare className="h-6 w-6 text-yellow-600" />
              Rédaction Blog SEO
            </h1>
            <p className="text-sm text-gray-600">
              Générez, relisez et publiez vos articles optimisés pour le marché belge.
            </p>
          </div>
          <Badge className="bg-purple-600 text-white">Admin</Badge>
        </div>

        {!draft && <ArticleGeneratorForm onGenerate={handleGenerate} isGenerating={isGenerating} />}

        {draft && (
          <ArticleEditor
            article={draft}
            onSave={handleSave}
            onCancel={() => setDraft(null)}
            isSaving={isSaving}
          />
        )}

        {!draft && (
          <ArticleAdminList
            articles={articles}
            onEdit={setDraft}
            onDelete={handleDelete}
            onTogglePublish={handleTogglePublish}
            onMove={handleMove}
          />
        )}

        {!draft && (
          <Card className="bg-slate-50">
            <CardContent className="p-4 text-xs text-gray-600">
              Les articles publiés apparaissent automatiquement sur la page Blog publique à l'adresse
              <span className="font-mono"> /blog/votre-slug</span>.
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}