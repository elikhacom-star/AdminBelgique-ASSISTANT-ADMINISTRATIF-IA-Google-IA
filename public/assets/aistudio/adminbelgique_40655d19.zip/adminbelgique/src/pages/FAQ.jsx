import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { HelpCircle, Search, ChevronDown, ChevronUp } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import StructuredData from "../components/seo/StructuredData";
import SEOHead from "../components/seo/SEOHead";
import { useTranslation } from "../components/localization/useTranslation";

export default function FAQ() {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState("");
  const [openIndex, setOpenIndex] = useState(null);

  const faqs = [
    {
      category: t("faq.cat.start"),
      questions: [
        {
          q: "Comment commencer à utiliser AdminBelgique ?",
          a: "Il suffit de vous connecter avec votre compte Google. Aucune carte bancaire n'est requise pour commencer. Vous pouvez immédiatement poser des questions, générer des documents et analyser vos fichiers administratifs."
        },
        {
          q: "AdminBelgique est-il vraiment gratuit ?",
          a: "Oui ! Notre plan gratuit vous permet d'utiliser l'assistant administratif IA avec des limites mensuelles raisonnables (3 questions, 2 analyses, 5 documents, 20 messages IA). Pour un usage illimité, découvrez nos plans Pro à partir de 29€/mois."
        },
        {
          q: "Dois-je installer un logiciel ?",
          a: "Non, AdminBelgique fonctionne entièrement en ligne dans votre navigateur. Accessible depuis n'importe quel appareil : ordinateur, tablette ou smartphone."
        }
      ]
    },
    {
      category: t("faq.cat.security"),
      questions: [
        {
          q: "Mes données personnelles sont-elles en sécurité ?",
          a: "Absolument ! Nous utilisons une technologie d'anonymisation brevetée. Vos données personnelles (noms, adresses, numéros) sont automatiquement chiffrées et remplacées par des codes avant traitement par l'IA. Elles ne quittent jamais votre appareil en clair."
        },
        {
          q: "Qui a accès à mes documents ?",
          a: "Vous seul. Tous vos documents, analyses et conversations sont privés et chiffrés. Même notre équipe ne peut pas y accéder. Conformité RGPD garantie."
        },
        {
          q: "Puis-je supprimer mes données ?",
          a: "Oui, à tout moment. Vous avez un contrôle total sur vos données. Contactez-nous pour une suppression complète de votre compte et de toutes vos données."
        }
      ]
    },
    {
      category: t("faq.cat.admin"),
      questions: [
        {
          q: "AdminBelgique remplace-t-il un conseiller juridique ?",
          a: "Non. AdminBelgique est un outil d'information et d'aide à la rédaction. Pour les cas complexes ou les litiges importants, nous recommandons toujours de consulter un avocat ou un juriste professionnel."
        },
        {
          q: "Quels organismes belges sont couverts ?",
          a: "SPF Finances (impôts), INAMI (santé), ONEM (emploi/chômage), CPAS, communes, SPF Emploi, allocations familiales, pensions, et bien plus. Nous couvrons tous les domaines administratifs belges."
        },
        {
          q: "L'IA connaît-elle vraiment la législation belge ?",
          a: "Oui ! Notre agent administratif IA est spécialement entraîné sur la législation et les procédures administratives belges. Il est régulièrement mis à jour avec les derniers changements législatifs."
        },
        {
          q: "Fonctionne-t-il dans toutes les villes de Belgique ?",
          a: "Oui, AdminBelgique fonctionne partout en Belgique : Bruxelles, Anvers, Gand, Charleroi, Liège, Bruges, Namur, Louvain, Mons, et toutes les autres communes."
        }
      ]
    },
    {
      category: t("faq.cat.services"),
      questions: [
        {
          q: "Quelle est la différence entre l'Assistant Simple et le Chat Agent ?",
          a: "L'Assistant Simple est idéal pour une question ponctuelle rapide. Le Chat Agent IA a une mémoire persistante et peut gérer des conversations longues et complexes sur plusieurs sessions."
        },
        {
          q: "Qu'est-ce que IMMO BOOST ?",
          a: "IMMO BOOST est notre module immobilier révolutionnaire pour agents immobiliers. Il recherche automatiquement sur Immoweb, Logic-Immo et Zimmo, puis utilise l'IA pour matcher les biens avec les critères de vos clients."
        },
        {
          q: "Puis-je modifier un document après sa génération ?",
          a: "Oui ! Tous les documents générés sont téléchargeables en PDF et DOCX. Vous pouvez les modifier avec Word ou tout autre traitement de texte."
        },
        {
          q: "Comment fonctionne l'analyseur de documents ?",
          a: "Uploadez simplement votre document (PDF, image, CSV). Notre IA l'analyse, extrait les informations clés, détecte les problèmes potentiels et vous donne des conseils personnalisés."
        }
      ]
    },
    {
      category: t("faq.cat.pricing"),
      questions: [
        {
          q: "Comment passer au plan Pro ?",
          a: "Cliquez sur 'Tarifs' dans le menu, choisissez votre plan et suivez le processus de paiement sécurisé via Stripe. Activation immédiate."
        },
        {
          q: "Puis-je annuler mon abonnement à tout moment ?",
          a: "Oui, sans engagement. Vous pouvez annuler à tout moment depuis votre tableau de bord. Votre abonnement restera actif jusqu'à la fin de la période payée."
        },
        {
          q: "Y a-t-il une réduction pour paiement annuel ?",
          a: "Oui ! 20% de réduction sur tous les plans si vous payez annuellement au lieu de mensuellement."
        },
        {
          q: "Quels moyens de paiement acceptez-vous ?",
          a: "Carte bancaire (Visa, Mastercard), Bancontact, virement SEPA. Tous les paiements sont sécurisés via Stripe."
        }
      ]
    },
    {
      category: t("faq.cat.support"),
      questions: [
        {
          q: "Comment obtenir de l'aide ?",
          a: "Consultez notre Guide d'Aide complet dans le menu, ou contactez-nous par email (elikaccesit@gmail.com) ou téléphone (+32 467 80 10 41). Nous répondons généralement sous 24h."
        },
        {
          q: "Y a-t-il une formation pour utiliser AdminBelgique ?",
          a: "Un guide interactif s'affiche lors de votre première connexion. De plus, notre page 'Aide' contient des tutoriels détaillés pour chaque fonctionnalité."
        },
        {
          q: "AdminBelgique est-il disponible en néerlandais ?",
          a: "Actuellement en français avec interface bilingue FR/NL en cours de déploiement. L'IA comprend et répond en français, néerlandais et allemand."
        }
      ]
    }
  ];

  // Convertir FAQs pour Schema.org
  const faqSchemaData = {
    questions: faqs.flatMap(category => 
      category.questions.map(q => ({
        question: q.q,
        answer: q.a
      }))
    )
  };

  const filteredFaqs = faqs.map(category => ({
    ...category,
    questions: category.questions.filter(
      faq =>
        faq.q.toLowerCase().includes(searchTerm.toLowerCase()) ||
        faq.a.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })).filter(category => category.questions.length > 0);

  const toggleQuestion = (categoryIndex, questionIndex) => {
    const key = `${categoryIndex}-${questionIndex}`;
    setOpenIndex(openIndex === key ? null : key);
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <SEOHead
        title="FAQ AdminBelgique — Vos Questions sur l'Assistant IA 🇧🇪"
        description="❓ Découvrez les réponses à toutes vos questions ! Gratuité, sécurité RGPD, SPF Finances, INAMI, ONEM. Démarrez en 2 min, sans carte bancaire. Essai gratuit ✨"
        canonical="https://adminbelgique.com/FAQ"
        keywords="faq assistant ia belgique, questions adminbelgique, assistant administratif gratuit belgique"
      />
      <StructuredData pageType="faq" data={faqSchemaData} />
      <StructuredData 
        pageType="breadcrumb" 
        data={{
          breadcrumbs: [
            { name: "Accueil", url: "/" },
            { name: "FAQ", url: "/faq" }
          ]
        }} 
      />
      
      <div className="max-w-4xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-purple-100 text-purple-800 border-purple-300">
            <HelpCircle className="w-4 h-4 mr-2" />
            {t("faq.badge")}
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            {t("faq.title")}
          </h1>
          <p className="text-xl text-gray-600">
            {t("faq.subtitle")}
          </p>
        </div>

        {/* Search */}
        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder={t("faq.search_placeholder")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 text-lg py-6"
            />
          </div>
        </div>

        {/* FAQs */}
        <div className="space-y-6">
          {filteredFaqs.map((category, catIndex) => (
            <Card key={catIndex}>
              <CardHeader>
                <CardTitle className="text-xl">{category.category}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {category.questions.map((faq, qIndex) => {
                  const isOpen = openIndex === `${catIndex}-${qIndex}`;
                  return (
                    <div key={qIndex} className="border-b last:border-b-0 pb-3 last:pb-0">
                      <button
                        onClick={() => toggleQuestion(catIndex, qIndex)}
                        className="w-full text-left flex items-start justify-between gap-4 py-2 hover:text-yellow-600 transition-colors"
                      >
                        <span className="font-semibold text-gray-900">{faq.q}</span>
                        {isOpen ? (
                          <ChevronUp className="w-5 h-5 text-gray-400 flex-shrink-0 mt-1" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0 mt-1" />
                        )}
                      </button>
                      {isOpen && (
                        <p className="text-gray-600 mt-2 pl-4 border-l-2 border-yellow-300">
                          {faq.a}
                        </p>
                      )}
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <Card className="mt-12 bg-gradient-to-r from-blue-500 to-purple-500 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">
              {t("faq.cta.title")}
            </h2>
            <p className="text-lg mb-6 opacity-90">
              {t("faq.cta.text")}
            </p>
            <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-100">
              <Link to={createPageUrl("Contact")}>
                {t("faq.cta.btn")}
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}