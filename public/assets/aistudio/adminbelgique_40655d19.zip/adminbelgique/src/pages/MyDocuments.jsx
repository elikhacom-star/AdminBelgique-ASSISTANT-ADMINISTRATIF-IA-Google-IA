import React, { useState, useEffect, useCallback } from "react";
import { Document } from "@/entities/Document";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Search, Filter, Calendar, Sparkles, Eye, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { fr, nl, de } from "date-fns/locale";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useTranslation } from "@/components/localization/useTranslation";
import DocumentDetailView from "@/components/documents/DocumentDetailView";
import DocumentFullScreenPreview from "@/components/documents/DocumentFullScreenPreview";
import PullToRefresh from "@/components/common/PullToRefresh";

const dateLocales = { fr, nl, de };

export default function MyDocuments() {
  const { t, locale } = useTranslation();

  const getDocumentTypeLabels = useCallback(() => ({
    lettre_reclamation: t("docgen.type.reclamation"),
    demande_remboursement: t("docgen.type.remboursement"),
    demande_renseignements: t("docgen.type.renseignements"),
    recours: t("docgen.type.recours"),
    plainte_administrative: t("docgen.type.plainte"),
    mise_en_demeure: "Mise en demeure",
    bail: "Bail",
    autre: "Autre"
  }), [t]);

  const getCategoryLabels = useCallback(() => ({
    finances: t("category.finances"),
    securite_sociale: t("category.social_security"),
    emploi: t("category.employment"),
    sante: t("category.health"),
    logement: t("category.housing"),
    etudes: t("category.studies"),
    pensions: t("category.pensions")
  }), [t]);

  const getStatusLabels = useCallback(() => ({
    brouillon: t("mydocs.status.draft"),
    finalise: t("mydocs.status.final"),
    envoye: t("mydocs.status.sent")
  }), [t]);

  const statusColors = {
    brouillon: "bg-yellow-100 text-yellow-800 border-yellow-200",
    finalise: "bg-blue-100 text-blue-800 border-blue-200",
    envoye: "bg-green-100 text-green-800 border-green-200"
  };

  const [documents, setDocuments] = useState([]);
  const [filteredDocuments, setFilteredDocuments] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [previewDoc, setPreviewDoc] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const loadDocuments = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await Document.list("-created_date");
      // S'assurer que data est un array
      const documentsArray = Array.isArray(data) ? data : [];
      setDocuments(documentsArray);
      if (documentsArray.length > 0) {
        setSelectedDocument(documentsArray[0]);
      }
    } catch (error) {
      console.error("Failed to load documents:", error);
      setDocuments([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDocuments();
  }, [loadDocuments]);

  useEffect(() => {
    // S'assurer que documents est un array avant de filtrer
    if (!Array.isArray(documents)) {
      setFilteredDocuments([]);
      return;
    }

    let filtered = documents.filter((doc) => {
      const termMatch = searchTerm ? doc.title.toLowerCase().includes(searchTerm.toLowerCase()) || (doc.recipient || "").toLowerCase().includes(searchTerm.toLowerCase()) : true;
      const categoryMatch = selectedCategory !== "all" ? doc.category === selectedCategory : true;
      const statusMatch = selectedStatus !== "all" ? doc.status === selectedStatus : true;
      return termMatch && categoryMatch && statusMatch;
    });
    setFilteredDocuments(filtered);
  }, [documents, searchTerm, selectedCategory, selectedStatus]);

  const documentTypeLabels = getDocumentTypeLabels();
  const categoryLabels = getCategoryLabels();
  const statusLabels = getStatusLabels();

  const handleDocumentUpdated = (updated) => {
    setSelectedDocument(updated);
    setDocuments((prev) => prev.map((d) => d.id === updated.id ? updated : d));
    setFilteredDocuments((prev) => prev.map((d) => d.id === updated.id ? updated : d));
  };

  const removeDocument = async (doc) => {
    await Document.delete(doc.id);
    const remaining = documents.filter((d) => d.id !== doc.id);
    setDocuments(remaining);
    if (selectedDocument?.id === doc.id) setSelectedDocument(remaining[0] || null);
    if (previewDoc?.id === doc.id) setPreviewDoc(null);
  };

  const handleDelete = async (doc) => {
    if (!window.confirm(`Supprimer définitivement « ${doc.title} » ?`)) return;
    await removeDocument(doc);
  };

  const handleRefresh = async () => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    await loadDocuments();
    setTimeout(() => setIsRefreshing(false), 600);
  };

  return (
    <PullToRefresh isRefreshing={isRefreshing} onRefresh={handleRefresh}>
      <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          {isRefreshing &&
            <div className="mt-2 flex items-center justify-center gap-2 text-sm text-blue-700">
              <span className="inline-block h-3 w-3 rounded-full bg-blue-500 animate-pulse" /> Mise à jour...
            </div>
            }
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{t("mydocs.title")}</h1>
          <p className="text-gray-600">{t("mydocs.subtitle")}</p>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Filter className="w-5 h-5" />{t("mydocs.filter_title")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input placeholder={t("mydocs.search_placeholder")} value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
              </div>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger><SelectValue placeholder={t("docgen.category_label")} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("mydocs.all_categories")}</SelectItem>
                  {Object.entries(categoryLabels).map(([key, label]) => <SelectItem key={key} value={key}>{label}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger><SelectValue placeholder={t("mydocs.status.title")} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("mydocs.all_statuses")}</SelectItem>
                  {Object.entries(statusLabels).map(([key, label]) => <SelectItem key={key} value={key}>{label}</SelectItem>)}
                </SelectContent>
              </Select>
              <Button variant="outline" onClick={() => {setSearchTerm("");setSelectedCategory("all");setSelectedStatus("all");}}>{t("mydocs.reset_button")}</Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 mx-auto">
            <div className="grid gap-4 max-h-[70vh] overflow-y-auto pr-3">
              {isLoading ?
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-500 mx-auto mb-4" />
                  <p className="text-gray-500">{t("loading")}</p>
                </div> :
                filteredDocuments.length === 0 ?
                <Card className="text-center py-12">
                  <CardContent>
                    <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{t("mydocs.no_docs_found")}</h3>
                    <p className="text-gray-500 mb-4">
                      {documents.length > 0 ? t("mydocs.no_docs_filter") : t("mydocs.no_docs_yet")}
                    </p>
                    {documents.length === 0 &&
                    <Button asChild>
                        <Link to={createPageUrl("DocumentGenerator")}><Sparkles className="w-4 h-4 mr-2" />{t("mydocs.create_doc_button")}</Link>
                      </Button>
                    }
                  </CardContent>
                </Card> :

                filteredDocuments.map((doc) =>
                <Card
                  key={doc.id}
                  className={`cursor-pointer transition-all ${selectedDocument?.id === doc.id ? 'border-yellow-400 shadow-lg' : 'hover:shadow-md'}`}
                  onClick={() => setSelectedDocument(doc)}>
                  
                    <CardHeader className="pt-6 pr-6 pb-6 pl-5 mx-auto">
                      <CardTitle className="text-base truncate">{doc.title}</CardTitle>
                      <div className="flex flex-wrap gap-2 pt-2">
                        <Badge variant="secondary" className="text-xs">{documentTypeLabels[doc.type]}</Badge>
                        <Badge className={`${statusColors[doc.status]} text-xs`}>{statusLabels[doc.status]}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-3 h-3" />
                          {format(new Date(doc.created_date), 'dd MMMM yyyy', { locale: dateLocales[locale] || fr })}
                        </div>
                        <div className="flex gap-1">
                          <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {e.stopPropagation();setPreviewDoc(doc);}}
                          className="h-7 px-2">
                            <Eye className="w-3 h-3 mr-1" /> Consulter
                          </Button>
                          <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {e.stopPropagation();handleDelete(doc);}}
                          className="h-7 px-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                          title="Supprimer">
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>

                      {Array.isArray(doc.tags) && doc.tags.length > 0 &&
                    <div className="mt-2 flex flex-wrap gap-1">
                          {doc.tags.slice(0, 4).map((tag, i) =>
                      <Badge key={i} variant="secondary" className="text-[10px]">#{tag}</Badge>
                      )}
                          {doc.tags.length > 4 &&
                      <Badge variant="outline" className="text-[10px]">+{doc.tags.length - 4}</Badge>
                      }
                        </div>
                    }
                    </CardContent>
                  </Card>
                )
                }
            </div>
          </div>
          <div className="lg:col-span-2">
            <div className="sticky top-4">
              <DocumentDetailView document={selectedDocument} onUpdated={handleDocumentUpdated} />
            </div>
          </div>
        </div>
      </div>

      {/* Aperçu plein écran */}
      <DocumentFullScreenPreview
        doc={previewDoc}
        open={!!previewDoc}
        onClose={() => setPreviewDoc(null)}
        typeLabel={previewDoc ? documentTypeLabels[previewDoc.type] : ""}
        statusLabel={previewDoc ? statusLabels[previewDoc.status] : ""}
        statusClass={previewDoc ? statusColors[previewDoc.status] : ""}
        onDelete={removeDocument}
      />
    </div>
    </PullToRefresh>);

}