import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowRight, BookOpen, TrendingUp, Search } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import StructuredData from "../components/seo/StructuredData";
import SEOHead from "../components/seo/SEOHead";
import { Input } from "@/components/ui/input";
import { useTranslation } from "../components/localization/useTranslation";

export default function Blog() {
  const { t } = useTranslation();
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [dynamicArticles, setDynamicArticles] = useState([]);

  useEffect(() => {
    const loadPublished = async () => {
      try {
        const list = await base44.entities.Article.filter({ published: true }, '-published_date', 50);
        const ordered = [...list].sort((a, b) => (a.display_order ?? 0) - (b.display_order ?? 0));
        setDynamicArticles(ordered.map((a) => ({
          id: a.id,
          title: a.title,
          excerpt: a.excerpt || "",
          category: a.category || "Guide",
          date: a.published_date || "",
          datePublished: a.published_date || "",
          readTime: a.read_time || "",
          image: a.image_url || "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=800",
          slug: a.slug,
          keywords: a.keywords || [],
          path: `/blog/${a.slug}`
        })));
      } catch (_) {
        setDynamicArticles([]);
      }
    };
    loadPublished();
  }, []);

  const staticArticles = [
    {
      id: "BlogArticle5TachesAutomatiser",
      title: "5 Tâches Administratives à Automatiser avec l'IA en Belgique",
      excerpt: "Découvrez comment l'intelligence artificielle peut transformer votre quotidien administratif et vous faire gagner jusqu'à 10 heures par semaine...",
      category: "Automatisation",
      date: "15 Jan 2025",
      datePublished: "2025-01-15",
      readTime: "5 min",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800",
      slug: "5-taches-administratives-automatiser-ia-belgique",
      keywords: ["automatisation administrative", "IA Belgique", "gain de temps"],
      path: "/BlogArticle5TachesAutomatiser"
    },
    {
      id: "BlogArticleIATransformation",
      title: "Comment l'IA Transforme la Gestion Administrative en Belgique",
      excerpt: "L'intelligence artificielle révolutionne la façon dont les Belges gèrent leurs démarches auprès du SPF Finances, de l'INAMI et de l'ONEM...",
      category: "Transformation Digitale",
      date: "10 Jan 2025",
      datePublished: "2025-01-10",
      readTime: "7 min",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800",
      slug: "ia-transformation-gestion-administrative-belgique",
      keywords: ["transformation digitale", "gestion administrative", "IA"],
      path: "/BlogArticleIATransformation"
    },
    {
      id: "BlogArticleAssistantVsIA",
      title: "Assistant Virtuel vs Assistant Administratif IA : Quelle Différence ?",
      excerpt: "Comparaison détaillée entre les assistants virtuels classiques et les assistants administratifs IA spécialisés pour la Belgique...",
      category: "Comparaison",
      date: "5 Jan 2025",
      datePublished: "2025-01-05",
      readTime: "6 min",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800",
      slug: "assistant-virtuel-vs-assistant-administratif-ia",
      keywords: ["assistant virtuel", "assistant IA", "comparaison"],
      path: "/BlogArticleAssistantVsIA"
    },
    {
      id: "BlogArticleDeclarationImpots",
      title: "Guide Complet : Déclarer Ses Impôts en Belgique avec l'IA",
      excerpt: "Comment utiliser l'intelligence artificielle pour préparer et optimiser votre déclaration d'impôts belge auprès du SPF Finances...",
      category: "Guide",
      date: "1 Jan 2025",
      datePublished: "2025-01-01",
      readTime: "10 min",
      image: "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=800",
      slug: "guide-declaration-impots-belgique-ia",
      keywords: ["déclaration impôts", "SPF Finances", "IA fiscalité"],
      path: "/BlogArticleDeclarationImpots"
    },
    {
      id: "BlogArticleINAMIOptimise",
      title: "Remboursements INAMI : Comment l'IA Optimise Vos Demandes",
      excerpt: "Maximisez vos remboursements de santé avec l'aide de l'intelligence artificielle. Conseils et astuces pour l'INAMI et les mutuelles...",
      category: "Santé",
      date: "28 Déc 2024",
      datePublished: "2024-12-28",
      readTime: "5 min",
      image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800",
      slug: "remboursements-inami-optimises-ia",
      keywords: ["INAMI", "remboursements santé", "mutuelle"],
      path: "/BlogArticleINAMIOptimise"
    },
    {
      id: "BlogArticleONEMChomage",
      title: "ONEM et Chômage : L'IA Comme Assistant Personnel",
      excerpt: "Comment l'intelligence artificielle peut vous aider dans vos démarches ONEM, de l'inscription aux allocations en passant par la recherche d'emploi...",
      category: "Emploi",
      date: "20 Déc 2024",
      datePublished: "2024-12-20",
      readTime: "8 min",
      image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=800",
      slug: "onem-chomage-ia-assistance-belgique",
      keywords: ["ONEM", "chômage Belgique", "allocations"],
      path: "/BlogArticleONEMChomage"
    }
  ];

  const articles = [...dynamicArticles, ...staticArticles];

  const categories = ["all", ...Array.from(new Set(articles.map(a => a.category)))];

  const filteredArticles = articles.filter(a => {
    const matchesCategory = selectedCategory === "all" || a.category === selectedCategory;
    const matchesSearch = searchTerm === "" || 
      a.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.keywords.some(k => k.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  // FAQ Schema pour le blog
  const faqData = {
    questions: [
      {
        question: "Comment l'IA peut-elle aider pour les démarches administratives belges ?",
        answer: "L'IA automatise la rédaction de documents, analyse vos factures pour détecter les remboursements oubliés, et vous guide pas à pas dans vos démarches SPF Finances, INAMI, ONEM."
      },
      {
        question: "AdminBelgique est-il adapté pour les démarches ONEM ?",
        answer: "Oui, notre IA vous aide à préparer votre dossier ONEM complet, calcule votre éligibilité, génère les formulaires et vous prépare pour le contrôle de disponibilité."
      }
    ]
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <SEOHead
        title="Blog AdminBelgique — Guides & Astuces Démarches IA 🇧🇪"
        description="📚 Découvrez +30 guides pratiques pour automatiser vos démarches en Belgique ! Impôts, INAMI, ONEM, logement. Gagnez 4h/semaine avec l'IA. Conseils d'experts ✨"
        canonical="https://adminbelgique.com/Blog"
        keywords="blog administratif belgique, guide démarches belgique, automatisation administrative ia, assistant ia belgique"
      />
      <StructuredData pageType="faq" data={faqData} />
      <StructuredData 
        pageType="breadcrumb" 
        data={{
          breadcrumbs: [
            { name: "Accueil", url: "/" },
            { name: "Blog", url: "/blog" }
          ]
        }} 
      />

      <div className="max-w-6xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-green-100 text-green-800 border-green-300">
            <BookOpen className="w-4 h-4 mr-2" />
            {t("blog.badge")}
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            {t("blog.title")}
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-6">
            {t("blog.subtitle")}
          </p>

          {/* Barre de recherche */}
          <div className="max-w-xl mx-auto mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                type="text"
                placeholder={t("blog.search_placeholder")}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </div>

        {/* Catégories */}
        <div className="flex flex-wrap justify-center gap-3 mb-8">
          {categories.map((cat) => (
            <Button
              key={cat}
              variant={selectedCategory === cat ? "default" : "outline"}
              onClick={() => setSelectedCategory(cat)}
              className={selectedCategory === cat ? "bg-yellow-500 hover:bg-yellow-600" : ""}
            >
              {cat === "all" ? t("blog.cat.all") : cat}
            </Button>
          ))}
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {filteredArticles.map((article) => (
            <Card key={article.id} className="hover:shadow-xl transition-all overflow-hidden group">
              <StructuredData 
                pageType="article" 
                data={{
                  title: article.title,
                  description: article.excerpt,
                  image: article.image,
                  datePublished: article.datePublished
                }}
              />
              <div className="h-48 overflow-hidden">
                <img 
                  src={article.image} 
                  alt={article.title}
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="secondary" className="text-xs">{article.category}</Badge>
                  <div className="flex items-center text-xs text-gray-500 gap-3">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {article.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {article.readTime}
                    </span>
                  </div>
                </div>
                <CardTitle className="text-lg leading-tight group-hover:text-yellow-600 transition-colors">
                  {article.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">{article.excerpt}</p>
                <Button asChild variant="outline" className="w-full group-hover:bg-yellow-50 group-hover:border-yellow-300">
                  <Link to={article.path || createPageUrl(article.id)}>
                    {t("blog.read_article")}
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Newsletter CTA */}
        <Card className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
          <CardContent className="p-8 text-center">
            <TrendingUp className="w-12 h-12 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-4">
              {t("blog.newsletter.title")}
            </h2>
            <p className="text-lg mb-6 opacity-90">
              {t("blog.newsletter.text")}
            </p>
            <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-100">
              <Link to={createPageUrl("Contact")}>
                {t("blog.newsletter.btn")}
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}