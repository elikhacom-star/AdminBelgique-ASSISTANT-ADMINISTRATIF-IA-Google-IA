import React, { useState } from "react";
import { User } from "@/entities/User";
import { Analyse } from "@/entities/Analyse";
import { UploadFile, ExtractDataFromUploadedFile, InvokeLLM } from "@/integrations/Core";
import { api as base44 } from "@/components/api/wrapper";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Upload, FileText, Loader2, CheckCircle, AlertTriangle, Sparkles, MessageSquare, Save } from "lucide-react";
import ReactMarkdown from 'react-markdown';
import { useTranslation } from "@/components/localization/useTranslation";
import { anonymizeText, deanonymizeText } from "../components/utils/anonymizer";
import SimpleLogin from "../components/auth/SimpleLogin";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import LimitChecker from "../components/freemium/LimitChecker";
import { throttledAPICall } from "../components/utils/apiThrottle";

export default function DocumentAnalyzer() {
  const { t } = useTranslation();
  const [user, setUser] = useState(null);
  const [showLogin, setShowLogin] = useState(false);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [error, setError] = useState(null);

  React.useEffect(() => {
    const checkUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        // Pas d'utilisateur connecté
      }
    };
    checkUser();
  }, []);

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!user) {
      setShowLogin(true);
      return;
    }

    setError(null);
    setIsUploading(true);

    try {
      // ✅ Throttle l'appel API
      const { file_url } = await throttledAPICall(() => UploadFile({ file }));
      
      setUploadedFile({
        name: file.name,
        size: file.size,
        type: file.type,
        url: file_url
      });
    } catch (err) {
      if (err?.response?.status === 429) {
        setError("⏸️ Trop de fichiers téléchargés. Attendez quelques secondes.");
      } else {
        setError("Erreur lors du téléchargement du fichier. Veuillez réessayer.");
      }
      console.error("Upload error:", err);
    } finally {
      setIsUploading(false);
    }
  };

  const handleAnalyze = async () => {
    if (!uploadedFile || !user) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      // ✅ Throttle TOUS les appels API
      const extractionResponse = await throttledAPICall(() =>
        ExtractDataFromUploadedFile({
          file_url: uploadedFile.url,
          json_schema: {
            type: "object",
            properties: {
              type: { type: "string", description: "Type de document (facture, courrier administratif, etc.)" },
              content: { type: "string", description: "Contenu principal du document" },
              key_information: { 
                type: "array", 
                items: { type: "string" },
                description: "Informations clés extraites du document" 
              },
              sender: { type: "string", description: "Expéditeur du document" },
              recipient: { type: "string", description: "Destinataire du document" },
              date: { type: "string", description: "Date du document si mentionnée" },
            }
          }
        })
      );
      
      if (extractionResponse.status !== 'success') {
        throw new Error(extractionResponse.details || "Erreur lors de l'extraction des données");
      }
      
      const extractedData = extractionResponse.output;
      const contentToAnonymize = JSON.stringify(extractedData);
      const { anonymizedText, mapping } = anonymizeText(contentToAnonymize);
      
      const prompt = `Tu es un expert en administration belge. Analyse ce document et fournis:

1. **Résumé**: Résume en 2-3 phrases ce dont il s'agit.
2. **Analyse de complétude & Incohérences**: Identifie s'il manque des informations cruciales, des signatures, des dates, ou s'il y a des incohérences manifestes dans le document (ex: dates contradictoires, montants bizarres).
3. **Actions recommandées**: Que doit faire l'utilisateur concrètement suite à ce document?
4. **Formulaires & Procédures suggérés**: Suggère précisément les formulaires administratifs ou les procédures officielles belges à suivre.
5. **Délais importants**: Y a-t-il des échéances strictes à respecter?
6. **Organismes à contacter**: Quelles administrations ou services contacter si nécessaire?
7. **Conseils pratiques**: Conseils spécifiques pour optimiser le traitement du dossier.

Document analysé (anonymisé): ${anonymizedText}

Réponds en français, de manière claire et actionnable. Formate ta réponse en Markdown pour une lecture facile. Utilise les pseudonymes dans ta réponse.`;

      // ✅ Throttle l'appel LLM
      const aiResponse = await throttledAPICall(() =>
        InvokeLLM({ 
          prompt,
          add_context_from_internet: true 
        })
      );
      
      const finalAnalysis = deanonymizeText(aiResponse, mapping);
      const finalExtractedData = JSON.parse(deanonymizeText(JSON.stringify(extractedData), mapping));

      // ✅ Throttle la sauvegarde
      const savedAnalysis = await throttledAPICall(() =>
        Analyse.create({
          original_filename: uploadedFile.name,
          file_url: uploadedFile.url,
          analysis_summary: finalAnalysis,
          extracted_data: JSON.stringify(finalExtractedData, null, 2),
          category: finalExtractedData.type || "Général"
        })
      );

      setAnalysisResult(savedAnalysis);

    } catch (err) {
      if (err?.response?.status === 429) {
        setError("⏸️ Trop d'analyses en même temps. Attendez 10 secondes avant de réessayer.");
      } else {
        setError("Erreur lors de l'analyse du document. Veuillez réessayer.");
      }
      console.error("Analysis error:", err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const resetAnalyzer = () => {
    setUploadedFile(null);
    setAnalysisResult(null);
    setError(null);
    const fileInput = document.getElementById('file-upload');
    if (fileInput) fileInput.value = '';
  };

  if (showLogin) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <SimpleLogin actionText="analyser des documents" />
      </div>
    );
  }

  return (
    <LimitChecker feature="analysis_count">
      {({ onActionStart, remainingActions, currentPlan }) => (
        <div className="p-4 md:p-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 bg-purple-100 rounded-full px-4 py-2 mb-4">
                <Sparkles className="w-5 h-5 text-purple-600" />
                <span className="text-purple-800 font-medium">Analyse IA de Documents</span>
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Analyseur de Documents Administratifs
              </h1>
              <p className="text-gray-600">
                Téléchargez un document administratif et obtenez une analyse instantanée avec les actions à effectuer
              </p>
              {user && currentPlan === 'free' && (
                <Badge className="mt-2 bg-yellow-100 text-yellow-800">
                  {remainingActions} analyses restantes ce mois-ci
                </Badge>
              )}
            </div>
            
            {!analysisResult ? (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Upload className="w-5 h-5" />
                    Télécharger votre document
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <input
                      id="file-upload"
                      type="file"
                      accept=".pdf,.png,.jpg,.jpeg,.csv,.doc,.docx,.xls,.xlsx"
                      onChange={handleFileUpload}
                      className="hidden"
                      disabled={isUploading}
                    />
                    <label
                      htmlFor="file-upload"
                      className={`cursor-pointer ${isUploading ? 'opacity-50' : ''}`}
                    >
                      <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        {isUploading ? (
                          <Loader2 className="w-8 h-8 text-purple-600 animate-spin" />
                        ) : (
                          <Upload className="w-8 h-8 text-purple-600" />
                        )}
                      </div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {isUploading ? "Téléchargement..." : "Cliquez pour sélectionner un fichier"}
                      </h3>
                      <p className="text-gray-500 mb-4">
                        Formats supportés: PDF, PNG, JPG, JPEG, CSV, DOC, DOCX, XLS, XLSX
                      </p>
                    </label>
                  </div>

                  {uploadedFile && (
                    <Alert>
                      <CheckCircle className="h-4 w-4" />
                      <AlertDescription>
                        <div className="flex items-center justify-between">
                          <div>
                            <strong>{uploadedFile.name}</strong>
                            <div className="text-sm text-gray-500">
                              {formatFileSize(uploadedFile.size)} • {uploadedFile.type}
                            </div>
                          </div>
                          <Button 
                            onClick={async () => {
                              const canProceed = await onActionStart();
                              if (canProceed) {
                                handleAnalyze();
                              }
                            }}
                            disabled={isAnalyzing}
                            className="ml-4"
                          >
                            {isAnalyzing ? (
                              <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyse en cours...
                              </>
                            ) : (
                              <>
                                <Sparkles className="w-4 h-4 mr-2" />
                                Analyser le document
                              </>
                            )}
                          </Button>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}

                  {error && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}
                </CardContent>
              </Card>
            ) : (
              /* NOUVEAU: Résultats de l'analyse avec actions */
              <div className="space-y-6">
                 <Alert variant="default" className="bg-green-50 border-green-200">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800 font-medium">
                    Analyse terminée et sauvegardée dans "Mes Analyses" !
                  </AlertDescription>
                </Alert>
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-gray-700" />
                        {analysisResult.original_filename}
                      </CardTitle>
                      <Button onClick={resetAnalyzer} variant="outline">
                        Analyser un autre document
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <ReactMarkdown 
                        className="prose max-w-none prose-sm prose-p:my-2 prose-headings:mb-2 prose-headings:mt-4 prose-ul:my-2"
                        components={{
                          h1: ({node, ...props}) => <h3 className="text-lg font-bold text-gray-900" {...props} />,
                          h2: ({node, ...props}) => <h4 className="text-md font-bold text-gray-800" {...props} />,
                          strong: ({node, ...props}) => <span className="font-semibold text-purple-900" {...props} />,
                        }}
                      >
                        {analysisResult.analysis_summary}
                      </ReactMarkdown>
                    </div>

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                       <h4 className="font-semibold text-blue-900 mb-2">
                         Et maintenant ?
                       </h4>
                       <p className="text-blue-800 text-sm mb-4">
                         Utilisez l'agent IA pour poser des questions de suivi sur ce document.
                       </p>
                       <Button asChild>
                         <Link to={createPageUrl(`Chat?analysisId=${analysisResult.id}`)}>
                           <MessageSquare className="w-4 h-4 mr-2"/>
                           Poser une question sur cette analyse
                         </Link>
                       </Button>
                    </div>

                    <details>
                      <summary className="cursor-pointer font-semibold text-gray-700 mb-2">
                        🔍 Afficher les données brutes extraites
                      </summary>
                      <div className="bg-gray-100 rounded-lg p-4 text-xs">
                        <pre className="whitespace-pre-wrap">
                          {analysisResult.extracted_data}
                        </pre>
                      </div>
                    </details>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      )}
    </LimitChecker>
  );
}