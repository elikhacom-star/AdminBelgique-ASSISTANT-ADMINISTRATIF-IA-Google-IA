import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { api as base44 } from "@/components/api/wrapper";
import { useTranslation } from "../components/localization/useTranslation";
import SEOHead from "../components/seo/SEOHead";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, CheckCircle, Zap, TrendingUp, Star, Crown, Building2, Rocket, ArrowRight, Sparkles, MessageSquare, Bot, FileText, Shield, Lock, EyeOff, RefreshCw, Globe, Database, HelpCircle, BookOpen, Users, Calculator, Heart, Briefcase, GraduationCap, Home as HomeIcon } from "lucide-react";
import DisclaimerBanner from "../components/legal/DisclaimerBanner";
import PublicDocumentCounter from "../components/home/PublicDocumentCounter";


export default function Home() {
  const { t } = useTranslation();
  const [user, setUser] = useState(null);

  useEffect(() => {
    const checkUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {}
    };
    checkUser();
  }, []);

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Assistant Administratif IA Belgique | Agent Administratif",
    "description": "Assistant administratif IA et agent administratif Belgique pour automatiser vos tâches administratives avec intelligence artificielle",
    "url": "https://adminbelgique.com"
  };

  const trustFeatures = [
    {
      icon: Shield,
      title: t("home.trust.encryption"),
      description: t("home.trust.encryption_desc"),
      color: "text-blue-600"
    },
    {
      icon: Globe,
      title: t("home.trust.hosting"),
      description: t("home.trust.hosting_desc"),
      color: "text-green-600"
    },
    {
      icon: Lock,
      title: t("home.trust.gdpr"),
      description: t("home.trust.gdpr_desc"),
      color: "text-purple-600"
    },
    {
      icon: Bot,
      title: t("home.trust.ai_ethics"),
      description: t("home.trust.ai_ethics_desc"),
      color: "text-orange-600"
    }
  ];

  const administrativeCategories = [
    {
      id: "finances",
      title: t("category.finances"),
      description: t("category.finances_desc"),
      icon: Calculator,
      color: "bg-green-500",
      examples: [t("category.finances_ex1"), t("category.finances_ex2"), t("category.finances_ex3")]
    },
    {
      id: "securite_sociale",
      title: t("category.social_security"),
      description: t("category.social_security_desc"),
      icon: Shield,
      color: "bg-blue-500",
      examples: [t("category.social_security_ex1"), t("category.social_security_ex2"), t("category.social_security_ex3")]
    },
    {
      id: "emploi",
      title: t("category.employment"),
      description: t("category.employment_desc"),
      icon: Briefcase,
      color: "bg-purple-500",
      examples: [t("category.employment_ex1"), t("category.employment_ex3"), t("category.employment_ex2")]
    },
    {
      id: "sante",
      title: t("category.health"),
      description: t("category.health_desc"),
      icon: Heart,
      color: "bg-red-500",
      examples: [t("category.health_ex1"), t("category.health_ex3"), t("category.health_ex2")]
    },
    {
      id: "logement",
      title: t("category.housing"),
      description: t("category.housing_desc"),
      icon: HomeIcon,
      color: "bg-orange-500",
      examples: [t("category.housing_ex1"), t("category.housing_ex2"), t("category.housing_ex3")]
    },
    {
      id: "etudes",
      title: t("category.studies"),
      description: t("category.studies_desc"),
      icon: GraduationCap,
      color: "bg-indigo-500",
      examples: [t("category.studies_ex1"), t("category.studies_ex2"), t("category.studies_ex3")]
    },
    {
      id: "pensions",
      title: t("category.pensions"),
      description: t("category.pensions_desc"),
      icon: Users,
      color: "bg-teal-500",
      examples: [t("category.pensions_ex1"), t("category.pensions_ex2"), t("category.pensions_ex3")]
    }
  ];

  return (
    <>
      <SEOHead
        title="Agent Administratif IA Belgique | AdminBelgique 🇧🇪"
        description="🤖 Agent administratif IA Belgique : rédigez courriers, analysez documents (SPF Finances, INAMI, ONEM). Automatisation administrative Belgique. Essai gratuit ✨"
        keywords="assistant administratif ia, assistant administratif ia belgique, agent administratif ia, agent administratif belgique, automatisation administrative belgique"
        canonical="https://adminbelgique.com/"
        ogImage="https://adminbelgique.com/logo.png"
        structuredData={structuredData}
      />
      
      <DisclaimerBanner />
      
      <div className="min-h-screen">
        {/* Hero Section */}
        <div className="bg-gradient-to-br from-purple-50 via-white to-blue-50 py-8 px-3 md:py-16 md:px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-full px-3 py-1.5 md:px-6 md:py-3 shadow-lg mb-4 md:mb-6">
                <span className="text-lg md:text-2xl">🤖</span>
                <span className="font-bold text-sm md:text-base">{t("home.hero.badge")}</span>
              </div>
              
              {/* H1 PRINCIPAL OPTIMISÉ SEO */}
              <h1 className="text-2xl md:text-5xl lg:text-6xl font-extrabold text-gray-900 mb-4 md:mb-6 leading-tight">
                {t("home.hero.title")}
                <br />
                <span className="bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  {t("home.hero.title_span")}
                </span>
              </h1>
              
              {/* DESCRIPTION OPTIMISÉE */}
              <div className="text-sm md:text-xl text-gray-700 max-w-4xl mx-auto mb-4 md:mb-8 leading-relaxed">
                <p className="mb-2 md:mb-4 font-semibold text-sm md:text-xl">
                  {t("home.hero.subtitle")}
                </p>
              </div>

              <div className="bg-blue-100 border-2 border-blue-300 rounded-lg p-4 max-w-3xl mx-auto mb-8">
                <p className="text-sm text-blue-900">
                  <strong>⚠️ {t("home.info.title")}</strong> {t("home.info.text")}
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
                <Button asChild size="lg" className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white shadow-xl text-sm md:text-lg px-4 py-3 md:px-8 md:py-6 h-auto">
                  <Link to={createPageUrl("Assistant")}>
                    <Sparkles className="w-5 h-5 mr-2" />
                    {t("home.cta.button_start")}
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="border-2 border-gray-300 hover:border-yellow-500 text-sm md:text-lg px-4 py-3 md:px-8 md:py-6 h-auto">
                  <Link to={createPageUrl("Pricing")}>
                    <Crown className="w-5 h-5 mr-2" />
                    {t("home.services.title")}
                  </Link>
                </Button>
              </div>

              <div className="flex items-center justify-center gap-8 text-sm text-gray-600">
                <div className="flex -space-x-2">
                  {[1,2,3,4].map(i => (
                    <div key={i} className="w-8 h-8 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 border-2 border-white" />
                  ))}
                </div>
                <PublicDocumentCounter />
                <div className="flex items-center gap-1">
                  {[1,2,3,4,5].map(i => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="ml-2"><strong>4.8/5</strong> assistant administratif IA</span>
                </div>
              </div>
            </div>
          </div>
        </div>



        {/* NOUVEAU: Section "Pourquoi nous faire confiance" */}
        <div className="py-6 px-3 md:py-12 md:px-4 bg-white">
          <div className="max-w-6xl mx-auto">
            <div className="bg-gradient-to-r from-blue-50 via-white to-green-50 rounded-2xl shadow-xl p-4 md:p-8 border-2 border-blue-200">
              <div className="text-center mb-8">
                <div className="inline-flex items-center gap-2 bg-blue-100 border border-blue-300 rounded-full px-3 py-1.5 md:px-6 md:py-3 mb-3 md:mb-4">
                  <Shield className="w-6 h-6 text-blue-600" />
                  <span className="text-blue-800 font-bold text-sm md:text-lg">🛡️ {t("home.trust.title")}</span>
                </div>
                <h2 className="text-xl md:text-3xl font-bold text-gray-900 mb-3 md:mb-4">
                  {t("home.trust.subtitle")}
                </h2>
                <p className="text-gray-700 text-lg max-w-3xl mx-auto">
                  {t("home.trust.intro")}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {trustFeatures.map((feature, index) => (
                  <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
                    <div className={`w-10 h-10 md:w-14 md:h-14 rounded-full bg-gray-50 flex items-center justify-center mx-auto mb-2 md:mb-4 ${feature.color.replace('text-', 'hover:bg-')}-50 transition-all`}>
                      <feature.icon className={`w-5 h-5 md:w-8 md:h-8 ${feature.color}`} />
                    </div>
                    <h3 className="font-bold text-gray-900 text-center mb-3">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600 text-sm text-center leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                ))}
              </div>

              <div className="text-center mt-8">
                <div className="bg-white rounded-lg p-4 shadow-md inline-block">
                  <p className="text-sm text-gray-600">
                    <strong className="text-green-700">✓ {t("home.trust.certified")}</strong> {t("home.trust.certified_text")}
                  </p>
                </div>
              </div>

              {/* MediCare IA — Preuve de robustesse infrastructure */}
              <div className="mt-8 bg-gradient-to-r from-red-50 via-white to-rose-50 rounded-xl p-5 md:p-6 border border-red-200 shadow-md">
                <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-red-500 flex items-center justify-center">
                    <Heart className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="font-bold text-gray-900 text-lg">MediCare IA</span>
                      <span className="text-xs border border-red-300 bg-red-50 text-red-600 rounded-full px-2.5 py-0.5 font-medium">🚀 En Beta</span>
                    </div>
                    <p className="text-sm text-gray-700 leading-relaxed">
                      Notre infrastructure est si sécurisée et robuste qu'elle propulse également <strong>MediCare IA</strong>, 
                      notre assistant spécialisé dans le pré-diagnostic médical et l'analyse de données de santé confidentielles. 
                      Même architecture multi-agents, normes de sécurité du secteur médical.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Avantages */}
        <div className="py-8 px-3 md:py-16 md:px-4 bg-white">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-xl md:text-4xl font-bold text-center text-gray-900 mb-3 md:mb-4">
              {t("home.advantages.title")}
            </h2>
            <p className="text-center text-gray-600 mb-10 max-w-3xl mx-auto">
              {t("home.advantages.subtitle")}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="hover:shadow-xl transition-all border-2 hover:border-yellow-300">
                <CardContent className="p-4 md:p-6 text-center">
                  <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Clock className="w-8 h-8 text-yellow-600" />
                  </div>
                  <div className="text-4xl font-bold text-yellow-600 mb-2">-80%</div>
                  <h3 className="font-bold text-gray-900 mb-2">{t("home.advantages.fast")}</h3>
                  <p className="text-sm text-gray-600">{t("home.advantages.fast_desc")}</p>
                </CardContent>
              </Card>
              <Card className="hover:shadow-xl transition-all border-2 hover:border-yellow-300">
                <CardContent className="p-4 md:p-6 text-center">
                  <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-yellow-600" />
                  </div>
                  <div className="text-4xl font-bold text-yellow-600 mb-2">98%</div>
                  <h3 className="font-bold text-gray-900 mb-2">{t("home.advantages.reliable")}</h3>
                  <p className="text-sm text-gray-600">{t("home.advantages.reliable_desc")}</p>
                </CardContent>
              </Card>
              <Card className="hover:shadow-xl transition-all border-2 hover:border-yellow-300">
                <CardContent className="p-4 md:p-6 text-center">
                  <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Zap className="w-8 h-8 text-yellow-600" />
                  </div>
                  <div className="text-4xl font-bold text-yellow-600 mb-2">&lt;30s</div>
                  <h3 className="font-bold text-gray-900 mb-2">{t("home.advantages.instant")}</h3>
                  <p className="text-sm text-gray-600">{t("home.advantages.instant_desc")}</p>
                </CardContent>
              </Card>
              <Card className="hover:shadow-xl transition-all border-2 hover:border-yellow-300">
                <CardContent className="p-4 md:p-6 text-center">
                  <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="w-8 h-8 text-yellow-600" />
                  </div>
                  <div className="text-4xl font-bold text-yellow-600 mb-2">4.8/5</div>
                  <h3 className="font-bold text-gray-900 mb-2">{t("home.advantages.performant")}</h3>
                  <p className="text-sm text-gray-600">{t("home.advantages.performant_desc")}</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>



        {/* Services */}
        <div className="py-8 px-3 md:py-16 md:px-4 bg-white">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-xl md:text-4xl font-bold text-center text-gray-900 mb-3 md:mb-4">
              {t("home.services.title")}
            </h2>
            <p className="text-center text-gray-600 mb-10 max-w-3xl mx-auto">
              {t("home.services.subtitle")}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Link to={createPageUrl("Assistant")} className="group">
                <Card className="h-full hover:shadow-2xl transition-all border-2 hover:border-yellow-400">
                  <CardHeader className="bg-yellow-500 text-white p-6">
                    <MessageSquare className="w-12 h-12 mb-4" />
                    <CardTitle className="text-xl">{t("home.services.simple.title")}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <p className="text-sm text-gray-600 mb-4">
                      {t("home.services.simple.desc")}
                    </p>
                    <div className="flex items-center text-yellow-600 font-semibold">
                      {t("home.services.simple.action")}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </div>
                  </CardContent>
                </Card>
              </Link>

              <Link to={createPageUrl("Chat")} className="group">
                <Card className="h-full hover:shadow-2xl transition-all border-2 hover:border-blue-400">
                  <CardHeader className="bg-blue-500 text-white p-6">
                    <Bot className="w-12 h-12 mb-4" />
                    <CardTitle className="text-xl">{t("home.services.advanced.title")}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <p className="text-sm text-gray-600 mb-4">
                      {t("home.services.advanced.desc")}
                    </p>
                    <div className="flex items-center text-blue-600 font-semibold">
                      {t("home.services.advanced.action")}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </div>
                  </CardContent>
                </Card>
              </Link>

              <Link to={createPageUrl("DocumentGenerator")} className="group">
                <Card className="h-full hover:shadow-2xl transition-all border-2 hover:border-red-400">
                  <CardHeader className="bg-red-500 text-white p-6">
                    <FileText className="w-12 h-12 mb-4" />
                    <CardTitle className="text-xl">{t("home.services.doc.title")}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <p className="text-sm text-gray-600 mb-4">
                      {t("home.services.doc.desc")}
                    </p>
                    <div className="flex items-center text-red-600 font-semibold">
                      {t("home.services.doc.action")}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </div>
          </div>
        </div>

        {/* Categories Grid */}
        <div className="py-12 px-4 bg-gray-50">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center gap-2 mb-6">
              <Sparkles className="w-6 h-6 text-yellow-600" />
              <h2 className="text-2xl font-bold text-gray-900">{t("home.domains.title")}</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {administrativeCategories.map((category) => (
                <Card key={category.id} className="group hover:shadow-lg transition-all duration-300 border-2 hover:border-yellow-300 cursor-pointer">
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-3">
                      <div className={`p-3 rounded-xl ${category.color} bg-opacity-20 group-hover:bg-opacity-30 transition-all duration-300`}>
                        <category.icon className={`w-6 h-6 ${category.color.replace('bg-', 'text-')}`} />
                      </div>
                      <div>
                        <CardTitle className="text-lg group-hover:text-yellow-800 transition-colors">
                          {category.title}
                        </CardTitle>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">{category.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {category.examples.map((example, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {example}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>



        {/* NOUVEAU: Section Protection Détaillée avec TABLEAU */}
        <div className="py-8 px-3 md:py-16 md:px-4 bg-white">
          <div className="max-w-6xl mx-auto">
            <div className="bg-gradient-to-r from-green-50 via-blue-50 to-purple-50 rounded-2xl shadow-xl p-8 border-2 border-green-200">
              <div className="text-center mb-8">
                <div className="inline-flex items-center gap-2 bg-green-100 border border-green-300 rounded-full px-6 py-3 mb-4">
                  <Shield className="w-6 h-6 text-green-600" />
                  <span className="text-green-800 font-bold text-lg">🔒 {t("home.security.title_badge")}</span>
                </div>
                <h2 className="text-xl md:text-3xl font-bold text-gray-900 mb-3 md:mb-4">
                  {t("home.security.title")}
                </h2>
              </div>

              {/* Les 3 étapes d'anonymisation */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
                <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-blue-500">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <Lock className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900">{t("home.security.step1.title")}</h3>
                      <p className="text-sm text-blue-600">{t("home.security.step1.subtitle")}</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <p className="text-sm text-gray-700"><strong>{t("home.security.step1.you_write")}</strong></p>
                    <div className="bg-gray-50 p-3 rounded-lg text-xs font-mono">
                      "Je suis Jean Dupont, NN: 80.01.01-123.45<br/>
                      Email: jean@email.com"
                    </div>
                    <p className="text-sm text-gray-700"><strong>{t("home.security.step1.ai_receives")}</strong></p>
                    <div className="bg-green-50 p-3 rounded-lg text-xs font-mono border border-green-200">
                      "Je suis [PERSON_1], NN: [NN_1]<br/>
                      Email: [EMAIL_1]"
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-purple-500">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                      <EyeOff className="w-6 h-6 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900">{t("home.security.step2.title")}</h3>
                      <p className="text-sm text-purple-600">{t("home.security.step2.subtitle")}</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <p className="text-sm text-gray-700">{t("home.security.step2.desc")}</p>
                    <div className="bg-purple-50 p-3 rounded-lg text-xs border border-purple-200">
                      <strong>🤖 IA :</strong> "{t("home.security.step2.ai_quote")}"
                    </div>
                    <div className="text-center">
                      <div className="inline-flex items-center gap-2 bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs">
                        <EyeOff className="w-3 h-3" />
                        {t("home.security.step2.invisible")}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-green-500">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                      <RefreshCw className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900">{t("home.security.step3.title")}</h3>
                      <p className="text-sm text-green-600">{t("home.security.step3.subtitle")}</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <p className="text-sm text-gray-700"><strong>{t("home.security.step3.ai_replies")}</strong></p>
                    <div className="bg-gray-50 p-3 rounded-lg text-xs font-mono">
                      "Pour [NN_1], contactez l'administration à [EMAIL_1]"
                    </div>
                    <p className="text-sm text-gray-700"><strong>{t("home.security.step3.you_receive")}</strong></p>
                    <div className="bg-green-50 p-3 rounded-lg text-xs font-mono border border-green-200">
                      "Pour 80.01.01-123.45, contactez l'administration à jean@email.com"
                    </div>
                  </div>
                </div>
              </div>

              {/* NOUVEAU TABLEAU DÉTAILLÉ - COPIÉ DE L'AUTRE VERSION */}
              <div className="bg-white rounded-xl p-6 shadow-lg">
                <h3 className="text-xl font-bold text-gray-900 mb-6 text-center">
                  🔐 {t("home.security.table.title")}
                </h3>
                <p className="text-center text-gray-600 mb-6">
                  {t("home.security.table.subtitle")}
                </p>
                
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="border border-gray-300 px-6 py-4 text-left font-bold text-gray-900">
                          {t("home.security.table.col1")}
                        </th>
                        <th className="border border-gray-300 px-6 py-4 text-left font-bold text-gray-900">
                          {t("home.security.table.col2")}
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="hover:bg-blue-50 transition-colors">
                        <td className="border border-gray-300 px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                              <Lock className="w-5 h-5 text-yellow-600" />
                            </div>
                            <div>
                              <div className="font-semibold text-gray-900">{t("home.security.table.row1.title")}</div>
                            </div>
                          </div>
                        </td>
                        <td className="border border-gray-300 px-6 py-4 text-gray-700">
                          {t("home.security.table.row1.desc")}
                        </td>
                      </tr>
                      
                      <tr className="hover:bg-purple-50 transition-colors">
                        <td className="border border-gray-300 px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                              <span className="text-purple-600">🕵️</span>
                            </div>
                            <div>
                              <div className="font-semibold text-gray-900">{t("home.security.table.row2.title")}</div>
                            </div>
                          </div>
                        </td>
                        <td className="border border-gray-300 px-6 py-4 text-gray-700">
                          <div className="space-y-1">
                            <div className="font-medium text-purple-800">
                              {t("home.security.table.row2.desc1")}
                            </div>
                            <div className="text-sm text-purple-600">
                              {t("home.security.table.row2.desc2")}
                            </div>
                          </div>
                        </td>
                      </tr>
                      
                      <tr className="hover:bg-green-50 transition-colors">
                        <td className="border border-gray-300 px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                              <Database className="w-5 h-5 text-green-600" />
                            </div>
                            <div>
                              <div className="font-semibold text-gray-900">{t("home.security.table.row3.title")}</div>
                            </div>
                          </div>
                        </td>
                        <td className="border border-gray-300 px-6 py-4 text-gray-700">
                          <div className="space-y-1">
                            <div>{t("home.security.table.row3.desc1")}</div>
                            <div className="text-sm text-green-600 font-medium">
                              {t("home.security.table.row3.desc2")}
                            </div>
                          </div>
                        </td>
                      </tr>
                      
                      <tr className="hover:bg-red-50 transition-colors">
                        <td className="border border-gray-300 px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                              <Shield className="w-5 h-5 text-red-600" />
                            </div>
                            <div>
                              <div className="font-semibold text-gray-900">{t("home.security.table.row4.title")}</div>
                            </div>
                          </div>
                        </td>
                        <td className="border border-gray-300 px-6 py-4 text-gray-700">
                          {t("home.security.table.row4.desc")}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                
                <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-gray-700 text-center">
                    <strong>🎯 {t("home.security.result")}</strong> {t("home.security.result_text")}
                  </p>
                </div>
              </div>

              {/* Garanties */}
              <div className="bg-white rounded-xl p-6 shadow-lg mt-8">
                <h3 className="text-xl font-bold text-gray-900 mb-4 text-center">
                  🛡️ {t("home.security.guarantees.title")}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <EyeOff className="w-6 h-6 text-red-600" />
                    </div>
                    <h4 className="font-semibold text-gray-900 text-sm">{t("home.security.guarantees.zero_vis")}</h4>
                    <p className="text-xs text-gray-600">{t("home.security.guarantees.zero_vis_desc")}</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Lock className="w-6 h-6 text-blue-600" />
                    </div>
                    <h4 className="font-semibold text-gray-900 text-sm">{t("home.security.guarantees.local_enc")}</h4>
                    <p className="text-xs text-gray-600">{t("home.security.guarantees.local_enc_desc")}</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Shield className="w-6 h-6 text-green-600" />
                    </div>
                    <h4 className="font-semibold text-gray-900 text-sm">{t("home.security.guarantees.gdpr")}</h4>
                    <p className="text-xs text-gray-600">{t("home.security.guarantees.gdpr_desc")}</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <RefreshCw className="w-6 h-6 text-purple-600" />
                    </div>
                    <h4 className="font-semibold text-gray-900 text-sm">{t("home.security.guarantees.zero_trace")}</h4>
                    <p className="text-xs text-gray-600">{t("home.security.guarantees.zero_trace_desc")}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Final */}
        <div className="py-20 px-4 bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500">
          <div className="max-w-4xl mx-auto text-center text-white">
            <h2 className="text-4xl font-bold mb-6">
              {t("home.cta.title")}
            </h2>
            <p className="text-xl mb-4 opacity-90">
              {t("home.cta.subtitle")}
            </p>
            <p className="text-lg mb-8 opacity-80">
              {t("home.cta.features")}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-100 text-sm md:text-lg px-4 py-3 md:px-8 md:py-6 h-auto">
                <Link to={createPageUrl("Chat")}>
                  <Sparkles className="w-5 h-5 mr-2" />
                  {t("home.cta.button_start")}
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-gray-900 text-sm md:text-lg px-4 py-3 md:px-8 md:py-6 h-auto">
                <Link to={createPageUrl("Contact")}>
                  {t("home.cta.button_contact")}
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}