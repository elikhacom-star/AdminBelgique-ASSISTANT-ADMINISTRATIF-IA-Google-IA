
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, CheckCircle, ExternalLink, Mail, Copy } from "lucide-react";

export default function Redirections301Guide() {
  // Ajouter meta noindex
  React.useEffect(() => {
    const metaRobots = document.createElement('meta');
    metaRobots.name = 'robots';
    metaRobots.content = 'noindex, nofollow';
    document.head.appendChild(metaRobots);

    return () => {
      document.head.removeChild(metaRobots);
    };
  }, []);

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert("Copié !");
  };

  const emailTemplate = `Objet : [URGENT] Configuration Redirections 301 - adminbelgique.com

Bonjour l'équipe Base44,

Je vous contacte concernant mon application AdminBelgique (adminbelgique.com) qui rencontre une erreur critique de redirections impactant son référencement Google.

PROBLÈME DÉTECTÉ :
Google Search Console rapporte des erreurs "Page avec redirection" pour les URLs suivantes :
• https://www.adminbelgique.com/
• http://adminbelgique.com/
• http://www.adminbelgique.com/

CONFIGURATION SOUHAITÉE :
Toutes ces URLs doivent rediriger (301 Moved Permanently) vers :
➡️ https://adminbelgique.com/ (version canonique)

ACTIONS REQUISES :
1. Implémenter des redirections permanentes (HTTP 301) :
   - http://adminbelgique.com/ → https://adminbelgique.com/
   - http://www.adminbelgique.com/ → https://adminbelgique.com/
   - https://www.adminbelgique.com/ → https://adminbelgique.com/

2. S'assurer qu'il n'y a pas de chaînes de redirections (redirection directe en 1 saut)

3. Vérifier que le certificat SSL couvre toutes les variantes du domaine

IMPACT SEO ACTUEL :
Cette configuration incorrecte empêche Google d'indexer correctement mon site et dilue mon autorité de domaine (duplicate content).

URGENCE : CRITIQUE
Cette correction doit être prioritaire pour éviter une perte de positionnement SEO.

Merci de confirmer la prise en compte et le délai de résolution.

Cordialement,
[Votre Nom]
App ID : [Votre App ID Base44]
Domaine : adminbelgique.com`;

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        
        {/* Header Alert */}
        <Alert className="mb-8 bg-red-50 border-2 border-red-300">
          <AlertTriangle className="h-6 w-6 text-red-600" />
          <AlertTitle className="text-red-900 font-bold text-lg">
            🚨 Problème Infrastructure Critique
          </AlertTitle>
          <AlertDescription className="text-red-800">
            <p className="font-semibold mb-2">
              Les redirections 301 nécessitent une configuration au niveau serveur/DNS.
            </p>
            <p>
              Cette configuration ne peut PAS être faite via le code de l'application. 
              Vous devez contacter le support Base44 ou configurer votre hébergeur.
            </p>
          </AlertDescription>
        </Alert>

        <div className="text-center mb-8">
          <Badge className="mb-4 bg-blue-100 text-blue-800 border-blue-300">
            <ExternalLink className="w-4 h-4 mr-2" />
            Guide Configuration Redirections 301
          </Badge>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Configuration Redirections 301 pour adminbelgique.com
          </h1>
          <p className="text-gray-600">
            Guide complet pour résoudre les erreurs Google Search Console
          </p>
        </div>

        {/* Diagnostic Actuel */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
              État Actuel des Redirections
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="bg-red-50 p-4 rounded-lg border-2 border-red-200">
                <p className="font-semibold text-red-900 mb-2">❌ URLs Problématiques :</p>
                <ul className="space-y-1 text-sm text-red-800">
                  <li>• <code className="bg-red-100 px-2 py-1 rounded">https://www.adminbelgique.com/</code></li>
                  <li>• <code className="bg-red-100 px-2 py-1 rounded">http://adminbelgique.com/</code></li>
                  <li>• <code className="bg-red-100 px-2 py-1 rounded">http://www.adminbelgique.com/</code></li>
                </ul>
              </div>

              <div className="bg-green-50 p-4 rounded-lg border-2 border-green-200">
                <p className="font-semibold text-green-900 mb-2">✅ URL Canonique (cible) :</p>
                <code className="bg-green-100 px-3 py-2 rounded text-green-800 font-mono">
                  https://adminbelgique.com/
                </code>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Configuration Technique */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>⚙️ Configuration Technique Requise</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-700">
              Les redirections suivantes doivent être implémentées au niveau serveur (HTTP 301) :
            </p>

            <div className="bg-gray-50 p-4 rounded-lg border space-y-2 font-mono text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-600">http://adminbelgique.com/</span>
                <span className="text-blue-600">→ 301 →</span>
                <span className="text-green-600 font-bold">https://adminbelgique.com/</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-600">http://www.adminbelgique.com/</span>
                <span className="text-blue-600">→ 301 →</span>
                <span className="text-green-600 font-bold">https://adminbelgique.com/</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-600">https://www.adminbelgique.com/</span>
                <span className="text-blue-600">→ 301 →</span>
                <span className="text-green-600 font-bold">https://adminbelgique.com/</span>
              </div>
            </div>

            <Alert className="bg-yellow-50 border-yellow-300">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-900">
                <strong>Important :</strong> Les redirections doivent être DIRECTES (1 saut), 
                pas de chaînes de redirections (A → B → C).
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* Email Template */}
        <Card className="mb-6 bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-300">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-blue-600" />
              Email Pré-Rédigé pour Support Base44
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <pre className="bg-white p-4 rounded-lg border text-sm overflow-x-auto whitespace-pre-wrap">
                {emailTemplate}
              </pre>
              <Button
                onClick={() => copyToClipboard(emailTemplate)}
                className="absolute top-2 right-2"
                variant="outline"
                size="sm"
              >
                <Copy className="w-4 h-4 mr-2" />
                Copier l'email
              </Button>
            </div>

            <div className="mt-4 flex gap-3">
              <Button asChild className="bg-blue-600 hover:bg-blue-700">
                <a href="mailto:support@base44.io?subject=[URGENT] Configuration Redirections 301 - adminbelgique.com">
                  <Mail className="w-4 h-4 mr-2" />
                  Envoyer au Support Base44
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Vérification Canonical Tags */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              ✅ Canonical Tags (Déjà Configurés)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 mb-4">
              Les canonical tags sont déjà correctement configurés dans votre code HTML :
            </p>
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <code className="text-sm text-green-800">
                &lt;link rel="canonical" href="https://www.adminbelgique.com/" /&gt;
              </code>
            </div>
            <p className="text-sm text-gray-600 mt-3">
              ✅ Cela aide Google à comprendre quelle est votre URL préférée, 
              MAIS cela ne remplace pas les redirections 301 au niveau serveur.
            </p>
          </CardContent>
        </Card>

        {/* Plan d'Action */}
        <Card className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-4">📋 Plan d'Action Immédiat</h2>
            <ol className="space-y-3 text-lg">
              <li className="flex items-start gap-3">
                <span className="font-bold">1.</span>
                <span>Copier l'email pré-rédigé ci-dessus</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="font-bold">2.</span>
                <span>Contacter le support Base44 (support@base44.io)</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="font-bold">3.</span>
                <span>Attendre confirmation de la mise en place des redirections</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="font-bold">4.</span>
                <span>Tester avec : <code className="bg-white/20 px-2 py-1 rounded">curl -I https://www.adminbelgique.com</code></span>
              </li>
              <li className="flex items-start gap-3">
                <span className="font-bold">5.</span>
                <span>Relancer la validation dans Google Search Console</span>
              </li>
            </ol>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
