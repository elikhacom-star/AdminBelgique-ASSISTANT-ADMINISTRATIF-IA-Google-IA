import React, { useState, useEffect } from "react";
import { Template } from "@/entities/Template";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Plus, Search, Edit2, Trash2, Share2, Copy, Loader2, Save, Wand2 } from "lucide-react";
import { format } from "date-fns";
import { api as base44 } from "@/components/api/wrapper";
import { Badge } from "@/components/ui/badge";
import StarterTemplates from "@/components/templates/StarterTemplates";
import TemplateGeneratorDialog from "@/components/templates/TemplateGeneratorDialog";
import TemplateCategoryFilter from "@/components/templates/TemplateCategoryFilter";
import { TEMPLATE_CATEGORIES, getCategoryLabel } from "@/lib/templateCategories";

export default function Templates() {
  const [templates, setTemplates] = useState([]);
  const [filteredTemplates, setFilteredTemplates] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  // Form State
  const [currentTemplate, setCurrentTemplate] = useState(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    content: "",
    category: "autre",
    is_public: false
  });
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Sharing State
  const [shareEmail, setShareEmail] = useState("");
  const [isSharing, setIsSharing] = useState(false);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [templateToShare, setTemplateToShare] = useState(null);

  // Generator State
  const [generatorTemplate, setGeneratorTemplate] = useState(null);
  const [isGeneratorOpen, setIsGeneratorOpen] = useState(false);

  const openGenerator = (template) => {
    setGeneratorTemplate(template);
    setIsGeneratorOpen(true);
  };

  useEffect(() => {
    const init = async () => {
      try {
        const user = await base44.auth.me();
        setCurrentUser(user);
        await loadTemplates();
      } catch (error) {
        console.error("Init error:", error);
      }
    };
    init();
  }, []);

  const loadTemplates = async () => {
    setIsLoading(true);
    try {
      const data = await Template.list("-created_date");
      setTemplates(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Error loading templates:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const term = searchTerm.toLowerCase();
    setFilteredTemplates(templates.filter(t =>
      (activeCategory === "all" || (t.category || "autre") === activeCategory) &&
      (!term ||
        t.title.toLowerCase().includes(term) ||
        t.description?.toLowerCase().includes(term) ||
        getCategoryLabel(t.category).toLowerCase().includes(term))
    ));
  }, [searchTerm, activeCategory, templates]);

  const handleCreate = () => {
    setCurrentTemplate(null);
    setFormData({
      title: "",
      description: "",
      content: "",
      category: "autre",
      is_public: false
    });
    setIsEditing(false);
    setIsDialogOpen(true);
  };

  const handleEdit = (template) => {
    if (template.created_by !== currentUser?.email) {
      alert("Vous ne pouvez modifier que vos propres modèles.");
      return;
    }
    setCurrentTemplate(template);
    setFormData({
      title: template.title,
      description: template.description || "",
      content: template.content,
      category: template.category || "autre",
      is_public: template.is_public || false
    });
    setIsEditing(true);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer ce modèle ?")) return;
    try {
      await Template.delete(id);
      setTemplates(prev => prev.filter(t => t.id !== id));
    } catch (error) {
      console.error("Error deleting:", error);
      alert("Erreur lors de la suppression");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (isEditing && currentTemplate) {
        await Template.update(currentTemplate.id, formData);
      } else {
        await Template.create(formData);
      }
      setIsDialogOpen(false);
      loadTemplates();
    } catch (error) {
      console.error("Error saving:", error);
      alert("Erreur lors de la sauvegarde");
    }
  };

  const openShareDialog = (template) => {
    setTemplateToShare(template);
    setShareEmail("");
    setShareDialogOpen(true);
  };

  const handleShare = async () => {
    if (!templateToShare || !shareEmail) return;
    setIsSharing(true);
    try {
      const currentShared = templateToShare.shared_with || [];
      if (!currentShared.includes(shareEmail)) {
        const updatedShared = [...currentShared, shareEmail];
        await Template.update(templateToShare.id, { shared_with: updatedShared });
        
        // Update local state
        setTemplates(prev => prev.map(t => 
          t.id === templateToShare.id ? { ...t, shared_with: updatedShared } : t
        ));
        
        alert(`Modèle partagé avec ${shareEmail}`);
        setShareEmail("");
        setShareDialogOpen(false);
      } else {
        alert("Déjà partagé avec cet email");
      }
    } catch (error) {
      console.error("Error sharing:", error);
      alert("Erreur lors du partage");
    } finally {
      setIsSharing(false);
    }
  };

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              <FileText className="w-8 h-8 text-blue-600" />
              Mes Modèles
            </h1>
            <p className="text-gray-600 mt-1">Générez une mise en demeure, un bail ou tout autre document en quelques clics</p>
          </div>
          <Button onClick={handleCreate} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Nouveau Modèle
          </Button>
        </div>

        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-1 flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-blue-600" />
            Modèles prêts à l'emploi
          </h2>
          <p className="text-sm text-gray-600 mb-4">
            Mise en demeure, bail, garantie locative : complétez les champs et le document est rédigé automatiquement.
          </p>
          <StarterTemplates onSelect={openGenerator} />
        </div>

        <div className="flex items-center gap-2 mb-4">
          <FileText className="w-5 h-5 text-blue-600" />
          <h2 className="text-xl font-bold text-gray-900">Mes modèles</h2>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Rechercher un modèle..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 border-gray-200"
            />
          </div>
          <TemplateCategoryFilter templates={templates} active={activeCategory} onChange={setActiveCategory} />
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : filteredTemplates.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-xl border-2 border-dashed border-gray-200">
            <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Aucun modèle trouvé</h3>
            <p className="text-gray-500 mb-6">Créez votre premier modèle personnalisé pour gagner du temps.</p>
            <Button onClick={handleCreate} variant="outline">
              Créer un modèle
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTemplates.map((template) => (
              <Card key={template.id} className="hover:shadow-lg transition-all duration-200 group">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <Badge variant={template.is_public ? "default" : "secondary"} className="mb-2">
                      {getCategoryLabel(template.category)}
                    </Badge>
                    {template.is_public && <Badge variant="outline" className="ml-2 border-blue-200 text-blue-700">Public</Badge>}
                  </div>
                  <CardTitle className="text-lg line-clamp-1" title={template.title}>
                    {template.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pb-3">
                  <p className="text-sm text-gray-500 line-clamp-2 mb-4 h-10">
                    {template.description || "Pas de description"}
                  </p>
                  <div className="text-xs text-gray-400">
                    Modifié le {format(new Date(template.updated_date || template.created_date), "dd/MM/yyyy")}
                  </div>
                </CardContent>
                <CardFooter className="pt-3 border-t bg-gray-50 flex justify-between">
                  <div className="flex gap-2">
                    {template.created_by === currentUser?.email ? (
                      <>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-blue-600" onClick={() => handleEdit(template)}>
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-red-600" onClick={() => handleDelete(template.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-green-600" onClick={() => openShareDialog(template)}>
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </>
                    ) : (
                      <span className="text-xs text-gray-500 italic py-2">Partagé par {template.created_by}</span>
                    )}
                  </div>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm" className="text-blue-700 hover:text-blue-800" onClick={() => openGenerator(template)}>
                      <Wand2 className="w-4 h-4 mr-2" /> Générer
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500" onClick={() => {
                       navigator.clipboard.writeText(template.content);
                       alert("Contenu copié !");
                    }}>
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}

        {/* Create/Edit Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{isEditing ? "Modifier le modèle" : "Nouveau modèle"}</DialogTitle>
              <DialogDescription>
                Créez un modèle réutilisable pour vos documents administratifs.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title">Titre</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="category">Catégorie</Label>
                  <Select 
                    value={formData.category} 
                    onValueChange={(val) => setFormData({ ...formData, category: val })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choisir..." />
                    </SelectTrigger>
                    <SelectContent>
                      {TEMPLATE_CATEGORIES.map((category) => (
                        <SelectItem key={category.value} value={category.value}>
                          {category.icon} {category.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">Description (optionnelle)</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="content">Contenu du modèle</Label>
                <Textarea
                  id="content"
                  className="min-h-[300px] font-mono text-sm"
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  required
                />
                <p className="text-xs text-gray-500">Vous pouvez utiliser des variables comme [NOM], [DATE], etc.</p>
              </div>
              <DialogFooter>
                <Button type="submit" className="w-full sm:w-auto">
                  <Save className="w-4 h-4 mr-2" />
                  {isEditing ? "Mettre à jour" : "Créer le modèle"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Share Dialog */}
        <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Partager le modèle</DialogTitle>
              <DialogDescription>
                Partagez "{templateToShare?.title}" avec d'autres utilisateurs.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="share-email">Email de l'utilisateur</Label>
                <Input
                  id="share-email"
                  placeholder="user@example.com"
                  value={shareEmail}
                  onChange={(e) => setShareEmail(e.target.value)}
                />
              </div>
              {templateToShare?.shared_with?.length > 0 && (
                <div className="text-sm text-gray-500">
                  <p className="font-semibold mb-1">Déjà partagé avec :</p>
                  <ul className="list-disc pl-5">
                    {templateToShare.shared_with.map((email, i) => (
                      <li key={i}>{email}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button onClick={handleShare} disabled={isSharing}>
                {isSharing ? "Partage..." : "Partager"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <TemplateGeneratorDialog
          template={generatorTemplate}
          open={isGeneratorOpen}
          onOpenChange={setIsGeneratorOpen} />
      </div>
    </div>
  );
}