import React, { useState, useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { db, api as base44 } from "@/components/api/wrapper";
const User = db.User;
const Analyse = db.Analyse;
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Bot, Send, Loader2, Sparkles, User as UserIcon, Plus, MessageSquare, Paperclip, X, FileText, HelpCircle, Archive, Save, Keyboard, Edit, Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { AnimatePresence, motion } from "framer-motion";
import SimpleLogin from "../components/auth/SimpleLogin";
import MessageBubble from "../components/chat/MessageBubble";
import LimitChecker from "../components/freemium/LimitChecker";
import { throttledAPICall } from "../components/utils/apiThrottle";
import { useTranslation } from "../components/localization/useTranslation";
import OnboardingTour from "../components/onboarding/OnboardingTour";
import EmergencyQuickReplies from "@/components/emergency/EmergencyQuickReplies";
import EmergencyDisplay, { DEFAULT_EMERGENCY_OPTIONS } from "@/components/emergency/EmergencyDisplay";
import PinnedEmergencyBar from "@/components/emergency/PinnedEmergencyBar";

const AGENT_NAME = "admin_belge";

export default function Chat() {
  const { t, locale } = useTranslation();
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [isCheckingUser, setIsCheckingUser] = useState(true);
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [showTour, setShowTour] = useState(false);
  const [showArchived, setShowArchived] = useState(false);

  // Nouveaux états pour renommage et recherche
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [messageSearchTerm, setMessageSearchTerm] = useState("");
  const [pinnedEmergency, setPinnedEmergency] = useState(null);

  const messagesEndRef = useRef(null);
  const messagesContainerRef = useRef(null);
  const fileInputRef = useRef(null);

  const chatSteps = [
  {
    title: "🤖 Agent IA Intelligent",
    description: "Bienvenue dans votre espace de discussion avec l'IA. Posez vos questions administratives ici.",
    icon: <Bot className="w-6 h-6 text-blue-600" />
  },
  {
    title: "💬 Posez vos questions",
    description: "Écrivez votre question simplement. L'IA comprend le contexte et peut suivre une conversation.",
    icon: <MessageSquare className="w-6 h-6 text-green-600" />
  },
  {
    title: "📎 Joindre des fichiers",
    description: "Vous pouvez analyser des courriers ou documents en les téléchargeant ici (PDF, images...).",
    icon: <Paperclip className="w-6 h-6 text-gray-600" />
  },
  {
    title: "➕ Nouvelle discussion",
    description: "Pour changer de sujet, commencez une nouvelle conversation pour repartir à zéro.",
    icon: <Plus className="w-6 h-6 text-purple-600" />
  }];


  useEffect(() => {
    const fetchUser = async () => {
      try {
        const fetchedUser = await base44.auth.me();
        setUser(fetchedUser);
      } catch (error) {
        console.error("No user logged in or error fetching user:", error);
        setUser(null);
      } finally {
        setIsCheckingUser(false);
      }
    };

    fetchUser();
  }, []);

  useEffect(() => {
    if (user && !conversation) {
      const initConversation = async () => {
        try {
          const existingConversations = await throttledAPICall(() =>
          base44.agents.listConversations({ agent_name: AGENT_NAME })
          );

          let activeConversation = existingConversations[0] || null;

          if (!activeConversation) {
            activeConversation = await throttledAPICall(() =>
            base44.agents.createConversation({
              agent_name: AGENT_NAME,
              metadata: {
                user_email: user.email,
                user_name: user.full_name,
                platform: 'web',
                created_at: new Date().toISOString()
              }
            })
            );
          }

          setConversation(activeConversation);
          setMessages(activeConversation.messages || []);
        } catch (error) {
          console.error("Error initializing conversation:", error);

          if (error?.response?.status === 429) {
            alert("⏸️ Trop de requêtes. Veuillez patienter quelques secondes et recharger la page.");
          }
        }
      };
      initConversation();
    }
  }, [user, conversation]);

  useEffect(() => {
    if (!conversation) return;

    const unsubscribe = base44.agents.subscribeToConversation(conversation.id, (data) => {
      setMessages(data.messages);
    });

    return () => {
      unsubscribe();
    };
  }, [conversation]);

  useEffect(() => {
    const stored = localStorage.getItem('adminbelgique_pinned_emergency');
    if (stored) {
      try {
        setPinnedEmergency(JSON.parse(stored));
      } catch (_) {}
    }
  }, []);

  useEffect(() => {
    if (!location.state?.emergencyPrompt) return;
    setInput(location.state.emergencyPrompt);
    navigate(location.pathname, { replace: true, state: {} });
  }, [location.state, location.pathname, navigate]);

  useEffect(() => {
    const latestEmergencyMessage = [...messages].reverse().find((msg) => {
      if (!msg?.content) return false;
      try {
        const parsed = JSON.parse(msg.content.trim());
        return parsed.status === 'EMERGENCY_ACTIVE';
      } catch {
        return false;
      }
    });

    if (!latestEmergencyMessage) return;

    try {
      const parsed = JSON.parse(latestEmergencyMessage.content.trim());
      setPinnedEmergency(parsed);
      localStorage.setItem('adminbelgique_pinned_emergency', JSON.stringify(parsed));
    } catch (_) {}
  }, [messages]);

  useEffect(() => {
    const container = messagesContainerRef.current;
    if (container) {
      container.scrollTo({ top: container.scrollHeight, behavior: "smooth" });
    }
  }, [messages]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Ctrl/Cmd + Enter to send (handled in textarea/form but good to have globally if focused elsewhere)
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {











        // Logic handled in form submission
      } // Ctrl/Cmd + Shift + A to archive
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'A') {e.preventDefault();if (conversation) handleArchiveConversation();} // Ctrl/Cmd + N to new chat
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'N') {e.preventDefault();handleNewChat();}};

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [conversation]);

  const handleArchiveConversation = async () => {
    if (!conversation) return;
    try {
      const isArchived = conversation.metadata?.archived === true;
      await base44.agents.updateConversation(conversation.id, {
        metadata: {
          ...conversation.metadata,
          archived: !isArchived
        }
      });
      alert(isArchived ? "Conversation désarchivée" : "Conversation archivée");
      // Refresh logic if needed or local state update
      setConversation((prev) => ({
        ...prev,
        metadata: {
          ...prev.metadata,
          archived: !isArchived
        }
      }));
    } catch (error) {
      console.error("Error archiving conversation:", error);
    }
  };

  const handleRenameConversation = async () => {
    if (!conversation || !newTitle.trim()) return;
    try {
      await base44.agents.updateConversation(conversation.id, {
        metadata: {
          ...conversation.metadata,
          user_name: user.full_name, // keep existing
          platform: 'web', // keep existing
          custom_title: newTitle // New field for title
        }
      });
      setConversation((prev) => ({
        ...prev,
        metadata: {
          ...prev.metadata,
          custom_title: newTitle
        }
      }));
      setIsEditingTitle(false);
    } catch (error) {
      console.error("Error renaming conversation:", error);
      alert("Erreur lors du renommage");
    }
  };

  // Initialiser le titre d'édition quand une conversation est chargée
  useEffect(() => {
    if (conversation) {
      setNewTitle(conversation.metadata?.custom_title || t("chat.title"));
    }
  }, [conversation, t]);

  const handleFileUpload = async (event) => {
    const files = Array.from(event.target.files);
    if (files.length === 0) return;

    setIsUploading(true);

    try {
      const uploadPromises = files.map(async (file) => {
        const { file_url } = await throttledAPICall(() =>
        base44.integrations.Core.UploadFile({ file })
        );
        return {
          name: file.name,
          url: file_url,
          size: file.size,
          type: file.type
        };
      });

      const uploadedFilesData = await Promise.all(uploadPromises);
      setUploadedFiles((prev) => [...prev, ...uploadedFilesData]);
    } catch (error) {
      console.error("Error uploading files:", error);
      if (error?.response?.status === 429) {
        alert("⏸️ Trop de fichiers téléchargés. Attendez quelques secondes.");
      } else {
        alert("❌ Erreur lors du téléchargement des fichiers.");
      }
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const removeFile = (index) => {
    setUploadedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleEmergencyQuickReply = (value) => {
    setInput(value);
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim() && uploadedFiles.length === 0 || isSending || !conversation) return;

    const messageText = input;
    const fileUrls = uploadedFiles.map((f) => f.url);

    setInput("");
    setUploadedFiles([]);
    setIsSending(true);

    let optimistic = null;
    try {
      const languageInstruction = locale === 'nl' ? "[Instructie: Antwoord in het Nederlands]" : locale === 'de' ? "[Anweisung: Antworte auf Deutsch]" : "";

      // Optimistic user message
      optimistic = { id: `temp-${Date.now()}`, role: 'user', content: messageText || '📎 Fichier(s) joint(s)' };
      setMessages((prev) => [...prev, optimistic]);

      const messageData = {
        role: "user",
        content: messageText ? `${messageText}\n\n${languageInstruction}` : "📎 Fichier(s) joint(s)"
      };

      if (fileUrls.length > 0) {
        messageData.file_urls = fileUrls;
      }

      await throttledAPICall(() => base44.agents.addMessage(conversation, messageData));
      // Remove optimistic after server accepts; subscription will re-render with real message
      setMessages((prev) => prev.filter((m) => m.id !== optimistic.id));
    } catch (error) {
      console.error("Error sending message:", error);
      // Remove optimistic if send failed
      if (optimistic) {
        setMessages((prev) => prev.filter((m) => m.id !== optimistic.id));
      }

      setInput(messageText);
      setUploadedFiles(uploadedFiles);

      if (error?.response?.status === 429) {
        alert("⏸️ Vous envoyez des messages trop rapidement. Attendez quelques secondes avant de réessayer.");
      } else {
        alert("❌ Erreur lors de l'envoi du message. Veuillez réessayer.");
      }
    }
    setIsSending(false);
  };

  const handleNewChat = async () => {
    if (!user) return;

    try {
      const newConversation = await throttledAPICall(() =>
      base44.agents.createConversation({
        agent_name: AGENT_NAME,
        metadata: {
          user_email: user.email,
          user_name: user.full_name,
          platform: 'web',
          created_at: new Date().toISOString()
        }
      })
      );

      setConversation(newConversation);
      setMessages([]);
      setInput("");
      setUploadedFiles([]);
    } catch (error) {
      console.error("Error creating new conversation:", error);
      alert("❌ Erreur lors de la création d'une nouvelle conversation.");
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (isCheckingUser) {
    return (
      <div className="flex flex-col h-screen items-center justify-center p-4">
                <div className="text-center">
                    <Loader2 className="w-8 h-8 text-yellow-500 animate-spin mb-4 mx-auto" />
                    <p className="text-gray-500">Vérification de l'authentification...</p>
                </div>
            </div>);

  }

  if (!user) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
            <SimpleLogin actionText="discuter avec l'agent IA" />
          </div>);

  }

  return (
    <LimitChecker feature="ai_messages_count">
            {({ onActionStart, remainingActions, currentPlan }) =>
      <div className="flex flex-col h-[calc(100vh-9rem)] md:h-[calc(100vh-4rem)]">
                    <OnboardingTour
          steps={chatSteps}
          storageKey="adminbelgique_chat_tour_completed"
          forceShow={showTour}
          onComplete={() => setShowTour(false)} />

                    {/* Header */}
                    <div className="md:p-4 border-b text-center bg-white pt-2 pr-2 pb-2 pl-2 px-2">
                        <div className="flex items-center justify-between max-w-4xl mx-auto">
                            <div className="flex-1">
                                <div className="inline-flex items-center gap-2 bg-blue-100 rounded-full px-4 py-2 mb-2">
                                    <Bot className="w-5 h-5 text-blue-600" />
                                    <span className="text-blue-800 font-medium">{t("chat.badge")}</span>
                                </div>
                                <div className="flex items-center gap-2 flex-wrap">
                                    {isEditingTitle ?
                <div className="flex items-center gap-2">
                                            <Input
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="h-8 w-48 md:w-64"
                    autoFocus
                    onKeyDown={(e) => e.key === 'Enter' && handleRenameConversation()} />

                                            <Button size="sm" onClick={handleRenameConversation} className="h-8 w-8 p-0"><Save className="w-4 h-4" /></Button>
                                            <Button size="sm" variant="ghost" onClick={() => setIsEditingTitle(false)} className="h-8 w-8 p-0"><X className="w-4 h-4" /></Button>
                                        </div> :

                <div className="flex items-center gap-2 group">
                                            <h1 className="text-lg md:text-2xl font-bold text-gray-900 truncate max-w-[200px] md:max-w-md py-2 text-center not-italic underline">
                                                {conversation?.metadata?.custom_title || t("chat.title")}
                                            </h1>
                                            {conversation &&
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      setNewTitle(conversation.metadata?.custom_title || t("chat.title"));
                      setIsEditingTitle(true);
                    }}
                    className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Renommer la conversation">

                                                    <Edit className="w-3 h-3 text-gray-500" />
                                                </Button>
                  }
                                        </div>
                }
                                    
                                    <Button variant="ghost" size="icon" onClick={() => setShowTour(true)} className="rounded-full hover:bg-gray-100 text-gray-400 ml-2" title="Aide">
                                        <HelpCircle className="w-5 h-5" />
                                    </Button>
                                    {conversation &&
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleArchiveConversation}
                  className={`rounded-full hover:bg-gray-100 ${conversation.metadata?.archived ? 'text-orange-500' : 'text-gray-400'}`}
                  title={conversation.metadata?.archived ? "Désarchiver" : "Archiver (Ctrl+Shift+A)"}>

                                            <Archive className="w-5 h-5" />
                                        </Button>
                }
                                </div>
                            </div>
                            
                            <div className="flex gap-2">
                                <Button
                onClick={handleNewChat}
                variant="outline"
                className="flex items-center gap-2 border-2 border-green-500 text-green-700 hover:bg-green-50 text-left uppercase text-lg"
                title="Nouvelle discussion (Ctrl+Shift+N)">

                                    <Plus className="w-5 h-5" />
                                    <span className="hidden sm:inline">{t("chat.new_discussion")}</span>
                                </Button>
                            </div>
                        </div>
                        
                        {user &&
          <div className="mt-2 flex items-center justify-center gap-3 flex-wrap">
                                <Badge>{t("chat.logged_in_as")} {user.full_name}</Badge>
                                {currentPlan === 'free' &&
            <Badge className="bg-yellow-100 text-yellow-800">
                                        {remainingActions} messages restants
                                    </Badge>
            }
                            </div>
          }
                        
                        {/* Barre de recherche dans l'historique */}
                        <div className="mt-2 max-w-md mx-auto relative px-4 hidden sm:block">
                            <div className="relative">
                                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 w-3 h-3 text-gray-400" />
                                <Input
                placeholder="Rechercher dans la conversation..."
                value={messageSearchTerm}
                onChange={(e) => setMessageSearchTerm(e.target.value)}
                className="h-8 pl-8 text-xs bg-gray-50 border-gray-200 focus-visible:ring-1" />

                                {messageSearchTerm &&
              <button
                onClick={() => setMessageSearchTerm("")}
                className="absolute right-2 top-1/2 transform -translate-y-1/2">

                                        <X className="w-3 h-3 text-gray-400 hover:text-gray-600" />
                                    </button>
              }
                            </div>
                        </div>
                    </div>

                    {/* Messages Area */}
                    <div ref={messagesContainerRef} className="flex-1 overflow-y-auto p-3 md:p-6 space-y-6 rounded-none">
                        {pinnedEmergency &&
          <PinnedEmergencyBar
            data={pinnedEmergency}
            onDismiss={() => {
              setPinnedEmergency(null);
              localStorage.removeItem('adminbelgique_pinned_emergency');
            }} />

          }
                        <AnimatePresence>
                            {messages.length === 0 && !conversation &&
            <div className="flex flex-col items-center justify-center h-full text-center">
                                    <Loader2 className="w-8 h-8 text-yellow-500 animate-spin mb-4" />
                                    <p className="text-gray-500">{t("chat.init")}</p>
                                </div>
            }
                            {messages.length === 0 && conversation &&
            <div className="flex flex-col items-center justify-center h-full text-center gap-4">
                                    <MessageSquare className="w-16 h-16 text-blue-500 mb-1" />
                                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{t("chat.new_discussion")}</h3>
                                    <p className="text-gray-600 max-w-md whitespace-pre-line">
                                        {t("chat.welcome_msg")}
                                    </p>
                                    <div className="w-full max-w-2xl rounded-2xl border border-red-100 bg-red-50 text-left px-4 my-4">
                                      <p className="mb-3 text-sm font-semibold text-red-700">Accès rapide urgences</p>
                                      <EmergencyQuickReplies onSelect={handleEmergencyQuickReply} />
                                    </div>
                                </div>
            }
                            {messages.
            filter((msg) => {
              if (!messageSearchTerm) return true;
              const term = messageSearchTerm.toLowerCase();
              return (
                msg.content && msg.content.toLowerCase().includes(term) ||
                (msg.role === 'user' ? "vous" : "ia").includes(term));

            }).
            map((message) =>
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}>

                                    <MessageBubble message={message} />
                                </motion.div>
            )}
                        </AnimatePresence>
                        <div ref={messagesEndRef} />
                    </div>

                    {/* Input Form */}
                    <div className="p-3 md:p-6 bg-white border-t">
                        {/* 🆕 ZONE D'AFFICHAGE DES FICHIERS UPLOADÉS */}
                        {uploadedFiles.length > 0 &&
          <div className="mb-3 flex flex-wrap gap-2">
                                {uploadedFiles.map((file, index) =>
            <div
              key={index}
              className="flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-lg px-3 py-2 text-sm">

                                        <FileText className="w-4 h-4 text-blue-600" />
                                        <span className="text-blue-800 font-medium truncate max-w-[150px]">
                                            {file.name}
                                        </span>
                                        <span className="text-blue-600 text-xs">
                                            ({formatFileSize(file.size)})
                                        </span>
                                        <button
                onClick={() => removeFile(index)}
                className="ml-2 text-blue-600 hover:text-blue-800">

                                            <X className="w-4 h-4" />
                                        </button>
                                    </div>
            )}
                            </div>
          }

                        {messages.length === 0 && conversation &&
          <div className="mb-3 rounded-xl border border-red-100 bg-red-50 p-3">
                            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-red-700">Suggestions urgentes</p>
                            <EmergencyQuickReplies onSelect={handleEmergencyQuickReply} />
                          </div>
          }

                        <form onSubmit={async (e) => {
            e.preventDefault();
            if (!input.trim() && uploadedFiles.length === 0 || isSending || !conversation) return;

            const canProceed = await onActionStart();
            if (canProceed) {
              handleSendMessage(e);
            }
          }} className="flex items-end gap-3">
                            {/* 🆕 BOUTON D'UPLOAD DE FICHIER */}
                            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".pdf,.png,.jpg,.jpeg,.doc,.docx,.txt"
              onChange={handleFileUpload}
              className="hidden"
              disabled={isUploading || isSending} />

                            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading || isSending || !conversation}
              className="h-12 w-12 flex-shrink-0"
              title={t("chat.join_file")}>

                                {isUploading ?
              <Loader2 className="w-5 h-5 animate-spin" /> :

              <Paperclip className="w-5 h-5" />
              }
                            </Button>

                            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={t("chat.input_placeholder")} className="bg-transparent text-gray-700 px-3 py-2 text-base rounded-md flex w-full border border-input shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm flex-1 min-h-12 max-h-36"

              onKeyPress={async (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  const canProceed = await onActionStart();
                  if (canProceed) {
                    handleSendMessage(e);
                  }
                }
              }}
              disabled={isSending || !conversation} />

                            <Button
              type="submit"
              disabled={!input.trim() && uploadedFiles.length === 0 || isSending || !conversation}
              className="h-12 w-12 flex-shrink-0"
              size="icon">

                                {isSending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                            </Button>
                        </form>

                        <p className="text-xs text-gray-500 mt-2">
                            {t("chat.formats")}
                        </p>
                    </div>
                </div>
      }
        </LimitChecker>);

}