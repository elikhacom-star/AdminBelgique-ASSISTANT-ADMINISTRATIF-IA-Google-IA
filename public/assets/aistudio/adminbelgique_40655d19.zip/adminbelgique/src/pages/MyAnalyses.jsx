import React, { useState, useEffect } from "react";
import { Analyse } from "@/entities/Analyse";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, RefreshCw } from "lucide-react";
import { FileText, Search, Loader2, MessageSquare, Share2, Calendar, Filter } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { Link } from "react-router-dom";
import PullToRefresh from "@/components/common/PullToRefresh";
import { createPageUrl } from "@/utils";
import { Badge } from "@/components/ui/badge";

const DetailView = ({ analysis, onUpdateCategory, onReAnalyze, shareDialogOpen, setShareDialogOpen, shareEmail, setShareEmail, handleShare, isSharing }) => {
  const [isUpdating, setIsUpdating] = useState(false);

  if (!analysis) {
    return (
      <Card className="sticky top-4">
        <CardContent className="text-center py-20">
          <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">Sélectionnez une analyse pour voir les détails</p>
        </CardContent>
      </Card>
    );
  }

  const handleCategoryChange = async (newCategory) => {
      setIsUpdating(true);
      await onUpdateCategory(analysis.id, newCategory);
      setIsUpdating(false);
  };
  
  return (
    <Card className="sticky top-4">
      <CardHeader>
        <CardTitle className="truncate">{analysis.original_filename}</CardTitle>
        <div className="text-sm text-gray-500">
          Analysé le {format(new Date(analysis.created_date), "d MMMM yyyy 'à' HH:mm", { locale: fr })}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* Catégorie */}
        <div>
            <h4 className="font-semibold text-gray-800 mb-2">Catégorie</h4>
            <Select 
                value={analysis.category || "autre"} 
                onValueChange={handleCategoryChange}
                disabled={isUpdating}
            >
                <SelectTrigger className="w-full">
                    <SelectValue placeholder="Sélectionner une catégorie" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="finances">Finances</SelectItem>
                    <SelectItem value="securite_sociale">Sécurité Sociale</SelectItem>
                    <SelectItem value="emploi">Emploi</SelectItem>
                    <SelectItem value="sante">Santé</SelectItem>
                    <SelectItem value="logement">Logement</SelectItem>
                    <SelectItem value="etudes">Études</SelectItem>
                    <SelectItem value="pensions">Pensions</SelectItem>
                    <SelectItem value="autre">Autre</SelectItem>
                </SelectContent>
            </Select>
        </div>

        <div>
          <h4 className="font-semibold text-gray-800 mb-2">Résumé de l'analyse IA</h4>
          <div className="prose prose-sm max-w-none bg-gray-50 p-4 rounded-lg whitespace-pre-wrap">
            {analysis.analysis_summary}
          </div>
        </div>

        <div className="grid gap-3">
            <Button asChild className="w-full">
            <Link to={createPageUrl(`Chat?analysisId=${analysis.id}`)}>
                <MessageSquare className="w-4 h-4 mr-2"/>
                Poser une question sur cette analyse
            </Link>
            </Button>

            <Button variant="outline" className="w-full" onClick={() => onReAnalyze(analysis)}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Analyser à nouveau
            </Button>
        </div>

        <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" className="w-full">
              <Share2 className="w-4 h-4 mr-2" />
              Partager cette analyse
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Partager l'analyse</DialogTitle>
              <DialogDescription>
                Invitez d'autres utilisateurs à voir cette analyse.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="email">Email de l'utilisateur</Label>
                <Input
                  id="email"
                  placeholder="user@example.com"
                  value={shareEmail}
                  onChange={(e) => setShareEmail(e.target.value)}
                />
              </div>
              {analysis.shared_with && analysis.shared_with.length > 0 && (
                <div className="text-sm text-gray-500">
                  <p className="font-semibold mb-1">Partagé avec :</p>
                  <ul className="list-disc pl-5">
                    {analysis.shared_with.map((email, i) => (
                      <li key={i}>{email}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button onClick={handleShare} disabled={isSharing}>
                {isSharing ? "Partage..." : "Partager"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

         <details>
          <summary className="cursor-pointer font-semibold text-gray-700 text-sm">
            Afficher les données brutes extraites
          </summary>
          <div className="bg-gray-100 rounded-lg p-4 text-xs mt-2">
            <pre className="whitespace-pre-wrap">
              {analysis.extracted_data}
            </pre>
          </div>
        </details>
      </CardContent>
    </Card>
  );
};

export default function MyAnalyses() {
  const [analyses, setAnalyses] = useState([]);
  const [filteredAnalyses, setFilteredAnalyses] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [dateFilter, setDateFilter] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [selectedAnalysis, setSelectedAnalysis] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [shareEmail, setShareEmail] = useState("");
  const [isSharing, setIsSharing] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);

  const handleShare = async () => {
    if (!selectedAnalysis || !shareEmail) return;
    setIsSharing(true);
    try {
      const currentShared = selectedAnalysis.shared_with || [];
      if (!currentShared.includes(shareEmail)) {
        const updatedShared = [...currentShared, shareEmail];
        await Analyse.update(selectedAnalysis.id, { shared_with: updatedShared });
        
        // Update local state
        const updatedAnalysis = { ...selectedAnalysis, shared_with: updatedShared };
        setSelectedAnalysis(updatedAnalysis);
        setAnalyses(prev => prev.map(a => a.id === updatedAnalysis.id ? updatedAnalysis : a));
        
        alert(`Analyse partagée avec ${shareEmail}`);
        setShareEmail("");
        setShareDialogOpen(false);
      } else {
        alert("Déjà partagé avec cet email");
      }
    } catch (error) {
      console.error("Erreur partage:", error);
      alert("Erreur lors du partage");
    } finally {
      setIsSharing(false);
    }
  };

  useEffect(() => {
    const loadAnalyses = async () => {
      setIsLoading(true);
      try {
        const data = await Analyse.list("-created_date");
        setAnalyses(Array.isArray(data) ? data : []);
        setFilteredAnalyses(Array.isArray(data) ? data : []);
        if (data && data.length > 0) {
          setSelectedAnalysis(data[0]);
        }
      } catch (error) {
        console.error("Erreur de chargement des analyses:", error);
      } finally {
        setIsLoading(false);
      }
    };
    loadAnalyses();
  }, []);

  useEffect(() => {
    let results = analyses;
    
    // Text filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      results = results.filter(analysis => 
        analysis.original_filename.toLowerCase().includes(term) ||
        analysis.analysis_summary.toLowerCase().includes(term) ||
        analysis.extracted_data?.toLowerCase().includes(term)
      );
    }

    // Date filter
    if (dateFilter) {
      results = results.filter(analysis => 
        analysis.created_date.startsWith(dateFilter)
      );
    }

    // Category filter
    if (categoryFilter && categoryFilter !== "all") {
        results = results.filter(analysis => analysis.category === categoryFilter);
    }

    setFilteredAnalyses(results);
  }, [searchTerm, dateFilter, categoryFilter, analyses]);

  const handleUpdateCategory = async (id, newCategory) => {
      try {
          await Analyse.update(id, { category: newCategory });
          const updated = { ...selectedAnalysis, category: newCategory };
          setSelectedAnalysis(updated);
          setAnalyses(prev => prev.map(a => a.id === id ? updated : a));
      } catch (error) {
          console.error("Erreur maj catégorie:", error);
          alert("Erreur lors de la mise à jour de la catégorie");
      }
  };

  const handleReAnalyze = (analysis) => {
      // Rediriger vers l'analyseur avec l'ID pour ré-analyser (logique à implémenter dans DocumentAnalyzer si nécessaire)
      // Ou simple redirection pour l'instant
      if(window.confirm("Voulez-vous ré-analyser ce document ? Cela vous redirigera vers l'outil d'analyse.")) {
          // Ici, on pourrait passer l'URL du fichier en paramètre pour pré-remplir
          window.location.href = createPageUrl(`DocumentAnalyzer?reanalyze=${analysis.id}`);
      }
  };

  const handleRefresh = async () => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    try {
      const data = await Analyse.list("-created_date");
      setAnalyses(Array.isArray(data) ? data : []);
      setFilteredAnalyses(Array.isArray(data) ? data : []);
      if (data && data.length > 0) {
        setSelectedAnalysis(data[0]);
      }
    } finally {
      setTimeout(() => setIsRefreshing(false), 600);
    }
  };

  return (
    <PullToRefresh isRefreshing={isRefreshing} onRefresh={handleRefresh}>
      <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          {isRefreshing && (
            <div className="mt-2 flex items-center justify-center gap-2 text-sm text-blue-700">
              <span className="inline-block h-3 w-3 rounded-full bg-blue-500 animate-pulse" /> Mise à jour...
            </div>
          )}
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Mes Analyses</h1>
          <p className="text-gray-600">Retrouvez ici toutes vos analyses de documents sauvegardées</p>
        </div>

        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input 
              placeholder="Rechercher par nom, contenu, données extraites..." 
              value={searchTerm} 
              onChange={(e) => setSearchTerm(e.target.value)} 
              className="pl-10"
            />
          </div>
          <div className="relative w-full md:w-auto flex flex-col md:flex-row gap-2">
             {/* Filtre Catégorie */}
             <div className="w-full md:w-48">
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger>
                        <SelectValue placeholder="Toutes catégories" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">Toutes catégories</SelectItem>
                        <SelectItem value="finances">Finances</SelectItem>
                        <SelectItem value="securite_sociale">Sécurité Sociale</SelectItem>
                        <SelectItem value="emploi">Emploi</SelectItem>
                        <SelectItem value="sante">Santé</SelectItem>
                        <SelectItem value="logement">Logement</SelectItem>
                        <SelectItem value="etudes">Études</SelectItem>
                        <SelectItem value="pensions">Pensions</SelectItem>
                        <SelectItem value="autre">Autre</SelectItem>
                    </SelectContent>
                </Select>
             </div>

             {/* Filtre Date */}
             <div className="flex items-center gap-2 w-full md:w-auto">
               <Input 
                 type="date"
                 value={dateFilter}
                 onChange={(e) => setDateFilter(e.target.value)}
                 className="w-full md:w-40"
               />
               {dateFilter && (
                 <Button variant="ghost" size="icon" onClick={() => setDateFilter("")}>
                   <X className="w-4 h-4" />
                 </Button>
               )}
             </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <div className="grid gap-4 max-h-[70vh] overflow-y-auto pr-2">
              {isLoading ? (
                <div className="text-center py-12 text-gray-500"><Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" /> Chargement...</div>
              ) : filteredAnalyses.length === 0 ? (
                <Card className="text-center py-12">
                  <CardContent>
                    <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Aucune analyse trouvée</h3>
                    <p className="text-gray-500 mb-4">
                      Commencez par analyser votre premier document.
                    </p>
                    <Button asChild>
                      <Link to={createPageUrl("DocumentAnalyzer")}>Analyser un document</Link>
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                filteredAnalyses.map(analysis => (
                  <Card 
                    key={analysis.id}
                    className={`cursor-pointer transition-all ${selectedAnalysis?.id === analysis.id ? 'border-yellow-400 shadow-lg' : 'hover:shadow-md'}`}
                    onClick={() => setSelectedAnalysis(analysis)}
                  >
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base truncate">{analysis.original_filename}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-xs text-gray-500 line-clamp-2">{analysis.analysis_summary}</p>
                      <div className="mt-2 text-xs text-gray-500">
                        {format(new Date(analysis.created_date), "dd/MM/yyyy")}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>
          <div className="lg:col-span-2">
            <DetailView 
                analysis={selectedAnalysis} 
                onUpdateCategory={handleUpdateCategory}
                onReAnalyze={handleReAnalyze}
                shareDialogOpen={shareDialogOpen}
                setShareDialogOpen={setShareDialogOpen}
                shareEmail={shareEmail}
                setShareEmail={setShareEmail}
                handleShare={handleShare}
                isSharing={isSharing}
            />
          </div>
        </div>
      </div>
      </div>
    </PullToRefresh>
  );
}