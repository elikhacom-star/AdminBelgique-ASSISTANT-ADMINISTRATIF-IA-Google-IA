import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { FileText, Shield, Clock, Users, ArrowRight } from "lucide-react";

export default function GuideDemarchesBelgique() {
  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <h1>Guide des démarches administratives en Belgique avec l'intelligence artificielle</h1>

        <p className="text-lg text-gray-700 leading-relaxed mb-6">
          Naviguer dans l'administration belge peut s'avérer complexe et chronophage pour de nombreux citoyens et
          entreprises. Entre les formulaires du SPF Finances, les démarches auprès de l'INAMI pour l'assurance
          maladie, les demandes à l'ONEM en matière d'emploi, ou encore les procédures locales auprès de votre
          commune, les procédures administratives belges sont multiples et souvent difficiles à comprendre.
          AdminBelgique est une plateforme privée indépendante qui utilise l'intelligence artificielle pour
          simplifier ces parcours administratifs. Notre assistant IA vous aide à rédiger des lettres de
          réclamation, des demandes de remboursement, des recours administratifs et des plaintes, tout en vous
          fournissant des réponses claires à vos questions administratives en français, néerlandais et allemand,
          les trois langues officielles de la Belgique.
        </p>

        <p className="text-gray-700 leading-relaxed mb-6">
          Que vous soyez un particulier cherchant à comprendre vos droits sociaux, un indépendant devant
          déclarer ses revenus, un étudiant demandant des bourses d'études, ou un propriétaire gérant un
          logement, notre assistant administratif IA est conçu pour vous accompagner à chaque étape. La
          plateforme couvre les principales catégories administratives belges : finances et fiscalité,
          sécurité sociale et INAMI, emploi et chômage ONEM, santé, logement, études et pensions. Grâce à
          la génération automatique de documents et à l'analyse intelligente de vos courriers
          administratifs, vous gagnez un temps précieux tout en évitant les erreurs courantes qui peuvent
          retarder vos démarches auprès des institutions publiques belges.
        </p>

        <p className="text-gray-700 leading-relaxed mb-8">
          Il est important de souligner qu'AdminBelgique est un service privé indépendant, non affilié au
          gouvernement belge ni à aucune institution publique telle que le SPF Finances, l'INAMI, l'ONEM ou
          les administrations communales. Notre objectif est de rendre les démarches administratives plus
          accessibles et compréhensibles pour tous les citoyens belges, en proposant un outil d'assistance
          moderne, sécurisé et propulsé par l'IA. Vos données personnelles sont protégées par des techniques
          d'anonymisation avancées, garantissant que vos informations sensibles ne quittent jamais votre
          appareil en clair. Découvrez comment notre assistant IA peut transformer votre expérience
          administrative au quotidien en Belgique.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <FileText className="w-5 h-5 text-blue-600" />
                Génération de documents
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Créez lettres de réclamation, demandes de remboursement, recours et plaintes administratives
                en quelques minutes grâce à l'IA.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Shield className="w-5 h-5 text-green-600" />
                Sécurité des données
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Anonymisation automatique de vos données personnelles et chiffrement multicouche pour une
                confidentialité maximale.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Clock className="w-5 h-5 text-purple-600" />
                Gain de temps
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Réduisez jusqu'à 80% du temps passé à vos démarches administratives grâce à l'assistance IA
                automatisée.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Users className="w-5 h-5 text-orange-600" />
                Pour tous les Belges
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Particuliers, indépendants, étudiants et entreprises : un assistant accessible en français,
                néerlandais et allemand.
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">
              Prêt à simplifier vos démarches administratives ?
            </h2>
            <p className="mb-6 opacity-90">
              Essayez gratuitement notre assistant IA et découvrez à quel point l'administration belge peut
              devenir simple et accessible.
            </p>
            <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
              <Link to={createPageUrl("Assistant")}>
                Commencer maintenant
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}