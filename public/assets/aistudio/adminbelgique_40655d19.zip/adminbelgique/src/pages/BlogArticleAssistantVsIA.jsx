import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowLeft, Users, Bot, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import SEOHead from "../components/seo/SEOHead";

export default function BlogArticleAssistantVsIA() {
  const comparaison = [
    {
      critere: "Disponibilité",
      virtuel: "Horaires de bureau (9h-17h)",
      ia: "24/7, 365 jours par an",
      winner: "ia"
    },
    {
      critere: "Temps de réponse",
      virtuel: "Quelques heures à plusieurs jours",
      ia: "Instantané (< 30 secondes)",
      winner: "ia"
    },
    {
      critere: "Coût",
      virtuel: "25-50€/heure",
      ia: "À partir de 0€ (gratuit)",
      winner: "ia"
    },
    {
      critere: "Expertise belge",
      virtuel: "Variable selon l'assistant",
      ia: "Connaissance exhaustive législation BE",
      winner: "ia"
    },
    {
      critere: "Gestion de documents",
      virtuel: "Manuelle, risque d'erreurs",
      ia: "Automatique, analyse intelligente",
      winner: "ia"
    },
    {
      critere: "Empathie humaine",
      virtuel: "Excellent (contact humain)",
      ia: "Limité (mais s'améliore)",
      winner: "virtuel"
    },
    {
      critere: "Cas très complexes",
      virtuel: "Peut consulter des experts",
      ia: "Recommande un professionnel si nécessaire",
      winner: "virtuel"
    },
    {
      critere: "Confidentialité",
      virtuel: "Bonne (mais humain = risque)",
      ia: "Excellente (anonymisation automatique)",
      winner: "ia"
    }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <SEOHead
        title="Assistant Virtuel vs Assistant IA : Le Comparatif 2025 🇧🇪"
        description="🤖 Virtuel ou IA ? Découvrez la différence et choisissez la meilleure solution pour vos démarches en Belgique. Dispo 24/7, -80% d'erreurs. Comparatif détaillé ⚡"
        canonical="https://adminbelgique.com/BlogArticleAssistantVsIA"
        keywords="assistant virtuel vs ia, comparatif assistant administratif belgique, agent ia belgique"
      />
      <div className="max-w-4xl mx-auto">
        
        <Button asChild variant="ghost" className="mb-6">
          <Link to={createPageUrl("Blog")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour au blog
          </Link>
        </Button>

        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Badge className="bg-purple-100 text-purple-800">Comparaison</Badge>
            <div className="flex items-center gap-4 text-sm text-gray-500">
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                5 Jan 2025
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                6 min de lecture
              </span>
            </div>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Assistant Virtuel vs Assistant Administratif IA : Quelle Différence ?
          </h1>
          
          <p className="text-xl text-gray-600">
            Comparaison détaillée pour vous aider à choisir la meilleure solution pour vos <strong>démarches administratives en Belgique</strong>.
          </p>
        </div>

        <div className="mb-8 rounded-xl overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1677442136019-21780ecad995?w=1200" 
            alt="Comparaison assistant virtuel vs IA"
            className="w-full h-64 object-cover"
          />
        </div>

        {/* Définitions */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <Card className="border-2 border-blue-300">
            <CardHeader className="bg-blue-50">
              <CardTitle className="flex items-center gap-2">
                <Users className="w-6 h-6 text-blue-600" />
                Assistant Virtuel Humain
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-gray-700 mb-4">
                Un <strong>assistant virtuel</strong> est une <strong>personne réelle</strong> qui travaille à distance 
                pour vous aider dans vos tâches administratives.
              </p>
              <div className="space-y-2">
                <h4 className="font-semibold text-gray-900">Caractéristiques :</h4>
                <ul className="space-y-1 text-sm text-gray-600">
                  <li>✅ Contact humain direct</li>
                  <li>✅ Flexibilité contextuelle</li>
                  <li>❌ Horaires limités</li>
                  <li>❌ Coût élevé (25-50€/h)</li>
                  <li>❌ Dépend d'une personne</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-purple-300">
            <CardHeader className="bg-purple-50">
              <CardTitle className="flex items-center gap-2">
                <Bot className="w-6 h-6 text-purple-600" />
                Assistant Administratif IA
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-gray-700 mb-4">
                Un <strong>agent administratif IA</strong> est un <strong>logiciel intelligent</strong> spécialisé 
                dans la gestion administrative belge.
              </p>
              <div className="space-y-2">
                <h4 className="font-semibold text-gray-900">Caractéristiques :</h4>
                <ul className="space-y-1 text-sm text-gray-600">
                  <li>✅ Disponible 24/7</li>
                  <li>✅ Réponses instantanées</li>
                  <li>✅ Gratuit ou faible coût</li>
                  <li>✅ Connaissance exhaustive</li>
                  <li>❌ Pas de contact humain</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tableau comparatif */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl">📊 Comparaison Détaillée</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2">
                    <th className="text-left p-3 font-bold">Critère</th>
                    <th className="text-center p-3 font-bold text-blue-700">Assistant Virtuel</th>
                    <th className="text-center p-3 font-bold text-purple-700">Assistant IA</th>
                    <th className="text-center p-3 font-bold">Gagnant</th>
                  </tr>
                </thead>
                <tbody>
                  {comparaison.map((row, index) => (
                    <tr key={index} className="border-b hover:bg-gray-50">
                      <td className="p-3 font-semibold">{row.critere}</td>
                      <td className="p-3 text-center text-sm text-gray-600">{row.virtuel}</td>
                      <td className="p-3 text-center text-sm text-gray-600">{row.ia}</td>
                      <td className="p-3 text-center">
                        {row.winner === "ia" ? (
                          <Badge className="bg-purple-100 text-purple-800">IA</Badge>
                        ) : (
                          <Badge className="bg-blue-100 text-blue-800">Virtuel</Badge>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Score final */}
        <Card className="mb-8 bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-300">
          <CardHeader>
            <CardTitle className="text-2xl">🏆 Score Final</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-blue-100 p-6 rounded-xl text-center">
                <Users className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                <div className="text-4xl font-bold text-blue-700 mb-2">2/8</div>
                <div className="font-semibold text-blue-800">Assistant Virtuel Humain</div>
                <p className="text-sm text-blue-600 mt-2">Meilleur pour empathie et cas complexes</p>
              </div>

              <div className="bg-purple-100 p-6 rounded-xl text-center border-4 border-yellow-400">
                <Bot className="w-12 h-12 text-purple-600 mx-auto mb-3" />
                <div className="text-4xl font-bold text-purple-700 mb-2">6/8</div>
                <div className="font-semibold text-purple-800">Assistant Administratif IA</div>
                <p className="text-sm text-purple-600 mt-2">Gagnant pour rapidité, coût et disponibilité</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Cas d'usage */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl">🎯 Quel Assistant Choisir ?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-500">
              <h4 className="font-bold text-green-800 mb-2 flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                Choisissez l'Assistant IA si :
              </h4>
              <ul className="space-y-1 text-sm text-green-700">
                <li>✅ Vous voulez des réponses immédiates 24/7</li>
                <li>✅ Votre budget est limité</li>
                <li>✅ Vos démarches sont standard (impôts, INAMI, ONEM)</li>
                <li>✅ Vous voulez automatiser vos tâches répétitives</li>
                <li>✅ La confidentialité maximale est importante</li>
              </ul>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
              <h4 className="font-bold text-blue-800 mb-2 flex items-center gap-2">
                <Users className="w-5 h-5" />
                Choisissez l'Assistant Virtuel si :
              </h4>
              <ul className="space-y-1 text-sm text-blue-700">
                <li>✅ Votre cas est extrêmement complexe</li>
                <li>✅ Vous avez besoin d'empathie humaine</li>
                <li>✅ Le budget n'est pas une contrainte</li>
                <li>✅ Vous préférez déléguer entièrement</li>
              </ul>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-500">
              <h4 className="font-bold text-yellow-800 mb-2">💡 Notre Recommandation :</h4>
              <p className="text-sm text-yellow-700">
                <strong>Combinaison optimale</strong> : Utilisez l'IA pour 90% de vos démarches 
                (gains énormes), et consultez un assistant virtuel humain uniquement pour les 10% 
                de cas très complexes nécessitant une expertise juridique pointue.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* CTA */}
        <Card className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">
              Essayez l'Assistant Administratif IA Gratuitement
            </h3>
            <p className="text-lg mb-6 opacity-90">
              0€ pour commencer • Aucune carte bancaire requise
            </p>
            <Button asChild size="lg" className="bg-white text-gray-900 hover:bg-gray-100">
              <Link to={createPageUrl("Assistant")}>
                Démarrer Maintenant
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}