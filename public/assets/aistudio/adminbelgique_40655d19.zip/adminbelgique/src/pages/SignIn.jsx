import React, { useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2 } from "lucide-react";

export default function SignIn() {
  useEffect(() => {
    // Redirection immédiate vers le login platform
    base44.auth.redirectToLogin(window.location.origin);
  }, []);

  return (
    <div className="flex h-screen items-center justify-center bg-gray-50">
      <div className="text-center">
        <Loader2 className="h-10 w-10 animate-spin text-blue-600 mx-auto mb-4" />
        <h2 className="text-lg font-semibold text-gray-700">Redirection vers la connexion...</h2>
      </div>
    </div>
  );
}