import React, { useEffect } from "react"; // 👈 Ajout de useEffect ici
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, Users, TrendingUp, Shield, Zap, Globe, Clock, Award } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useTranslation } from "../components/localization/useTranslation";

export default function About() {
  const { t } = useTranslation();

  // 👇 CE BLOC BLOQUE L'INDEXATION GOOGLE SUR BASE44 ET CORRIGE LE SEO
  useEffect(() => {
    // 1. On vérifie si l'adresse contient "base44.app"
    if (window.location.hostname.includes("base44.app")) {
      // On cherche si une balise robots existe déjà, sinon on la crée
      let metaRobots = document.querySelector('meta[name="robots"]');
      if (!metaRobots) {
        metaRobots = document.createElement('meta');
        metaRobots.name = 'robots';
        document.head.appendChild(metaRobots);
      }
      // On ordonne à Google de ne pas indexer
      metaRobots.content = 'noindex, nofollow';
    } else {
      // 2. Si on est sur votre VRAI site (adminbelgique.com), on configure la balise Canonical 
      // pour dire à Google que c'est la page officielle.
      let linkCanonical = document.querySelector('link[rel="canonical"]');
      if (!linkCanonical) {
        linkCanonical = document.createElement('link');
        linkCanonical.rel = 'canonical';
        document.head.appendChild(linkCanonical);
      }
      linkCanonical.href = 'https://adminbelgique.com';
    }
  }, []);

  const steps = [
    {
      number: "1",
      title: t("about.how.step1.title"),
      description: t("about.how.step1.desc"),
      icon: Users
    },
    {
      number: "2",
      title: t("about.how.step2.title"),
      description: t("about.how.step2.desc"),
      icon: Zap
    },
    {
      number: "3",
      title: t("about.how.step3.title"),
      description: t("about.how.step3.desc"),
      icon: CheckCircle
    },
    {
      number: "4",
      title: t("about.how.step4.title"),
      description: t("about.how.step4.desc"),
      icon: TrendingUp
    }
  ];

  const benefits = [
    {
      icon: Clock,
      title: t("about.why.benefit1.title"),
      description: t("about.why.benefit1.desc"),
      stat: "-80%"
    },
    {
      icon: Shield,
      title: t("about.why.benefit2.title"),
      description: t("about.why.benefit2.desc"),
      stat: "100%"
    },
    {
      icon: CheckCircle,
      title: t("about.why.benefit3.title"),
      description: t("about.why.benefit3.desc"),
      stat: "98%"
    },
    {
      icon: Globe,
      title: t("about.why.benefit4.title"),
      description: t("about.why.benefit4.desc"),
      stat: "100%"
    }
  ];

  const cities = [
    "Bruxelles", "Anvers", "Gand", "Charleroi", "Liège", "Bruges", 
    "Namur", "Louvain", "Mons", "Aalst", "Malines", "Hasselt"
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        
        {/* Hero Section */}
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-blue-100 text-blue-800 border-blue-300">
            <Award className="w-4 h-4 mr-2" />
            {t("about.hero.badge")}
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            {t("about.hero.title")}
          </h1>
          <p className="text-xl text-gray-600 mb-6 max-w-3xl mx-auto">
            {t("about.hero.text")}
          </p>
        </div>

        {/* Mission */}
        <Card className="mb-12 bg-gradient-to-br from-yellow-50 to-orange-50 border-2 border-yellow-200">
          <CardHeader>
            <CardTitle className="text-2xl text-center">{t("about.mission.title")}</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-lg text-gray-700 leading-relaxed max-w-4xl mx-auto mb-4">
              {t("about.mission.text")}
            </p>
            <p className="text-base text-gray-700 leading-relaxed max-w-4xl mx-auto text-left">
              AdminBelgique est un assistant administratif propulsé par l'intelligence artificielle, conçu
              pour simplifier les démarches administratives des citoyens, des indépendants et des entreprises
              en Belgique. Notre plateforme vous aide à générer des lettres de réclamation, des demandes de
              remboursement, des recours administratifs et des plaintes, tout en répondant à vos questions
              sur la fiscalité, la sécurité sociale, l'emploi, le logement, la santé, les études et les
              pensions. Que vous soyez un particulier cherchant à comprendre vos droits sociaux, un étudiant
              demandant des bourses, ou un propriétaire gérant un bien immobilier, notre assistant IA vous
              accompagne à chaque étape en français, néerlandais et allemand. AdminBelgique est édité par
              Elika, une initiative privée indépendante non affiliée au gouvernement belge ni à aucune
              institution publique telle que le SPF Finances, l'INAMI ou l'ONEM. Notre mission est de rendre
              l'administration belge plus accessible, plus transparente et plus humaine grâce à la puissance
              de l'intelligence artificielle, tout en garantissant la confidentialité de vos données
              personnelles par des techniques d'anonymisation avancées.
            </p>
          </CardContent>
        </Card>

        {/* Comment ça marche */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">
            {t("about.how.title")}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-all">
                  <CardHeader>
                    <div className="w-16 h-16 bg-yellow-500 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                      {step.number}
                    </div>
                    <CardTitle className="text-lg">{step.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Icon className="w-8 h-8 text-yellow-600 mx-auto mb-3" />
                    <p className="text-sm text-gray-600">{step.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Avantages */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">
            {t("about.why.title")}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <Card key={index} className="border-2 hover:shadow-xl transition-all">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-bold text-gray-900">{benefit.title}</h3>
                          <Badge className="bg-yellow-100 text-yellow-800 font-bold">
                            {benefit.stat}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600">{benefit.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Couverture géographique */}
        <Card className="mb-12 bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="text-2xl text-center text-blue-900">
              {t("about.coverage.title")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-center text-gray-700 mb-6">
              {t("about.coverage.text")}
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              {cities.map((city, index) => (
                <Badge key={index} variant="outline" className="text-sm">
                  📍 {city}
                </Badge>
              ))}
            </div>
            <p className="text-center text-gray-600 mt-6 text-sm">
              + toutes les autres communes de Belgique
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
