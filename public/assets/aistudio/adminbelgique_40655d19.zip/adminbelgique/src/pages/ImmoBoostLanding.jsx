import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building2, Brain, PenTool, Rocket, Shield, Globe, Zap, TrendingUp, Check, ArrowRight, Lock, LogIn, Loader2, Search, Settings, FileText, CreditCard } from "lucide-react";
import ImmoBoostStudioTool from "@/components/immo/ImmoBoostStudioTool";

export default function ImmoBoostLanding() {
  const { isAuthenticated, isLoadingAuth } = useAuth();

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#fdf8f0" }}>

      {/* ═══ HERO ═══ */}
      <section className="relative overflow-hidden text-white py-20 px-6" style={{ background: "linear-gradient(160deg, #0f1f3d 0%, #1a2e52 60%, #2d1a00 100%)" }}>
        <div className="max-w-4xl mx-auto">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 border border-orange-400/40 rounded-full px-4 py-1.5 mb-8 text-sm text-orange-300 font-medium">
            <Zap className="w-4 h-4" />
            Infrastructure IA B2B — Verticalisée sur la Belgique
          </div>

          {/* H1 */}
          <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-6">
            L'infrastructure IA de gestion{" "}
            <span className="underline decoration-orange-400 underline-offset-4">administrative</span>{" "}
            pour les{" "}
            <span className="text-orange-400">PME et indépendants</span>{" "}
            en Belgique
          </h1>

          <p className="text-lg text-slate-300 mb-10 max-w-2xl leading-relaxed">
            Une plateforme prête, testée et verticalisée. Des algorithmes configurés pour les contraintes belges de 2026. Démontrée sur l'immobilier avec ImmoBoost AI — immédiatement duplicable vers les assurances, fiduciaires et courtage de crédit.
          </p>

          <div className="flex flex-wrap gap-3 mb-14">
            <a href="#immoboost">
              <Button className="bg-orange-500 hover:bg-orange-600 text-white font-semibold px-6 py-2.5 rounded-lg">
                Découvrir ImmoBoost AI
              </Button>
            </a>
            <Button asChild variant="outline" className="border-white/30 text-white bg-white/10 hover:bg-white/20 font-semibold px-6 py-2.5 rounded-lg">
              <Link to={isAuthenticated ? "/Dashboard" : "/login"}>
                Accéder à la plateforme
              </Link>
            </Button>
          </div>

          {/* Divider */}
          <hr className="border-white/10 mb-10" />

          {/* Stats 2×2 */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
            { icon: Zap, value: "20 sec", label: "Scraping de 12 comparables" },
            { icon: Globe, value: "FR / NL / EN", label: "Multilingue natif" },
            { icon: Shield, value: "Loi 1991", label: "Conformité intégrée" },
            { icon: FileText, value: "6h/sem", label: "Gagnées par utilisateur" }].
            map((s, i) =>
            <div key={i} className="flex flex-col items-center text-center gap-2">
                <s.icon className="w-6 h-6 text-orange-400" />
                <div className="text-2xl font-bold text-white">{s.value}</div>
                <div className="text-xs text-slate-400">{s.label}</div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ═══ PROOF-OF-CONCEPT ═══ */}
      <section className="py-16 px-6" style={{ backgroundColor: "#fdf8f0" }}>
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-xs font-bold tracking-widest text-orange-500 uppercase mb-3">Proof-of-Concept Majeur</p>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">ImmoBoost AI</h2>
            <p className="text-slate-600 leading-relaxed">
              Pour prouver la puissance de notre infrastructure, nous avons automatisé le secteur le plus rentable : l'immobilier. Découvrez comment nos agents IA collaborent sans intervention humaine.
            </p>
          </div>

          {/* Agent cards */}
          <div className="space-y-4 mb-10">
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "linear-gradient(135deg, #3b82f6, #06b6d4)" }}>
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="font-bold text-slate-900 text-base">Le Cerveau Commercial &amp; Juridique</div>
                  <div className="text-xs text-blue-500 font-mono mb-2">real_estate_assistant</div>
                  <p className="text-sm text-slate-600">Analyse financière, pige de marché, estimation, conformité légale (PEB/EPC, loi 1991, critères IPI). Le raisonnement stratégique et data-driven de l'agence.</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "linear-gradient(135deg, #22c55e, #16a34a)" }}>
                  <PenTool className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="font-bold text-slate-900 text-base">La Plume Marketing</div>
                  <div className="text-xs text-green-500 font-mono mb-2">marketing_assistant</div>
                  <p className="text-sm text-slate-600">Copywriting d'élite, annonces SEO Immoweb trilingues, publications Instagram, envoi e-mail. La force de frappe commerciale qui convertit les leads.</p>
                </div>
              </div>
            </div>
          </div>

          {/* 3 steps */}
          <div className="space-y-5">
            {[
            {
              num: "1", color: "#3b82f6",
              title: "L'Analyse et la Pige Financière",
              agent: "real_estate_assistant",
              desc: "L'assistant analyse un bien, scrape le marché pour extraire 12 comparables en 20 secondes, et prépare les arguments juridiques pour décrocher un mandat exclusif."
            },
            {
              num: "2", color: "#f97316",
              title: "Le Clic Magique — Flux JSON Interne",
              agent: "Transfert automatique",
              desc: "En un clic, les données techniques et juridiques validées sont transférées en arrière-plan à l'assistant marketing. Zéro double saisie. Zéro perte de temps."
            },
            {
              num: "3", color: "#22c55e",
              title: "La Force de Frappe Commerciale",
              agent: "marketing_assistant",
              desc: "En 30 secondes, il génère l'annonce optimisée SEO pour Immoweb en 3 langues, prépare les publications Instagram, et envoie le dossier complet par e-mail à l'agent."
            }].
            map((step) =>
            <div key={step.num} className="flex gap-4">
                <div className="flex-shrink-0 flex flex-col items-center">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-base" style={{ backgroundColor: step.color }}>
                    {step.num}
                  </div>
                </div>
                <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex-1">
                  <div className="font-bold text-slate-900 mb-1">{step.title}</div>
                  <div className="text-xs font-mono text-slate-400 mb-2">{step.agent}</div>
                  <p className="text-sm text-slate-600">{step.desc}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ═══ TRACTION ═══ */}
      <section className="py-16 px-6" style={{ backgroundColor: "#fdf8f0" }}>
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-xs font-bold tracking-widest text-orange-500 uppercase mb-3">La Traction Actuelle</p>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Un outil opérationnel en 30 minutes</h2>
            <p className="text-slate-600">La verticale immobilier (ImmoBoost) démontre une infrastructure robuste, immédiatement duplicable.</p>
          </div>

          <div className="space-y-4">
            {[
            {
              iconBg: "linear-gradient(135deg, #f97316, #ea580c)",
              icon: Search,
              title: "Le Moteur de Scraping Résilient",
              desc: "Une technologie de capture de données immobilières en temps réel sur les portails belges (Immoweb, Zimmo). Système de serveurs proxy et de cache pour contourner les blocages et garantir des comparables fiables en 20 secondes.",
              tags: ["Scraping temps réel", "Rotation de proxies", "Cache intelligent"]
            },
            {
              iconBg: "linear-gradient(135deg, #3b82f6, #06b6d4)",
              icon: Globe,
              title: "L'Intelligence Multilingue Native",
              desc: "Traduction et adaptation automatique juridique (FR/NL/EN), indispensable au marché trilingue belge. Bascule automatique des termes légaux selon la région (PEB en Wallonie, EPC en Flandre).",
              tags: ["FR / NL / EN natif", "Bascule PEB ↔ EPC", "Adaptation juridique régionale"]
            },
            {
              iconBg: "linear-gradient(135deg, #22c55e, #16a34a)",
              icon: FileText,
              title: "Conformité Intégrée",
              desc: "Génération de baux de résidence principale (loi du 20 février 1991) et vérification automatique des critères obligatoires de l'IPI. L'infrastructure gère le cadre légal belge à votre place.",
              tags: ["Baux loi 1991", "Critères IPI", "Audit automatique"]
            },
            {
              iconBg: "linear-gradient(135deg, #a855f7, #7c3aed)",
              icon: Settings,
              title: "L'Architecture Multi-Agents",
              desc: "Le code source exclusif permettant à deux IA de collaborer par échange de flux de données structurées (JSON). Séparation nette entre le cerveau commercial/juridique et la plume marketing — une architecture propre et scalable.",
              tags: ["Flux JSON structurés", "Séparation des rôles", "Scalable horizontalement"]
            }].
            map((f, i) =>
            <div key={i} className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4" style={{ background: f.iconBg }}>
                  <f.icon className="w-6 h-6 text-white" />
                </div>
                <div className="font-bold text-slate-900 mb-2">{f.title}</div>
                <p className="text-sm text-slate-600 mb-3">{f.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {f.tags.map((tag, j) =>
                <span key={j} className="text-xs border border-orange-300 text-orange-600 rounded-full px-3 py-0.5">{tag}</span>
                )}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ═══ PRICING ═══ */}
      <section className="py-16 px-6 text-white" style={{ background: "linear-gradient(160deg, #0f1f3d 0%, #1a2e52 100%)" }}>
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-xs font-bold tracking-widest text-orange-500 uppercase mb-3">Le Modèle Économique</p>
            <h2 className="text-3xl md:text-4xl font-bold text-white">Scalabilité SaaS — Abonnements récurrents (MRR)</h2>
          </div>

          <div className="space-y-4">
            {/* Solo */}
            <div className="rounded-2xl p-6 border border-white/10 bg-white/5">
              <div className="font-bold text-xl text-white mb-1">Solo</div>
              <div className="text-sm text-slate-400 mb-4">Pour les indépendants</div>
              <div className="text-4xl font-bold text-white mb-6">49€<span className="text-base font-normal text-slate-400">/mois HT</span></div>
              <ul className="space-y-2 mb-6">
                {["1 utilisateur", "Estimation IA (12 comparables)", "Annonces trilingues FR/NL/EN", "Génération de baux loi 1991", "Support e-mail"].map((f, i) =>
                <li key={i} className="flex items-center gap-2 text-sm text-slate-300">
                    <Check className="w-4 h-4 text-orange-400 flex-shrink-0" />{f}
                  </li>
                )}
              </ul>
              <Button asChild className="w-full bg-white/10 border border-white/20 text-white hover:bg-white/20 font-semibold rounded-xl">
                <Link to="/register">Choisir Solo</Link>
              </Button>
            </div>

            {/* Pro */}
            <div className="rounded-2xl p-6 border-2 border-orange-500 bg-white/5 relative">
              <div className="absolute -top-3 left-6">
                <span className="bg-orange-500 text-white text-xs font-bold px-3 py-1 rounded-full">LE PLUS POPULAIRE</span>
              </div>
              <div className="font-bold text-xl text-white mb-1 mt-2">Pro</div>
              <div className="text-sm text-slate-400 mb-4">Pour les PME &amp; agences</div>
              <div className="text-4xl font-bold text-white mb-6">299€<span className="text-base font-normal text-slate-400">/mois HT</span></div>
              <ul className="space-y-2 mb-6">
                {["Jusqu'à 10 utilisateurs", "Tout le plan Solo", "Intégrations API (Immoweb, Zimmo)", "Architecture multi-agents", "Scraping résilient (proxies)", "Conformité IPI automatisée", "Support prioritaire"].map((f, i) =>
                <li key={i} className="flex items-center gap-2 text-sm text-slate-300">
                    <Check className="w-4 h-4 text-orange-400 flex-shrink-0" />{f}
                  </li>
                )}
              </ul>
              <Button asChild className="w-full bg-orange-500 hover:bg-orange-600 text-white font-semibold rounded-xl">
                <Link to="/register">Choisir Pro</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* ═══ ROADMAP ═══ */}
      <section className="py-16 px-6" style={{ backgroundColor: "#fdf8f0" }}>
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-xs font-bold tracking-widest text-orange-500 uppercase mb-3">Une Roadmap Infinie</p>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">D'un vertical à une infrastructure</h2>
            <p className="text-slate-600">La technologie validée sur l'immobilier avec ImmoBoost AI est immédiatement duplicable aux autres secteurs administratifs belges.</p>
          </div>

          <div className="space-y-4">
            {[
            { icon: Building2, iconBg: "#3b82f6", title: "Immobilier", badge: "Validé — Disponible", badgeColor: "text-green-600 border-green-300 bg-green-50", desc: "ImmoBoost AI opérationnel. Proof-of-Concept majeur déployé et testé." },
            { icon: Shield, iconBg: "#f97316", title: "Assurances", badge: "Prochainement", badgeColor: "text-orange-500 border-orange-300 bg-orange-50", desc: "Gestion de devis, conformité FSMA, comparaison de polices multilingue." },
            { icon: FileText, iconBg: "#6366f1", title: "Fiduciaires (Comptabilité)", badge: "Prochainement", badgeColor: "text-orange-500 border-orange-300 bg-orange-50", desc: "Automatisation TVA, déclarations IPC, bilans, gestion fiscale belge." },
            { icon: CreditCard, iconBg: "#0ea5e9", title: "Courtage de Crédit", badge: "Prochainement", badgeColor: "text-orange-500 border-orange-300 bg-orange-50", desc: "Simulation de prêts hypothécaires, comparaison taux, conformité CKP." }].
            map((item, i) =>
            <div key={i} className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: item.iconBg }}>
                  <item.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="font-bold text-slate-900">{item.title}</span>
                    <span className={`text-xs border rounded-full px-2.5 py-0.5 font-medium ${item.badgeColor}`}>{item.badge}</span>
                  </div>
                  <p className="text-sm text-slate-600">{item.desc}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ═══ FINAL CTA ═══ */}
      <section className="py-16 px-6 text-center" style={{ background: "linear-gradient(135deg, #f97316 0%, #fb923c 100%)" }}>
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">L'infrastructure IA B2B de référence en Belgique</h2>
          <p className="text-orange-100 mb-8">La plateforme est prête, testée et verticalisée. Les algorithmes sont configurés pour les contraintes belges de 2026.</p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Button asChild className="bg-white/20 border border-white/40 text-white hover:bg-white/30 font-semibold px-6 rounded-lg">
              <Link to="/register">Démarrer maintenant →</Link>
            </Button>
            <Button asChild variant="outline" className="border-white/40 text-white bg-white/10 hover:bg-white/20 font-semibold px-6 rounded-lg">
              <Link to="/login">Se connecter</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ═══ STUDIO TOOL ═══ */}
      <section id="immoboost" className="scroll-mt-20 pt-16 pr-4 pl-4 pb-64" style={{ backgroundColor: "#fdf8f0" }}>
        <div className="max-w-7xl mx-auto">
          {isLoadingAuth ?
          <div className="flex items-center justify-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
            </div> :
          isAuthenticated ?
          <ImmoBoostStudioTool /> :

          <div className="max-w-xl mx-auto text-center bg-white rounded-2xl shadow-sm border border-slate-100 p-10">
              <div className="w-16 h-16 rounded-2xl bg-orange-100 flex items-center justify-center mx-auto mb-4">
                <Lock className="w-8 h-8 text-orange-500" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-3">Accédez au Studio IA</h3>
              <p className="text-slate-600 mb-6">
                Connectez-vous pour accéder à ImmoBoost AI Studio — estimez des biens, générez des annonces trilingues et propulsez votre marketing immobilier en un clic.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button asChild className="bg-orange-500 hover:bg-orange-600 text-white font-semibold rounded-xl">
                  <Link to="/register">Démarrer maintenant</Link>
                </Button>
                <Button asChild variant="outline" className="border-orange-300 text-orange-600 hover:bg-orange-50 font-semibold rounded-xl">
                  <Link to="/login">
                    <LogIn className="w-4 h-4 mr-2" />Se connecter
                  </Link>
                </Button>
              </div>
            </div>
          }
        </div>
      </section>
    </div>);

}