import React, { useState, useRef, useEffect } from "react";
import { db, api as base44 } from "@/components/api/wrapper";
const User = db.User;
const Question = db.Question;
// 🔒 Les appels IA passent par les fonctions backend (intégration et quotas côté serveur).
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MessageSquare, Send, Bot, User as UserIcon, Sparkles, Star } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import SimpleLogin from "../components/auth/SimpleLogin";
import { anonymizeText, deanonymizeText } from "../components/utils/anonymizer";
import LimitChecker from "../components/freemium/LimitChecker";
import { throttledAPICall } from "../components/utils/apiThrottle";
import { useTranslation } from "../components/localization/useTranslation";

export default function Assistant() {
  const { t, locale } = useTranslation();
  const [conversations, setConversations] = useState([]);

  const categories = [
    { value: "finances", label: t("category.finances") },
    { value: "securite_sociale", label: t("category.social_security") },
    { value: "emploi", label: t("category.employment") },
    { value: "sante", label: t("category.health") },
    { value: "logement", label: t("category.housing") },
    { value: "etudes", label: t("category.studies") },
    { value: "pensions", label: t("category.pensions") },
    { value: "general", label: t("category.general") }
  ];

  const suggestedQuestions = [
    t("assistant.suggested.1"),
    t("assistant.suggested.2"),
    t("assistant.suggested.3"),
    t("assistant.suggested.4"),
    t("assistant.suggested.5")
  ];
  const [currentQuestion, setCurrentQuestion] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("general");
  const [isLoading, setIsLoading] = useState(false);
  const [showRating, setShowRating] = useState(null);
  const [user, setUser] = useState(null);
  const [showLogin, setShowLogin] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    const checkUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        // Pas d'utilisateur connecté
      }
    };
    checkUser();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversations]);

  const handleSubmitQuestion = async (question, onActionStart) => {
    if (!question.trim() || isLoading) return;

    if (!user) {
      setShowLogin(true);
      return;
    }

    // IMPORTANT : Vérifier et incrémenter le compteur AVANT de traiter la question
    const canProceed = await onActionStart();
    if (!canProceed) {
      return; // Limite atteinte, le LimitChecker affichera l'écran
    }

    const userMessage = { type: "user", content: question, timestamp: new Date() };
    setConversations(prev => [...prev, userMessage]);
    setCurrentQuestion("");
    setIsLoading(true);

    try {
      const { anonymizedText: anonymizedQuestion, mapping } = anonymizeText(question);

      const languageName = locale === 'nl' ? 'Néerlandais (Dutch)' : locale === 'de' ? 'Allemand (German)' : 'Français';

      // ✅ Throttle l'appel API — l'appel IA est exécuté côté serveur, où le
      // quota freemium est vérifié et décompté.
      const aiResponse = await throttledAPICall(() =>
        base44.functions.invoke('askAdministrativeQuestion', {
          anonymizedQuestion,
          categoryLabel: categories.find(c => c.value === selectedCategory)?.label,
          languageName
        })
      );
      const anonymizedResponse = aiResponse?.data?.response || aiResponse?.response;
      
      const finalResponse = deanonymizeText(anonymizedResponse, mapping);

      const botMessage = { type: "bot", content: finalResponse, timestamp: new Date(), questionId: Date.now() };
      setConversations(prev => [...prev, botMessage]);
      setShowRating(botMessage.questionId);

      // ✅ Throttle l'appel API
      await throttledAPICall(() =>
        Question.create({ question, category: selectedCategory, response: finalResponse })
      );
    } catch (error) {
      console.error("Error invoking LLM or creating question:", error);
      
      let errorMsg = "Désolé, une erreur s'est produite. Veuillez réessayer.";
      
      if (error?.response?.status === 429) {
        errorMsg = "⏸️ Vous faites trop de requêtes. Attendez 10 secondes avant de réessayer.";
      }
      
      const errorMessage = { type: "bot", content: errorMsg, timestamp: new Date(), isError: true };
      setConversations(prev => [...prev, errorMessage]);
    }
    setIsLoading(false);
  };

  const handleRating = async (questionId, rating) => {
    setShowRating(null);
  };

  if (showLogin) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <SimpleLogin actionText="poser des questions à l'assistant IA" />
      </div>
    );
  }

  return (
    <LimitChecker feature="research_count">
      {({ onActionStart, remainingActions, currentPlan }) => (
        <div className="min-h-screen p-2 md:p-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 bg-blue-100 rounded-full px-4 py-2 mb-4">
                <Bot className="w-5 h-5 text-blue-600" />
                <span className="text-blue-800 font-medium">{t("assistant.badge")}</span>
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
                Assistant IA Administratif
              </h1>
              <div className="text-xl font-bold text-blue-600 mb-2">
                Assistant IA Administratif spécialisé SIMPLE
              </div>
              <p className="text-sm font-semibold text-purple-600 mb-4 animate-pulse">
                👇 Pour le chat IA AVANCÉ voir en bas de page 👇
              </p>
              <p className="text-gray-600">
                {t("assistant.subtitle")}
              </p>
              {user && (
                <div className="mt-2 flex items-center justify-center gap-3">
                  <Badge className="bg-green-100 text-green-800">
                    {t("assistant.logged_in_as")} {user.full_name}
                  </Badge>
                  {currentPlan === 'free' && (
                    <Badge className={remainingActions === 0 ? "bg-red-100 text-red-800" : remainingActions <= 1 ? "bg-orange-100 text-orange-800" : "bg-yellow-100 text-yellow-800"}>
                      {remainingActions === 0 ? "⚠️ Limite atteinte" : `${remainingActions} question${remainingActions > 1 ? 's' : ''} restante${remainingActions > 1 ? 's' : ''}`}
                    </Badge>
                  )}
                  {currentPlan !== 'free' && (
                    <Badge className="bg-purple-100 text-purple-800">
                      ✨ {t("assistant.unlimited")}
                    </Badge>
                  )}
                </div>
              )}
            </div>
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-6">
              <div className="h-[50vh] md:h-96 overflow-y-auto p-3 md:p-6 space-y-4">
                {conversations.length === 0 && (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <MessageSquare className="w-8 h-8 text-blue-600" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {t("assistant.start_conv")}
                    </h3>
                    <p className="text-gray-500 mb-6">
                      {t("assistant.choose_question")}
                    </p>
                    <div className="grid gap-2 max-w-md mx-auto">
                      {suggestedQuestions.slice(0, 3).map((question, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          onClick={() => {
                            setCurrentQuestion(question);
                            handleSubmitQuestion(question, onActionStart);
                          }}
                          className="text-left justify-start h-auto py-3 px-4"
                          disabled={isLoading}
                        >
                          <Sparkles className="w-4 h-4 mr-2 text-yellow-500" />
                          <span className="text-sm">{question}</span>
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
                <AnimatePresence>
                  {conversations.map((message, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className={`flex gap-3 ${message.type === "user" ? "justify-end" : "justify-start"}`}
                    >
                      {message.type === "bot" && (
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <Bot className="w-4 h-4 text-blue-600" />
                        </div>
                      )}
                      <div className={`max-w-xs md:max-w-md lg:max-w-lg p-4 rounded-2xl ${
                        message.type === "user" 
                          ? "bg-yellow-500 text-white" 
                          : message.isError
                            ? "bg-red-50 border border-red-200 text-red-800"
                            : "bg-gray-100 text-gray-900"
                      }`}>
                        <div className="whitespace-pre-wrap leading-relaxed">
                          {message.content}
                        </div>
                        <div className="text-xs opacity-70 mt-2">
                          {message.timestamp.toLocaleTimeString('fr-BE', { hour: '2-digit', minute: '2-digit' })}
                        </div>
                        {message.type === "bot" && !message.isError && showRating === message.questionId && (
                          <div className="flex items-center gap-2 mt-3 pt-3 border-t border-gray-200">
                            <span className="text-xs text-gray-600">Cette réponse vous a-t-elle aidé?</span>
                            {[1, 2, 3, 4, 5].map((star) => (
                              <button
                                key={star}
                                onClick={() => handleRating(message.questionId, star)}
                                className="text-yellow-400 hover:text-yellow-500 transition-colors"
                              >
                                <Star className="w-4 h-4" />
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                      {message.type === "user" && (
                        <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <UserIcon className="w-4 h-4 text-yellow-600" />
                        </div>
                      )}
                    </motion.div>
                  ))}
                </AnimatePresence>
                {isLoading && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex gap-3 justify-start"
                  >
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <Bot className="w-4 h-4 text-blue-600" />
                    </div>
                    <div className="bg-gray-100 p-4 rounded-2xl">
                      <div className="flex items-center gap-2">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                        </div>
                        <span className="text-sm text-gray-600">{t("assistant.searching")}</span>
                      </div>
                    </div>
                  </motion.div>
                )}
                <div ref={messagesEndRef} />
              </div>
              <div className="border-t border-gray-200 p-3 md:p-6">
                <div className="flex gap-3 mb-3">
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger className="w-full sm:w-48">
                      <SelectValue placeholder={t("assistant.category_placeholder")} />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.value} value={category.value}>
                          {category.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex gap-3">
                  <Textarea
                    value={currentQuestion}
                    onChange={(e) => setCurrentQuestion(e.target.value)}
                    placeholder={t("assistant.input_placeholder")}
                    className="flex-1 min-h-12 max-h-32"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSubmitQuestion(currentQuestion, onActionStart);
                      }
                    }}
                    disabled={isLoading}
                  />
                  <Button 
                    onClick={() => handleSubmitQuestion(currentQuestion, onActionStart)}
                    disabled={!currentQuestion.trim() || isLoading}
                    className="bg-yellow-500 hover:bg-yellow-600 text-white"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6 mt-8">
              {/* Card 1: Chat Avancé */}
              <Card className="border-2 border-blue-100 hover:border-blue-500 transition-colors cursor-pointer bg-white">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Bot className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-gray-900">Agent Administratif IA - Chat Avancé</h3>
                        <p className="text-sm text-gray-500">Assistant administratif conversationnel avec mémoire persistante</p>
                      </div>
                  </div>
                  <ul className="space-y-3 mb-6">
                      <li className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-blue-500 mt-1">•</span>
                        Se souvient de toutes vos conversations précédentes - agent administratif avec mémoire
                      </li>
                      <li className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-blue-500 mt-1">•</span>
                        Peut gérer des dossiers complexes - assistant administratif expert
                      </li>
                      <li className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-blue-500 mt-1">•</span>
                        Accès à votre historique de documents et questions
                      </li>
                      <li className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-blue-500 mt-1">•</span>
                        Capable de faire des recherches immobilières intelligentes
                      </li>
                      <li className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-blue-500 mt-1">•</span>
                        Interface de chat avancée avec outils intégrés agent administratif IA
                      </li>
                  </ul>
                  <Link to={createPageUrl("Chat")}>
                      <Button className="w-full bg-blue-600 hover:bg-blue-700">Utiliser ce service</Button>
                  </Link>
                </CardContent>
              </Card>

              {/* Card 2: Assistant Simple */}
              <Card className="border-2 border-yellow-100 hover:border-yellow-500 transition-colors cursor-pointer bg-white">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <Bot className="w-6 h-6 text-yellow-600" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg text-gray-900">Assistant Administratif IA Simple</h3>
                        <p className="text-sm text-gray-500">Agent administratif pour questions rapides et ponctuelles</p>
                      </div>
                  </div>
                  <ul className="space-y-3 mb-6">
                      <li className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-blue-500 mt-1">•</span>
                        Posez une question et obtenez une réponse immédiate de l'assistant administratif IA
                      </li>
                      <li className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-blue-500 mt-1">•</span>
                        Idéal pour des informations spécifiques avec agent administratif
                      </li>
                      <li className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-blue-500 mt-1">•</span>
                        Questions suggérées pour vous guider par assistant administratif
                      </li>
                      <li className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-blue-500 mt-1">•</span>
                        Interface simple et rapide agent administratif IA
                      </li>
                      <li className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-blue-500 mt-1">•</span>
                        Système d'évaluation des réponses de l'assistant administratif
                      </li>
                  </ul>
                  <Link to={createPageUrl("Assistant")}>
                      <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-white">Utiliser ce service</Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      )}
    </LimitChecker>
  );
}